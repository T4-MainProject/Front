import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function ProblemSolving() {
  const navigate = useNavigate();
  const location = useLocation();
  const problemData = location.state?.problemData;
  
  const [currentProblemIndex, setCurrentProblemIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState({});
  const [showResults, setShowResults] = useState({});
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [isSubmitted, setIsSubmitted] = useState(false);

  // 파라다이스 효과 상태
  const [crystalEffect, setCrystalEffect] = useState(false);
  const [waveEffect, setWaveEffect] = useState(false);
  const [sparkleEffect, setSparkleEffect] = useState(false);
  const [gentleBreeze, setGentleBreeze] = useState(false);

  // 뒤로가기
  const handleBackToNote = () => {
    navigate('/wrong-answer-note');
  };

  // 파라다이스 효과 트리거
  useEffect(() => {
    const crystalInterval = setInterval(() => {
      setCrystalEffect(true);
      setTimeout(() => setCrystalEffect(false), 500);
    }, 8000 + Math.random() * 12000);

    const waveInterval = setInterval(() => {
      setWaveEffect(true);
      setTimeout(() => setWaveEffect(false), 3000);
    }, 12000 + Math.random() * 18000);

    const sparkleInterval = setInterval(() => {
      setSparkleEffect(true);
      setTimeout(() => setSparkleEffect(false), 2000);
    }, 6000 + Math.random() * 14000);

    const breezeInterval = setInterval(() => {
      setGentleBreeze(true);
      setTimeout(() => setGentleBreeze(false), 4000);
    }, 15000 + Math.random() * 25000);

    return () => {
      clearInterval(crystalInterval);
      clearInterval(waveInterval);
      clearInterval(sparkleInterval);
      clearInterval(breezeInterval);
    };
  }, []);

  // 더미 문제 데이터 (실제로는 props로 받아올 데이터) - 파라다이스 버전
  const problems = problemData?.problems || [
    {
      id: 101,
      year: '2023',
      exam: '수능',
      subject: '국어',
      category: '독해',
      passage: `다음 글을 읽고 물음에 답하시오.

      문화는 인간이 자연환경과 상호 작용하며 형성한 아름다운 생활 양식의 총체이다. 문화는 물질적 요소와 정신적 요소로 구분할 수 있는데, 물질적 요소에는 의식주와 관련된 도구나 기술 등이 포함되며, 정신적 요소에는 언어, 종교, 예술, 철학 등의 크리스탈 지혜가 포함된다.

      문화의 가장 중요한 특징 중 하나는 다양성이다. 지구상에는 수많은 민족과 집단이 있으며, 각각은 고유한 문화를 발달시켜 왔다. 이러한 문화의 다양성은 인류 전체의 소중한 자산이다. 서로 다른 문화 간의 접촉과 교류를 통해 새로운 가치가 창조되기도 하고, 기존 문화가 더욱 풍부해지기도 한다.

      또한 문화는 학습을 통해 전승된다. 인간은 태어날 때부터 특정한 문화 속에서 성장하며, 그 문화의 가치관과 행동 양식을 학습한다. 이러한 문화의 전승 과정에서 언어는 매우 중요한 역할을 한다. 언어는 단순히 의사소통의 도구가 아니라 그 민족의 사고방식과 세계관을 담고 있는 크리스탈 그릇이기 때문이다.

      현대 사회에서는 교통과 통신의 발달로 인해 문화 간의 접촉이 빈번해지고 있다. 이로 인해 문화의 세계화 현상이 나타나고 있으며, 일부에서는 문화의 획일화를 우려하는 목소리도 높아지고 있다. 하지만 진정한 의미의 문화 교류는 서로의 다양성을 존중하고 이해하는 바탕 위에서 이루어져야 한다.`,
      question: '다음 글에서 필자가 강조하고자 하는 바는?',
      options: [
        '① 문화의 획일성이 가져오는 이점',
        '② 전통 문화의 보존과 계승',
        '③ 문화의 다양성과 그 소중한 가치',
        '④ 현대 사회의 문화적 문제점'
      ],
      answer: 3,
      explanation: '이 글에서 필자는 문화의 다양성이 인류 전체의 소중한 자산임을 강조하고 있습니다. 특히 "문화의 가장 중요한 특징 중 하나는 다양성이다"라고 명시하며, 서로 다른 문화 간의 교류를 통해 새로운 가치가 창조되고 기존 문화가 풍부해진다고 설명하고 있습니다.',
      points: 3,
      difficulty: '중'
    },
    {
      id: 102,
      year: '2022',
      exam: '6월 모의평가',
      subject: '국어',
      category: '독해',
      passage: `다음 글을 읽고 물음에 답하시오.

      우리나라의 전통 정원은 자연과의 조화를 중시하는 특징을 보인다. 서양의 기하학적이고 인위적인 정원과는 달리, 우리의 전통 정원은 자연의 아름다움을 있는 그대로 살리면서도 인간의 따뜻한 손길을 은은하게 가미한 것이 특징이다.

      창덕궁의 후원은 이러한 우리 전통 정원의 대표적인 예이다. 후원에는 인위적으로 조성된 부분과 자연 그대로의 모습이 절묘하게 어우러져 있다. 연못과 정자, 그리고 다양한 수목들이 자연스럽게 배치되어 있어 사계절 내내 서로 다른 아름다움을 선사한다.

      특히 우리 전통 정원에서는 '차경(借景)'이라는 기법을 자주 사용했다. 차경이란 정원 밖의 자연 경관을 정원의 일부로 끌어들여 활용하는 기법으로, 정원의 공간을 무한히 확장시키는 효과를 가져온다. 이는 자연을 정복의 대상이 아닌 조화의 상대로 바라보는 우리 조상들의 지혜로운 자연관을 잘 보여준다.`,
      question: '글의 화제로 가장 적절한 것은?',
      options: [
        '① 서양 정원과 동양 정원의 차이점',
        '② 창덕궁 후원의 역사적 의미',
        '③ 우리나라 전통 정원의 특징',
        '④ 차경 기법의 구체적 활용 방안'
      ],
      answer: 3,
      explanation: '이 글은 우리나라 전통 정원의 특징에 대해 설명하고 있습니다. 자연과의 조화, 창덕궁 후원의 예, 차경 기법 등을 통해 우리 전통 정원의 고유한 특성을 종합적으로 다루고 있습니다.',
      points: 2,
      difficulty: '하'
    },
    {
      id: 201,
      year: '2023',
      exam: '수능',
      subject: '영어',
      category: '독해',
      passage: `Read the following passage and answer the question.

      Sustainable development is one of the most important concepts of our time. While the Earth's resources have always been limited, the current rate of consumption is unprecedented and largely attributed to human activities. The burning of fossil fuels, deforestation, and industrial processes have significantly increased the concentration of greenhouse gases in the atmosphere.

      The consequences of climate change are already visible around the world. Rising sea levels threaten coastal communities, extreme weather events are becoming more frequent and severe, and ecosystems are being disrupted. Arctic ice is melting at an alarming rate, and many species are struggling to adapt to rapidly changing conditions.

      However, there is still hope. Governments, businesses, and individuals are taking action to reduce greenhouse gas emissions. Renewable energy sources like solar and wind power are becoming more affordable and widespread. Electric vehicles are gaining popularity, and energy-efficient technologies are being developed at an unprecedented pace.

      The transition to a sustainable future requires collective action. Every individual can contribute by making environmentally conscious choices in their daily lives. Small acts of conservation, when multiplied by millions of people, can have a significant impact on our planet's health.`,
      question: 'What is the main purpose of this passage?',
      options: [
        '① To explain the natural causes of climate change',
        '② To describe the current state of renewable energy',
        '③ To discuss climate change and potential solutions',
        '④ To compare different types of greenhouse gases'
      ],
      answer: 3,
      explanation: 'The passage provides a comprehensive overview of climate change, discussing both its causes and consequences, while also highlighting potential solutions and the need for collective action.',
      points: 3,
      difficulty: '중'
    }
  ];

  const currentProblem = problems[currentProblemIndex];

  // 타이머
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeElapsed(prev => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // 답안 선택
  const handleAnswerSelect = (optionIndex) => {
    setUserAnswers(prev => ({
      ...prev,
      [currentProblem.id]: optionIndex
    }));
  };

  // 정답 확인
  const handleSubmitAnswer = () => {
    setShowResults(prev => ({
      ...prev,
      [currentProblem.id]: true
    }));
  };

  // 다음 문제
  const handleNextProblem = () => {
    if (currentProblemIndex < problems.length - 1) {
      setCurrentProblemIndex(prev => prev + 1);
    }
  };

  // 이전 문제
  const handlePrevProblem = () => {
    if (currentProblemIndex > 0) {
      setCurrentProblemIndex(prev => prev - 1);
    }
  };

  // 전체 제출
  const handleSubmitAll = () => {
    setIsSubmitted(true);
    // 모든 문제에 대해 결과 표시
    const allResults = {};
    problems.forEach(problem => {
      allResults[problem.id] = true;
    });
    setShowResults(allResults);
  };

  // 시간 포맷팅
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 난이도 색상 - 파라다이스 버전
  const getDifficultyColor = (difficulty) => {
    switch(difficulty) {
      case '하': return 'bg-emerald-100/70 text-emerald-700 border border-emerald-300';
      case '중': return 'bg-sky-100/70 text-sky-700 border border-sky-300';
      case '상': return 'bg-cyan-100/70 text-cyan-700 border border-cyan-300';
      default: return 'bg-white/70 text-emerald-700 border border-white/40';
    }
  };

  // 점수 계산
  const calculateScore = () => {
    let correct = 0;
    let total = 0;
    
    problems.forEach(problem => {
      if (userAnswers[problem.id] !== undefined) {
        total += problem.points;
        if (userAnswers[problem.id] === problem.answer - 1) {
          correct += problem.points;
        }
      }
    });
    
    return { correct, total };
  };

  const { correct, total } = calculateScore();

  if (!problemData) {
    navigate('/wrong-answer-note');
    return null;
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br from-emerald-50 via-cyan-50 to-sky-100 relative overflow-hidden ${crystalEffect ? 'animate-pulse' : ''} ${gentleBreeze ? 'animate-bounce' : ''}`}>
      {/* 파라다이스 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 크리스탈 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-20">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,0 Q50,20 100,0 L100,15 Q50,35 0,15 Z" fill="url(#crystalGradient)" />
            <path d="M0,40 Q25,60 50,40 Q75,20 100,40" stroke="#10b981" strokeWidth="0.5" fill="none" opacity="0.6"/>
            <defs>
              <linearGradient id="crystalGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.2" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 파도 효과 */}
        {waveEffect && (
          <>
            <div className="absolute top-0 left-1/4 w-3 h-40 bg-gradient-to-b from-emerald-400 to-transparent animate-pulse opacity-60"></div>
            <div className="absolute top-0 right-1/3 w-2 h-32 bg-gradient-to-b from-cyan-400 to-transparent animate-pulse opacity-50"></div>
          </>
        )}
        
        {/* 반짝임 효과 */}
        {sparkleEffect && (
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-200/30 via-white/40 to-cyan-200/30 animate-pulse"></div>
        )}
        
        {/* 안개 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-white/40 to-transparent"></div>
        
        {/* 움직이는 크리스탈 */}
        <div className="absolute top-1/4 left-10 w-32 h-32 bg-emerald-300/30 rounded-full blur-3xl opacity-50 animate-pulse"></div>
        <div className="absolute bottom-1/3 right-20 w-40 h-40 bg-cyan-300/30 rounded-full blur-3xl opacity-40 animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* 헤더 - 파라다이스 스타일 */}
      <div className="bg-white/40 backdrop-blur-md shadow-2xl shadow-emerald-500/20 border-b border-white/30 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToNote}
                className="text-emerald-600 hover:text-emerald-700 mr-4 transition-all duration-300 transform hover:scale-110 bg-white/50 backdrop-blur-sm p-2 rounded-full border border-white/30 shadow-lg"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-black bg-gradient-to-r from-emerald-600 to-cyan-600 bg-clip-text text-transparent ${crystalEffect ? 'animate-bounce' : ''} drop-shadow-lg`}>
                📝 기출문제 풀이 - Paradise Test
              </h1>
            </div>
            
            <div className="flex items-center space-x-6">
              <div className="text-sm text-emerald-600 bg-white/30 backdrop-blur-sm px-3 py-1 rounded-full border border-white/30">
                ⏰ 소요시간: <span className="font-bold text-emerald-700">{formatTime(timeElapsed)}</span>
              </div>
              <div className="text-sm text-cyan-600 bg-white/30 backdrop-blur-sm px-3 py-1 rounded-full border border-white/30">
                🔢 문제: <span className="font-bold text-cyan-700">{currentProblemIndex + 1}/{problems.length}</span>
              </div>
              {isSubmitted && (
                <div className="text-sm text-sky-600 bg-white/30 backdrop-blur-sm px-3 py-1 rounded-full border border-white/30">
                  🌺 점수: <span className="font-bold text-sky-700">{correct}/{total}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          
          {/* 문제 정보 - 파라다이스 스타일 */}
          <div className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-emerald-500/20 p-6 mb-8 border border-white/30 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-100/30 to-cyan-100/30"></div>
            <div className="flex items-center justify-between mb-4 relative z-10">
              <div className="flex items-center space-x-4">
                <span className="bg-gradient-to-r from-emerald-500 to-cyan-500 text-white px-4 py-2 rounded-full font-black shadow-lg shadow-emerald-500/50">
                  🌺 {currentProblem.subject}
                </span>
                <span className="bg-sky-100/70 text-sky-700 px-3 py-1 rounded-full text-sm font-medium border border-sky-300 backdrop-blur-sm">
                  🕰️ {currentProblem.year}년 {currentProblem.exam}
                </span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium backdrop-blur-sm ${getDifficultyColor(currentProblem.difficulty)}`}>
                  ⚡ 난이도: {currentProblem.difficulty}
                </span>
                <span className="bg-white/50 text-emerald-700 px-3 py-1 rounded-full text-sm font-medium border border-white/40 backdrop-blur-sm">
                  📚 {currentProblem.category}
                </span>
                <span className="text-cyan-600 text-sm font-medium bg-white/30 backdrop-blur-sm px-2 py-1 rounded-full border border-white/30">
                  🎯 {currentProblem.points}점
                </span>
              </div>
            </div>
            {/* 파라다이스 장식 */}
            <div className="absolute top-2 right-2 text-emerald-400 opacity-60 animate-pulse">🌺</div>
            <div className="absolute bottom-2 left-2 text-cyan-400 opacity-50 animate-pulse">🏖️</div>
          </div>

          {/* 지문 - 파라다이스 스타일 */}
          <div className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-emerald-500/20 p-8 mb-8 border border-white/30 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-100/20 to-cyan-100/20"></div>
            <div className="prose max-w-none relative z-10">
              <div className="text-emerald-800 leading-8 whitespace-pre-line text-lg">
                {currentProblem.passage}
              </div>
            </div>
            {/* 파라다이스 장식 */}
            <div className="absolute top-4 right-4 text-emerald-400 opacity-50 animate-pulse">🌊</div>
            <div className="absolute bottom-4 right-8 text-cyan-400 opacity-40 animate-pulse">💎</div>
          </div>

          {/* 문제 - 파라다이스 스타일 */}
          <div className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-emerald-500/20 p-8 mb-8 border border-white/30 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-sky-100/20 to-teal-100/20"></div>
            <h3 className="text-xl font-black text-sky-700 mb-6 relative z-10 drop-shadow-sm">🌺 {currentProblem.question}</h3>
            
            <div className="space-y-4 relative z-10">
              {currentProblem.options.map((option, index) => (
                <label 
                  key={index} 
                  className={`flex items-center space-x-4 p-4 rounded-2xl border-2 cursor-pointer transition-all duration-300 transform hover:scale-105 backdrop-blur-sm ${
                    userAnswers[currentProblem.id] === index 
                      ? 'border-emerald-400 bg-emerald-50/60 shadow-lg shadow-emerald-500/30' 
                      : 'border-white/40 hover:border-emerald-200 bg-white/30 hover:bg-white/50'
                  } ${
                    showResults[currentProblem.id] && index === currentProblem.answer - 1
                      ? 'border-cyan-400 bg-cyan-50/60 shadow-lg shadow-cyan-500/30'
                      : showResults[currentProblem.id] && userAnswers[currentProblem.id] === index && index !== currentProblem.answer - 1
                      ? 'border-emerald-400 bg-emerald-50/60 shadow-lg shadow-emerald-500/30'
                      : ''
                  }`}
                >
                  <input
                    type="radio"
                    name={`problem-${currentProblem.id}`}
                    value={index}
                    checked={userAnswers[currentProblem.id] === index}
                    onChange={() => handleAnswerSelect(index)}
                    disabled={showResults[currentProblem.id]}
                    className="w-5 h-5 text-emerald-600 bg-white border-emerald-300 focus:ring-emerald-500"
                  />
                  <span className={`flex-1 text-lg ${
                    showResults[currentProblem.id] && index === currentProblem.answer - 1
                      ? 'text-cyan-700 font-black'
                      : showResults[currentProblem.id] && userAnswers[currentProblem.id] === index && index !== currentProblem.answer - 1
                      ? 'text-emerald-700 font-bold'
                      : 'text-emerald-800'
                  }`}>
                    {option}
                  </span>
                  {showResults[currentProblem.id] && index === currentProblem.answer - 1 && (
                    <svg className="w-6 h-6 text-cyan-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                  {showResults[currentProblem.id] && userAnswers[currentProblem.id] === index && index !== currentProblem.answer - 1 && (
                    <svg className="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  )}
                </label>
              ))}
            </div>

            {!showResults[currentProblem.id] && userAnswers[currentProblem.id] !== undefined && (
              <div className="mt-6 relative z-10">
                <button
                  onClick={handleSubmitAnswer}
                  className="bg-gradient-to-r from-emerald-500 to-cyan-500 text-white px-6 py-3 rounded-2xl font-bold hover:from-emerald-400 hover:to-cyan-400 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-emerald-500/50 border-2 border-white/30 backdrop-blur-sm"
                >
                  🌺 정답 확인
                </button>
              </div>
            )}

            {/* 해설 - 파라다이스 스타일 */}
            {showResults[currentProblem.id] && (
              <div className="mt-8 bg-emerald-50/60 backdrop-blur-sm border border-emerald-200 rounded-2xl p-6 relative z-10 shadow-inner">
                <h4 className="font-black text-emerald-700 mb-3 drop-shadow-sm">💡 해설 - The Paradise Truth</h4>
                <p className="text-emerald-800 leading-7">{currentProblem.explanation}</p>
              </div>
            )}
            
            {/* 파라다이스 장식 */}
            <div className="absolute top-4 right-4 text-sky-400 opacity-50 animate-pulse">🔥</div>
            <div className="absolute bottom-4 left-4 text-teal-400 opacity-40 animate-pulse">⚡</div>
          </div>

          {/* 네비게이션 - 파라다이스 스타일 */}
          <div className="flex items-center justify-between">
            <button
              onClick={handlePrevProblem}
              disabled={currentProblemIndex === 0}
              className="flex items-center space-x-2 px-6 py-3 bg-white/50 backdrop-blur-sm text-emerald-700 rounded-2xl font-bold hover:bg-white/70 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed border border-white/40 transform hover:scale-105 shadow-lg"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              <span>🌊 이전 문제</span>
            </button>

            <div className="flex space-x-4">
              {!isSubmitted && (
                <button
                  onClick={handleSubmitAll}
                  className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-teal-500 text-white rounded-2xl font-bold hover:from-cyan-400 hover:to-teal-400 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-cyan-500/50 border-2 border-white/30 backdrop-blur-sm"
                >
                  🌺 전체 제출
                </button>
              )}
              {isSubmitted && (
                <button
                  onClick={() => navigate('/wrong-answer-note')}
                  className="px-6 py-3 bg-gradient-to-r from-sky-500 to-emerald-500 text-white rounded-2xl font-bold hover:from-sky-400 hover:to-emerald-400 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-sky-500/50 border-2 border-white/30 backdrop-blur-sm"
                >
                  🌊 학습노트로 돌아가기
                </button>
              )}
            </div>

            <button
              onClick={handleNextProblem}
              disabled={currentProblemIndex === problems.length - 1}
              className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-cyan-500 text-white rounded-2xl font-bold hover:from-emerald-400 hover:to-cyan-400 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 shadow-lg hover:shadow-emerald-500/50 border-2 border-white/30 backdrop-blur-sm"
            >
              <span>다음 문제 🏖️</span>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>

          {/* 문제 진행 표시 - 파라다이스 스타일 */}
          <div className="mt-8 bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-emerald-500/20 p-6 border border-white/30 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-100/30 to-cyan-100/30"></div>
            <div className="flex items-center justify-between mb-4 relative z-10">
              <h4 className="font-black text-emerald-700 drop-shadow-sm">🌺 문제 진행 상황 - Progress of Paradise</h4>
              <span className="text-sm text-emerald-600 bg-white/30 backdrop-blur-sm px-3 py-1 rounded-full border border-white/30">
                🔥 완료: {Object.keys(showResults).length}/{problems.length}
              </span>
            </div>
            <div className="flex space-x-2 relative z-10">
              {problems.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentProblemIndex(index)}
                  className={`w-10 h-10 rounded-full font-bold text-sm transition-all duration-300 transform hover:scale-110 ${
                    index === currentProblemIndex
                      ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-white shadow-lg shadow-emerald-500/50'
                      : showResults[problems[index].id]
                      ? userAnswers[problems[index].id] === problems[index].answer - 1
                        ? 'bg-gradient-to-r from-cyan-500 to-teal-500 text-white shadow-lg shadow-cyan-500/50'
                        : 'bg-gradient-to-r from-emerald-400 to-emerald-600 text-white shadow-lg shadow-emerald-500/50'
                      : userAnswers[problems[index].id] !== undefined
                      ? 'bg-gradient-to-r from-sky-400 to-sky-600 text-white shadow-lg shadow-sky-500/50'
                      : 'bg-white/50 text-emerald-600 hover:bg-white/70 border border-white/40 backdrop-blur-sm'
                  }`}
                >
                  {index + 1}
                </button>
              ))}
            </div>
            
            {/* 상태 범례 */}
            <div className="mt-4 flex flex-wrap gap-4 text-xs text-emerald-700 relative z-10">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500"></div>
                <span>현재 문제</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-gradient-to-r from-cyan-500 to-teal-500"></div>
                <span>정답</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-gradient-to-r from-emerald-400 to-emerald-600"></div>
                <span>오답</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-gradient-to-r from-sky-400 to-sky-600"></div>
                <span>답안 선택됨</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-white/50 border border-white/40"></div>
                <span>미완료</span>
              </div>
            </div>
            
            {/* 파라다이스 장식 */}
            <div className="absolute top-2 right-2 text-emerald-400 opacity-60 animate-pulse">⚡</div>
            <div className="absolute bottom-2 left-2 text-cyan-400 opacity-50 animate-pulse">💎</div>
          </div>

          {/* 결과 요약 (제출 후) */}
          {isSubmitted && (
            <div className="mt-8 bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-emerald-500/20 p-8 border border-white/30 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-100/30 to-cyan-100/30"></div>
              <div className="text-center relative z-10">
                <h3 className="text-2xl font-black bg-gradient-to-r from-emerald-600 to-cyan-600 bg-clip-text text-transparent mb-6 drop-shadow-lg">🌺 최종 결과 - Final Paradise</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="bg-emerald-50/60 backdrop-blur-sm rounded-2xl p-6 border border-emerald-200 shadow-lg">
                    <div className="text-3xl mb-2">🎯</div>
                    <div className="text-2xl font-black text-emerald-700 mb-1 drop-shadow-sm">{correct}/{total}</div>
                    <div className="text-sm text-emerald-600 font-medium">획득 점수</div>
                  </div>
                  
                  <div className="bg-cyan-50/60 backdrop-blur-sm rounded-2xl p-6 border border-cyan-200 shadow-lg">
                    <div className="text-3xl mb-2">📊</div>
                    <div className="text-2xl font-black text-cyan-700 mb-1 drop-shadow-sm">{total > 0 ? Math.round((correct / total) * 100) : 0}%</div>
                    <div className="text-sm text-cyan-600 font-medium">정답률</div>
                  </div>
                  
                  <div className="bg-sky-50/60 backdrop-blur-sm rounded-2xl p-6 border border-sky-200 shadow-lg">
                    <div className="text-3xl mb-2">⏰</div>
                    <div className="text-2xl font-black text-sky-700 mb-1 drop-shadow-sm">{formatTime(timeElapsed)}</div>
                    <div className="text-sm text-sky-600 font-medium">소요 시간</div>
                  </div>
                </div>
                
                <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-6 border border-white/40 shadow-lg">
                  <h4 className="font-black text-emerald-700 mb-4 drop-shadow-sm">📈 성과 분석</h4>
                  <div className="text-emerald-600 space-y-2">
                    {total > 0 && (
                      <>
                        <div>정답: {problems.filter((_, index) => userAnswers[problems[index].id] === problems[index].answer - 1).length}문제</div>
                        <div>오답: {problems.filter((_, index) => userAnswers[problems[index].id] !== undefined && userAnswers[problems[index].id] !== problems[index].answer - 1).length}문제</div>
                        <div>미완료: {problems.filter((_, index) => userAnswers[problems[index].id] === undefined).length}문제</div>
                      </>
                    )}
                  </div>
                </div>
              </div>
              
              {/* 파라다이스 장식 */}
              <div className="absolute top-4 right-4 text-emerald-400 opacity-60 animate-pulse">👑</div>
              <div className="absolute bottom-4 left-4 text-cyan-400 opacity-50 animate-pulse">🏆</div>
            </div>
          )}
        </div>
      </div>

      {/* 파라다이스 CSS 애니메이션 */}
      <style jsx>{`
        @keyframes crystal-glow {
          0%, 100% { 
            filter: drop-shadow(0 0 8px rgba(16, 185, 129, 0.8)) brightness(1.0); 
          }
          50% { 
            filter: drop-shadow(0 0 20px rgba(16, 185, 129, 1.2)) brightness(1.3); 
          }
        }
        
        @keyframes wave-flow {
          0% { 
            transform: translateY(-50px) scaleY(0); 
            opacity: 0; 
          }
          10% { 
            transform: translateY(0px) scaleY(1); 
            opacity: 0.8; 
          }
          90% { 
            transform: translateY(200px) scaleY(1); 
            opacity: 0.6; 
          }
          100% { 
            transform: translateY(300px) scaleY(0); 
            opacity: 0; 
          }
        }
        
        @keyframes gentle-sway {
          0%, 100% { transform: translateX(0); }
          10% { transform: translateX(1px) translateY(-1px); }
          20% { transform: translateX(-1px) translateY(1px); }
          30% { transform: translateX(1px) translateY(-1px); }
          40% { transform: translateX(-1px) translateY(1px); }
          50% { transform: translateX(1px) translateY(-1px); }
          60% { transform: translateX(-1px) translateY(1px); }
          70% { transform: translateX(1px) translateY(-1px); }
          80% { transform: translateX(-1px) translateY(1px); }
          90% { transform: translateX(1px) translateY(-1px); }
        }
        
        .animate-crystal-glow {
          animation: crystal-glow 3s ease-in-out infinite;
        }
        
        .animate-wave-flow {
          animation: wave-flow 3s ease-in-out;
        }
        
        .animate-gentle-sway {
          animation: gentle-sway 4s ease-in-out infinite;
        }
        
        /* 스크롤바 스타일링 */
        ::-webkit-scrollbar {
          width: 12px;
        }
        
        ::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.3);
          border-radius: 6px;
        }
        
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #10b981, #0891b2);
          border-radius: 6px;
          border: 2px solid rgba(255, 255, 255, 0.3);
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #059669, #0e7490);
        }
      `}</style>
    </div>
  );
}