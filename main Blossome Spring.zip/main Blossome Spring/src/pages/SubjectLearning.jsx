import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function BlossomSubjectLearning() {
  const navigate = useNavigate();
  const location = useLocation();
  const { subject } = location.state || {};
  
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [completedLessons, setCompletedLessons] = useState(new Set());

  // 🌸 벚꽃 효과 상태
  const [petalFall, setPetalFall] = useState(false);
  const [blossomWave, setBlossomWave] = useState(false);
  const [sparkleEffect, setSparkleEffect] = useState(false);
  const [gentleBreeze, setGentleBreeze] = useState(false);

  // 뒤로가기
  const handleBackToAnalysis = () => {
    navigate('/learning-analysis');
  };

  // 🌸 벚꽃 효과 트리거
  useEffect(() => {
    const petalInterval = setInterval(() => {
      setPetalFall(true);
      setTimeout(() => setPetalFall(false), 800);
    }, 8000 + Math.random() * 15000);

    const blossomInterval = setInterval(() => {
      setBlossomWave(true);
      setTimeout(() => setBlossomWave(false), 3000);
    }, 12000 + Math.random() * 20000);

    const sparkleInterval = setInterval(() => {
      setSparkleEffect(true);
      setTimeout(() => setSparkleEffect(false), 2000);
    }, 6000 + Math.random() * 12000);

    const breezeInterval = setInterval(() => {
      setGentleBreeze(true);
      setTimeout(() => setGentleBreeze(false), 4000);
    }, 25000 + Math.random() * 35000);

    return () => {
      clearInterval(petalInterval);
      clearInterval(blossomInterval);
      clearInterval(sparkleInterval);
      clearInterval(breezeInterval);
    };
  }, []);

  // 과목별 학습 과정 데이터 - 🌸 벚꽃 버전
  const learningData = {
    영어: {
      title: '영어 집중 학습 - English Blossom Garden',
      subtitle: '체계적인 영어 실력 향상을 위한 맞춤형 벚꽃 커리큘럼',
      color: 'from-pink-500 to-rose-500',
      bgColor: 'from-pink-50 to-rose-100',
      icon: '🌸',
      courses: [
        {
          id: 'english-grammar',
          title: '어법/문법 벚꽃 마스터',
          description: '영어 문법의 아름다운 구조를 체계적으로 학습합니다',
          duration: '4주 벚꽃 과정',
          level: '중급',
          progress: 0,
          lessons: [
            { id: 1, title: '시제의 완벽한 이해', duration: '45분', type: '이론' },
            { id: 2, title: '조동사 활용의 아름다움', duration: '35분', type: '이론' },
            { id: 3, title: '가정법 벚꽃 정복하기', duration: '50분', type: '이론' },
            { id: 4, title: '관계대명사/관계부사의 하모니', duration: '40분', type: '이론' },
            { id: 5, title: '실전 문제 벚꽃 풀이 1', duration: '60분', type: '실습' },
            { id: 6, title: '실전 문제 벚꽃 풀이 2', duration: '60분', type: '실습' }
          ],
          expectedImprovement: '+8점'
        },
        {
          id: 'english-reading',
          title: '독해 속도 벚꽃 향상',
          description: '빠르고 정확한 영어 독해 능력을 기릅니다',
          duration: '3주 벚꽃 과정',
          level: '고급',
          progress: 25,
          lessons: [
            { id: 1, title: 'Skimming & Scanning 벚꽃 기법', duration: '40분', type: '이론' },
            { id: 2, title: '주제문 찾기 벚꽃 전략', duration: '35분', type: '이론' },
            { id: 3, title: '빈칸추론 벚꽃 해결법', duration: '45분', type: '이론' },
            { id: 4, title: '실전 독해 벚꽃 연습 1', duration: '50분', type: '실습' },
            { id: 5, title: '실전 독해 벚꽃 연습 2', duration: '50분', type: '실습' }
          ],
          expectedImprovement: '+6점'
        },
        {
          id: 'english-vocabulary',
          title: '어휘력 벚꽃 집중 강화',
          description: '수능 빈출 어휘를 체계적으로 암기합니다',
          duration: '2주 벚꽃 과정',
          level: '초급',
          progress: 60,
          lessons: [
            { id: 1, title: '접두사/접미사 벚꽃 활용', duration: '30분', type: '이론' },
            { id: 2, title: '동의어/반의어 벚꽃 정리', duration: '40분', type: '이론' },
            { id: 3, title: '주제별 어휘 벚꽃 학습', duration: '45분', type: '이론' },
            { id: 4, title: '어휘 벚꽃 암기 테스트', duration: '30분', type: '테스트' }
          ],
          expectedImprovement: '+4점'
        }
      ]
    },
    국어: {
      title: '국어 집중 학습 - Korean Blossom Garden',
      subtitle: '언어의 아름다움을 탐구하며 실력을 향상시킵니다',
      color: 'from-rose-500 to-fuchsia-500',
      bgColor: 'from-rose-50 to-fuchsia-100',
      icon: '🌺',
      courses: [
        {
          id: 'korean-literature',
          title: '문학 작품 벚꽃 심화 분석',
          description: '고전문학부터 현대문학까지 작품을 깊이 있게 분석합니다',
          duration: '5주 벚꽃 과정',
          level: '고급',
          progress: 80,
          lessons: [
            { id: 1, title: '고전 시가의 아름다운 이해', duration: '50분', type: '이론' },
            { id: 2, title: '현대 소설 벚꽃 분석 기법', duration: '45분', type: '이론' },
            { id: 3, title: '극문학의 벚꽃 특성', duration: '40분', type: '이론' },
            { id: 4, title: '수필과 기행문의 감성', duration: '35분', type: '이론' },
            { id: 5, title: '문학 작품 실전 벚꽃 분석', duration: '60분', type: '실습' },
            { id: 6, title: '문학사 벚꽃 정리', duration: '40분', type: '이론' }
          ],
          expectedImprovement: '+10점'
        },
        {
          id: 'korean-nonfiction',
          title: '비문학 독해 벚꽃 전략',
          description: '다양한 비문학 지문을 효과적으로 분석하는 방법을 배웁니다',
          duration: '3주 벚꽃 과정',
          level: '중급',
          progress: 30,
          lessons: [
            { id: 1, title: '설명문 구조 벚꽃 파악', duration: '40분', type: '이론' },
            { id: 2, title: '논증문 논리 벚꽃 분석', duration: '45분', type: '이론' },
            { id: 3, title: '과학/기술 지문 벚꽃 공략', duration: '50분', type: '이론' },
            { id: 4, title: '인문/예술 지문 벚꽃 이해', duration: '45분', type: '이론' },
            { id: 5, title: '비문학 실전 벚꽃 연습', duration: '60분', type: '실습' }
          ],
          expectedImprovement: '+6점'
        },
        {
          id: 'korean-writing',
          title: '화법과 작문의 벚꽃 정원',
          description: '효과적인 의사소통과 글쓰기 능력을 기릅니다',
          duration: '4주 벚꽃 과정',
          level: '중급',
          progress: 0,
          lessons: [
            { id: 1, title: '화법의 기본 벚꽃 원리', duration: '35분', type: '이론' },
            { id: 2, title: '토론과 토의 벚꽃 전략', duration: '40분', type: '이론' },
            { id: 3, title: '설득적 벚꽃 글쓰기', duration: '45분', type: '이론' },
            { id: 4, title: '정보 전달 벚꽃 글쓰기', duration: '40분', type: '이론' },
            { id: 5, title: '실제 작문 벚꽃 연습', duration: '60분', type: '실습' }
          ],
          expectedImprovement: '+5점'
        }
      ]
    }
  };

  const currentSubjectData = learningData[subject];

  const getLevelColor = (level) => {
    switch(level) {
      case '초급': return 'bg-pink-100/70 text-pink-700 border border-pink-300';
      case '중급': return 'bg-rose-100/70 text-rose-700 border border-rose-300';
      case '고급': return 'bg-fuchsia-100/70 text-fuchsia-700 border border-fuchsia-300';
      default: return 'bg-white/70 text-pink-700 border border-white/40';
    }
  };

  const getTypeIcon = (type) => {
    switch(type) {
      case '이론': return '🌸';
      case '실습': return '🌺';
      case '테스트': return '💮';
      default: return '🌷';
    }
  };

  const handleStartLesson = (courseId, lessonId) => {
    setCompletedLessons(prev => new Set([...prev, `${courseId}-${lessonId}`]));
    // 실제로는 학습 컨텐츠 페이지로 이동
    alert('🌺 벚꽃 학습이 시작됩니다! (실제로는 학습 컨텐츠로 이동)');
  };

  const calculateCourseProgress = (course) => {
    const completedCount = course.lessons.filter(lesson => 
      completedLessons.has(`${course.id}-${lesson.id}`)
    ).length;
    return Math.round((completedCount / course.lessons.length) * 100);
  };

  if (!subject || !currentSubjectData) {
    navigate('/learning-analysis');
    return null;
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br ${currentSubjectData.bgColor} relative overflow-hidden ${petalFall ? 'animate-pulse' : ''}`}>
      {/* 🌸 벚꽃 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 벚꽃 그라데이션과 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-15">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            {/* 벚꽃 패턴 */}
            <path d="M0,0 Q50,20 100,0 L100,15 Q50,35 0,15 Z" fill="url(#blossomGradient)" />
            <path d="M0,40 Q25,60 50,40 Q75,20 100,40" stroke="#ec4899" strokeWidth="0.5" fill="none" opacity="0.6"/>
            <path d="M15,0 L15,100 M35,0 L35,100 M55,0 L55,100 M75,0 L75,100" stroke="#be185d" strokeWidth="0.3" opacity="0.4"/>
            
            {/* 벚꽃 장식 */}
            <circle cx="20" cy="20" r="8" stroke="#ec4899" strokeWidth="0.5" fill="none" opacity="0.4"/>
            <circle cx="80" cy="80" r="6" stroke="#be185d" strokeWidth="0.5" fill="none" opacity="0.5"/>
            <polygon points="20,15 25,20 20,25 15,20" fill="#ec4899" opacity="0.3"/>
            <polygon points="80,75 85,80 80,85 75,80" fill="#be185d" opacity="0.4"/>
            
            {/* 벚꽃들 */}
            <circle cx="30" cy="30" r="2" fill="#ec4899" opacity="0.7"/>
            <circle cx="70" cy="70" r="1.5" fill="#be185d" opacity="0.6"/>
            <circle cx="15" cy="85" r="1" fill="#9d174d" opacity="0.5"/>
            
            <defs>
              <linearGradient id="blossomGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ec4899" stopOpacity="0.5" />
                <stop offset="50%" stopColor="#be185d" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#9d174d" stopOpacity="0.2" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 🌸 벚꽃 꽃잎 효과 */}
        {blossomWave && (
          <>
            <div className="absolute top-0 left-1/6 w-3 h-40 bg-gradient-to-b from-pink-400 to-transparent animate-pulse opacity-60"></div>
            <div className="absolute top-0 right-1/5 w-2 h-32 bg-gradient-to-b from-rose-400 to-transparent animate-pulse opacity-50"></div>
            <div className="absolute top-0 left-2/3 w-2.5 h-36 bg-gradient-to-b from-fuchsia-400 to-transparent animate-bounce opacity-70"></div>
          </>
        )}
        
        {/* 🌺 반짝임 효과 */}
        {sparkleEffect && (
          <div className="absolute inset-0 bg-gradient-to-r from-pink-200/20 via-white/30 to-rose-200/20 animate-pulse"></div>
        )}
        
        {/* 🌸 벚꽃 바람 효과 */}
        {gentleBreeze && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-pink-400 opacity-40 text-4xl animate-pulse">
            🌺🌸💮
          </div>
        )}
        
        {/* 벚꽃 안개 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-white/50 to-transparent"></div>
        
        {/* 움직이는 벚꽃들 */}
        <div className="absolute top-1/4 left-10 w-32 h-32 bg-pink-300/30 rounded-full blur-3xl opacity-50 animate-pulse"></div>
        <div className="absolute bottom-1/3 right-20 w-40 h-40 bg-rose-300/30 rounded-full blur-3xl opacity-40 animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-2/3 left-1/3 w-24 h-24 bg-fuchsia-300/30 rounded-full blur-3xl opacity-60 animate-pulse" style={{ animationDelay: '4s' }}></div>
        <div className="absolute top-1/6 right-1/4 w-20 h-20 bg-pink-300/30 rounded-full blur-3xl opacity-50 animate-pulse" style={{ animationDelay: '6s' }}></div>
        
        {/* 흩날리는 벚꽃 꽃잎들 */}
        <div className="absolute top-10 left-1/6 w-3 h-3 bg-pink-400/60 rounded-full animate-pulse shadow-md transform rotate-45"></div>
        <div className="absolute top-20 right-1/4 w-2 h-2 bg-rose-400/50 rounded-full animate-pulse delay-500 shadow-sm transform rotate-12"></div>
        <div className="absolute bottom-32 left-1/2 w-2 h-2 bg-pink-300/50 rounded-full animate-pulse delay-1000 shadow-sm transform -rotate-12"></div>
        <div className="absolute top-1/2 left-1/5 w-1 h-1 bg-rose-300/40 rounded-full animate-pulse delay-700 shadow-sm"></div>
        <div className="absolute bottom-40 right-1/3 w-2 h-2 bg-pink-400/40 rounded-full animate-pulse delay-300 shadow-sm transform rotate-45"></div>
      </div>

      {/* 🌸 헤더 - 벚꽃 스타일 */}
      <div className="bg-white/20 backdrop-blur-md shadow-2xl shadow-pink-500/20 border-b border-white/30">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToAnalysis}
                className="text-pink-600 hover:text-pink-700 mr-4 transition-all duration-300 transform hover:scale-110 bg-white/50 backdrop-blur-sm p-2 rounded-full border border-white/30 shadow-lg"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-black bg-gradient-to-r ${currentSubjectData.color} bg-clip-text text-transparent ${petalFall ? 'animate-bounce' : ''} drop-shadow-lg`}>
                {currentSubjectData.icon} {currentSubjectData.title}
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          
          {/* 🌸 과목 소개 - 벚꽃 스타일 */}
          <div className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-pink-500/20 p-8 mb-8 border border-white/30 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-pink-100/30 to-rose-100/30"></div>
            <div className="text-center relative z-10">
              <div className="text-6xl mb-4 animate-pulse">{currentSubjectData.icon}</div>
              <h2 className="text-3xl font-black bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent mb-2 drop-shadow-lg">{currentSubjectData.title}</h2>
              <p className="text-pink-700 text-lg">{currentSubjectData.subtitle}</p>
            </div>
            {/* 🌺 벚꽃 장식 */}
            <div className="absolute top-4 right-4 text-pink-400 opacity-60 animate-pulse">🌺</div>
            <div className="absolute bottom-4 left-4 text-rose-400 opacity-50 animate-pulse">🌸</div>
            <div className="absolute top-4 left-4 text-pink-400 opacity-70 animate-pulse">💮</div>
            <div className="absolute bottom-4 right-4 text-fuchsia-400 opacity-60 animate-pulse">🌷</div>
          </div>

          {/* 🌸 학습 과정 목록 - 벚꽃 스타일 */}
          <div className="space-y-8">
            {currentSubjectData.courses.map((course) => {
              const courseProgress = calculateCourseProgress(course);
              
              return (
                <div key={course.id} className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-pink-500/20 overflow-hidden border border-white/30 relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-pink-100/20 to-rose-100/20"></div>
                  
                  {/* 🌸 코스 헤더 - 벚꽃 스타일 */}
                  <div className={`bg-gradient-to-r ${currentSubjectData.color} p-6 text-white relative z-10`}>
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h3 className="text-2xl font-black mb-2 drop-shadow-lg">🌺 {course.title}</h3>
                        <p className="text-white/90 mb-4 drop-shadow-sm">🌸 {course.description}</p>
                        <div className="flex items-center space-x-6 text-sm">
                          <span className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full border border-white/30">🕰️ {course.duration}</span>
                          <span className={`px-3 py-1 rounded-full backdrop-blur-sm ${getLevelColor(course.level)}`}>
                            ⚡ {course.level}
                          </span>
                          <span className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full border border-white/30">📈 예상 향상: {course.expectedImprovement}</span>
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-black mb-1 drop-shadow-lg">{courseProgress}%</div>
                        <div className="text-white/90 text-sm drop-shadow-sm">완료율</div>
                      </div>
                    </div>
                    
                    {/* 🌸 진행률 바 - 벚꽃 스타일 */}
                    <div className="mt-4 w-full bg-white/20 backdrop-blur-sm rounded-full h-3 border border-white/30">
                      <div 
                        className="bg-gradient-to-r from-white/80 to-white/60 h-3 rounded-full transition-all duration-500 shadow-lg"
                        style={{ 
                          width: `${courseProgress}%`,
                          boxShadow: '0 0 15px rgba(255, 255, 255, 0.8)'
                        }}
                      />
                    </div>
                  </div>

                  {/* 🌺 강의 목록 - 벚꽃 스타일 */}
                  <div className="p-6 relative z-10">
                    <div className="grid gap-4">
                      {course.lessons.map((lesson, index) => {
                        const isCompleted = completedLessons.has(`${course.id}-${lesson.id}`);
                        const isAccessible = index === 0 || completedLessons.has(`${course.id}-${course.lessons[index - 1].id}`);
                        
                        return (
                          <div 
                            key={lesson.id}
                            className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all duration-300 transform hover:scale-105 ${
                              isCompleted 
                                ? 'border-pink-400 bg-pink-50/60 backdrop-blur-sm shadow-lg shadow-pink-500/30' 
                                : isAccessible
                                ? 'border-rose-300 bg-rose-50/40 backdrop-blur-sm hover:border-rose-400 hover:bg-rose-50/60 hover:shadow-lg hover:shadow-rose-500/30'
                                : 'border-white/40 bg-white/20 backdrop-blur-sm'
                            }`}
                          >
                            <div className="flex items-center space-x-4">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all duration-300 ${
                                isCompleted 
                                  ? 'bg-pink-500 text-white shadow-lg shadow-pink-500/50' 
                                  : isAccessible
                                  ? 'bg-rose-100/70 text-rose-700 border-2 border-rose-300 backdrop-blur-sm'
                                  : 'bg-white/30 text-gray-500 border-2 border-white/40 backdrop-blur-sm'
                              }`}>
                                {isCompleted ? '✓' : lesson.id}
                              </div>
                              
                              <div className="flex-1">
                                <div className="flex items-center space-x-3 mb-1">
                                  <h4 className={`font-bold ${
                                    isAccessible ? 'text-pink-800' : 'text-gray-500'
                                  }`}>
                                    {getTypeIcon(lesson.type)} {lesson.title}
                                  </h4>
                                  <span className={`text-sm px-2 py-1 rounded-full border backdrop-blur-sm ${
                                    lesson.type === '이론' ? 'bg-pink-100/60 text-pink-700 border-pink-300' :
                                    lesson.type === '실습' ? 'bg-rose-100/60 text-rose-700 border-rose-300' :
                                    'bg-fuchsia-100/60 text-fuchsia-700 border-fuchsia-300'
                                  }`}>
                                    {lesson.type}
                                  </span>
                                </div>
                                <p className={`text-sm ${
                                  isAccessible ? 'text-pink-600' : 'text-gray-500'
                                }`}>
                                  ⏱️ {lesson.duration}
                                </p>
                              </div>
                            </div>
                            
                            <div className="flex items-center space-x-3">
                              {isCompleted ? (
                                <span className="text-pink-600 font-bold bg-pink-100/60 backdrop-blur-sm px-3 py-1 rounded-full border border-pink-300">🌺 완료</span>
                              ) : isAccessible ? (
                                <button
                                  onClick={() => handleStartLesson(course.id, lesson.id)}
                                  className={`px-6 py-2 rounded-2xl font-bold transition-all duration-300 transform hover:scale-105 bg-gradient-to-r ${currentSubjectData.color} text-white hover:shadow-lg shadow-lg border-2 border-white/30 backdrop-blur-sm`}
                                  style={{ boxShadow: `0 0 15px ${currentSubjectData.color.includes('pink') ? '#ec4899' : '#be185d'}50` }}
                                >
                                  🌸 학습 시작
                                </button>
                              ) : (
                                <span className="text-gray-500 font-medium bg-white/30 backdrop-blur-sm px-3 py-1 rounded-full border border-white/40">🔒 잠금</span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  
                  {/* 🌺 벚꽃 장식 */}
                  <div className="absolute top-4 right-4 text-pink-400 opacity-50 animate-pulse">
                    {course.id.includes('grammar') ? '🌺' : course.id.includes('reading') ? '🌸' : '💮'}
                  </div>
                  <div className="absolute bottom-4 left-4 text-rose-400 opacity-40 animate-pulse">🌷</div>
                </div>
              );
            })}
          </div>

          {/* 🌸 학습 통계 - 벚꽃 스타일 */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-pink-500/20 p-6 text-center border border-white/30 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-pink-100/30 to-transparent"></div>
              <div className="w-12 h-12 bg-pink-100/70 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10 border border-pink-300">
                <svg className="w-6 h-6 text-pink-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C20.168 18.477 18.582 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <div className="text-3xl font-black text-pink-600 mb-1 relative z-10 drop-shadow-lg">
                {currentSubjectData.courses.length}
              </div>
              <div className="text-sm text-pink-700 relative z-10 font-medium">총 학습 과정</div>
              <div className="absolute top-2 right-2 text-pink-400 opacity-60 animate-pulse">📚</div>
            </div>

            <div className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-pink-500/20 p-6 text-center border border-white/30 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-rose-100/30 to-transparent"></div>
              <div className="w-12 h-12 bg-rose-100/70 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10 border border-rose-300">
                <svg className="w-6 h-6 text-rose-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div className="text-3xl font-black text-rose-600 mb-1 relative z-10 drop-shadow-lg">
                {completedLessons.size}
              </div>
              <div className="text-sm text-rose-700 relative z-10 font-medium">완료한 강의</div>
              <div className="absolute top-2 right-2 text-rose-400 opacity-60 animate-pulse">✅</div>
            </div>

            <div className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-pink-500/20 p-6 text-center border border-white/30 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-fuchsia-100/30 to-transparent"></div>
              <div className="w-12 h-12 bg-fuchsia-100/70 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10 border border-fuchsia-300">
                <svg className="w-6 h-6 text-fuchsia-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
              <div className="text-3xl font-black text-fuchsia-600 mb-1 relative z-10 drop-shadow-lg">
                +{currentSubjectData.courses.reduce((sum, course) => 
                  sum + parseInt(course.expectedImprovement.replace('+', '').replace('점', '')), 0
                )}점
              </div>
              <div className="text-sm text-fuchsia-700 relative z-10 font-medium">예상 총 향상</div>
              <div className="absolute top-2 right-2 text-fuchsia-400 opacity-60 animate-pulse">📈</div>
            </div>
          </div>

          {/* 🌸 학습 동기 부여 섹션 - 벚꽃 스타일 */}
          <div className="mt-12 bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-pink-500/20 p-8 border border-white/30 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-pink-100/30 to-rose-100/30"></div>
            <div className="text-center relative z-10">
              <h3 className="text-2xl font-black bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent mb-6 drop-shadow-lg">🌺 벚꽃 학습 동기 - Blossom Motivation</h3>
              
              {completedLessons.size === 0 ? (
                <div className="bg-pink-50/60 backdrop-blur-sm rounded-2xl p-6 border border-pink-200 shadow-lg">
                  <div className="text-4xl mb-4 animate-pulse">🌸</div>
                  <h4 className="text-xl font-black text-pink-700 mb-2 drop-shadow-sm">벚꽃 여정을 시작하세요!</h4>
                  <p className="text-pink-600 mb-4">
                    첫 번째 강의를 완료하면 아름다운 실력 향상의 길이 열립니다.
                  </p>
                  <div className="text-sm text-pink-500 bg-white/40 backdrop-blur-sm px-4 py-2 rounded-full border border-pink-200">
                    🌺 총 {currentSubjectData.courses.reduce((sum, course) => sum + course.lessons.length, 0)}개의 벚꽃 강의가 당신을 기다리고 있습니다.
                  </div>
                </div>
              ) : completedLessons.size < 5 ? (
                <div className="bg-rose-50/60 backdrop-blur-sm rounded-2xl p-6 border border-rose-200 shadow-lg">
                  <div className="text-4xl mb-4 animate-pulse">🌸</div>
                  <h4 className="text-xl font-black text-rose-700 mb-2 drop-shadow-sm">벚꽃이 피어나고 있습니다!</h4>
                  <p className="text-rose-600 mb-4">
                    {completedLessons.size}개의 강의를 완료했습니다. 계속해서 벚꽃 실력을 키워나가세요!
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div className="bg-pink-100/60 backdrop-blur-sm p-3 rounded-xl border border-pink-200">
                      <div className="text-pink-700 font-bold">🎯 다음 목표</div>
                      <div className="text-pink-600">10개 강의 완료</div>
                    </div>
                    <div className="bg-rose-100/60 backdrop-blur-sm p-3 rounded-xl border border-rose-200">
                      <div className="text-rose-700 font-bold">⚡ 진행률</div>
                      <div className="text-rose-600">
                        {Math.round((completedLessons.size / currentSubjectData.courses.reduce((sum, course) => sum + course.lessons.length, 0)) * 100)}% 완료
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-fuchsia-50/60 backdrop-blur-sm rounded-2xl p-6 border border-fuchsia-200 shadow-lg">
                  <div className="text-4xl mb-4 animate-pulse">👑</div>
                  <h4 className="text-xl font-black text-fuchsia-700 mb-2 drop-shadow-sm">벚꽃 마스터에 근접했습니다!</h4>
                  <p className="text-fuchsia-600 mb-4">
                    훌륭합니다! {completedLessons.size}개의 강의를 완료하여 상당한 진전을 이루었습니다.
                  </p>
                  <div className="bg-rose-100/60 backdrop-blur-sm p-4 rounded-xl border border-rose-200">
                    <div className="text-rose-700 font-bold mb-2">🏆 달성 현황</div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <div className="text-rose-600">완료 강의</div>
                        <div className="text-rose-800 font-bold">{completedLessons.size}개</div>
                      </div>
                      <div>
                        <div className="text-rose-600">전체 진행률</div>
                        <div className="text-rose-800 font-bold">
                          {Math.round((completedLessons.size / currentSubjectData.courses.reduce((sum, course) => sum + course.lessons.length, 0)) * 100)}%
                        </div>
                      </div>
                      <div>
                        <div className="text-rose-600">예상 향상</div>
                        <div className="text-rose-800 font-bold">
                          +{Math.round((completedLessons.size / currentSubjectData.courses.reduce((sum, course) => sum + course.lessons.length, 0)) * 
                            currentSubjectData.courses.reduce((sum, course) => sum + parseInt(course.expectedImprovement.replace('+', '').replace('점', '')), 0))}점
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            {/* 🌺 벚꽃 장식 */}
            <div className="absolute top-4 right-4 text-pink-400 opacity-60 animate-pulse">🌸</div>
            <div className="absolute bottom-4 left-4 text-rose-400 opacity-50 animate-pulse">⚡</div>
          </div>

          {/* 🌸 추천 학습 경로 - 벚꽃 스타일 */}
          <div className="mt-8 bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-pink-500/20 p-8 border border-white/30 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-rose-100/30 to-fuchsia-100/30"></div>
            <div className="relative z-10">
              <h3 className="text-xl font-black bg-gradient-to-r from-rose-600 to-fuchsia-600 bg-clip-text text-transparent mb-6 drop-shadow-lg">🗺️ 추천 벚꽃 학습 경로 - Recommended Blossom Path</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {currentSubjectData.courses.map((course, index) => {
                  const courseProgress = calculateCourseProgress(course);
                  const isRecommended = index === 0 || calculateCourseProgress(currentSubjectData.courses[index - 1]) >= 50;
                  
                  return (
                    <div key={course.id} className={`p-4 rounded-2xl border-2 transition-all duration-300 transform hover:scale-105 backdrop-blur-sm ${
                      isRecommended && courseProgress < 100
                        ? 'border-pink-400 bg-pink-50/60 shadow-lg shadow-pink-500/30'
                        : courseProgress === 100
                        ? 'border-rose-400 bg-rose-50/60 shadow-lg shadow-rose-500/30'
                        : 'border-white/40 bg-white/30'
                    }`}>
                      <div className="flex items-center justify-between mb-3">
                        <h4 className={`font-bold ${
                          courseProgress === 100 ? 'text-rose-700' :
                          isRecommended ? 'text-pink-700' : 'text-gray-500'
                        }`}>
                          {course.title}
                        </h4>
                        <span className={`text-xs px-2 py-1 rounded-full backdrop-blur-sm ${
                          courseProgress === 100 ? 'bg-rose-100/70 text-rose-700 border border-rose-300' :
                          isRecommended ? 'bg-pink-100/70 text-pink-700 border border-pink-300' : 'bg-white/50 text-gray-500 border border-white/40'
                        }`}>
                          {courseProgress === 100 ? '✅ 완료' :
                           isRecommended ? '🎯 추천' : '🔒 잠금'}
                        </span>
                      </div>
                      
                      <div className="text-sm text-gray-600 mb-3">
                        📊 진행률: {courseProgress}%
                      </div>
                      
                      <div className="w-full bg-white/40 backdrop-blur-sm rounded-full h-2 mb-3 border border-white/30">
                        <div 
                          className={`h-2 rounded-full transition-all duration-500 ${
                            courseProgress === 100 ? 'bg-gradient-to-r from-rose-500 to-fuchsia-500' :
                            isRecommended ? 'bg-gradient-to-r from-pink-500 to-rose-500' : 'bg-white/50'
                          }`}
                          style={{ width: `${courseProgress}%` }}
                        />
                      </div>
                      
                      <div className="text-xs text-gray-500">
                        {course.lessons.length}개 강의 • {course.expectedImprovement} 향상 예상
                      </div>
                    </div>
                  );
                })}
              </div>
              
              <div className="mt-6 bg-white/50 backdrop-blur-sm rounded-2xl p-4 border border-white/40 shadow-lg">
                <h4 className="font-bold text-pink-700 mb-2">💡 벚꽃 학습 팁</h4>
                <div className="text-sm text-pink-600 space-y-1">
                  <div>🌸 하루에 1-2개 강의씩 꾸준히 학습하세요</div>
                  <div>🌺 이전 강의를 완료해야 다음 강의가 잠금 해제됩니다</div>
                  <div>💮 실습 강의에서는 직접 문제를 풀어보며 실력을 확인하세요</div>
                </div>
              </div>
            </div>
            
            {/* 🌺 벚꽃 장식 */}
            <div className="absolute top-4 right-4 text-rose-400 opacity-60 animate-pulse">🗺️</div>
            <div className="absolute bottom-4 left-4 text-fuchsia-400 opacity-50 animate-pulse">🧭</div>
          </div>
        </div>
      </div>

      {/* 🌸 벚꽃 CSS 애니메이션 */}
      <style jsx>{`
        @keyframes petal-pulse {
          0%, 100% { 
            opacity: 0.6;
            transform: scale(1) rotate(0deg);
          }
          50% { 
            opacity: 1;
            transform: scale(1.05) rotate(180deg);
          }
        }
        
        @keyframes blossom-whisper {
          0% { 
            opacity: 0;
            transform: scale(0.8) rotate(-5deg);
          }
          50% { 
            opacity: 0.8;
            transform: scale(1.1) rotate(3deg);
          }
          100% { 
            opacity: 0;
            transform: scale(0.9) rotate(-2deg);
          }
        }
        
        @keyframes petal-flow {
          0% { 
            transform: translateY(-50%) scaleY(0) rotate(0deg);
            opacity: 0;
          }
          30% { 
            transform: translateY(0%) scaleY(1) rotate(180deg);
            opacity: 0.8;
          }
          70% { 
            transform: translateY(200%) scaleY(1) rotate(360deg);
            opacity: 0.6;
          }
          100% { 
            transform: translateY(300%) scaleY(0) rotate(720deg);
            opacity: 0;
          }
        }
        
        @keyframes blossom-circle {
          0% { 
            transform: rotate(0deg) scale(1);
            opacity: 0.4;
          }
          50% { 
            transform: rotate(180deg) scale(1.05);
            opacity: 0.7;
          }
          100% { 
            transform: rotate(360deg) scale(1);
            opacity: 0.4;
          }
        }
        
        @keyframes floating-petals {
          0%, 100% { 
            transform: translateY(0px) rotate(0deg);
          }
          33% { 
            transform: translateY(-8px) rotate(120deg);
          }
          66% { 
            transform: translateY(4px) rotate(240deg);
          }
        }
        
        @keyframes gentle-sway {
          0%, 100% { 
            transform: translateX(0) rotate(0deg); 
          }
          25% { 
            transform: translateX(2px) translateY(-1px) rotate(1deg); 
          }
          50% { 
            transform: translateX(0) translateY(-2px) rotate(0deg); 
          }
          75% { 
            transform: translateX(-2px) translateY(-1px) rotate(-1deg); 
          }
        }
        
        .animate-petal-pulse {
          animation: petal-pulse 2s ease-in-out infinite;
        }
        
        .animate-blossom-whisper {
          animation: blossom-whisper 4s ease-in-out;
        }
        
        .animate-petal-flow {
          animation: petal-flow 3s ease-in-out;
        }
        
        .animate-blossom-circle {
          animation: blossom-circle 8s linear infinite;
        }
        
        .animate-floating-petals {
          animation: floating-petals 4s ease-in-out infinite;
        }
        
        .animate-gentle-sway {
          animation: gentle-sway 6s ease-in-out infinite;
        }
        
        /* 🌸 스크롤바 스타일링 - 벚꽃 버전 */
        ::-webkit-scrollbar {
          width: 12px;
        }
        
        ::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.3);
          border-radius: 6px;
        }
        
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #ec4899, #be185d);
          border-radius: 6px;
          border: 2px solid rgba(255, 255, 255, 0.3);
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #db2777, #9d174d);
        }
        
        /* 🌺 반짝임 효과 - 벚꽃 버전 */
        .sparkle-text {
          position: relative;
        }
        
        .sparkle-text::before,
        .sparkle-text::after {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: linear-gradient(45deg, transparent, rgba(236, 72, 153, 0.3), transparent);
          animation: sparkle 2s ease-in-out infinite;
        }
        
        .sparkle-text::after {
          animation-delay: 1s;
        }
        
        @keyframes sparkle {
          0%, 100% {
            transform: translateX(-100%);
          }
          50% {
            transform: translateX(100%);
          }
        }
        
        /* 🌸 호버 글로우 효과 - 벚꽃 버전 */
        .blossom-hover {
          transition: all 0.3s ease;
        }
        
        .blossom-hover:hover {
          filter: drop-shadow(0 0 20px rgba(236, 72, 153, 0.6));
          transform: scale(1.02) rotate(1deg);
        }
        
        /* 🌺 벚꽃 글로우 효과 */
        .blossom-glow {
          box-shadow: 0 0 20px rgba(236, 72, 153, 0.3);
        }
        
        .blossom-glow:hover {
          box-shadow: 0 0 30px rgba(236, 72, 153, 0.5);
        }
        
        /* 🌸 벚꽃 텍스트 효과 */
        .blossom-text {
          background: linear-gradient(45deg, #ec4899, #be185d, #ec4899);
          background-size: 200% 200%;
          animation: blossom-gradient 3s ease infinite;
        }
        
        @keyframes blossom-gradient {
          0%, 100% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
        }
      `}</style>
    </div>
  );
}