// ============================================
// 🏝️ Tropical Paradise Hero.jsx - 파라다이스 히어로 섹션
// ============================================
import React, { useLayoutEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function Hero({ onNext }) {
  const heroRef = useRef(null);
  const titleRef = useRef(null);
  const subtitleRef = useRef(null);
  const buttonsRef = useRef(null);
  const bgRef = useRef(null);
  const particlesRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 파라다이스 패럴랙스 효과
      gsap.to(bgRef.current, {
        yPercent: 50,
        ease: "none",
        scrollTrigger: {
          trigger: heroRef.current,
          start: "top bottom",
          end: "bottom top",
          scrub: true
        }
      });

      // 파라다이스 텍스트 애니메이션
      const tl = gsap.timeline();
      
      tl.fromTo(titleRef.current, 
        { 
          y: 150, 
          opacity: 0, 
          scale: 0.6,
          rotationX: -120,
          filter: "blur(20px)"
        },
        { 
          y: 0, 
          opacity: 1, 
          scale: 1,
          rotationX: 0,
          filter: "blur(0px)",
          duration: 1.8, 
          ease: "power4.out" 
        }
      )
      .fromTo(subtitleRef.current,
        { y: 80, opacity: 0, filter: "blur(10px)" },
        { y: 0, opacity: 1, filter: "blur(0px)", duration: 1.2, ease: "power3.out" },
        "-=0.8"
      )
      .fromTo(buttonsRef.current,
        { y: 60, opacity: 0, scale: 0.8, rotationY: 90 },
        { y: 0, opacity: 1, scale: 1, rotationY: 0, duration: 1.0, ease: "back.out(2)" },
        "-=0.6"
      );

      // 크리스탈 파티클 애니메이션
      particlesRef.current.forEach((particle, index) => {
        if (particle) {
          gsap.to(particle, {
            y: "random(-40, 40)",
            x: "random(-40, 40)",
            rotation: "random(-360, 360)",
            scale: "random(0.5, 1.5)",
            duration: "random(3, 6)",
            repeat: -1,
            yoyo: true,
            ease: "sine.inOut",
            delay: index * 0.2
          });
        }
      });

    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={heroRef}
      className="relative min-h-screen bg-gradient-to-br from-emerald-50 via-cyan-50 to-sky-100 overflow-hidden flex items-center"
    >
      {/* 파라다이스 배경 요소들 */}
      <div ref={bgRef} className="absolute inset-0 overflow-hidden">
        {/* 파라다이스 그라데이션 블러 */}
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-br from-emerald-400/30 to-cyan-300/50 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-br from-sky-400/30 to-emerald-300/40 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-br from-cyan-300/20 to-white/40 rounded-full blur-3xl animate-pulse delay-500"></div>
        
        {/* 파라다이스 추가 레이어 */}
        <div className="absolute inset-0 bg-white/30"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.1)_0%,rgba(6,182,212,0.05)_50%,rgba(14,165,233,0.1)_100%)]"></div>
        
        {/* 떠다니는 크리스탈 파티클들 */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            ref={el => particlesRef.current[i] = el}
            className={`absolute w-6 h-6 bg-gradient-to-br from-emerald-400 to-cyan-500 rounded-full opacity-30 blur-sm shadow-lg shadow-emerald-500/50`}
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
          ></div>
        ))}

        {/* 추가 파라다이스 효과들 */}
        {[...Array(6)].map((_, i) => (
          <div
            key={`sparkle-${i}`}
            className={`absolute w-8 h-8 bg-white/40 rounded-full blur-lg animate-pulse`}
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.5}s`
            }}
          ></div>
        ))}
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center min-h-screen py-20">
          {/* 파라다이스 텍스트 콘텐츠 */}
          <div className="flex-1 lg:pr-12 text-center lg:text-left">
            {/* 파라다이스 배지 */}
            <div 
              data-aos="fade-down" 
              data-aos-delay="100"
              className="inline-flex items-center space-x-3 bg-white/40 backdrop-blur-md border border-white/50 text-emerald-700 px-6 py-3 rounded-full text-sm font-semibold mb-8 shadow-lg shadow-emerald-500/30 hover:shadow-xl hover:shadow-emerald-500/50 transition-all duration-300 hover:scale-105"
            >
              <div className="relative">
                <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                <div className="absolute inset-0 w-2 h-2 bg-emerald-500 rounded-full animate-ping opacity-75"></div>
              </div>
              <span>🏝️ AI 파라다이스 채점 시스템</span>
              <span className="bg-gradient-to-r from-emerald-500 to-cyan-500 text-white px-2 py-1 rounded-full text-xs font-bold animate-pulse border border-emerald-400">
                PARADISE
              </span>
            </div>
            
            {/* 파라다이스 메인 타이틀 */}
            <h1 
              ref={titleRef}
              className="text-5xl md:text-6xl lg:text-7xl font-black leading-tight mb-6 drop-shadow-2xl"
            >
              <span className="bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-700 bg-clip-text text-transparent drop-shadow-2xl">
                AI 크리스탈의
              </span>
              <br />
              <span className="text-emerald-700 drop-shadow-lg">
                정확한 채점,
              </span>
              <br />
              <span className="bg-gradient-to-r from-cyan-600 to-emerald-600 bg-clip-text text-transparent">
                파라다이스 같은 편리함
              </span>
            </h1>
            
            {/* 파라다이스 서브타이틀 */}
            <p 
              ref={subtitleRef}
              className="text-xl md:text-2xl text-emerald-600 mb-10 leading-relaxed max-w-3xl mx-auto lg:mx-0 drop-shadow-lg"
            >
              <span className="font-semibold text-emerald-600">YOLO8 크리스탈 비전</span>, 
              <span className="font-semibold text-cyan-600"> OCR 텍스트 인식</span>, 
              <span className="font-semibold text-sky-600"> GPT 상세 해설</span>이 
              결합된 차세대 파라다이스 채점 솔루션
            </p>

            {/* 파라다이스 버튼들 */}
            <div 
              ref={buttonsRef}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12"
            >
              <button 
                onClick={onNext}
                className="group bg-gradient-to-r from-emerald-500 to-cyan-500 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-xl shadow-emerald-500/50 hover:shadow-2xl hover:shadow-emerald-500/70 transition-all duration-300 hover:scale-105 hover:from-emerald-400 hover:to-cyan-400 relative overflow-hidden border-2 border-white/30 backdrop-blur-sm"
              >
                <span className="relative z-10 flex items-center justify-center">
                  🏝️ 파라다이스 시작하기
                  <svg className="ml-2 w-6 h-6 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
              </button>
            </div>

            {/* 파라다이스 통계 */}
            <div 
              data-aos="fade-up" 
              data-aos-delay="400"
              className="grid grid-cols-3 gap-8 pt-8 border-t border-emerald-300/50"
            >
              <div className="text-center group bg-white/40 backdrop-blur-sm p-4 rounded-lg border border-white/50">
                <div className="text-3xl font-black bg-gradient-to-r from-emerald-600 to-cyan-600 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                  99.5%
                </div>
                <div className="text-sm text-emerald-600 font-medium">크리스탈 정확도</div>
              </div>
              <div className="text-center group bg-white/40 backdrop-blur-sm p-4 rounded-lg border border-white/50">
                <div className="text-3xl font-black bg-gradient-to-r from-cyan-600 to-sky-600 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                  3.5초
                </div>
                <div className="text-sm text-emerald-600 font-medium">파라다이스 처리시간</div>
              </div>
              <div className="text-center group bg-white/40 backdrop-blur-sm p-4 rounded-lg border border-white/50">
                <div className="text-3xl font-black bg-gradient-to-r from-sky-600 to-emerald-600 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                  1000+
                </div>
                <div className="text-sm text-emerald-600 font-medium">완료된 시험지</div>
              </div>
            </div>
          </div>

          {/* 파라다이스 오른쪽 일러스트레이션 */}
          <div className="flex-1 lg:pl-12 mt-12 lg:mt-0">
            <div 
              data-aos="fade-left" 
              data-aos-delay="200"
              className="relative"
            >
              {/* 파라다이스 메인 카드 */}
              <div className="bg-white/30 backdrop-blur-md p-8 rounded-3xl shadow-2xl shadow-emerald-500/30 transform rotate-3 hover:rotate-0 transition-all duration-700 hover:scale-105 border border-white/50 relative overflow-hidden">
                {/* 카드 내부 파라다이스 글로우 */}
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-100/40 via-white/60 to-cyan-100/40 rounded-3xl"></div>
                
                <div className="relative z-10">
                  {/* 파라다이스 브라우저 헤더 */}
                  <div className="flex items-center space-x-2 mb-6">
                    <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse"></div>
                    <div className="w-3 h-3 bg-cyan-400 rounded-full animate-pulse delay-100"></div>
                    <div className="w-3 h-3 bg-sky-500 rounded-full animate-pulse delay-200"></div>
                    <div className="flex-1 bg-white/50 h-6 rounded-full ml-4 border border-emerald-300/50"></div>
                  </div>
                  
                  {/* 파라다이스 콘텐츠 */}
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="h-4 bg-gradient-to-r from-emerald-400 to-emerald-500 rounded-lg w-3/4 animate-pulse shadow-lg"></div>
                      <div className="h-4 bg-gradient-to-r from-cyan-400 to-cyan-500 rounded-lg w-1/2 animate-pulse shadow-lg delay-100"></div>
                      <div className="h-4 bg-gradient-to-r from-sky-400 to-emerald-400 rounded-lg w-2/3 animate-pulse shadow-lg delay-200"></div>
                    </div>
                    
                    {/* 파라다이스 결과 카드 */}
                    <div className="bg-emerald-100/60 backdrop-blur-sm p-6 rounded-2xl shadow-lg shadow-emerald-500/30 border border-emerald-300/50">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-sm font-bold text-emerald-700 flex items-center">
                          <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          채점 완료
                        </span>
                        <span className="text-xs text-emerald-600">3.5초</span>
                      </div>
                      <div className="text-4xl font-black bg-gradient-to-r from-emerald-600 to-cyan-600 bg-clip-text text-transparent drop-shadow-lg">
                        87점
                      </div>
                      <div className="text-sm text-emerald-700 mt-2">
                        20문제 중 17문제 정답 🌟
                      </div>
                      <div className="text-xs text-emerald-600 mt-1">
                        "훌륭한 성과입니다!"
                      </div>
                    </div>
                  </div>
                </div>

                {/* 파라다이스 추가 효과 */}
                <div className="absolute inset-0 bg-gradient-to-t from-emerald-100/20 to-transparent rounded-3xl"></div>
              </div>

              {/* 떠다니는 파라다이스 요소들 */}
              <div className="absolute -top-6 -right-6 w-16 h-16 bg-gradient-to-br from-emerald-500 to-cyan-500 rounded-2xl flex items-center justify-center shadow-xl shadow-emerald-500/50 animate-bounce border-2 border-white/50">
                <span className="text-white text-2xl">🌺</span>
              </div>
              
              <div className="absolute -bottom-6 -left-6 w-16 h-16 bg-gradient-to-br from-cyan-400 to-sky-500 rounded-2xl flex items-center justify-center shadow-xl shadow-cyan-500/50 animate-pulse border-2 border-white/50">
                <span className="text-white text-2xl">🏖️</span>
              </div>

              {/* 추가 파라다이스 장식 */}
              <div className="absolute top-1/2 -left-8 w-12 h-12 bg-gradient-to-br from-emerald-400 to-emerald-500 rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/40 animate-pulse delay-300">
                <span className="text-white text-lg">✨</span>
              </div>

              <div className="absolute top-1/4 -right-8 w-12 h-12 bg-gradient-to-br from-cyan-400 to-sky-500 rounded-full flex items-center justify-center shadow-lg shadow-cyan-500/40 animate-pulse delay-700">
                <span className="text-white text-lg">💎</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 파라다이스 그라데이션 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white/20 to-transparent"></div>
    </section>
  );
}