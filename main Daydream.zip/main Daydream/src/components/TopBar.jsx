// ============================================
// ✨ Angelic Light TopBar.jsx - 희망의 상단 공지
// ============================================
// src/components/TopBar.jsx

import React from 'react';

export default function TopBar() {
  return (
    <div className="bg-gradient-to-r from-blue-500/80 via-white to-blue-500/80 border-b border-blue-200/50 relative overflow-hidden">
      {/* 빛의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-r from-white/60 via-blue-100/40 to-white/60"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_70%,rgba(59,130,246,0.1)_100%)]"></div>
      
      {/* 움직이는 빛 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1 left-1/4 w-1 h-1 bg-blue-400/40 rounded-full animate-pulse"></div>
        <div className="absolute top-2 right-1/3 w-1 h-1 bg-sky-400/30 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-1 left-1/2 w-1 h-1 bg-blue-300/30 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-blue-500/40 rounded-full animate-pulse delay-500"></div>
      </div>

      <div className="container mx-auto px-4 py-2 text-center relative z-10">
        <div className="flex items-center justify-center space-x-2 text-sm">
          <span className="animate-pulse text-blue-500 drop-shadow-lg">✨</span>
          <span className="font-medium text-blue-600 drop-shadow-sm">
            천국 서비스 개방! AI 자동 축복을 무료로 체험해보세요
          </span>
          <span className="animate-pulse text-blue-500 drop-shadow-lg">👼</span>
        </div>
      </div>

      {/* 하단 빛 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-blue-400/50 to-transparent"></div>
    </div>
  );
}