// ============================================
// 🏝️ Tropical Paradise AppHeader.jsx - 파라다이스 헤더
// ============================================
import React, { useState, useEffect } from 'react';

export default function AppHeader({ currentUser, onOpenLogin, onOpenSignup, onLogout, onOpenMyPage }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // 🌊 활성 버튼 상태 관리 (어떤 파라다이스 문이 열려있는지)
  const [activeButton, setActiveButton] = useState(null); // 'login' | 'signup' | null
  
  // 🏖️ 버튼 클릭 상태 관리 (파라다이스 클릭 애니메이션용)
  const [clickedButtons, setClickedButtons] = useState({
    login: false,
    signup: false,
    mypage: false
  });

  const handleLogin = () => {
    // 파라다이스 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, login: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, login: false }));
    }, 200);
    
    // 파라다이스 활성 버튼 설정
    setActiveButton('login');
    
    // 파라다이스 로그인 문 열기
    if (onOpenLogin) {
      onOpenLogin();
    }
  };

  const handleSignup = () => {
    // 파라다이스 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, signup: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, signup: false }));
    }, 200);
    
    // 파라다이스 활성 버튼 설정
    setActiveButton('signup');
    
    // 크리스탈 멤버십 가입 문서 열기
    if (onOpenSignup) {
      onOpenSignup();
    }
  };

  const handleLogout = () => {
    // 파라다이스 로그아웃 확인
    if (window.confirm('🏝️ 정말 파라다이스에서 로그아웃하시겠습니까?')) {
      setActiveButton(null); // 파라다이스 활성 상태 초기화
      if (onLogout) {
        onLogout();
      }
    }
  };

  const handleMyPage = () => {
    // 파라다이스 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, mypage: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, mypage: false }));
    }, 200);
    
    // 크리스탈 룸 열기
    if (onOpenMyPage) {
      onOpenMyPage();
    }
  };

  // 파라다이스 문이 닫힐 때 활성 상태 해제
  useEffect(() => {
    // 사용자 상태가 변경되면 파라다이스 활성 버튼 초기화
    if (currentUser) {
      setActiveButton(null);
    }
  }, [currentUser]);

  // 크리스탈 아바타 이미지 처리
  const getAvatarSrc = (avatar) => {
    if (!avatar) {
      return "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiMxMEI5ODEiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iI0ZGRkZGRiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iI0ZGRkZGRiIvPgo8L3N2Zz4K";
    }
    return avatar;
  };

  // 파라다이스 역할 텍스트 변환
  const getRoleText = (role) => {
    switch(role) {
      case 'admin': return '🏝️ 파라다이스 마스터';
      case 'teacher': return '🌺 교육 전문가';
      case 'student': return '🏖️ 크리스탈 학습자';
      case 'parent': return '💎 보호자';
      default: return '🌊 파라다이스 멤버';
    }
  };

  return (
    <header className="bg-white/25 backdrop-blur-md shadow-2xl shadow-emerald-500/20 border-b border-white/30 sticky top-0 z-50 relative overflow-hidden">
      {/* 파라다이스 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-r from-emerald-100/40 via-white/60 to-cyan-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.1)_0%,rgba(6,182,212,0.05)_50%,rgba(14,165,233,0.1)_100%)]"></div>
      
      {/* 움직이는 크리스탈 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-2 h-2 bg-emerald-400/40 rounded-full animate-pulse shadow-sm"></div>
        <div className="absolute top-2 right-1/3 w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse delay-500 shadow-sm"></div>
        <div className="absolute bottom-1 left-1/2 w-1 h-1 bg-sky-400/30 rounded-full animate-pulse delay-1000 shadow-sm"></div>
      </div>

      <div className="container mx-auto flex items-center justify-between py-4 px-4 lg:px-6 relative z-10">
        {/* 파라다이스 로고 영역 */}
        <div className="flex items-center space-x-4">
          <div className="relative group">
            <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 via-cyan-400 to-sky-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/50 group-hover:shadow-xl group-hover:shadow-emerald-500/70 transition-all duration-300 group-hover:scale-105 border-2 border-white/30">
              <span className="text-white font-bold text-xl drop-shadow-lg">🏝️</span>
            </div>
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/40 via-cyan-300/20 to-sky-400/40 rounded-xl blur opacity-60 group-hover:opacity-80 transition-opacity duration-300"></div>
          </div>
          
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 via-emerald-500 to-cyan-600 bg-clip-text text-transparent drop-shadow-lg">
              ParadiseCheck
            </h1>
            <p className="text-xs text-emerald-600/80 font-medium tracking-wide drop-shadow-sm">
              🏖️ AI 파라다이스 채점 시스템
            </p>
          </div>
        </div>

        {/* 파라다이스 우측 상태 표시기 - 데스크탑 */}
        <div className="hidden lg:flex items-center space-x-6 flex-1 justify-end mr-8">
          <div className="flex items-center space-x-2 bg-white/40 backdrop-blur-sm border border-white/50 px-4 py-2 rounded-full">
            <div className="relative">
              <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse"></div>
              <div className="absolute inset-0 w-3 h-3 bg-emerald-500 rounded-full animate-ping opacity-40"></div>
            </div>
            <span className="text-sm font-medium text-emerald-700">🌟 파라다이스 운영중</span>
          </div>
          
          <div className="text-sm text-emerald-700 bg-white/40 backdrop-blur-sm px-3 py-1 rounded-full border border-white/50">
            <span className="font-medium">크리스탈 정확도</span>
            <span className="ml-2 text-emerald-600 font-bold">99.5%</span>
          </div>
        </div>

        {/* 파라다이스 우측 버튼들 */}
        <div className="flex items-center space-x-4">
          {/* 파라다이스 데스크탑 버튼들 */}
          <div className="hidden md:flex items-center space-x-3">
            {currentUser ? (
              // 사용자가 로그인된 상태
              <>
                {/* 사용자 정보 */}
                <div className="flex items-center space-x-3 text-sm">
                  <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-emerald-400/70 shadow-lg shadow-emerald-500/50">
                    <img 
                      src={getAvatarSrc(currentUser.avatar)} 
                      alt={currentUser.name || '파라다이스 멤버'}
                      className="w-full h-full object-cover brightness-110 saturate-150"
                      onError={(e) => {
                        e.target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiMxMEI5ODEiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iI0ZGRkZGRiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iI0ZGRkZGRiIvPgo8L3N2Zz4K";
                      }}
                    />
                  </div>
                  <div className="text-emerald-700">
                    <span className="font-medium drop-shadow-sm">{currentUser.name || '파라다이스 멤버'}</span>
                    <span className="ml-2 text-xs bg-emerald-100/70 text-emerald-700 px-2 py-1 rounded-full border border-emerald-300/50">
                      {getRoleText(currentUser.role)}
                    </span>
                  </div>
                </div>

                {/* 크리스탈 룸 버튼 */}
                <button
                  onClick={handleMyPage}
                  className={`font-medium px-4 py-2 rounded-lg transition-all duration-200 relative group border border-white/50 ${
                    clickedButtons.mypage 
                      ? 'text-emerald-700 bg-white/60 transform scale-95 shadow-lg shadow-emerald-500/50' 
                      : 'text-emerald-600 hover:text-emerald-700 hover:bg-white/50 hover:shadow-lg hover:shadow-emerald-500/40'
                  }`}
                >
                  💎 마이 파라다이스
                  <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-emerald-500 group-hover:w-full transition-all duration-300"></span>
                </button>
                
                {/* 로그아웃 버튼 */}
                <button
                  onClick={handleLogout}
                  className="bg-gradient-to-r from-emerald-500 to-cyan-500 text-white font-medium px-6 py-2 rounded-lg shadow-md shadow-emerald-500/50 hover:shadow-lg hover:shadow-emerald-500/70 transition-all duration-300 hover:scale-105 relative overflow-hidden group border-2 border-white/30"
                >
                  <span className="relative z-10">🌊 로그아웃</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-500"></div>
                </button>
              </>
            ) : (
              // 사용자가 로그인되지 않은 상태
              <>
                <button
                  onClick={handleLogin}
                  className={`font-medium px-6 py-3 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                    activeButton === 'login'
                      ? 'bg-gradient-to-r from-emerald-500 via-emerald-400 to-cyan-500 border-white/50 text-white shadow-lg shadow-emerald-500/50'
                      : clickedButtons.login 
                      ? 'bg-gradient-to-r from-emerald-500 via-emerald-400 to-cyan-500 border-white/50 text-white transform scale-95 shadow-lg shadow-emerald-500/50'
                      : 'bg-white/40 backdrop-blur-sm border-white/50 text-emerald-700 hover:bg-gradient-to-r hover:from-emerald-500 hover:via-emerald-400 hover:to-cyan-500 hover:border-white/50 hover:text-white hover:scale-105 hover:shadow-lg hover:shadow-emerald-500/50'
                  }`}
                >
                  {(activeButton === 'login' || clickedButtons.login) && (
                    <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-white/10 to-white/20 animate-pulse"></div>
                  )}
                  <span className="relative z-10">🏝️ 파라다이스 입장</span>
                </button>
                
                <button
                  onClick={handleSignup}
                  className={`font-medium px-6 py-3 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                    activeButton === 'signup'
                      ? 'bg-gradient-to-r from-emerald-500 via-emerald-400 to-cyan-500 border-white/50 text-white shadow-lg shadow-emerald-500/50'
                      : clickedButtons.signup 
                      ? 'bg-gradient-to-r from-emerald-500 via-emerald-400 to-cyan-500 border-white/50 text-white transform scale-95 shadow-lg shadow-emerald-500/50'
                      : 'bg-white/40 backdrop-blur-sm border-white/50 text-emerald-700 hover:bg-gradient-to-r hover:from-emerald-500 hover:via-emerald-400 hover:to-cyan-500 hover:border-white/50 hover:text-white hover:scale-105 hover:shadow-lg hover:shadow-emerald-500/50'
                  }`}
                >
                  {(activeButton === 'signup' || clickedButtons.signup) && (
                    <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-white/10 to-white/20 animate-pulse"></div>
                  )}
                  <span className="relative z-10">🏖️ 크리스탈 멤버십</span>
                </button>
              </>
            )}
          </div>

          {/* 파라다이스 모바일 메뉴 버튼 */}
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-white/50 transition-colors duration-200 text-emerald-600 border border-white/50 bg-white/30 backdrop-blur-sm"
            aria-label="파라다이스 메뉴 토글"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* 파라다이스 모바일 메뉴 */}
      {isMenuOpen && (
        <div className="md:hidden bg-white/30 backdrop-blur-md border-t border-white/30 py-4 px-4 shadow-lg shadow-emerald-500/30">
          {/* 파라다이스 모바일 상태 표시 */}
          <div className="flex items-center space-x-2 bg-emerald-100/60 px-3 py-2 rounded-lg mb-4 border border-emerald-300/50">
            <div className="relative">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              <div className="absolute inset-0 w-2 h-2 bg-emerald-500 rounded-full animate-ping opacity-30"></div>
            </div>
            <span className="text-sm text-emerald-700 font-medium">🌟 파라다이스 운영중</span>
            <span className="text-xs text-emerald-600 ml-auto">크리스탈 정확도 99.5%</span>
          </div>
          
          {currentUser ? (
            // 사용자가 로그인된 상태 - 모바일
            <div className="space-y-4">
              {/* 사용자 정보 */}
              <div className="flex items-center space-x-3 bg-white/40 backdrop-blur-sm px-4 py-3 rounded-lg border border-white/50">
                <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-emerald-400/70 shadow-lg shadow-emerald-500/50">
                  <img 
                    src={getAvatarSrc(currentUser.avatar)} 
                    alt={currentUser.name || '파라다이스 멤버'}
                    className="w-full h-full object-cover brightness-110 saturate-150"
                    onError={(e) => {
                      e.target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiMxMEI5ODEiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iI0ZGRkZGRiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iI0ZGRkZGRiIvPgo8L3N2Zz4K";
                    }}
                  />
                </div>
                <div>
                  <div className="font-medium text-emerald-700">{currentUser.name || '파라다이스 멤버'}</div>
                  <div className="text-sm text-emerald-600">
                    {getRoleText(currentUser.role)}
                  </div>
                </div>
              </div>

              {/* 파라다이스 모바일 버튼들 */}
              <div className="space-y-3">
                <button
                  onClick={handleMyPage}
                  className={`w-full text-left font-medium py-3 px-4 rounded-lg transition-all duration-200 border border-white/50 ${
                    clickedButtons.mypage 
                      ? 'text-emerald-700 bg-white/60 transform scale-95 shadow-lg shadow-emerald-500/50' 
                      : 'text-emerald-600 hover:text-emerald-700 hover:bg-white/50 hover:shadow-lg hover:shadow-emerald-500/40'
                  }`}
                >
                  💎 마이 파라다이스
                </button>
                
                <button
                  onClick={handleLogout}
                  className="w-full bg-gradient-to-r from-emerald-500 to-cyan-500 text-white font-medium py-3 px-4 rounded-lg shadow-md shadow-emerald-500/50 hover:shadow-lg hover:shadow-emerald-500/70 transition-all duration-300 border-2 border-white/30"
                >
                  🌊 로그아웃
                </button>
              </div>
            </div>
          ) : (
            // 사용자가 로그인되지 않은 상태 - 모바일
            <div className="space-y-3">
              <button
                onClick={handleLogin}
                className={`w-full font-medium py-3 px-4 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                  activeButton === 'login'
                    ? 'bg-gradient-to-r from-emerald-500 via-emerald-400 to-cyan-500 border-white/50 text-white shadow-lg shadow-emerald-500/50'
                    : clickedButtons.login 
                    ? 'bg-gradient-to-r from-emerald-500 via-emerald-400 to-cyan-500 border-white/50 text-white transform scale-95 shadow-lg shadow-emerald-500/50'
                    : 'bg-white/40 backdrop-blur-sm border-white/50 text-emerald-700 hover:bg-gradient-to-r hover:from-emerald-500 hover:via-emerald-400 hover:to-cyan-500 hover:border-white/50 hover:text-white hover:shadow-lg hover:shadow-emerald-500/50'
                }`}
              >
                {(activeButton === 'login' || clickedButtons.login) && (
                  <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-white/10 to-white/20 animate-pulse"></div>
                )}
                <span className="relative z-10">🏝️ 파라다이스 입장</span>
              </button>
              
              <button
                onClick={handleSignup}
                className={`w-full font-medium py-3 px-4 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                  activeButton === 'signup'
                    ? 'bg-gradient-to-r from-emerald-500 via-emerald-400 to-cyan-500 border-white/50 text-white shadow-lg shadow-emerald-500/50'
                    : clickedButtons.signup 
                    ? 'bg-gradient-to-r from-emerald-500 via-emerald-400 to-cyan-500 border-white/50 text-white transform scale-95 shadow-lg shadow-emerald-500/50'
                    : 'bg-white/40 backdrop-blur-sm border-white/50 text-emerald-700 hover:bg-gradient-to-r hover:from-emerald-500 hover:via-emerald-400 hover:to-cyan-500 hover:border-white/50 hover:text-white hover:shadow-lg hover:shadow-emerald-500/50'
                }`}
              >
                {(activeButton === 'signup' || clickedButtons.signup) && (
                  <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-white/10 to-white/20 animate-pulse"></div>
                )}
                <span className="relative z-10">🏖️ 크리스탈 멤버십</span>
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
}