import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function SubjectLearning() {
  const navigate = useNavigate();
  const location = useLocation();
  const { subject } = location.state || {};
  
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [completedLessons, setCompletedLessons] = useState(new Set());

  // 무서운 효과 상태
  const [glitchEffect, setGlitchEffect] = useState(false);
  const [bloodDrip, setBloodDrip] = useState(false);
  const [shadowFlicker, setShadowFlicker] = useState(false);
  const [cursedWhisper, setCursedWhisper] = useState(false);

  // 뒤로가기
  const handleBackToAnalysis = () => {
    navigate('/learning-analysis');
  };

  // 무서운 효과 트리거
  useEffect(() => {
    const glitchInterval = setInterval(() => {
      setGlitchEffect(true);
      setTimeout(() => setGlitchEffect(false), 250);
    }, 8000 + Math.random() * 15000);

    const bloodInterval = setInterval(() => {
      setBloodDrip(true);
      setTimeout(() => setBloodDrip(false), 4000);
    }, 12000 + Math.random() * 20000);

    const shadowInterval = setInterval(() => {
      setShadowFlicker(true);
      setTimeout(() => setShadowFlicker(false), 500);
    }, 6000 + Math.random() * 12000);

    const whisperInterval = setInterval(() => {
      setCursedWhisper(true);
      setTimeout(() => setCursedWhisper(false), 3000);
    }, 25000 + Math.random() * 35000);

    return () => {
      clearInterval(glitchInterval);
      clearInterval(bloodInterval);
      clearInterval(shadowInterval);
      clearInterval(whisperInterval);
    };
  }, []);

  // 과목별 학습 과정 데이터 - 무서운 버전
  const learningData = {
    영어: {
      title: '영어 집중 학습 - English Dark Arts',
      subtitle: '체계적인 영어 저주 향상을 위한 맞춤형 어둠의 커리큘럼',
      color: 'from-red-500 to-red-700',
      bgColor: 'from-red-950 to-black',
      icon: '💀',
      courses: [
        {
          id: 'english-grammar',
          title: '어법/문법 악마 마스터',
          description: '영어 문법의 저주를 체계적으로 학습합니다',
          duration: '4주 지옥 과정',
          level: '중급',
          progress: 0,
          lessons: [
            { id: 1, title: '시제의 완벽한 절망', duration: '45분', type: '저주' },
            { id: 2, title: '조동사 악마 활용법', duration: '35분', type: '저주' },
            { id: 3, title: '가정법 지옥 정복하기', duration: '50분', type: '저주' },
            { id: 4, title: '관계대명사/관계부사의 어둠', duration: '40분', type: '저주' },
            { id: 5, title: '실전 문제 악마 풀이 1', duration: '60분', type: '실습' },
            { id: 6, title: '실전 문제 악마 풀이 2', duration: '60분', type: '실습' }
          ],
          expectedImprovement: '+8점'
        },
        {
          id: 'english-reading',
          title: '독해 속도 저주 향상',
          description: '빠르고 정확한 영어 독해 저주 능력을 기릅니다',
          duration: '3주 악마 과정',
          level: '고급',
          progress: 25,
          lessons: [
            { id: 1, title: 'Skimming & Scanning 악마 기법', duration: '40분', type: '저주' },
            { id: 2, title: '주제문 찾기 어둠 전략', duration: '35분', type: '저주' },
            { id: 3, title: '빈칸추론 지옥 해결법', duration: '45분', type: '저주' },
            { id: 4, title: '실전 독해 악마 연습 1', duration: '50분', type: '실습' },
            { id: 5, title: '실전 독해 악마 연습 2', duration: '50분', type: '실습' }
          ],
          expectedImprovement: '+6점'
        },
        {
          id: 'english-vocabulary',
          title: '어휘력 저주 집중 강화',
          description: '수능 빈출 저주 어휘를 체계적으로 암기합니다',
          duration: '2주 악마 과정',
          level: '초급',
          progress: 60,
          lessons: [
            { id: 1, title: '접두사/접미사 악마 활용', duration: '30분', type: '저주' },
            { id: 2, title: '동의어/반의어 지옥 정리', duration: '40분', type: '저주' },
            { id: 3, title: '주제별 저주 어휘 학습', duration: '45분', type: '저주' },
            { id: 4, title: '어휘 악마 암기 테스트', duration: '30분', type: '테스트' }
          ],
          expectedImprovement: '+4점'
        }
      ]
    },
    국어: {
      title: '국어 집중 학습 - Korean Dark Literature',
      subtitle: '언어의 어둠을 탐구하며 저주받은 실력을 향상시킵니다',
      color: 'from-purple-500 to-purple-700',
      bgColor: 'from-purple-950 to-black',
      icon: '👻',
      courses: [
        {
          id: 'korean-literature',
          title: '문학 작품 어둠 심화 분석',
          description: '고전문학부터 현대문학까지 저주받은 작품을 깊이 있게 분석합니다',
          duration: '5주 지옥 과정',
          level: '고급',
          progress: 80,
          lessons: [
            { id: 1, title: '고전 시가의 절망적 이해', duration: '50분', type: '저주' },
            { id: 2, title: '현대 소설 악마 분석 기법', duration: '45분', type: '저주' },
            { id: 3, title: '극문학의 어둠 특성', duration: '40분', type: '저주' },
            { id: 4, title: '수필과 기행문의 절망', duration: '35분', type: '저주' },
            { id: 5, title: '문학 작품 실전 악마 분석', duration: '60분', type: '실습' },
            { id: 6, title: '문학사 지옥 정리', duration: '40분', type: '저주' }
          ],
          expectedImprovement: '+10점'
        },
        {
          id: 'korean-nonfiction',
          title: '비문학 독해 어둠 전략',
          description: '다양한 비문학 지문을 효과적으로 분석하는 저주받은 방법을 배웁니다',
          duration: '3주 악마 과정',
          level: '중급',
          progress: 30,
          lessons: [
            { id: 1, title: '설명문 구조 악마 파악', duration: '40분', type: '저주' },
            { id: 2, title: '논증문 논리 지옥 분석', duration: '45분', type: '저주' },
            { id: 3, title: '과학/기술 지문 악마 공략', duration: '50분', type: '저주' },
            { id: 4, title: '인문/예술 지문 어둠 이해', duration: '45분', type: '저주' },
            { id: 5, title: '비문학 실전 악마 연습', duration: '60분', type: '실습' }
          ],
          expectedImprovement: '+6점'
        },
        {
          id: 'korean-writing',
          title: '화법과 작문의 저주',
          description: '효과적인 악마적 의사소통과 글쓰기 능력을 기릅니다',
          duration: '4주 지옥 과정',
          level: '중급',
          progress: 0,
          lessons: [
            { id: 1, title: '화법의 기본 악마 원리', duration: '35분', type: '저주' },
            { id: 2, title: '토론과 토의 어둠 전략', duration: '40분', type: '저주' },
            { id: 3, title: '설득적 악마 글쓰기', duration: '45분', type: '저주' },
            { id: 4, title: '정보 전달 지옥 글쓰기', duration: '40분', type: '저주' },
            { id: 5, title: '실제 작문 악마 연습', duration: '60분', type: '실습' }
          ],
          expectedImprovement: '+5점'
        }
      ]
    }
  };

  const currentSubjectData = learningData[subject];

  const getLevelColor = (level) => {
    switch(level) {
      case '초급': return 'bg-green-900 bg-opacity-50 text-green-300 border border-green-800';
      case '중급': return 'bg-yellow-900 bg-opacity-50 text-yellow-300 border border-yellow-800';
      case '고급': return 'bg-red-900 bg-opacity-50 text-red-300 border border-red-800';
      default: return 'bg-gray-900 bg-opacity-50 text-gray-300 border border-gray-800';
    }
  };

  const getTypeIcon = (type) => {
    switch(type) {
      case '저주': return '💀';
      case '실습': return '🕷️';
      case '테스트': return '👻';
      default: return '🔮';
    }
  };

  const handleStartLesson = (courseId, lessonId) => {
    setCompletedLessons(prev => new Set([...prev, `${courseId}-${lessonId}`]));
    // 실제로는 학습 컨텐츠 페이지로 이동
    alert('💀 어둠의 학습이 시작됩니다! (실제로는 저주받은 학습 컨텐츠로 이동)');
  };

  const calculateCourseProgress = (course) => {
    const completedCount = course.lessons.filter(lesson => 
      completedLessons.has(`${course.id}-${lesson.id}`)
    ).length;
    return Math.round((completedCount / course.lessons.length) * 100);
  };

  if (!subject || !currentSubjectData) {
    navigate('/learning-analysis');
    return null;
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br ${currentSubjectData.bgColor} relative overflow-hidden ${glitchEffect ? 'animate-pulse' : ''}`}>
      {/* 무서운 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 복잡한 거미줄과 마법진 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            {/* 거미줄 */}
            <path d="M0,0 Q50,30 100,0 L100,20 Q50,50 0,20 Z" fill="url(#webGradient)" />
            <path d="M0,50 Q25,80 50,50 Q75,20 100,50" stroke="#ff0000" strokeWidth="0.5" fill="none" opacity="0.4"/>
            <path d="M20,0 L20,100 M40,0 L40,100 M60,0 L60,100 M80,0 L80,100" stroke="#990000" strokeWidth="0.3" opacity="0.3"/>
            
            {/* 마법진 */}
            <circle cx="20" cy="20" r="8" stroke="#660000" strokeWidth="0.5" fill="none" opacity="0.3"/>
            <circle cx="80" cy="80" r="6" stroke="#990000" strokeWidth="0.5" fill="none" opacity="0.4"/>
            <polygon points="20,15 25,20 20,25 15,20" fill="#ff0000" opacity="0.2"/>
            <polygon points="80,75 85,80 80,85 75,80" fill="#cc0000" opacity="0.3"/>
            
            {/* 거미들 */}
            <circle cx="30" cy="30" r="2" fill="#ff0000" opacity="0.6"/>
            <circle cx="70" cy="70" r="1.5" fill="#cc0000" opacity="0.5"/>
            <circle cx="15" cy="85" r="1" fill="#990000" opacity="0.4"/>
            
            <defs>
              <linearGradient id="webGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ff0000" stopOpacity="0.4" />
                <stop offset="50%" stopColor="#990000" stopOpacity="0.2" />
                <stop offset="100%" stopColor="#660000" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 피 효과 */}
        {bloodDrip && (
          <>
            <div className="absolute top-0 left-1/6 w-2 h-40 bg-gradient-to-b from-red-600 to-transparent animate-ping opacity-80"></div>
            <div className="absolute top-0 right-1/5 w-1 h-32 bg-gradient-to-b from-red-700 to-transparent animate-pulse opacity-60"></div>
            <div className="absolute top-0 left-2/3 w-1.5 h-36 bg-gradient-to-b from-red-800 to-transparent animate-bounce opacity-70"></div>
          </>
        )}
        
        {/* 그림자 깜빡임 */}
        {shadowFlicker && (
          <div className="absolute inset-0 bg-black opacity-60 animate-pulse"></div>
        )}
        
        {/* 저주받은 속삭임 효과 */}
        {cursedWhisper && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-red-400 opacity-30 text-4xl animate-pulse">
            💀👻🕷️
          </div>
        )}
        
        {/* 안개 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-black/70 to-transparent"></div>
        
        {/* 움직이는 어둠의 구체들 */}
        <div className="absolute top-1/4 left-10 w-32 h-32 bg-red-900 rounded-full blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-1/3 right-20 w-40 h-40 bg-purple-900 rounded-full blur-3xl opacity-15 animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-2/3 left-1/3 w-24 h-24 bg-orange-900 rounded-full blur-3xl opacity-25 animate-pulse" style={{ animationDelay: '4s' }}></div>
        <div className="absolute top-1/6 right-1/4 w-20 h-20 bg-gray-900 rounded-full blur-3xl opacity-30 animate-pulse" style={{ animationDelay: '6s' }}></div>
      </div>

      {/* 헤더 - 무서운 스타일 */}
      <div className="bg-black bg-opacity-90 shadow-2xl border-b-2 border-red-900 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToAnalysis}
                className="text-red-400 hover:text-red-300 mr-4 transition-all duration-300 transform hover:scale-110"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-bold bg-gradient-to-r ${currentSubjectData.color} bg-clip-text text-transparent ${glitchEffect ? 'animate-bounce' : ''}`}>
                {currentSubjectData.icon} {currentSubjectData.title}
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          
          {/* 과목 소개 - 무서운 스타일 */}
          <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 mb-8 border-2 border-red-900 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 to-purple-900/20"></div>
            <div className="text-center relative z-10">
              <div className="text-6xl mb-4 animate-pulse">{currentSubjectData.icon}</div>
              <h2 className="text-3xl font-bold text-red-400 mb-2">{currentSubjectData.title}</h2>
              <p className="text-gray-300 text-lg">{currentSubjectData.subtitle}</p>
            </div>
            {/* 무서운 장식 */}
            <div className="absolute top-4 right-4 text-red-600 opacity-50 animate-pulse">💀</div>
            <div className="absolute bottom-4 left-4 text-red-600 opacity-30 animate-pulse">🕷️</div>
            <div className="absolute top-4 left-4 text-red-600 opacity-40 animate-pulse">👻</div>
            <div className="absolute bottom-4 right-4 text-red-600 opacity-35 animate-pulse">🔮</div>
          </div>

          {/* 학습 과정 목록 - 무서운 스타일 */}
          <div className="space-y-8">
            {currentSubjectData.courses.map((course) => {
              const courseProgress = calculateCourseProgress(course);
              
              return (
                <div key={course.id} className="bg-black bg-opacity-90 rounded-3xl shadow-2xl overflow-hidden border-2 border-purple-900 relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-900/10 to-red-900/10"></div>
                  
                  {/* 코스 헤더 - 무서운 스타일 */}
                  <div className={`bg-gradient-to-r ${currentSubjectData.color} p-6 text-white relative z-10`}>
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h3 className="text-2xl font-bold mb-2">💀 {course.title}</h3>
                        <p className="text-white/90 mb-4">👻 {course.description}</p>
                        <div className="flex items-center space-x-6 text-sm">
                          <span>🕰️ {course.duration}</span>
                          <span className={`px-3 py-1 rounded-full ${getLevelColor(course.level)}`}>
                            ⚡ {course.level}
                          </span>
                          <span>📈 예상 향상: {course.expectedImprovement}</span>
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold mb-1">{courseProgress}%</div>
                        <div className="text-white/80 text-sm">완료율</div>
                      </div>
                    </div>
                    
                    {/* 진행률 바 - 무서운 스타일 */}
                    <div className="mt-4 w-full bg-black/30 rounded-full h-3 border border-gray-700">
                      <div 
                        className="bg-gradient-to-r from-red-600 to-red-400 h-3 rounded-full transition-all duration-500 shadow-lg"
                        style={{ 
                          width: `${courseProgress}%`,
                          boxShadow: '0 0 10px rgba(239, 68, 68, 0.8)'
                        }}
                      />
                    </div>
                  </div>

                  {/* 강의 목록 - 무서운 스타일 */}
                  <div className="p-6 relative z-10">
                    <div className="grid gap-4">
                      {course.lessons.map((lesson, index) => {
                        const isCompleted = completedLessons.has(`${course.id}-${lesson.id}`);
                        const isAccessible = index === 0 || completedLessons.has(`${course.id}-${course.lessons[index - 1].id}`);
                        
                        return (
                          <div 
                            key={lesson.id}
                            className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all duration-300 transform hover:scale-105 ${
                              isCompleted 
                                ? 'border-green-500 bg-green-950 bg-opacity-30 shadow-lg shadow-green-500/30' 
                                : isAccessible
                                ? 'border-red-700 bg-red-950 bg-opacity-20 hover:border-red-600 hover:bg-red-950 hover:bg-opacity-30'
                                : 'border-gray-700 bg-gray-950 bg-opacity-30'
                            }`}
                          >
                            <div className="flex items-center space-x-4">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all duration-300 ${
                                isCompleted 
                                  ? 'bg-green-600 text-white shadow-lg shadow-green-500/50' 
                                  : isAccessible
                                  ? 'bg-red-900 bg-opacity-50 text-red-300 border-2 border-red-700'
                                  : 'bg-gray-800 text-gray-500 border-2 border-gray-700'
                              }`}>
                                {isCompleted ? '✓' : lesson.id}
                              </div>
                              
                              <div className="flex-1">
                                <div className="flex items-center space-x-3 mb-1">
                                  <h4 className={`font-semibold ${
                                    isAccessible ? 'text-gray-300' : 'text-gray-500'
                                  }`}>
                                    {getTypeIcon(lesson.type)} {lesson.title}
                                  </h4>
                                  <span className={`text-sm px-2 py-1 rounded-full border ${
                                    lesson.type === '저주' ? 'bg-red-900 bg-opacity-50 text-red-300 border-red-800' :
                                    lesson.type === '실습' ? 'bg-purple-900 bg-opacity-50 text-purple-300 border-purple-800' :
                                    'bg-orange-900 bg-opacity-50 text-orange-300 border-orange-800'
                                  }`}>
                                    {lesson.type}
                                  </span>
                                </div>
                                <p className={`text-sm ${
                                  isAccessible ? 'text-gray-400' : 'text-gray-600'
                                }`}>
                                  ⏱️ {lesson.duration}
                                </p>
                              </div>
                            </div>
                            
                            <div className="flex items-center space-x-3">
                              {isCompleted ? (
                                <span className="text-green-400 font-medium">👻 완료</span>
                              ) : isAccessible ? (
                                <button
                                  onClick={() => handleStartLesson(course.id, lesson.id)}
                                  className={`px-6 py-2 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 bg-gradient-to-r ${currentSubjectData.color} text-white hover:shadow-lg shadow-lg`}
                                  style={{ boxShadow: `0 0 15px ${currentSubjectData.color.includes('red') ? '#ef4444' : '#a855f7'}50` }}
                                >
                                  💀 학습 시작
                                </button>
                              ) : (
                                <span className="text-gray-500 font-medium">🔒 잠금</span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  
                  {/* 무서운 장식 */}
                  <div className="absolute top-4 right-4 text-purple-600 opacity-40 animate-pulse">
                    {course.id.includes('grammar') ? '💀' : course.id.includes('reading') ? '👻' : '🕷️'}
                  </div>
                  <div className="absolute bottom-4 left-4 text-purple-600 opacity-30 animate-pulse">🔮</div>
                </div>
              );
            })}
          </div>

          {/* 학습 통계 - 무서운 스타일 */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 text-center border-2 border-red-900 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 to-transparent"></div>
              <div className="w-12 h-12 bg-red-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C20.168 18.477 18.582 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-red-400 mb-1 relative z-10">
                {currentSubjectData.courses.length}
              </div>
              <div className="text-sm text-gray-400 relative z-10">총 학습 과정</div>
              <div className="absolute top-2 right-2 text-red-600 opacity-50 animate-pulse">📚</div>
            </div>

            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 text-center border-2 border-green-900 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-green-900/20 to-transparent"></div>
              <div className="w-12 h-12 bg-green-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-green-400 mb-1 relative z-10">
                {completedLessons.size}
              </div>
              <div className="text-sm text-gray-400 relative z-10">완료한 강의</div>
              <div className="absolute top-2 right-2 text-green-600 opacity-50 animate-pulse">✅</div>
            </div>

            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 text-center border-2 border-purple-900 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 to-transparent"></div>
              <div className="w-12 h-12 bg-purple-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-purple-400 mb-1 relative z-10">
                +{currentSubjectData.courses.reduce((sum, course) => 
                  sum + parseInt(course.expectedImprovement.replace('+', '').replace('점', '')), 0
                )}점
              </div>
              <div className="text-sm text-gray-400 relative z-10">예상 총 향상</div>
              <div className="absolute top-2 right-2 text-purple-600 opacity-50 animate-pulse">📈</div>
            </div>
          </div>

          {/* 학습 동기 부여 섹션 - 무서운 스타일 */}
          <div className="mt-12 bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-orange-900 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-orange-900/20 to-red-900/20"></div>
            <div className="text-center relative z-10">
              <h3 className="text-2xl font-bold text-orange-300 mb-6">💀 어둠의 학습 동기 - Dark Motivation</h3>
              
              {completedLessons.size === 0 ? (
                <div className="bg-red-950 bg-opacity-50 rounded-2xl p-6 border-2 border-red-800">
                  <div className="text-4xl mb-4 animate-pulse">👻</div>
                  <h4 className="text-xl font-bold text-red-300 mb-2">어둠의 여정을 시작하세요!</h4>
                  <p className="text-gray-400 mb-4">
                    첫 번째 강의를 완료하면 저주받은 실력 향상의 길이 열립니다.
                  </p>
                  <div className="text-sm text-gray-500">
                    💀 총 {currentSubjectData.courses.reduce((sum, course) => sum + course.lessons.length, 0)}개의 어둠의 강의가 당신을 기다리고 있습니다.
                  </div>
                </div>
              ) : completedLessons.size < 5 ? (
                <div className="bg-yellow-950 bg-opacity-50 rounded-2xl p-6 border-2 border-yellow-800">
                  <div className="text-4xl mb-4 animate-pulse">🔥</div>
                  <h4 className="text-xl font-bold text-yellow-300 mb-2">어둠의 힘이 성장하고 있습니다!</h4>
                  <p className="text-gray-400 mb-4">
                    {completedLessons.size}개의 강의를 완료했습니다. 계속해서 저주받은 실력을 키워나가세요!
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div className="bg-red-900 bg-opacity-30 p-3 rounded-xl">
                      <div className="text-red-300 font-bold">🎯 다음 목표</div>
                      <div className="text-gray-400">10개 강의 완료</div>
                    </div>
                    <div className="bg-purple-900 bg-opacity-30 p-3 rounded-xl">
                      <div className="text-purple-300 font-bold">⚡ 진행률</div>
                      <div className="text-gray-400">
                        {Math.round((completedLessons.size / currentSubjectData.courses.reduce((sum, course) => sum + course.lessons.length, 0)) * 100)}% 완료
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-green-950 bg-opacity-50 rounded-2xl p-6 border-2 border-green-800">
                  <div className="text-4xl mb-4 animate-pulse">👑</div>
                  <h4 className="text-xl font-bold text-green-300 mb-2">어둠의 마스터에 근접했습니다!</h4>
                  <p className="text-gray-400 mb-4">
                    훌륭합니다! {completedLessons.size}개의 강의를 완료하여 상당한 진전을 이루었습니다.
                  </p>
                  <div className="bg-purple-900 bg-opacity-30 p-4 rounded-xl">
                    <div className="text-purple-300 font-bold mb-2">🏆 달성 현황</div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <div className="text-gray-400">완료 강의</div>
                        <div className="text-white font-bold">{completedLessons.size}개</div>
                      </div>
                      <div>
                        <div className="text-gray-400">전체 진행률</div>
                        <div className="text-white font-bold">
                          {Math.round((completedLessons.size / currentSubjectData.courses.reduce((sum, course) => sum + course.lessons.length, 0)) * 100)}%
                        </div>
                      </div>
                      <div>
                        <div className="text-gray-400">예상 향상</div>
                        <div className="text-white font-bold">
                          +{Math.round((completedLessons.size / currentSubjectData.courses.reduce((sum, course) => sum + course.lessons.length, 0)) * 
                            currentSubjectData.courses.reduce((sum, course) => sum + parseInt(course.expectedImprovement.replace('+', '').replace('점', '')), 0))}점
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            {/* 무서운 장식 */}
            <div className="absolute top-4 right-4 text-orange-600 opacity-50 animate-pulse">🔥</div>
            <div className="absolute bottom-4 left-4 text-orange-600 opacity-30 animate-pulse">⚡</div>
          </div>

          {/* 추천 학습 경로 - 무서운 스타일 */}
          <div className="mt-8 bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-blue-900 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-purple-900/20"></div>
            <div className="relative z-10">
              <h3 className="text-xl font-bold text-blue-300 mb-6">🗺️ 추천 어둠의 학습 경로 - Recommended Dark Path</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {currentSubjectData.courses.map((course, index) => {
                  const courseProgress = calculateCourseProgress(course);
                  const isRecommended = index === 0 || calculateCourseProgress(currentSubjectData.courses[index - 1]) >= 50;
                  
                  return (
                    <div key={course.id} className={`p-4 rounded-2xl border-2 transition-all duration-300 transform hover:scale-105 ${
                      isRecommended && courseProgress < 100
                        ? 'border-blue-500 bg-blue-950 bg-opacity-30 shadow-lg shadow-blue-500/30'
                        : courseProgress === 100
                        ? 'border-green-500 bg-green-950 bg-opacity-30 shadow-lg shadow-green-500/30'
                        : 'border-gray-700 bg-gray-950 bg-opacity-30'
                    }`}>
                      <div className="flex items-center justify-between mb-3">
                        <h4 className={`font-bold ${
                          courseProgress === 100 ? 'text-green-300' :
                          isRecommended ? 'text-blue-300' : 'text-gray-400'
                        }`}>
                          {course.title}
                        </h4>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          courseProgress === 100 ? 'bg-green-900 bg-opacity-50 text-green-300' :
                          isRecommended ? 'bg-blue-900 bg-opacity-50 text-blue-300' : 'bg-gray-900 bg-opacity-50 text-gray-400'
                        }`}>
                          {courseProgress === 100 ? '✅ 완료' :
                           isRecommended ? '🎯 추천' : '🔒 잠금'}
                        </span>
                      </div>
                      
                      <div className="text-sm text-gray-400 mb-3">
                        📊 진행률: {courseProgress}%
                      </div>
                      
                      <div className="w-full bg-gray-800 rounded-full h-2 mb-3">
                        <div 
                          className={`h-2 rounded-full transition-all duration-500 ${
                            courseProgress === 100 ? 'bg-green-500' :
                            isRecommended ? 'bg-blue-500' : 'bg-gray-600'
                          }`}
                          style={{ width: `${courseProgress}%` }}
                        />
                      </div>
                      
                      <div className="text-xs text-gray-500">
                        {course.lessons.length}개 강의 • {course.expectedImprovement} 향상 예상
                      </div>
                    </div>
                  );
                })}
              </div>
              
              <div className="mt-6 bg-gray-950 bg-opacity-50 rounded-2xl p-4 border border-gray-700">
                <h4 className="font-bold text-gray-300 mb-2">💡 학습 팁</h4>
                <div className="text-sm text-gray-400 space-y-1">
                  <div>🔥 하루에 1-2개 강의씩 꾸준히 학습하세요</div>
                  <div>👻 이전 강의를 완료해야 다음 강의가 잠금 해제됩니다</div>
                  <div>💀 실습 강의에서는 직접 문제를 풀어보며 실력을 확인하세요</div>
                </div>
              </div>
            </div>
            
            {/* 무서운 장식 */}
            <div className="absolute top-4 right-4 text-blue-600 opacity-50 animate-pulse">🗺️</div>
            <div className="absolute bottom-4 left-4 text-blue-600 opacity-30 animate-pulse">🧭</div>
          </div>
        </div>
      </div>

      {/* 무서운 CSS 애니메이션 */}
      <style jsx>{`
        @keyframes dark-pulse {
          0%, 100% { 
            opacity: 0.5;
            transform: scale(1);
          }
          50% { 
            opacity: 1;
            transform: scale(1.1);
          }
        }
        
        @keyframes cursed-whisper {
          0% { 
            opacity: 0;
            transform: scale(0.5) rotate(-10deg);
          }
          50% { 
            opacity: 0.7;
            transform: scale(1.2) rotate(5deg);
          }
          100% { 
            opacity: 0;
            transform: scale(0.8) rotate(-5deg);
          }
        }
        
        @keyframes blood-flow {
          0% { 
            transform: translateY(-100%) scaleY(0);
            opacity: 0;
          }
          20% { 
            transform: translateY(0%) scaleY(1);
            opacity: 1;
          }
          80% { 
            transform: translateY(300%) scaleY(1);
            opacity: 0.8;
          }
          100% { 
            transform: translateY(400%) scaleY(0);
            opacity: 0;
          }
        }
        
        @keyframes magic-circle {
          0% { 
            transform: rotate(0deg) scale(1);
            opacity: 0.3;
          }
          50% { 
            transform: rotate(180deg) scale(1.1);
            opacity: 0.6;
          }
          100% { 
            transform: rotate(360deg) scale(1);
            opacity: 0.3;
          }
        }
        
        @keyframes floating-orb {
          0%, 100% { 
            transform: translateY(0px) rotate(0deg);
          }
          33% { 
            transform: translateY(-10px) rotate(120deg);
          }
          66% { 
            transform: translateY(5px) rotate(240deg);
          }
        }
        
        .animate-dark-pulse {
          animation: dark-pulse 3s ease-in-out infinite;
        }
        
        .animate-cursed-whisper {
          animation: cursed-whisper 3s ease-in-out;
        }
        
        .animate-blood-flow {
          animation: blood-flow 4s ease-in-out;
        }
        
        .animate-magic-circle {
          animation: magic-circle 10s linear infinite;
        }
        
        .animate-floating-orb {
          animation: floating-orb 6s ease-in-out infinite;
        }
        
        /* 스크롤바 스타일링 */
        ::-webkit-scrollbar {
          width: 12px;
        }
        
        ::-webkit-scrollbar-track {
          background: #1f2937;
          border-radius: 6px;
        }
        
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #dc2626, #991b1b);
          border-radius: 6px;
          border: 2px solid #1f2937;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #ef4444, #dc2626);
        }
        
        /* 글리치 효과 */
        .glitch-text {
          position: relative;
        }
        
        .glitch-text::before,
        .glitch-text::after {
          content: attr(data-text);
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
        }
        
        .glitch-text::before {
          animation: glitch-1 0.5s infinite;
          color: #ff0000;
          z-index: -1;
        }
        
        .glitch-text::after {
          animation: glitch-2 0.5s infinite;
          color: #0000ff;
          z-index: -2;
        }
        
        @keyframes glitch-1 {
          0%, 14%, 15%, 49%, 50%, 99%, 100% {
            transform: translate(0, 0);
          }
          15%, 49% {
            transform: translate(-2px, 0);
          }
        }
        
        @keyframes glitch-2 {
          0%, 20%, 21%, 62%, 63%, 99%, 100% {
            transform: translate(0, 0);
          }
          21%, 62% {
            transform: translate(2px, 0);
          }
        }
        
        /* 호버 글로우 효과 */
        .hover-glow {
          transition: all 0.3s ease;
        }
        
        .hover-glow:hover {
          filter: drop-shadow(0 0 15px rgba(239, 68, 68, 0.8));
          transform: scale(1.05);
        }
      `}</style>
    </div>
  );
}