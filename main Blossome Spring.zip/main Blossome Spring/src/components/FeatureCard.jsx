// ============================================
// 🌸 Spring Blossom FeatureCard.jsx - 벚꽃 특징 카드
// ============================================
import React, { useRef, useEffect } from 'react';
import { gsap } from 'gsap';

export default function FeatureCard({ 
  icon, 
  title, 
  description, 
  gradient = 'from-pink-500 to-rose-500',
  bgGradient = 'from-pink-100/50 to-white/80',
  className = '',
  delay = 0,
  ...props 
}) {
  const cardRef = useRef(null);
  const iconRef = useRef(null);

  useEffect(() => {
    const card = cardRef.current;
    const iconEl = iconRef.current;

    if (!card || !iconEl) return;

    // 🌸 초기 진입 애니메이션 (벚꽃 느낌으로)
    gsap.fromTo(card, 
      { 
        y: 80, 
        opacity: 0, 
        scale: 0.7,
        rotationY: -30,
        filter: "blur(10px)"
      },
      { 
        y: 0, 
        opacity: 1, 
        scale: 1,
        rotationY: 0,
        filter: "blur(0px)",
        duration: 1.2, 
        ease: "power4.out",
        delay: delay 
      }
    );

    // 🌸 호버 애니메이션 (벚꽃 정원 효과)
    const handleMouseEnter = () => {
      gsap.to(card, {
        y: -16,
        scale: 1.06,
        rotationX: 8,
        duration: 0.5,
        ease: "power3.out"
      });

      gsap.to(iconEl, {
        scale: 1.3,
        rotation: 15,
        y: -8,
        duration: 0.5,
        ease: "back.out(2)"
      });
    };

    const handleMouseLeave = () => {
      gsap.to(card, {
        y: 0,
        scale: 1,
        rotationX: 0,
        duration: 0.5,
        ease: "power3.out"
      });

      gsap.to(iconEl, {
        scale: 1,
        rotation: 0,
        y: 0,
        duration: 0.5,
        ease: "power3.out"
      });
    };

    card.addEventListener('mouseenter', handleMouseEnter);
    card.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      card.removeEventListener('mouseenter', handleMouseEnter);
      card.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [delay]);

  return (
    <div 
      ref={cardRef}
      className={`
        bg-gradient-to-br ${bgGradient} backdrop-blur-md p-8 rounded-3xl shadow-2xl shadow-pink-500/30 hover:shadow-3xl hover:shadow-rose-500/50
        border border-white/40 transition-all duration-500 cursor-pointer group 
        relative overflow-hidden ${className}
      `}
      {...props}
    >
      {/* 🌺 배경 호버 효과 */}
      <div className={`
        absolute inset-0 bg-gradient-to-br ${gradient} opacity-0 
        group-hover:opacity-25 transition-opacity duration-500 rounded-3xl
      `}></div>
      
      {/* 🌺 벚꽃 정원 배경 레이어 */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/70 via-pink-50/50 to-rose-100/40 rounded-3xl"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(253,125,191,0.18)_0%,rgba(251,207,232,0.12)_40%,rgba(244,114,182,0.18)_80%)] rounded-3xl"></div>
      
      {/* 🌸 흩날리는 벚꽃 꽃잎들 */}
      <div className="absolute top-4 right-4 w-4 h-4 bg-pink-400/60 rounded-full animate-pulse shadow-lg transform rotate-45"></div>
      <div className="absolute bottom-6 left-6 w-3 h-3 bg-rose-400/70 rounded-full animate-ping shadow-lg transform rotate-12"></div>
      <div className="absolute top-1/2 right-8 w-3 h-3 bg-pink-300/60 rounded-full animate-bounce shadow-lg transform -rotate-12"></div>
      <div className="absolute top-1/3 left-4 w-2 h-2 bg-rose-500/70 rounded-full animate-pulse delay-700 transform rotate-45"></div>
      <div className="absolute bottom-1/3 right-6 w-2 h-2 bg-pink-300/60 rounded-full animate-ping delay-1000 transform -rotate-30"></div>
      
      {/* 🌸 아이콘 */}
      <div className="relative z-10 text-center mb-6">
        <div className="relative inline-block">
          <div 
            ref={iconRef}
            className={`
              inline-flex items-center justify-center w-24 h-24 
              bg-white/50 backdrop-blur-md rounded-3xl shadow-2xl shadow-pink-500/60 group-hover:shadow-3xl group-hover:shadow-rose-500/80
              transition-all duration-300 relative z-10 border border-white/50
            `}
          >
            <span className="text-5xl drop-shadow-xl filter">{icon}</span>
          </div>
          
          {/* 🌺 아이콘 로즈 글로우 효과 */}
          <div className={`
            absolute inset-0 bg-gradient-to-br ${gradient} rounded-3xl 
            blur-xl opacity-0 group-hover:opacity-70 transition-opacity duration-500
          `}></div>
          
          {/* 🌸 추가 벚꽃 효과 */}
          <div className="absolute inset-0 bg-gradient-radial from-pink-200/30 via-rose-200/15 to-transparent rounded-3xl blur-lg opacity-0 group-hover:opacity-50 transition-opacity duration-700"></div>
        </div>
      </div>
      
      {/* 🌸 콘텐츠 */}
      <div className="relative z-10 text-center">
        <h3 className="text-xl font-bold text-pink-700 mb-4 group-hover:text-rose-700 transition-colors duration-300 drop-shadow-lg">
          {title}
        </h3>
        <p className="text-pink-600 leading-relaxed group-hover:text-rose-600 transition-colors duration-300 drop-shadow-sm">
          {description}
        </p>
      </div>

      {/* 🌺 하단 로즈 액센트 라인 */}
      <div className={`
        absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r ${gradient} 
        transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 
        origin-left rounded-b-3xl shadow-lg shadow-pink-500/60
      `}></div>

      {/* 🌸 벚꽃 코너 장식 */}
      <div className="absolute top-0 right-0 w-24 h-24 overflow-hidden rounded-tr-3xl">
        <div className={`
          absolute -top-8 -right-8 w-20 h-20 bg-gradient-to-br ${gradient} 
          rounded-full opacity-25 group-hover:opacity-60 transition-opacity duration-300 animate-pulse
        `}></div>
      </div>

      {/* 🌸 추가 장식 요소들 */}
      <div className="absolute top-0 left-0 w-20 h-20 overflow-hidden rounded-tl-3xl">
        <div className="absolute -top-6 -left-6 w-16 h-16 bg-pink-300/30 rounded-full opacity-40 group-hover:opacity-70 transition-opacity duration-300 animate-pulse delay-500"></div>
      </div>

      {/* 🌸 로즈 경계선 효과 */}
      <div className="absolute inset-0 rounded-3xl border border-white/50 group-hover:border-pink-300/70 transition-colors duration-300"></div>
      
      {/* 🌹 중앙 로즈 효과 */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-40 h-40 bg-gradient-radial from-white/20 via-pink-100/15 to-transparent rounded-full blur-3xl opacity-0 group-hover:opacity-70 transition-opacity duration-700"></div>

      {/* 🌺 하단 그라데이션 */}
      <div className="absolute bottom-0 left-0 right-0 h-10 bg-gradient-to-t from-white/50 to-transparent rounded-b-3xl pointer-events-none"></div>
      
      {/* 🌸 미니 벚꽃 나무 장식 */}
      <div className="absolute bottom-2 right-2 opacity-25 group-hover:opacity-50 transition-opacity duration-300">
        <svg width="20" height="24" viewBox="0 0 20 24">
          <path d="M10 24 L10 14 M5 14 Q10 10 15 14" stroke="#ec4899" strokeWidth="1.5" fill="none"/>
          <circle cx="10" cy="12" r="2.5" fill="#ec4899"/>
          <circle cx="7" cy="12" r="1" fill="#fce7f3"/>
          <circle cx="13" cy="13" r="1" fill="#fce7f3"/>
          <circle cx="9" cy="10" r="0.5" fill="#f9a8d4"/>
          <circle cx="11" cy="11" r="0.5" fill="#f9a8d4"/>
        </svg>
      </div>
      
      {/* 🌸 추가 벚꽃 꽃잎 장식 */}
      <div className="absolute top-2 left-2 opacity-20 group-hover:opacity-40 transition-opacity duration-300">
        <svg width="16" height="16" viewBox="0 0 16 16">
          <circle cx="8" cy="8" r="2" fill="#f472b6" opacity="0.6"/>
          <circle cx="6" cy="6" r="1" fill="#fce7f3"/>
          <circle cx="10" cy="10" r="1" fill="#fce7f3"/>
          <circle cx="10" cy="6" r="0.5" fill="#f9a8d4"/>
          <circle cx="6" cy="10" r="0.5" fill="#f9a8d4"/>
        </svg>
      </div>
      
      <style jsx>{`
        .bg-gradient-radial {
          background: radial-gradient(circle, var(--tw-gradient-stops));
        }
        
        .shadow-3xl {
          box-shadow: 0 35px 60px -12px rgba(0, 0, 0, 0.25);
        }
      `}</style>
    </div>
  );
}