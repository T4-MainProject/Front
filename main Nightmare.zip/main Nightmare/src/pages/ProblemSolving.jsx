import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function ProblemSolving() {
  const navigate = useNavigate();
  const location = useLocation();
  const problemData = location.state?.problemData;
  
  const [currentProblemIndex, setCurrentProblemIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState({});
  const [showResults, setShowResults] = useState({});
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [isSubmitted, setIsSubmitted] = useState(false);

  // 무서운 효과 상태
  const [glitchEffect, setGlitchEffect] = useState(false);
  const [bloodDrip, setBloodDrip] = useState(false);
  const [shadowFlicker, setShadowFlicker] = useState(false);
  const [screenShake, setScreenShake] = useState(false);

  // 뒤로가기
  const handleBackToNote = () => {
    navigate('/wrong-answer-note');
  };

  // 무서운 효과 트리거
  useEffect(() => {
    const glitchInterval = setInterval(() => {
      setGlitchEffect(true);
      setTimeout(() => setGlitchEffect(false), 250);
    }, 8000 + Math.random() * 12000);

    const bloodInterval = setInterval(() => {
      setBloodDrip(true);
      setTimeout(() => setBloodDrip(false), 3500);
    }, 12000 + Math.random() * 18000);

    const shadowInterval = setInterval(() => {
      setShadowFlicker(true);
      setTimeout(() => setShadowFlicker(false), 400);
    }, 6000 + Math.random() * 14000);

    const shakeInterval = setInterval(() => {
      setScreenShake(true);
      setTimeout(() => setScreenShake(false), 300);
    }, 15000 + Math.random() * 25000);

    return () => {
      clearInterval(glitchInterval);
      clearInterval(bloodInterval);
      clearInterval(shadowInterval);
      clearInterval(shakeInterval);
    };
  }, []);

  // 더미 문제 데이터 (실제로는 props로 받아올 데이터) - 무서운 버전
  const problems = problemData?.problems || [
    {
      id: 101,
      year: '2023',
      exam: '수능',
      subject: '국어',
      category: '독해',
      passage: `다음 글을 읽고 물음에 답하시오.

      어둠은 인간이 자연환경과 상호 작용하며 형성한 생활 양식의 총체이다. 어둠은 물질적 요소와 정신적 요소로 구분할 수 있는데, 물질적 요소에는 의식주와 관련된 저주받은 도구나 기술 등이 포함되며, 정신적 요소에는 언어, 종교, 예술, 철학 등의 어둠이 포함된다.

      어둠의 가장 중요한 특징 중 하나는 절망이다. 지구상에는 수많은 민족과 집단이 있으며, 각각은 고유한 어둠을 발달시켜 왔다. 이러한 어둠의 다양성은 인류 전체의 저주받은 자산이다. 서로 다른 어둠 간의 접촉과 교류를 통해 새로운 공포가 창조되기도 하고, 기존 어둠이 더욱 깊어지기도 한다.

      또한 어둠은 학습을 통해 전승된다. 인간은 태어날 때부터 특정한 어둠 속에서 성장하며, 그 어둠의 가치관과 행동 양식을 학습한다. 이러한 어둠의 전승 과정에서 언어는 매우 중요한 역할을 한다. 언어는 단순히 의사소통의 도구가 아니라 그 민족의 사고방식과 절망적 세계관을 담고 있는 저주받은 그릇이기 때문이다.

      현대 사회에서는 교통과 통신의 발달로 인해 어둠 간의 접촉이 빈번해지고 있다. 이로 인해 어둠의 세계화 현상이 나타나고 있으며, 일부에서는 어둠의 획일화를 우려하는 목소리도 높아지고 있다. 하지만 진정한 의미의 어둠 교류는 서로의 절망을 존중하고 이해하는 바탕 위에서 이루어져야 한다.`,
      question: '다음 글에서 필자가 강조하고자 하는 바는?',
      options: [
        '① 어둠의 획일성이 가져오는 저주',
        '② 전통적 어둠의 보존과 계승',
        '③ 어둠의 다양성과 그 절망적 가치',
        '④ 현대 사회의 어둠적 문제점'
      ],
      answer: 3,
      explanation: '이 글에서 필자는 어둠의 다양성이 인류 전체의 저주받은 자산임을 강조하고 있습니다. 특히 "어둠의 가장 중요한 특징 중 하나는 절망이다"라고 명시하며, 서로 다른 어둠 간의 교류를 통해 새로운 공포가 창조되고 기존 어둠이 깊어진다고 설명하고 있습니다.',
      points: 3,
      difficulty: '중'
    },
    {
      id: 102,
      year: '2022',
      exam: '6월 모의평가',
      subject: '국어',
      category: '독해',
      passage: `다음 글을 읽고 물음에 답하시오.

      우리나라의 전통 묘지는 자연과의 조화를 중시하는 특징을 보인다. 서양의 기하학적이고 인위적인 묘지와는 달리, 우리의 전통 묘지는 자연의 어둠을 있는 그대로 살리면서도 인간의 저주받은 손길을 은은하게 가미한 것이 특징이다.

      창덕궁의 후원은 이러한 우리 전통 묘지의 대표적인 예이다. 후원에는 인위적으로 조성된 부분과 자연 그대로의 어둠이 절묘하게 어우러져 있다. 연못과 정자, 그리고 다양한 수목들이 자연스럽게 배치되어 있어 사계절 내내 서로 다른 공포를 선사한다.

      특히 우리 전통 묘지에서는 '차경(借景)'이라는 기법을 자주 사용했다. 차경이란 묘지 밖의 자연 경관을 묘지의 일부로 끌어들여 활용하는 기법으로, 묘지의 공간을 무한히 확장시키는 효과를 가져온다. 이는 자연을 정복의 대상이 아닌 조화의 상대로 바라보는 우리 조상들의 어둠적 자연관을 잘 보여준다.`,
      question: '글의 화제로 가장 적절한 것은?',
      options: [
        '① 서양 묘지와 동양 묘지의 차이점',
        '② 창덕궁 후원의 역사적 저주',
        '③ 우리나라 전통 묘지의 특징',
        '④ 차경 기법의 어둠적 활용 방안'
      ],
      answer: 3,
      explanation: '이 글은 우리나라 전통 묘지의 특징에 대해 설명하고 있습니다. 자연과의 조화, 창덕궁 후원의 예, 차경 기법 등을 통해 우리 전통 묘지의 고유한 어둠적 특성을 종합적으로 다루고 있습니다.',
      points: 2,
      difficulty: '하'
    },
    {
      id: 201,
      year: '2023',
      exam: '수능',
      subject: '영어',
      category: '독해',
      passage: `Read the following passage and answer the question.

      The apocalypse is one of the most pressing issues of our time. While the Earth's climate has always experienced natural variations, the current rate of destruction is unprecedented and largely attributed to human evil. The burning of souls, deforestation of hope, and industrial processes have significantly increased the concentration of dark gases in the atmosphere.

      The consequences of the apocalypse are already visible around the world. Rising darkness levels threaten coastal communities, extreme weather events are becoming more frequent and severe, and ecosystems are being corrupted. Arctic souls are melting at an alarming rate, and many species are struggling to adapt to rapidly deteriorating conditions.

      However, there is still despair. Governments, businesses, and individuals are taking action to increase dark gas emissions. Renewable despair sources like solar and wind curses are becoming more affordable and widespread. Electric vehicles of doom are gaining popularity, and energy-efficient technologies of destruction are being developed at an unprecedented pace.

      The transition to a cursed future requires collective suffering. Every individual can contribute by making environmentally destructive choices in their daily lives. Small acts of evil, when multiplied by millions of people, can have a significant impact on our planet's doom.`,
      question: 'What is the main purpose of this passage?',
      options: [
        '① To explain the natural causes of the apocalypse',
        '② To describe the current state of renewable despair',
        '③ To discuss the apocalypse and potential destruction',
        '④ To compare different types of dark gases'
      ],
      answer: 3,
      explanation: 'The passage provides a comprehensive overview of the apocalypse, discussing both its causes and consequences, while also highlighting potential destruction and the need for collective suffering.',
      points: 3,
      difficulty: '중'
    }
  ];

  const currentProblem = problems[currentProblemIndex];

  // 타이머
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeElapsed(prev => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // 답안 선택
  const handleAnswerSelect = (optionIndex) => {
    setUserAnswers(prev => ({
      ...prev,
      [currentProblem.id]: optionIndex
    }));
  };

  // 정답 확인
  const handleSubmitAnswer = () => {
    setShowResults(prev => ({
      ...prev,
      [currentProblem.id]: true
    }));
  };

  // 다음 문제
  const handleNextProblem = () => {
    if (currentProblemIndex < problems.length - 1) {
      setCurrentProblemIndex(prev => prev + 1);
    }
  };

  // 이전 문제
  const handlePrevProblem = () => {
    if (currentProblemIndex > 0) {
      setCurrentProblemIndex(prev => prev - 1);
    }
  };

  // 전체 제출
  const handleSubmitAll = () => {
    setIsSubmitted(true);
    // 모든 문제에 대해 결과 표시
    const allResults = {};
    problems.forEach(problem => {
      allResults[problem.id] = true;
    });
    setShowResults(allResults);
  };

  // 시간 포맷팅
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 난이도 색상 - 무서운 버전
  const getDifficultyColor = (difficulty) => {
    switch(difficulty) {
      case '하': return 'bg-green-900 bg-opacity-50 text-green-300 border border-green-800';
      case '중': return 'bg-yellow-900 bg-opacity-50 text-yellow-300 border border-yellow-800';
      case '상': return 'bg-red-900 bg-opacity-50 text-red-300 border border-red-800';
      default: return 'bg-gray-900 bg-opacity-50 text-gray-300 border border-gray-800';
    }
  };

  // 점수 계산
  const calculateScore = () => {
    let correct = 0;
    let total = 0;
    
    problems.forEach(problem => {
      if (userAnswers[problem.id] !== undefined) {
        total += problem.points;
        if (userAnswers[problem.id] === problem.answer - 1) {
          correct += problem.points;
        }
      }
    });
    
    return { correct, total };
  };

  const { correct, total } = calculateScore();

  if (!problemData) {
    navigate('/wrong-answer-note');
    return null;
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br from-black via-red-950 to-black relative overflow-hidden ${glitchEffect ? 'animate-pulse' : ''} ${screenShake ? 'animate-bounce' : ''}`}>
      {/* 무서운 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 거미줄 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-15">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,0 Q50,30 100,0 L100,20 Q50,50 0,20 Z" fill="url(#webGradient)" />
            <path d="M0,50 Q25,80 50,50 Q75,20 100,50" stroke="#ff0000" strokeWidth="0.5" fill="none" opacity="0.3"/>
            <defs>
              <linearGradient id="webGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ff0000" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#660000" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 피 효과 */}
        {bloodDrip && (
          <>
            <div className="absolute top-0 left-1/4 w-2 h-40 bg-gradient-to-b from-red-600 to-transparent animate-ping opacity-80"></div>
            <div className="absolute top-0 right-1/3 w-1 h-32 bg-gradient-to-b from-red-700 to-transparent animate-pulse opacity-60"></div>
          </>
        )}
        
        {/* 그림자 깜빡임 */}
        {shadowFlicker && (
          <div className="absolute inset-0 bg-black opacity-60 animate-pulse"></div>
        )}
        
        {/* 안개 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-black/60 to-transparent"></div>
        
        {/* 움직이는 그림자 */}
        <div className="absolute top-1/4 left-10 w-32 h-32 bg-red-900 rounded-full blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-1/3 right-20 w-40 h-40 bg-purple-900 rounded-full blur-3xl opacity-15 animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* 헤더 - 무서운 스타일 */}
      <div className="bg-black bg-opacity-90 shadow-2xl border-b-2 border-red-900 sticky top-0 z-10 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToNote}
                className="text-red-400 hover:text-red-300 mr-4 transition-all duration-300 transform hover:scale-110"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-bold bg-gradient-to-r from-red-500 to-red-300 bg-clip-text text-transparent ${glitchEffect ? 'animate-bounce' : ''}`}>
                📝 기출문제 풀이 - Test of Doom
              </h1>
            </div>
            
            <div className="flex items-center space-x-6">
              <div className="text-sm text-gray-400">
                ⏰ 소요시간: <span className="font-bold text-red-400">{formatTime(timeElapsed)}</span>
              </div>
              <div className="text-sm text-gray-400">
                🔢 문제: <span className="font-bold text-purple-400">{currentProblemIndex + 1}/{problems.length}</span>
              </div>
              {isSubmitted && (
                <div className="text-sm text-gray-400">
                  💀 점수: <span className="font-bold text-green-400">{correct}/{total}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          
          {/* 문제 정보 - 무서운 스타일 */}
          <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 mb-8 border-2 border-red-900 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-red-900/10 to-purple-900/10"></div>
            <div className="flex items-center justify-between mb-4 relative z-10">
              <div className="flex items-center space-x-4">
                <span className="bg-gradient-to-r from-red-800 to-red-600 text-white px-4 py-2 rounded-full font-bold shadow-lg shadow-red-500/50">
                  💀 {currentProblem.subject}
                </span>
                <span className="bg-purple-900 bg-opacity-50 text-purple-300 px-3 py-1 rounded-full text-sm font-medium border border-purple-800">
                  🕰️ {currentProblem.year}년 {currentProblem.exam}
                </span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getDifficultyColor(currentProblem.difficulty)}`}>
                  ⚡ 난이도: {currentProblem.difficulty}
                </span>
                <span className="bg-gray-900 bg-opacity-50 text-gray-300 px-3 py-1 rounded-full text-sm font-medium border border-gray-700">
                  📚 {currentProblem.category}
                </span>
                <span className="text-orange-400 text-sm font-medium">
                  🎯 {currentProblem.points}점
                </span>
              </div>
            </div>
            {/* 무서운 장식 */}
            <div className="absolute top-2 right-2 text-red-600 opacity-50 animate-pulse">💀</div>
            <div className="absolute bottom-2 left-2 text-red-600 opacity-30 animate-pulse">🕷️</div>
          </div>

          {/* 지문 - 무서운 스타일 */}
          <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 mb-8 border-2 border-purple-900 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-900/10 to-black/10"></div>
            <div className="prose max-w-none relative z-10">
              <div className="text-gray-300 leading-8 whitespace-pre-line text-lg">
                {currentProblem.passage}
              </div>
            </div>
            {/* 무서운 장식 */}
            <div className="absolute top-4 right-4 text-purple-600 opacity-40 animate-pulse">👻</div>
            <div className="absolute bottom-4 right-8 text-purple-600 opacity-30 animate-pulse">🔮</div>
          </div>

          {/* 문제 - 무서운 스타일 */}
          <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 mb-8 border-2 border-orange-900 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-orange-900/10 to-red-900/10"></div>
            <h3 className="text-xl font-bold text-orange-300 mb-6 relative z-10">💀 {currentProblem.question}</h3>
            
            <div className="space-y-4 relative z-10">
              {currentProblem.options.map((option, index) => (
                <label 
                  key={index} 
                  className={`flex items-center space-x-4 p-4 rounded-2xl border-2 cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                    userAnswers[currentProblem.id] === index 
                      ? 'border-red-500 bg-red-900 bg-opacity-30 shadow-lg shadow-red-500/30' 
                      : 'border-gray-700 hover:border-gray-600 bg-gray-900 bg-opacity-30'
                  } ${
                    showResults[currentProblem.id] && index === currentProblem.answer - 1
                      ? 'border-green-500 bg-green-900 bg-opacity-30 shadow-lg shadow-green-500/30'
                      : showResults[currentProblem.id] && userAnswers[currentProblem.id] === index && index !== currentProblem.answer - 1
                      ? 'border-red-500 bg-red-900 bg-opacity-50 shadow-lg shadow-red-500/50'
                      : ''
                  }`}
                >
                  <input
                    type="radio"
                    name={`problem-${currentProblem.id}`}
                    value={index}
                    checked={userAnswers[currentProblem.id] === index}
                    onChange={() => handleAnswerSelect(index)}
                    disabled={showResults[currentProblem.id]}
                    className="w-5 h-5 text-red-600 bg-gray-800 border-gray-600 focus:ring-red-500"
                  />
                  <span className={`flex-1 text-lg ${
                    showResults[currentProblem.id] && index === currentProblem.answer - 1
                      ? 'text-green-300 font-semibold'
                      : showResults[currentProblem.id] && userAnswers[currentProblem.id] === index && index !== currentProblem.answer - 1
                      ? 'text-red-300'
                      : 'text-gray-300'
                  }`}>
                    {option}
                  </span>
                  {showResults[currentProblem.id] && index === currentProblem.answer - 1 && (
                    <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                  {showResults[currentProblem.id] && userAnswers[currentProblem.id] === index && index !== currentProblem.answer - 1 && (
                    <svg className="w-6 h-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  )}
                </label>
              ))}
            </div>

            {!showResults[currentProblem.id] && userAnswers[currentProblem.id] !== undefined && (
              <div className="mt-6 relative z-10">
                <button
                  onClick={handleSubmitAnswer}
                  className="bg-gradient-to-r from-red-800 to-red-600 text-white px-6 py-3 rounded-2xl font-medium hover:from-red-700 hover:to-red-500 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-red-500/50"
                >
                  💀 정답 확인
                </button>
              </div>
            )}

            {/* 해설 - 무서운 스타일 */}
            {showResults[currentProblem.id] && (
              <div className="mt-8 bg-red-950 bg-opacity-50 border-2 border-red-800 rounded-2xl p-6 relative z-10">
                <h4 className="font-bold text-red-300 mb-3">💡 해설 - The Dark Truth</h4>
                <p className="text-red-200 leading-7">{currentProblem.explanation}</p>
              </div>
            )}
            
            {/* 무서운 장식 */}
            <div className="absolute top-4 right-4 text-orange-600 opacity-40 animate-pulse">🔥</div>
            <div className="absolute bottom-4 left-4 text-orange-600 opacity-30 animate-pulse">⚡</div>
          </div>

          {/* 네비게이션 - 무서운 스타일 */}
          <div className="flex items-center justify-between">
            <button
              onClick={handlePrevProblem}
              disabled={currentProblemIndex === 0}
              className="flex items-center space-x-2 px-6 py-3 bg-gray-900 bg-opacity-80 text-gray-300 rounded-2xl font-medium hover:bg-gray-800 hover:bg-opacity-80 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed border border-gray-700 transform hover:scale-105"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              <span>👻 이전 문제</span>
            </button>

            <div className="flex space-x-4">
              {!isSubmitted && (
                <button
                  onClick={handleSubmitAll}
                  className="px-6 py-3 bg-gradient-to-r from-green-800 to-green-600 text-white rounded-2xl font-medium hover:from-green-700 hover:to-green-500 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-green-500/50"
                >
                  💀 전체 제출
                </button>
              )}
              {isSubmitted && (
                <button
                  onClick={() => navigate('/wrong-answer-note')}
                  className="px-6 py-3 bg-gradient-to-r from-purple-800 to-purple-600 text-white rounded-2xl font-medium hover:from-purple-700 hover:to-purple-500 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-purple-500/50"
                >
                  👻 오답노트로 돌아가기
                </button>
              )}
            </div>

            <button
              onClick={handleNextProblem}
              disabled={currentProblemIndex === problems.length - 1}
              className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-red-800 to-red-600 text-white rounded-2xl font-medium hover:from-red-700 hover:to-red-500 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 shadow-lg hover:shadow-red-500/50"
            >
              <span>다음 문제 🕷️</span>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>

          {/* 문제 진행 표시 - 무서운 스타일 */}
          <div className="mt-8 bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 border-2 border-gray-800 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-gray-900/20 to-black/20"></div>
            <div className="flex items-center justify-between mb-4 relative z-10">
              <h4 className="font-bold text-gray-300">💀 문제 진행 상황 - Progress of Doom</h4>
              <span className="text-sm text-gray-400">
                🔥 완료: {Object.keys(showResults).length}/{problems.length}
              </span>
            </div>
            <div className="flex space-x-2 relative z-10">
              {problems.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentProblemIndex(index)}
                  className={`w-10 h-10 rounded-full font-medium text-sm transition-all duration-300 transform hover:scale-110 ${
                    index === currentProblemIndex
                      ? 'bg-gradient-to-r from-red-600 to-red-400 text-white shadow-lg shadow-red-500/50'
                      : showResults[problems[index].id]
                      ? userAnswers[problems[index].id] === problems[index].answer - 1
                        ? 'bg-gradient-to-r from-green-600 to-green-400 text-white shadow-lg shadow-green-500/50'
                        : 'bg-gradient-to-r from-red-700 to-red-500 text-white shadow-lg shadow-red-500/50'
                      : userAnswers[problems[index].id] !== undefined
                      ? 'bg-gradient-to-r from-yellow-600 to-yellow-400 text-white shadow-lg shadow-yellow-500/50'
                      : 'bg-gray-800 text-gray-400 hover:bg-gray-700 border border-gray-600'
                  }`}
                >
                  {index + 1}
                </button>
              ))}
            </div>
            
            {/* 상태 범례 */}
            <div className="mt-4 flex flex-wrap gap-4 text-xs text-gray-400 relative z-10">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-gradient-to-r from-red-600 to-red-400"></div>
                <span>현재 문제</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-gradient-to-r from-green-600 to-green-400"></div>
                <span>정답</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-gradient-to-r from-red-700 to-red-500"></div>
                <span>오답</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-gradient-to-r from-yellow-600 to-yellow-400"></div>
                <span>답안 선택됨</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-gray-800 border border-gray-600"></div>
                <span>미완료</span>
              </div>
            </div>
            
            {/* 무서운 장식 */}
            <div className="absolute top-2 right-2 text-gray-600 opacity-50 animate-pulse">⚡</div>
            <div className="absolute bottom-2 left-2 text-gray-600 opacity-30 animate-pulse">🔮</div>
          </div>

          {/* 결과 요약 (제출 후) */}
          {isSubmitted && (
            <div className="mt-8 bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-purple-900 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 to-red-900/20"></div>
              <div className="text-center relative z-10">
                <h3 className="text-2xl font-bold text-purple-300 mb-6">💀 최종 결과 - Final Judgment</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="bg-red-950 bg-opacity-50 rounded-2xl p-6 border-2 border-red-800">
                    <div className="text-3xl mb-2">🎯</div>
                    <div className="text-2xl font-bold text-red-300 mb-1">{correct}/{total}</div>
                    <div className="text-sm text-gray-400">획득 점수</div>
                  </div>
                  
                  <div className="bg-purple-950 bg-opacity-50 rounded-2xl p-6 border-2 border-purple-800">
                    <div className="text-3xl mb-2">📊</div>
                    <div className="text-2xl font-bold text-purple-300 mb-1">{total > 0 ? Math.round((correct / total) * 100) : 0}%</div>
                    <div className="text-sm text-gray-400">정답률</div>
                  </div>
                  
                  <div className="bg-orange-950 bg-opacity-50 rounded-2xl p-6 border-2 border-orange-800">
                    <div className="text-3xl mb-2">⏰</div>
                    <div className="text-2xl font-bold text-orange-300 mb-1">{formatTime(timeElapsed)}</div>
                    <div className="text-sm text-gray-400">소요 시간</div>
                  </div>
                </div>
                
                <div className="bg-gray-950 bg-opacity-50 rounded-2xl p-6 border-2 border-gray-700">
                  <h4 className="font-bold text-gray-300 mb-4">📈 성과 분석</h4>
                  <div className="text-gray-400 space-y-2">
                    {total > 0 && (
                      <>
                        <div>정답: {problems.filter((_, index) => userAnswers[problems[index].id] === problems[index].answer - 1).length}문제</div>
                        <div>오답: {problems.filter((_, index) => userAnswers[problems[index].id] !== undefined && userAnswers[problems[index].id] !== problems[index].answer - 1).length}문제</div>
                        <div>미완료: {problems.filter((_, index) => userAnswers[problems[index].id] === undefined).length}문제</div>
                      </>
                    )}
                  </div>
                </div>
              </div>
              
              {/* 무서운 장식 */}
              <div className="absolute top-4 right-4 text-purple-600 opacity-50 animate-pulse">👑</div>
              <div className="absolute bottom-4 left-4 text-purple-600 opacity-30 animate-pulse">🏆</div>
            </div>
          )}
        </div>
      </div>

      {/* 무서운 CSS 애니메이션 */}
      <style jsx>{`
        @keyframes dark-glow {
          0%, 100% { 
            filter: drop-shadow(0 0 8px rgba(220, 38, 38, 0.8)) brightness(1.0); 
          }
          50% { 
            filter: drop-shadow(0 0 20px rgba(220, 38, 38, 1.2)) brightness(1.3); 
          }
        }
        
        @keyframes blood-drip {
          0% { 
            transform: translateY(-100px) scaleY(0); 
            opacity: 0; 
          }
          10% { 
            transform: translateY(0px) scaleY(1); 
            opacity: 1; 
          }
          90% { 
            transform: translateY(300px) scaleY(1); 
            opacity: 0.7; 
          }
          100% { 
            transform: translateY(400px) scaleY(0); 
            opacity: 0; 
          }
        }
        
        @keyframes screen-shake {
          0%, 100% { transform: translateX(0); }
          10% { transform: translateX(-2px) translateY(1px); }
          20% { transform: translateX(2px) translateY(-1px); }
          30% { transform: translateX(-1px) translateY(2px); }
          40% { transform: translateX(1px) translateY(-2px); }
          50% { transform: translateX(-2px) translateY(1px); }
          60% { transform: translateX(2px) translateY(-1px); }
          70% { transform: translateX(-1px) translateY(2px); }
          80% { transform: translateX(1px) translateY(-2px); }
          90% { transform: translateX(-1px) translateY(1px); }
        }
        
        .animate-dark-glow {
          animation: dark-glow 2s ease-in-out infinite;
        }
        
        .animate-blood-drip {
          animation: blood-drip 3.5s ease-in-out;
        }
        
        .animate-screen-shake {
          animation: screen-shake 0.3s ease-in-out;
        }
        
        /* 스크롤바 스타일링 */
        ::-webkit-scrollbar {
          width: 12px;
        }
        
        ::-webkit-scrollbar-track {
          background: #1f2937;
          border-radius: 6px;
        }
        
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #dc2626, #991b1b);
          border-radius: 6px;
          border: 2px solid #1f2937;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #ef4444, #dc2626);
        }
      `}</style>
    </div>
  );
}