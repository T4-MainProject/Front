// 🏝️ Tropical Paradise PricingTable.jsx - 크리스탈 멤버십
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const plans = [
  { 
    name: '크리스탈 입문', 
    price: '무료', 
    period: '/월',
    originalPrice: null,
    features: [
      '일일 채점 3회',
      '기본 파라다이스 서비스',
      '이메일 지원',
      '제한된 기능 사용'
    ],
    popular: false,
    color: 'emerald',
    description: '파라다이스에 입문하는 크리스탈을 위한 기본 플랜',
    icon: '🌺'
  },
  { 
    name: '트로피컬 PRO', 
    price: '19,900원', 
    period: '/월',
    originalPrice: '29,900원',
    features: [
      '일일 채점 20회',
      '상세 분석 서비스',
      '파라다이스 오답노트',
      '우선 지원',
      '기타 기능 제한'
    ],
    popular: false,
    color: 'cyan',
    description: '학생과 학부모를 위한 트로피컬 프로 플랜',
    icon: '🏖️'
  },
  { 
    name: '파라다이스 PRO+', 
    price: '39,900원', 
    period: '/월',
    originalPrice: '59,900원',
    features: [
      '일일 채점 50회',
      '프리미엄 분석 서비스',
      '파라다이스 오답노트',
      '학습 분석 기능',
      '고급 리포트',
      '기타 기능 제한'
    ],
    popular: true,
    color: 'emerald',
    description: '교사와 소규모 학원을 위한 파라다이스 플러스',
    icon: '🏝️'
  },
  { 
    name: '크리스탈 ULTRA', 
    price: '99,900원', 
    period: '/월',
    originalPrice: '149,900원',
    features: [
      '무제한 채점',
      'AI 맞춤 분석',
      '파라다이스 오답노트',
      '학습 분석 기능',
      '모든 기능 사용',
      '24/7 지원',
      '전담 매니저'
    ],
    popular: false,
    color: 'sky',
    description: '대규모 교육기관을 위한 궁극의 크리스탈',
    icon: '💎'
  }
];

export default function PricingTable() {
  const sectionRef = useRef(null);
  const cardsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      cardsRef.current.forEach((card, index) => {
        if (!card) return;

        // 파라다이스 스크롤 트리거 애니메이션 (부드럽고 우아하게)
        gsap.fromTo(card,
          { y: 120, opacity: 0, scale: 0.7, rotationY: -30, filter: "blur(10px)" },
          {
            y: 0,
            opacity: 1,
            scale: 1,
            rotationY: 0,
            filter: "blur(0px)",
            duration: 1.2,
            ease: 'power4.out',
            delay: index * 0.25,
            scrollTrigger: {
              trigger: card,
              start: 'top 90%',
              toggleActions: 'play none none reverse',
            },
          }
        );

        // 파라다이스 호버 애니메이션 (부드럽고 세련되게)
        card.addEventListener('mouseenter', () => {
          gsap.to(card, {
            y: -15,
            scale: 1.05,
            rotationX: 5,
            duration: 0.4,
            ease: 'power3.out',
          });
        });
        card.addEventListener('mouseleave', () => {
          gsap.to(card, {
            y: 0,
            scale: 1,
            rotationX: 0,
            duration: 0.4,
            ease: 'power3.out',
          });
        });
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const getCardStyle = (plan) => {
    if (plan.popular) {
      return 'bg-white/30 backdrop-blur-md border-2 border-emerald-400/70 shadow-2xl shadow-emerald-500/50 transform scale-105';
    }
    return 'bg-white/25 backdrop-blur-md border border-white/50 shadow-xl shadow-emerald-500/30';
  };

  const getIconStyle = (plan) => {
    if (plan.popular) {
      return 'text-4xl animate-pulse drop-shadow-lg';
    }
    return 'text-3xl drop-shadow-md';
  };

  return (
    <section ref={sectionRef} className="py-16 bg-gradient-to-b from-emerald-50 via-cyan-50 to-sky-100 relative overflow-hidden">
      {/* 파라다이스 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-b from-emerald-100/40 via-white/60 to-cyan-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.1)_0%,rgba(6,182,212,0.05)_50%,rgba(14,165,233,0.1)_100%)]"></div>
      
      {/* 움직이는 크리스탈 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-2 h-2 bg-emerald-400/40 rounded-full animate-pulse shadow-sm"></div>
        <div className="absolute top-32 right-1/3 w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse delay-700 shadow-sm"></div>
        <div className="absolute bottom-24 left-1/2 w-1 h-1 bg-sky-400/30 rounded-full animate-pulse delay-1000 shadow-sm"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-teal-500/40 rounded-full animate-pulse delay-500 shadow-sm"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-emerald-300/30 rounded-full animate-pulse delay-1500 shadow-sm"></div>
      </div>

      <div className="container mx-auto px-4 text-center mb-8 relative z-10">
        <h2 className="text-3xl font-bold text-emerald-700 mb-4 drop-shadow-2xl">🏝️ 크리스탈 멤버십 요금제</h2>
        <p className="text-emerald-600/80 mt-2 drop-shadow-lg">당신의 파라다이스에 맞는 플랜을 선택하세요</p>
      </div>
      
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
        {plans.map((plan, i) => (
          <div
            key={i}
            ref={el => (cardsRef.current[i] = el)}
            className={`${getCardStyle(plan)} p-6 rounded-2xl flex flex-col relative overflow-hidden transition-all duration-300`}
          >
            {/* 파라다이스 배경 레이어 */}
            <div className="absolute inset-0 bg-gradient-to-br from-white/30 via-emerald-50/20 to-cyan-100/20 rounded-2xl"></div>
            
            {/* 움직이는 크리스탈 파티클 (카드 내부) */}
            <div className="absolute inset-0 overflow-hidden rounded-2xl pointer-events-none">
              <div className="absolute top-4 right-4 w-1 h-1 bg-emerald-400/40 rounded-full animate-pulse shadow-sm"></div>
              <div className="absolute bottom-6 left-6 w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse delay-700 shadow-sm"></div>
            </div>

            <div className="relative z-10">
              {plan.popular && (
                <div className="text-center mb-4">
                  <div className="inline-flex items-center space-x-2 bg-emerald-500/80 text-white px-3 py-1 rounded-full text-sm font-bold border border-emerald-400/50 shadow-lg">
                    <span>🌟</span>
                    <span>30일 무료 체험</span>
                  </div>
                </div>
              )}

              {/* 아이콘 */}
              <div className="text-center mb-4">
                <span className={getIconStyle(plan)}>{plan.icon}</span>
              </div>

              <h3 className="text-xl font-semibold mb-2 text-emerald-700 text-center drop-shadow-lg">{plan.name}</h3>
              
              <div className="text-center mb-4">
                <p className="text-3xl font-bold text-emerald-600 drop-shadow-lg">
                  {plan.price}
                  <span className="text-base font-normal text-emerald-500/80">{plan.period}</span>
                </p>
                {plan.originalPrice && (
                  <p className="text-sm text-emerald-500/70 line-through mt-1">
                    {plan.originalPrice}
                  </p>
                )}
              </div>

              <p className="text-emerald-600/80 mb-6 text-center text-sm leading-relaxed drop-shadow-sm">{plan.description}</p>
              
              <ul className="mb-6 space-y-3 flex-1">
                {plan.features.map((feat, j) => (
                  <li key={j} className="flex items-start space-x-3">
                    <span className="text-emerald-500 mt-1 drop-shadow-sm">✨</span>
                    <span className="text-emerald-700/90 text-sm drop-shadow-sm">{feat}</span>
                  </li>
                ))}
              </ul>
              
              <button className={`mt-auto w-full py-3 rounded-xl font-semibold transition-all duration-300 ${
                plan.popular 
                  ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-white hover:from-emerald-400 hover:to-cyan-400 shadow-lg shadow-emerald-500/50 hover:shadow-xl hover:shadow-emerald-500/70 hover:scale-105 border-2 border-white/30'
                  : 'bg-white/40 backdrop-blur-sm text-emerald-700 hover:bg-white/60 border border-white/50 hover:border-emerald-400 hover:shadow-lg hover:shadow-emerald-500/40'
              }`}>
                {plan.popular ? '🌟 파라다이스 시작하기' : '🏝️ 크리스탈 선택하기'}
              </button>
            </div>

            {/* 인기 플랜 글로우 효과 */}
            {plan.popular && (
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/20 to-transparent rounded-2xl animate-pulse pointer-events-none"></div>
            )}

            {/* 파라다이스 테두리 효과 */}
            <div className="absolute inset-0 rounded-2xl border border-emerald-300/30 pointer-events-none"></div>
          </div>
        ))}
      </div>

      {/* 추가 파라다이스 정보 */}
      <div className="container mx-auto px-4 mt-12 text-center relative z-10">
        <div className="bg-white/25 backdrop-blur-md rounded-2xl p-8 border border-white/30 shadow-lg shadow-emerald-500/30">
          <h3 className="text-xl font-bold text-emerald-700 mb-4 drop-shadow-lg">💎 모든 크리스탈 멤버십에 포함된 파라다이스 혜택</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
            <div className="flex items-center justify-center space-x-2">
              <span className="text-emerald-500 text-lg">🌺</span>
              <span className="text-emerald-700/90">무료 학습 상담</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <span className="text-cyan-500 text-lg">🏖️</span>
              <span className="text-emerald-700/90">24/7 파라다이스 지원</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <span className="text-sky-500 text-lg">🛡️</span>
              <span className="text-emerald-700/90">크리스탈 보안 보장</span>
            </div>
          </div>
          
          <div className="mt-6 pt-6 border-t border-emerald-300/50">
            <p className="text-emerald-600/80 text-xs italic">
              "모든 멤버십은 파라다이스 이용약관에 따라 제공되며, 크리스탈 보안 시스템으로 보호됩니다"
            </p>
          </div>
        </div>
      </div>

      {/* 하단 파라다이스 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white/20 to-transparent pointer-events-none"></div>
    </section>
  );
}