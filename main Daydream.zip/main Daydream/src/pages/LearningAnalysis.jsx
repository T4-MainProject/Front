import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function LearningAnalysis() {
  const navigate = useNavigate();
  const [selectedPeriod, setSelectedPeriod] = useState('최근 6개월');

  // 축복 효과 상태
  const [blessingEffect, setBlessingEffect] = useState(false);
  const [lightShine, setLightShine] = useState(false);
  const [angelFlicker, setAngelFlicker] = useState(false);

  // 🏠 홈으로 가기
  const handleBackToHome = () => {
    navigate(-1);
  };

  // 🎨 개별 과목 표시/숨김 토글 상태
  const [visibleSubjects, setVisibleSubjects] = useState({
    korean: true,
    english: true,
    math: true
  });

  // 🎨 선택된 회차들 상태
  const [selectedExams, setSelectedExams] = useState(new Set());

  // 🆕 비교 모드 상태 (내 점수만, 회원평균, 전국평균)
  const [comparisonMode, setComparisonMode] = useState('mine');

  // 축복 효과 트리거
  useEffect(() => {
    const blessingInterval = setInterval(() => {
      setBlessingEffect(true);
      setTimeout(() => setBlessingEffect(false), 300);
    }, 7000 + Math.random() * 15000);

    const lightInterval = setInterval(() => {
      setLightShine(true);
      setTimeout(() => setLightShine(false), 4000);
    }, 10000 + Math.random() * 20000);

    const angelInterval = setInterval(() => {
      setAngelFlicker(true);
      setTimeout(() => setAngelFlicker(false), 500);
    }, 5000 + Math.random() * 10000);

    return () => {
      clearInterval(blessingInterval);
      clearInterval(lightInterval);
      clearInterval(angelInterval);
    };
  }, []);

  // 과목 토글 함수
  const toggleSubject = (subject) => {
    setVisibleSubjects(prev => ({
      ...prev,
      [subject]: !prev[subject]
    }));
  };

  // 🎯 회차 토글 함수
  const toggleExam = (examIndex) => {
    // 평균 모드일 때는 단일 선택만 가능
    if (comparisonMode !== 'mine') {
      setSelectedExams(new Set([examIndex]));
      return;
    }
    
    setSelectedExams(prev => {
      const newSet = new Set(prev);
      if (newSet.has(examIndex)) {
        newSet.delete(examIndex);
      } else {
        newSet.add(examIndex);
      }
      return newSet;
    });
  };

  // 모든 회차 선택/해제 함수
  const toggleAllExams = () => {
    // 평균 모드일 때는 동작하지 않음
    if (comparisonMode !== 'mine') return;
    
    const allIndices = currentData.map((_, index) => index);
    if (selectedExams.size === currentData.length) {
      setSelectedExams(new Set());
    } else {
      setSelectedExams(new Set(allIndices));
    }
  };

  // 🆕 비교 모드 변경 시 선택 초기화
  const handleComparisonModeChange = (mode) => {
    setComparisonMode(mode);
    if (mode !== 'mine') {
      // 평균 모드로 변경시 첫 번째 회차만 선택
      setSelectedExams(new Set([0]));
    } else {
      // 내 점수 모드로 변경시 선택 초기화
      setSelectedExams(new Set());
    }
  };

  // 더미 성적 데이터 (회원평균, 전국평균 추가)
  const scoreData = {
    '최근 6개월': [
      { 
        exam: '1회', 
        date: '2024-01', 
        total: 72, 
        korean: 68, 
        english: 75, 
        math: 73,
        memberAvg: { total: 75, korean: 72, english: 76, math: 77 },
        nationalAvg: { total: 70, korean: 68, english: 71, math: 72 }
      },
      { 
        exam: '2회', 
        date: '2024-02', 
        total: 76, 
        korean: 72, 
        english: 78, 
        math: 78,
        memberAvg: { total: 77, korean: 74, english: 78, math: 79 },
        nationalAvg: { total: 72, korean: 70, english: 73, math: 74 }
      },
      { 
        exam: '3회', 
        date: '2024-03', 
        total: 82, 
        korean: 85, 
        english: 80, 
        math: 81,
        memberAvg: { total: 79, korean: 76, english: 80, math: 81 },
        nationalAvg: { total: 74, korean: 72, english: 75, math: 76 }
      },
      { 
        exam: '4회', 
        date: '2024-04', 
        total: 78, 
        korean: 82, 
        english: 75, 
        math: 77,
        memberAvg: { total: 80, korean: 78, english: 81, math: 82 },
        nationalAvg: { total: 75, korean: 73, english: 76, math: 77 }
      },
      { 
        exam: '5회', 
        date: '2024-05', 
        total: 86, 
        korean: 88, 
        english: 85, 
        math: 85,
        memberAvg: { total: 82, korean: 80, english: 83, math: 84 },
        nationalAvg: { total: 77, korean: 75, english: 78, math: 79 }
      },
      { 
        exam: '6회', 
        date: '2024-06', 
        total: 89, 
        korean: 92, 
        english: 87, 
        math: 88,
        memberAvg: { total: 84, korean: 82, english: 85, math: 86 },
        nationalAvg: { total: 79, korean: 77, english: 80, math: 81 }
      }
    ],
    '최근 1년': [
      { 
        exam: '1회', 
        date: '2023-06', 
        total: 65, 
        korean: 62, 
        english: 68, 
        math: 65,
        memberAvg: { total: 68, korean: 65, english: 70, math: 69 },
        nationalAvg: { total: 63, korean: 61, english: 65, math: 64 }
      },
      { 
        exam: '2회', 
        date: '2023-08', 
        total: 68, 
        korean: 65, 
        english: 70, 
        math: 69,
        memberAvg: { total: 70, korean: 67, english: 72, math: 71 },
        nationalAvg: { total: 65, korean: 63, english: 67, math: 66 }
      },
      { 
        exam: '3회', 
        date: '2023-10', 
        total: 71, 
        korean: 67, 
        english: 73, 
        math: 73,
        memberAvg: { total: 72, korean: 69, english: 74, math: 73 },
        nationalAvg: { total: 67, korean: 65, english: 69, math: 68 }
      },
      { 
        exam: '4회', 
        date: '2023-12', 
        total: 74, 
        korean: 70, 
        english: 76, 
        math: 76,
        memberAvg: { total: 74, korean: 71, english: 76, math: 75 },
        nationalAvg: { total: 69, korean: 67, english: 71, math: 70 }
      },
      { 
        exam: '5회', 
        date: '2024-02', 
        total: 78, 
        korean: 75, 
        english: 80, 
        math: 79,
        memberAvg: { total: 76, korean: 73, english: 78, math: 77 },
        nationalAvg: { total: 71, korean: 69, english: 73, math: 72 }
      },
      { 
        exam: '6회', 
        date: '2024-04', 
        total: 83, 
        korean: 85, 
        english: 82, 
        math: 82,
        memberAvg: { total: 80, korean: 78, english: 81, math: 82 },
        nationalAvg: { total: 75, korean: 73, english: 76, math: 77 }
      },
      { 
        exam: '7회', 
        date: '2024-06', 
        total: 89, 
        korean: 92, 
        english: 87, 
        math: 88,
        memberAvg: { total: 84, korean: 82, english: 85, math: 86 },
        nationalAvg: { total: 79, korean: 77, english: 80, math: 81 }
      }
    ]
  };

  const currentData = scoreData[selectedPeriod];

  // 과목별 강점과 개선점 데이터 (무서운 버전)
  const subjectAnalysisData = {
    korean: {
      strengths: [
        '어둠 속에서도 문학 작품을 정확히 분석함',
        '고전 시가의 숨겨진 의미를 읽어냄',
        '화자의 절망과 상황을 깊이 파악함'
      ],
      improvements: [
        '비문학 지문의 어두운 진실을 찾아내야 함',
        '문법의 혼돈을 정리하고 기억해야 함',
        '독해 속도를 늘려 시간의 저주를 피해야 함'
      ]
    },
    english: {
      strengths: [
        '어둠 속에서도 영어 독해 능력이 향상됨',
        '어휘력이 서서히 늘어가고 있음',
        '긴 지문 속 숨겨진 의미에 집중력 우수'
      ],
      improvements: [
        '어법/문법의 혼돈을 극복해야 함',
        '빈칸추론의 미로에서 탈출해야 함',
        '듣기 영역의 속삭임을 반복 연습해야 함'
      ]
    },
    math: {
      strengths: [
        '수학의 어둠 속에서도 기초 연산 능력 탁월',
        '기본 공식의 마법을 잘 활용함',
        '계산의 정확도가 빛을 발함'
      ],
      improvements: [
        '응용 문제의 미궁을 헤쳐나가야 함',
        '복잡한 사고의 늪을 통과해야 함',
        '시간의 압박을 이겨내야 함'
      ]
    }
  };

  const analysisData = {
    totalExams: 12,
    averageScore: 87.5,
    improvementRate: 15.2,
    strongSubjects: ['✨ 희망의 국어', '🌟 빛의 영어'],
    weakSubjects: ['💫 천사의 수학'],
    
    // 월별 성적 데이터 (천사 테마)
    monthlyScores: [
      { month: '2024-01', korean: 75, english: 70, math: 68, date: '1월' },
      { month: '2024-02', korean: 78, english: 73, math: 71, date: '2월' },
      { month: '2024-03', korean: 82, english: 76, math: 74, date: '3월' },
      { month: '2024-04', korean: 85, english: 79, math: 77, date: '4월' },
      { month: '2024-05', korean: 88, english: 82, math: 80, date: '5월' },
      { month: '2024-06', korean: 92, english: 85, math: 83, date: '6월' }
    ],

    // 회차별 상세 데이터
    examDetails: [
      { id: 1, title: '✨ 3월 희망 모의고사', date: '2024-03-15', korean: 85, english: 78, math: 72, total: 235 },
      { id: 2, title: '🌟 4월 천사 모의고사', date: '2024-04-12', korean: 88, english: 81, math: 75, total: 244 },
      { id: 3, title: '💫 5월 축복 모의고사', date: '2024-05-17', korean: 91, english: 84, math: 78, total: 253 },
      { id: 4, title: '👼 6월 빛 모의고사', date: '2024-06-14', korean: 94, english: 87, math: 81, total: 262 },
      { id: 5, title: '🪽 7월 희망 모의고사', date: '2024-07-19', korean: 89, english: 82, math: 76, total: 247 },
      { id: 6, title: '✨ 8월 천사 모의고사', date: '2024-08-16', korean: 92, english: 85, math: 79, total: 256 },
      { id: 7, title: '🌟 9월 축복 모의고사', date: '2024-09-13', korean: 88, english: 80, math: 74, total: 242 },
      { id: 8, title: '💫 10월 빛 모의고사', date: '2024-10-18', korean: 95, english: 88, math: 82, total: 265 },
      { id: 9, title: '👼 11월 희망 모의고사', date: '2024-11-15', korean: 90, english: 83, math: 77, total: 250 },
      { id: 10, title: '🪽 12월 천사 모의고사', date: '2024-12-13', korean: 93, english: 86, math: 80, total: 259 },
      { id: 11, title: '✨ 1월 축복 모의고사', date: '2025-01-17', korean: 96, english: 89, math: 83, total: 268 },
      { id: 12, title: '🌟 2월 빛 모의고사', date: '2025-02-14', korean: 91, english: 84, math: 78, total: 253 }
    ],

    // 과목별 상세 분석 (천사 테마)
    subjectAnalysis: {
      korean: {
        name: '✨ 희망의 국어',
        color: '#3b82f6',
        lightColor: '#dbeafe',
        icon: '📚',
        currentScore: 92,
        previousScore: 88,
        change: +4,
        rank: '상위 15%',
        strengths: ['문학 작품 이해', '언어와 매체', '화법과 작문'],
        weaknesses: ['독서 지문 해석', '문법 규칙'],
        recommendations: [
          '다양한 갈래별 문학 작품 감상하기',
          '비문학 독서 속도 향상 연습',
          '문법 개념 체계적 정리'
        ]
      },
      english: {
        name: '🌟 빛의 영어',
        color: '#0ea5e9',
        lightColor: '#e0f2fe',
        icon: '🗣️',
        currentScore: 85,
        previousScore: 82,
        change: +3,
        rank: '상위 25%',
        strengths: ['듣기 이해', '어휘 활용', '문법 적용'],
        weaknesses: ['긴 지문 독해', '영작문'],
        recommendations: [
          '영어 원서 읽기로 독해력 향상',
          '영작문 패턴 학습',
          '일상 영어 회화 연습'
        ]
      },
      math: {
        name: '💫 천사의 수학',
        color: '#6366f1',
        lightColor: '#e0e7ff',
        icon: '🧮',
        currentScore: 78,
        previousScore: 75,
        change: +3,
        rank: '상위 45%',
        strengths: ['기본 연산', '함수 이해'],
        weaknesses: ['기하 문제', '확률과 통계', '미적분'],
        recommendations: [
          '기하 도형 성질 반복 학습',
          '확률 개념 기초부터 정리',
          '미적분 개념 시각화 학습'
        ]
      }
    },

    // 학습 패턴 분석 (천사 테마)
    studyPatterns: {
      bestTimeSlots: ['오전 9-11시', '오후 2-4시'],
      concentrationLevel: 85,
      preferredSubjects: ['✨ 희망의 국어', '🌟 빛의 영어'],
      studyFrequency: '주 5일',
      averageStudyTime: '3.5시간'
    },

    // 목표 설정 (천사 테마)
    goals: {
      shortTerm: {
        target: '다음 모의고사 290점',
        current: 268,
        progress: 89,
        daysLeft: 15
      },
      longTerm: {
        target: '수능 1등급',
        current: '2등급',
        subjects: ['✨ 희망의 국어', '🌟 빛의 영어', '💫 천사의 수학']
      }
    }
  };

  // 선택된 과목별 강점과 개선점 필터링
  const getFilteredAnalysisData = () => {
    const selectedSubjects = Object.keys(visibleSubjects).filter(subject => visibleSubjects[subject]);
    
    const filteredStrengths = [];
    const filteredImprovements = [];
    
    selectedSubjects.forEach(subject => {
      if (subjectAnalysisData[subject]) {
        filteredStrengths.push(...subjectAnalysisData[subject].strengths);
        filteredImprovements.push(...subjectAnalysisData[subject].improvements);
      }
    });
    
    return {
      strengths: filteredStrengths,
      improvements: filteredImprovements
    };
  };

  const filteredData = getFilteredAnalysisData();

  const renderLineChart = () => {
    const koreanData = currentData.map(d => d.korean);
    const englishData = currentData.map(d => d.english);
    const mathData = currentData.map(d => d.math);
    
    // 🆕 비교 데이터 추가
    const koreanAvgData = comparisonMode === 'member' ? currentData.map(d => d.memberAvg.korean) : 
                         comparisonMode === 'national' ? currentData.map(d => d.nationalAvg.korean) : [];
    const englishAvgData = comparisonMode === 'member' ? currentData.map(d => d.memberAvg.english) : 
                          comparisonMode === 'national' ? currentData.map(d => d.nationalAvg.english) : [];
    const mathAvgData = comparisonMode === 'member' ? currentData.map(d => d.memberAvg.math) : 
                       comparisonMode === 'national' ? currentData.map(d => d.nationalAvg.math) : [];
    
    const maxValue = 100;
    const minValue = 60;
    const range = maxValue - minValue;
    
    const width = 500;
    const height = 350;
    const padding = 50;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    
    const getX = (index) => padding + (index / (currentData.length - 1)) * chartWidth;
    const getY = (value) => padding + ((maxValue - value) / range) * chartHeight;
    
    const createPath = (data) => data.map((value, index) => `${index === 0 ? 'M' : 'L'} ${getX(index)} ${getY(value)}`).join(' ');
    
    return (
      <div className="relative bg-black bg-opacity-90 backdrop-blur-md rounded-2xl border-2 border-red-900 p-4">
        <h4 className="text-center font-bold text-red-400 mb-4">📈 성적 변화 추이 - The Dark Evolution</h4>
        
        {/* 🆕 비교 모드 선택 - 무서운 스타일 */}
        <div className="flex justify-center space-x-2 mb-4">
          <button 
            onClick={() => handleComparisonModeChange('mine')}
            className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
              comparisonMode === 'mine' 
                ? 'bg-gradient-to-r from-red-800 to-red-600 text-white shadow-lg shadow-red-500/50 border border-red-700' 
                : 'bg-gray-900 bg-opacity-80 text-gray-400 hover:bg-gray-800 hover:bg-opacity-80 border border-gray-700'
            }`}
          >
            💀 내 점수만
          </button>
          <button 
            onClick={() => handleComparisonModeChange('member')}
            className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
              comparisonMode === 'member' 
                ? 'bg-gradient-to-r from-purple-800 to-purple-600 text-white shadow-lg shadow-purple-500/50 border border-purple-700' 
                : 'bg-gray-900 bg-opacity-80 text-gray-400 hover:bg-gray-800 hover:bg-opacity-80 border border-gray-700'
            }`}
          >
            👻 회원평균 비교
          </button>
          <button 
            onClick={() => handleComparisonModeChange('national')}
            className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
              comparisonMode === 'national' 
                ? 'bg-gradient-to-r from-orange-800 to-orange-600 text-white shadow-lg shadow-orange-500/50 border border-orange-700' 
                : 'bg-gray-900 bg-opacity-80 text-gray-400 hover:bg-gray-800 hover:bg-opacity-80 border border-gray-700'
            }`}
          >
            🕷️ 전국평균 비교
          </button>
        </div>
        
        <div className="flex justify-center space-x-2 md:space-x-4 mb-6">
          <button onClick={() => toggleSubject('korean')} className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-300 ${visibleSubjects.korean ? 'bg-gradient-to-r from-red-800/50 to-red-600/50 text-red-300 shadow-lg border-2 border-red-600/70' : 'bg-gray-900 bg-opacity-80 text-gray-500 hover:bg-gray-800 hover:bg-opacity-80 border-2 border-gray-700/50'}`}>
            <div className={`w-3 h-3 rounded-full ${visibleSubjects.korean ? 'bg-gradient-to-r from-red-600 to-red-400 shadow-md shadow-red-500/50' : 'bg-gray-600'}`}></div>
            <span className="text-sm font-medium">💀 국어</span>
          </button>
          <button onClick={() => toggleSubject('english')} className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-300 ${visibleSubjects.english ? 'bg-gradient-to-r from-purple-800/50 to-purple-600/50 text-purple-300 shadow-lg border-2 border-purple-600/70' : 'bg-gray-900 bg-opacity-80 text-gray-500 hover:bg-gray-800 hover:bg-opacity-80 border-2 border-gray-700/50'}`}>
            <div className={`w-3 h-3 rounded-full ${visibleSubjects.english ? 'bg-gradient-to-r from-purple-600 to-purple-400 shadow-md shadow-purple-500/50' : 'bg-gray-600'}`}></div>
            <span className="text-sm font-medium">👻 영어</span>
          </button>
          <button onClick={() => toggleSubject('math')} className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-300 ${visibleSubjects.math ? 'bg-gradient-to-r from-orange-800/50 to-orange-600/50 text-orange-300 shadow-lg border-2 border-orange-600/70' : 'bg-gray-900 bg-opacity-80 text-gray-500 hover:bg-gray-800 hover:bg-opacity-80 border-2 border-gray-700/50'}`}>
            <div className={`w-3 h-3 rounded-full ${visibleSubjects.math ? 'bg-gradient-to-r from-orange-600 to-orange-400 shadow-md shadow-orange-500/50' : 'bg-gray-600'}`}></div>
            <span className="text-sm font-medium">🕷️ 수학</span>
          </button>
        </div>
        
        <svg width="100%" viewBox={`0 0 ${width} ${height}`}>
          <defs>
            <linearGradient id="gradient-korean-dark" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#dc2626" /><stop offset="30%" stopColor="#b91c1c" /><stop offset="70%" stopColor="#991b1b" /><stop offset="100%" stopColor="#7f1d1d" /></linearGradient>
            <linearGradient id="gradient-english-dark" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#7c3aed" /><stop offset="30%" stopColor="#6d28d9" /><stop offset="70%" stopColor="#5b21b6" /><stop offset="100%" stopColor="#4c1d95" /></linearGradient>
            <linearGradient id="gradient-math-dark" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#ea580c" /><stop offset="30%" stopColor="#dc2626" /><stop offset="70%" stopColor="#b91c1c" /><stop offset="100%" stopColor="#991b1b" /></linearGradient>
            
            {/* 🆕 평균 선을 위한 점선 패턴 */}
            <pattern id="dashed-dark" patternUnits="userSpaceOnUse" width="10" height="2">
              <rect width="6" height="2" fill="currentColor"/>
            </pattern>
          </defs>
          {[60, 70, 80, 90, 100].map(value => <g key={value}><line x1={padding} y1={getY(value)} x2={width - padding} y2={getY(value)} stroke="#374151" strokeWidth="1"/><text x={padding - 10} y={getY(value) + 4} textAnchor="end" fontSize="12" fill="#6b7280">{value}</text></g>)}
          {currentData.map((item, index) => <text key={index} x={getX(index)} y={height - padding + 20} textAnchor="middle" fontSize="12" fill="#6b7280">{item.exam}</text>)}
          
          {/* 내 점수 선 */}
          {visibleSubjects.korean && <path d={createPath(koreanData)} fill="none" stroke="url(#gradient-korean-dark)" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" className="drop-shadow-md" style={{ filter: 'drop-shadow(0 0 8px #dc2626)' }}/>}
          {visibleSubjects.english && <path d={createPath(englishData)} fill="none" stroke="url(#gradient-english-dark)" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" className="drop-shadow-md" style={{ filter: 'drop-shadow(0 0 8px #7c3aed)' }}/>}
          {visibleSubjects.math && <path d={createPath(mathData)} fill="none" stroke="url(#gradient-math-dark)" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" className="drop-shadow-md" style={{ filter: 'drop-shadow(0 0 8px #ea580c)' }}/>}
          
          {/* 🆕 평균 점수 선 (점선) */}
          {comparisonMode !== 'mine' && (
            <>
              {visibleSubjects.korean && koreanAvgData.length > 0 && <path d={createPath(koreanAvgData)} fill="none" stroke="#dc2626" strokeWidth="3" strokeDasharray="8,4" opacity="0.7"/>}
              {visibleSubjects.english && englishAvgData.length > 0 && <path d={createPath(englishAvgData)} fill="none" stroke="#7c3aed" strokeWidth="3" strokeDasharray="8,4" opacity="0.7"/>}
              {visibleSubjects.math && mathAvgData.length > 0 && <path d={createPath(mathAvgData)} fill="none" stroke="#ea580c" strokeWidth="3" strokeDasharray="8,4" opacity="0.7"/>}
            </>
          )}
          
          {currentData.map((item, index) => (
            <g key={`points-${index}`}>
              {visibleSubjects.korean && <circle cx={getX(index)} cy={getY(item.korean)} r="6" fill={selectedExams.has(index) ? "#dc2626" : "url(#gradient-korean-dark)"} stroke="#000" strokeWidth="2" className="cursor-pointer drop-shadow-lg hover:r-8 transition-all duration-300" onClick={() => toggleExam(index)} style={{ filter: 'drop-shadow(0 0 10px #dc2626)' }}/>}
              {visibleSubjects.english && <circle cx={getX(index)} cy={getY(item.english)} r="6" fill={selectedExams.has(index) ? "#7c3aed" : "url(#gradient-english-dark)"} stroke="#000" strokeWidth="2" className="cursor-pointer drop-shadow-lg hover:r-8 transition-all duration-300" onClick={() => toggleExam(index)} style={{ filter: 'drop-shadow(0 0 10px #7c3aed)' }}/>}
              {visibleSubjects.math && <circle cx={getX(index)} cy={getY(item.math)} r="6" fill={selectedExams.has(index) ? "#ea580c" : "url(#gradient-math-dark)"} stroke="#000" strokeWidth="2" className="cursor-pointer drop-shadow-lg hover:r-8 transition-all duration-300" onClick={() => toggleExam(index)} style={{ filter: 'drop-shadow(0 0 10px #ea580c)' }}/>}
              
              {/* 🆕 평균 점수 점 */}
              {comparisonMode !== 'mine' && (
                <>
                  {visibleSubjects.korean && <circle cx={getX(index)} cy={getY(comparisonMode === 'member' ? item.memberAvg.korean : item.nationalAvg.korean)} r="4" fill="#dc2626" stroke="#000" strokeWidth="2" opacity="0.7"/>}
                  {visibleSubjects.english && <circle cx={getX(index)} cy={getY(comparisonMode === 'member' ? item.memberAvg.english : item.nationalAvg.english)} r="4" fill="#7c3aed" stroke="#000" strokeWidth="2" opacity="0.7"/>}
                  {visibleSubjects.math && <circle cx={getX(index)} cy={getY(comparisonMode === 'member' ? item.memberAvg.math : item.nationalAvg.math)} r="4" fill="#ea580c" stroke="#000" strokeWidth="2" opacity="0.7"/>}
                </>
              )}
            </g>
          ))}
        </svg>
        
        {/* 🆕 범례 업데이트 */}
        {comparisonMode !== 'mine' && (
          <div className="mt-4 text-center text-xs text-gray-400">
            <div className="flex justify-center items-center space-x-4">
              <div className="flex items-center space-x-1">
                <div className="w-4 h-0.5 bg-gradient-to-r from-red-600 to-red-400"></div>
                <span>내 점수</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-4 h-0.5 border-t-2 border-dashed border-gray-500"></div>
                <span>{comparisonMode === 'member' ? '회원평균' : '전국평균'}</span>
              </div>
            </div>
          </div>
        )}
        
        <div className="mt-2 text-center">
          <button 
            onClick={toggleAllExams} 
            className={`text-xs px-3 py-1 rounded-full transition-all duration-300 backdrop-blur-sm ${
              comparisonMode !== 'mine' 
                ? 'bg-gray-900 bg-opacity-50 text-gray-500 cursor-not-allowed border border-gray-700' 
                : 'bg-gray-800 bg-opacity-80 hover:bg-gray-700 hover:bg-opacity-80 text-gray-300 border border-gray-600'
            }`}
            disabled={comparisonMode !== 'mine'}
          >
            {comparisonMode !== 'mine' 
              ? '�� 평균 비교시 개별 선택만 가능' 
              : (selectedExams.size === currentData.length ? '👻 모두 해제' : '🕷️ 모두 선택')
            }
          </button>
        </div>
      </div>
    );
  };

  const renderStackedBarChart = () => {
    // 🆕 평균 모드일 때는 선택된 회차만, 아닐 때는 기존 로직
    const displayData = comparisonMode !== 'mine' 
      ? (selectedExams.size > 0 ? currentData.filter((_, index) => selectedExams.has(index)) : [currentData[0]])
      : (selectedExams.size > 0 
          ? currentData.filter((_, index) => selectedExams.has(index))
          : currentData.slice(-5));
    
    const activeSubjects = Object.entries(visibleSubjects).filter(([_, value]) => value);
    const isOnlyOneSubject = activeSubjects.length === 1;

    const width = 450;
    const height = 400;
    const padding = { top: 40, right: 20, bottom: 100, left: 50 };

    const subjectDetails = {
      korean: { name: '💀 국어', color: 'url(#gradient-korean-dark)' },
      english: { name: '👻 영어', color: 'url(#gradient-english-dark)' },
      math: { name: '🕷️ 수학', color: 'url(#gradient-math-dark)' }
    };
    
    const visibleSubjectKeys = activeSubjects.map(([key]) => key);

    return (
      <div className="bg-black bg-opacity-90 backdrop-blur-md rounded-2xl border-2 border-purple-900 p-4">
        <h4 className="text-center font-bold text-purple-400 mb-4 px-4">
          📊 {comparisonMode !== 'mine' 
                ? `${comparisonMode === 'member' ? '👻 회원평균' : '🕷️ 전국평균'} 비교`
                : (isOnlyOneSubject 
                    ? `${subjectDetails[visibleSubjectKeys[0]]?.name || ''} 점수 비교` 
                    : `💀 과목별 점수 비교`)}
        </h4>
        
        <svg width="100%" viewBox={`0 0 ${width} ${height}`}>
          <defs>
              <linearGradient id="gradient-korean-bar-dark" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#dc2626" /><stop offset="50%" stopColor="#b91c1c" /><stop offset="100%" stopColor="#991b1b" /></linearGradient>
              <linearGradient id="gradient-english-bar-dark" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#7c3aed" /><stop offset="50%" stopColor="#6d28d9" /><stop offset="100%" stopColor="#5b21b6" /></linearGradient>
              <linearGradient id="gradient-math-bar-dark" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#ea580c" /><stop offset="50%" stopColor="#dc2626" /><stop offset="100%" stopColor="#b91c1c" /></linearGradient>
              
              {/* 🌈 세로 어둠의 그라데이션 (다중 과목용) */}
              <linearGradient id="aurora-korean-dark" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fca5a5" />
                <stop offset="25%" stopColor="#f87171" />
                <stop offset="50%" stopColor="#ef4444" />
                <stop offset="75%" stopColor="#dc2626" />
                <stop offset="100%" stopColor="#991b1b" />
              </linearGradient>
              
              <linearGradient id="aurora-english-dark" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#c4b5fd" />
                <stop offset="25%" stopColor="#a78bfa" />
                <stop offset="50%" stopColor="#8b5cf6" />
                <stop offset="75%" stopColor="#7c3aed" />
                <stop offset="100%" stopColor="#5b21b6" />
              </linearGradient>
              
              <linearGradient id="aurora-math-dark" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fed7aa" />
                <stop offset="25%" stopColor="#fdba74" />
                <stop offset="50%" stopColor="#fb923c" />
                <stop offset="75%" stopColor="#f97316" />
                <stop offset="100%" stopColor="#ea580c" />
              </linearGradient>
              
              {/* 🆕 평균용 어둠의 그라데이션 */}
              <linearGradient id="avg-korean-dark" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#f87171" />
                <stop offset="50%" stopColor="#ef4444" />
                <stop offset="100%" stopColor="#dc2626" />
              </linearGradient>
              
              <linearGradient id="avg-english-dark" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#a78bfa" />
                <stop offset="50%" stopColor="#8b5cf6" />
                <stop offset="100%" stopColor="#7c3aed" />
              </linearGradient>
              
              <linearGradient id="avg-math-dark" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fdba74" />
                <stop offset="50%" stopColor="#fb923c" />
                <stop offset="100%" stopColor="#f97316" />
              </linearGradient>
              
              <linearGradient id="text-gradient-dark" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#f3f4f6" /><stop offset="50%" stopColor="#dc2626" /><stop offset="100%" stopColor="#7c3aed" /></linearGradient>
          </defs>

          {isOnlyOneSubject ? (
            comparisonMode !== 'mine' ? (
              /* 평균 비교 모드: 세로 막대 그래프 - 무서운 스타일 */
              (() => {
                const chartWidth = width - padding.left - padding.right;
                const chartHeight = height - padding.top - padding.bottom;
                const subjectKey = visibleSubjectKeys[0];
                const getY = (value) => padding.top + (1 - value / 100) * chartHeight;

                const groupWidth = chartWidth / displayData.length;
                const groupPadding = 0.3;
                const barGroupWidth = groupWidth * (1 - groupPadding);
                const barWidth = barGroupWidth / 2; // 2개 바 (내 점수 + 평균)
                const actualBarWidth = barWidth * 0.7;
                const barSpacing = barWidth * 0.3;

                return (
                  <g>
                    {[0, 20, 40, 60, 80, 100].map(value => {
                        const y = getY(value);
                        return <g key={value}><line x1={padding.left} y1={y} x2={width - padding.right} y2={y} stroke="#374151" strokeWidth="1"/><text x={padding.left - 10} y={y} textAnchor="end" dominantBaseline="middle" fontSize="10" fill="#6b7280">{value}</text></g>
                    })}
                    
                    {displayData.map((item, index) => {
                      const groupX = padding.left + index * groupWidth + (groupWidth * groupPadding / 2);
                      const myScore = item[subjectKey];
                      const avgScore = comparisonMode === 'member' ? item.memberAvg[subjectKey] : 
                                     comparisonMode === 'national' ? item.nationalAvg[subjectKey] : null;
                      
                      return (
                        <g key={`${item.exam}-${myScore}`}>
                          {/* 회차명 라벨 */}
                          <text x={groupX + barGroupWidth / 2} y={height - padding.bottom + 15} textAnchor="middle" fontSize="12" fill="#6b7280" fontWeight="600">{item.exam}</text>
                          
                          {/* 평균 바 */}
                          <rect 
                            x={groupX} 
                            y={getY(avgScore)} 
                            width={actualBarWidth} 
                            height={height - padding.bottom - getY(avgScore)} 
                            fill={`url(#avg-${subjectKey}-dark)`} 
                            rx="3" 
                            opacity="0.7"
                            className="animate-bar-grow-vertical" 
                            style={{ 
                              animation: `bar-grow-vertical 0.8s ease-out forwards ${index * 200}ms`, 
                              transformOrigin: 'bottom center',
                              filter: `drop-shadow(0 0 8px ${subjectKey === 'korean' ? '#dc2626' : subjectKey === 'english' ? '#7c3aed' : '#f97316'})`
                            }} 
                          />
                          <text 
                            x={groupX + actualBarWidth / 2} 
                            y={getY(avgScore) - 5} 
                            textAnchor="middle" 
                            fontSize="11" 
                            fill="#9ca3af" 
                            fontWeight="500" 
                            className="animate-text-fade" 
                            style={{ animationDelay: `${index * 200 + 400}ms` }}
                          >
                            {avgScore}
                          </text>
                          
                          {/* 내 점수 바 */}
                          <rect 
                            x={groupX + actualBarWidth + barSpacing} 
                            y={getY(myScore)} 
                            width={actualBarWidth} 
                            height={height - padding.bottom - getY(myScore)} 
                            fill={`url(#aurora-${subjectKey}-dark)`} 
                            rx="4" 
                            className="animate-bar-grow-vertical drop-shadow-lg" 
                            style={{ 
                              animation: `bar-grow-vertical 0.8s ease-out forwards ${index * 200 + 100}ms, dark-sparkle-glow 3s ease-in-out infinite ${index * 0.5 + 1}s`, 
                              transformOrigin: 'bottom center',
                              filter: `drop-shadow(0 4px 12px rgba(0, 0, 0, 0.5)) brightness(1.1) drop-shadow(0 0 12px ${subjectKey === 'korean' ? '#dc2626' : subjectKey === 'english' ? '#7c3aed' : '#f97316'})`
                            }} 
                          />
                          <text 
                            x={groupX + actualBarWidth + barSpacing + actualBarWidth / 2} 
                            y={getY(myScore) - 5} 
                            textAnchor="middle" 
                            fontSize="11" 
                            fill="#f3f4f6" 
                            fontWeight="600" 
                            className="animate-text-fade" 
                            style={{ 
                              animationDelay: `${index * 200 + 500}ms`,
                              textShadow: '0 0 8px rgba(0, 0, 0, 0.8)'
                            }}
                          >
                            {myScore}
                          </text>
                          
                          {/* 범례 라벨 (첫 번째 바에만) */}
                          {index === 0 && (
                            <>
                              <text 
                                x={groupX + actualBarWidth / 2} 
                                y={height - padding.bottom + 35} 
                                textAnchor="middle" 
                                fontSize="9" 
                                fill="#6b7280" 
                                fontWeight="500"
                              >
                                {comparisonMode === 'member' ? '👻 회원평균' : '🕷️ 전국평균'}
                              </text>
                              <text 
                                x={groupX + actualBarWidth + barSpacing + actualBarWidth / 2} 
                                y={height - padding.bottom + 35} 
                                textAnchor="middle" 
                                fontSize="9" 
                                fill="#6b7280" 
                                fontWeight="500"
                              >
                                💀 내 점수
                              </text>
                            </>
                          )}
                        </g>
                      );
                    })}
                  </g>
                )
              })()
            ) : (
              /* 내 점수만 모드: 가로 막대 그래프 - 무서운 스타일 */
              (() => {
                const chartWidth = width - padding.left - padding.right;
                const chartHeight = height - padding.top - padding.bottom;
                const barHeight = Math.min(chartHeight / displayData.length * 0.7, 30);
                const subjectKey = visibleSubjectKeys[0];

                return (
                  <g>
                    {[0, 20, 40, 60, 80, 100].map(value => {
                        const x = padding.left + (value / 100) * chartWidth;
                        return <g key={value}><line x1={x} y1={padding.top} x2={x} y2={height - padding.bottom} stroke="#374151" strokeWidth="1"/><text x={x} y={height - padding.bottom + 15} textAnchor="middle" fontSize="10" fill="#6b7280">{value}</text></g>
                    })}
                    {displayData.map((item, index) => {
                      const y = padding.top + index * (chartHeight / displayData.length) + (chartHeight / displayData.length - barHeight) / 2;
                      const score = item[subjectKey];
                      const barWidth = (score / 100) * chartWidth;
                      
                      return (
                        <g key={`${item.exam}-${score}`}>
                          <text x={padding.left - 10} y={y + barHeight / 2} textAnchor="end" dominantBaseline="middle" fontSize="12" fill="#6b7280" fontWeight="600">{item.exam}</text>
                          
                          {/* 내 점수 막대 */}
                          <rect 
                            x={padding.left} 
                            y={y} 
                            width={barWidth} 
                            height={barHeight} 
                            fill={`url(#gradient-${subjectKey}-bar-dark)`} 
                            rx="4" 
                            className="animate-bar-grow" 
                            style={{ 
                              animation: `bar-grow 0.6s ease-out forwards, dark-sparkle-glow 3s ease-in-out infinite ${index * 0.5}s`, 
                              transformOrigin: 'left center',
                              filter: `drop-shadow(0 0 8px ${subjectKey === 'korean' ? '#dc2626' : subjectKey === 'english' ? '#7c3aed' : '#f97316'})`
                            }}
                          />
                          
                          {/* 점수 라벨 */}
                          <text 
                            x={padding.left + barWidth + 8} 
                            y={y + barHeight / 2} 
                            dominantBaseline="middle" 
                            fontSize="14" 
                            fill="url(#text-gradient-dark)" 
                            fontWeight="700" 
                            className="animate-text-fade" 
                            style={{ 
                              animationDelay: `${index * 100 + 300}ms`,
                              textShadow: '0 0 8px rgba(0, 0, 0, 0.8)'
                            }}
                          >
                            {score}점
                          </text>
                        </g>
                      );
                    })}
                  </g>
                )
              })()
            )
          ) : (
            /* 다중 과목 선택 시: 세로 그룹 막대 그래프 - 무서운 스타일 */
            (() => {
                const chartWidth = width - padding.left - padding.right;
                const chartHeight = height - padding.top - padding.bottom;
                const getY = (value) => padding.top + (1 - value / 100) * chartHeight;

                // 🆕 평균 비교 모드일 때 바 배치 조정
                const groupWidth = chartWidth / displayData.length;
                const groupPadding = 0.3; // 그룹 간 간격 증가
                const barGroupWidth = groupWidth * (1 - groupPadding);
                
                // 평균 비교시에는 각 과목마다 2개씩 (내 점수 + 평균)
                const barsPerSubject = comparisonMode !== 'mine' ? 2 : 1;
                const totalBars = visibleSubjectKeys.length * barsPerSubject;
                const barWidth = barGroupWidth / totalBars;
                const barSpacing = barWidth * 0.3; // 바 간 간격 추가
                const actualBarWidth = barWidth * 0.7; // 바 너비 조정

                return (
                    <g>
                        {/* Y축 눈금 */}
                        {[0, 20, 40, 60, 80, 100].map(value => (
                            <g key={value}>
                                <line x1={padding.left} y1={getY(value)} x2={width - padding.right} y2={getY(value)} stroke="#374151" strokeWidth="1"/>
                                <text x={padding.left - 10} y={getY(value)} textAnchor="end" dominantBaseline="middle" fontSize="10" fill="#6b7280">{value}</text>
                            </g>
                        ))}

                        {/* 각 회차별 그룹 */}
                        {displayData.map((item, examIndex) => {
                            const groupX = padding.left + examIndex * groupWidth + (groupWidth * groupPadding / 2);
                            let barIndex = 0;
                            
                            return (
                                <g key={`${item.exam}-${selectedExams.size}`}>
                                    {/* 회차명 라벨 */}
                                    <text x={groupX + barGroupWidth / 2} y={height - padding.bottom + 20} textAnchor="middle" fontSize="12" fill="#6b7280" fontWeight="600">{item.exam}</text>
                                    
                                    {/* 각 과목별 바 */}
                                    {visibleSubjectKeys.map((subjectKey, subIndex) => {
                                        const myScore = item[subjectKey];
                                        const avgScore = comparisonMode === 'member' ? item.memberAvg[subjectKey] : 
                                                       comparisonMode === 'national' ? item.nationalAvg[subjectKey] : null;

                                        const elements = [];
                                        
                                        if (comparisonMode !== 'mine' && avgScore) {
                                            // 평균 바
                                            const avgBarX = groupX + barIndex * (actualBarWidth + barSpacing);
                                            const avgBarY = getY(avgScore);
                                            const avgBarH = height - padding.bottom - avgBarY;
                                            
                                            elements.push(
                                                <g key={`${subjectKey}-avg`}>
                                                    <rect 
                                                        x={avgBarX} 
                                                        y={avgBarY} 
                                                        width={actualBarWidth} 
                                                        height={avgBarH} 
                                                        fill={`url(#avg-${subjectKey}-dark)`} 
                                                        rx="3" 
                                                        opacity="0.7"
                                                        className="animate-bar-grow-vertical" 
                                                        style={{ 
                                                            animation: `bar-grow-vertical 0.8s ease-out forwards ${examIndex * 200 + barIndex * 100}ms`, 
                                                            transformOrigin: 'bottom center',
                                                            filter: `drop-shadow(0 0 8px ${subjectKey === 'korean' ? '#dc2626' : subjectKey === 'english' ? '#7c3aed' : '#f97316'})`
                                                        }} 
                                                    />
                                                    <text 
                                                        x={avgBarX + actualBarWidth / 2} 
                                                        y={avgBarY - 5} 
                                                        textAnchor="middle" 
                                                        fontSize="9" 
                                                        fill="#9ca3af" 
                                                        fontWeight="500" 
                                                        className="animate-text-fade" 
                                                        style={{ animationDelay: `${examIndex * 200 + barIndex * 100 + 400}ms` }}
                                                    >
                                                        {avgScore}
                                                    </text>
                                                </g>
                                            );
                                            barIndex++;
                                        }
                                        
                                        // 내 점수 바
                                        const myBarX = groupX + barIndex * (actualBarWidth + barSpacing);
                                        const myBarY = getY(myScore);
                                        const myBarH = height - padding.bottom - myBarY;
                                        
                                        elements.push(
                                            <g key={`${subjectKey}-mine`}>
                                                <rect 
                                                    x={myBarX} 
                                                    y={myBarY} 
                                                    width={actualBarWidth} 
                                                    height={myBarH} 
                                                    fill={`url(#aurora-${subjectKey}-dark)`} 
                                                    rx="4" 
                                                    className="animate-bar-grow-vertical drop-shadow-lg" 
                                                    style={{ 
                                                        animation: `bar-grow-vertical 0.8s ease-out forwards ${examIndex * 200 + barIndex * 100}ms, dark-sparkle-glow 3s ease-in-out infinite ${examIndex * 0.5 + barIndex * 0.2 + 1}s`, 
                                                        transformOrigin: 'bottom center',
                                                        filter: `drop-shadow(0 4px 12px rgba(0, 0, 0, 0.5)) brightness(1.1) drop-shadow(0 0 12px ${subjectKey === 'korean' ? '#dc2626' : subjectKey === 'english' ? '#7c3aed' : '#f97316'})`
                                                    }} 
                                                />
                                                <text 
                                                    x={myBarX + actualBarWidth / 2} 
                                                    y={myBarY - 5} 
                                                    textAnchor="middle" 
                                                    fontSize="11" 
                                                    fill="#f3f4f6" 
                                                    fontWeight="600" 
                                                    className="animate-text-fade" 
                                                    style={{ 
                                                        animationDelay: `${examIndex * 200 + barIndex * 100 + 400}ms`,
                                                        textShadow: '0 0 8px rgba(0, 0, 0, 0.8)'
                                                    }}
                                                >
                                                    {myScore}
                                                </text>
                                            </g>
                                        );
                                        barIndex++;
                                        
                                        return elements;
                                    })}
                                    
                                    {/* 과목명 라벨 (첫 번째 회차에만) */}
                                    {examIndex === 0 && visibleSubjectKeys.map((subjectKey, subIndex) => {
                                        const labelX = groupX + (subIndex * barsPerSubject + barsPerSubject / 2 - 0.5) * (actualBarWidth + barSpacing) + actualBarWidth / 2;
                                        return (
                                            <text 
                                                key={`label-${subjectKey}`}
                                                x={labelX} 
                                                y={height - padding.bottom + 35} 
                                                textAnchor="middle" 
                                                fontSize="9" 
                                                fill="#6b7280" 
                                                fontWeight="500"
                                            >
                                                {subjectDetails[subjectKey]?.name}
                                            </text>
                                        );
                                    })}
                                </g>
                            )
                        })}
                    </g>
                )
            })()
          )}
        </svg>
        
        {/* 🆕 범례 업데이트 - 무서운 스타일 */}
        <div className="flex justify-center flex-wrap gap-x-4 gap-y-2 mt-4 text-sm px-4">
          {visibleSubjectKeys.map(key => (
            <div key={key} className="flex items-center space-x-2">
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 rounded shadow-sm border border-gray-700" style={{ 
                  background: isOnlyOneSubject ? 
                    (key === 'korean' ? 'linear-gradient(to right, #dc2626, #b91c1c, #991b1b)' : 
                     key === 'english' ? 'linear-gradient(to right, #7c3aed, #6d28d9, #5b21b6)' : 
                     'linear-gradient(to right, #ea580c, #dc2626, #b91c1c)') :
                    (key === 'korean' ? 'linear-gradient(to bottom, #fca5a5, #f87171, #ef4444, #dc2626, #991b1b)' :
                     key === 'english' ? 'linear-gradient(to bottom, #c4b5fd, #a78bfa, #8b5cf6, #7c3aed, #5b21b6)' :
                     'linear-gradient(to bottom, #fed7aa, #fdba74, #fb923c, #f97316, #ea580c)')
                }}></div>
                <span className="text-gray-300 font-medium">{subjectDetails[key]?.name}</span>
              </div>
              {comparisonMode !== 'mine' && (
                <div className="flex items-center space-x-1 ml-2">
                  <div className="w-3 h-3 rounded shadow-sm opacity-70 border border-gray-700" style={{ 
                    background: key === 'korean' ? 'linear-gradient(to bottom, #f87171, #ef4444, #dc2626)' :
                               key === 'english' ? 'linear-gradient(to bottom, #a78bfa, #8b5cf6, #7c3aed)' :
                               'linear-gradient(to bottom, #fdba74, #fb923c, #f97316)'
                  }}></div>
                  <span className="text-gray-500 text-xs">
                    {comparisonMode === 'member' ? '👻 회원평균' : '🕷️ 전국평균'}
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* 선택 초기화 버튼 */}
        {comparisonMode === 'mine' && selectedExams.size > 0 && (
          <div className="text-center mt-4">
            <button
              onClick={() => setSelectedExams(new Set())}
              className="text-sm px-4 py-2 bg-gradient-to-r from-gray-800 bg-opacity-80 to-gray-700 bg-opacity-80 hover:from-gray-700 hover:bg-opacity-80 hover:to-gray-600 hover:bg-opacity-80 rounded-lg transition-all duration-300 backdrop-blur-sm border border-gray-600 text-gray-300"
            >
              💀 선택 초기화 (최근 5회 보기)
            </button>
          </div>
        )}
        
        {/* 🆕 평균 비교 모드 안내 */}
        {comparisonMode !== 'mine' && (
          <div className="text-center mt-4">
            <div className="text-xs text-gray-400 bg-gray-900 bg-opacity-80 rounded-lg px-3 py-2 backdrop-blur-sm border border-gray-700">
              💡 {comparisonMode === 'member' ? '👻 회원평균' : '🕷️전국평균'} 비교 모드에서는 개별 회차만 선택할 수 있습니다
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-black via-red-950 to-black relative overflow-hidden ${blessingEffect ? 'animate-pulse' : ''}`}>
      {/* 축복 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 축복 날개 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,0 Q50,30 100,0 L100,20 Q50,50 0,20 Z" fill="url(#angelGradient)" />
            <defs>
              <linearGradient id="angelGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#60a5fa" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 빛 효과 */}
        {lightShine && (
          <div className="absolute top-0 left-1/4 w-2 h-32 bg-gradient-to-b from-blue-400 to-transparent animate-ping opacity-70"></div>
        )}
        
        {/* 구름 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-white/30 to-transparent"></div>
      </div>

      <div className="bg-black bg-opacity-80 shadow-2xl border-b border-red-900 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToHome}
                className="text-red-400 hover:text-red-300 mr-4 transition-all duration-300 transform hover:scale-110"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-bold bg-gradient-to-r from-red-500 to-red-300 bg-clip-text text-transparent ${blessingEffect ? 'animate-bounce' : ''}`}>
                📊 학습 분석 - Dark Analytics of Doom
              </h1>
            </div>
          </div>
        </div>
      </div>
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-6xl mx-auto space-y-8">
          
          <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 border-2 border-red-900">
            <div className="flex flex-wrap gap-4">
              {['최근 6개월', '최근 1년'].map(period => 
                <button 
                  key={period} 
                  onClick={() => setSelectedPeriod(period)} 
                  className={`px-6 py-3 rounded-2xl font-medium transition-all duration-300 transform hover:scale-105 ${
                    selectedPeriod === period 
                      ? 'bg-gradient-to-r from-red-800 to-red-600 text-white shadow-lg shadow-red-500/50 border border-red-700' 
                      : 'bg-gray-900 bg-opacity-80 text-gray-300 hover:bg-gray-800 hover:bg-opacity-80 border border-gray-700'
                  }`}
                >
                  💀 {period}
                </button>
              )}
            </div>
          </div>
          
          <div className="relative bg-gradient-to-br from-red-950/80 via-black/80 to-purple-950/80 backdrop-blur-sm rounded-3xl shadow-2xl p-8 border-2 border-red-900 overflow-hidden">
            {/* 🌟 움직이는 어둠의 오로라 효과 */}
            <div className="absolute inset-0 opacity-20 pointer-events-none">
              <div className="absolute -top-10 -left-20 w-40 h-40 bg-gradient-to-r from-red-600/60 via-black/40 to-purple-600/40 rounded-full blur-3xl animate-dark-aurora-1"></div>
              <div className="absolute top-20 -right-20 w-60 h-60 bg-gradient-to-r from-purple-600/40 via-red-600/40 to-black/60 rounded-full blur-3xl animate-dark-aurora-2"></div>
              <div className="absolute bottom-10 left-1/3 w-50 h-50 bg-gradient-to-r from-black/60 via-red-600/60 to-orange-600/40 rounded-full blur-3xl animate-dark-aurora-3"></div>
            </div>
            
            <div className="relative z-10">
              <h3 className="text-2xl font-bold bg-gradient-to-r from-red-400 via-purple-400 to-orange-400 bg-clip-text text-transparent drop-shadow-sm mb-6 text-center lg:text-left">
                ✨ 성적 변화 추이 & 과목별 비교 - The Evolution of Darkness
              </h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                {renderLineChart()}
                {renderStackedBarChart()}
              </div>
            </div>

            {/* 🌟 어둠의 CSS 애니메이션 정의 */}
            <style jsx>{`
              @keyframes dark-aurora-1 { 
                0% { transform: translateX(-100px) translateY(0px) rotate(0deg); } 
                33% { transform: translateX(100px) translateY(-50px) rotate(120deg); } 
                66% { transform: translateX(50px) translateY(20px) rotate(240deg); } 
                100% { transform: translateX(-100px) translateY(0px) rotate(360deg); } 
              }
              .animate-dark-aurora-1 { animation: dark-aurora-1 20s ease-in-out infinite; }
              
              @keyframes dark-aurora-2 { 
                0% { transform: translateX(100px) translateY(0px) rotate(0deg); } 
                33% { transform: translateX(-50px) translateY(30px) rotate(-120deg); } 
                66% { transform: translateX(-100px) translateY(-40px) rotate(-240deg); } 
                100% { transform: translateX(100px) translateY(0px) rotate(-360deg); } 
              }
              .animate-dark-aurora-2 { animation: dark-aurora-2 25s ease-in-out infinite reverse; }
              
              @keyframes dark-aurora-3 { 
                0% { transform: translateX(-50px) translateY(0px) rotate(0deg); } 
                50% { transform: translateX(100px) translateY(-30px) rotate(180deg); } 
                100% { transform: translateX(-50px) translateY(0px) rotate(360deg); } 
              }
              .animate-dark-aurora-3 { animation: dark-aurora-3 18s ease-in-out infinite; }

              .animate-bar-grow { animation: bar-grow 0.6s ease-out forwards; }
              @keyframes bar-grow { from { transform: scaleX(0); } to { transform: scaleX(1); } }
              
              .animate-bar-grow-vertical { animation: bar-grow-vertical 0.8s ease-out forwards; }
              @keyframes bar-grow-vertical { from { transform: scaleY(0); } to { transform: scaleY(1); } }

              .animate-text-fade { animation: text-fade 0.5s ease-out forwards; opacity: 0; }
              @keyframes text-fade { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

              @keyframes dark-sparkle-glow {
                0%, 100% { filter: drop-shadow(0 0 8px rgba(220, 38, 38, 0.8)) brightness(1.1); }
                50% { filter: drop-shadow(0 0 20px rgba(220, 38, 38, 1.2)) brightness(1.4) contrast(1.2); }
              }
            `}</style>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 text-center border-2 border-green-900 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-green-900/20 to-transparent"></div>
              <div className="w-12 h-12 bg-green-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-green-400 mb-1 relative z-10">+{analysisData.totalImprovement}점</div>
              <div className="text-sm text-gray-400 relative z-10">총 향상도</div>
              <div className="absolute top-2 right-2 text-green-600 opacity-50 animate-pulse">📈</div>
            </div>
            
            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 text-center border-2 border-red-900 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 to-transparent"></div>
              <div className="w-12 h-12 bg-red-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-red-400 mb-1 relative z-10">{analysisData.bestSubject}</div>
              <div className="text-sm text-gray-400 relative z-10">최우수 과목</div>
              <div className="absolute top-2 right-2 text-red-600 opacity-50 animate-pulse">👑</div>
            </div>
            
            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 text-center border-2 border-orange-900 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-orange-900/20 to-transparent"></div>
              <div className="w-12 h-12 bg-orange-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.864-.833-2.5 0L5.268 16.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-orange-400 mb-1 relative z-10">{analysisData.weakestSubject}</div>
              <div className="text-sm text-gray-400 relative z-10">집중 필요 과목</div>
              <div className="absolute top-2 right-2 text-orange-600 opacity-50 animate-pulse">⚠️</div>
            </div>
            
            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 text-center border-2 border-purple-900 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 to-transparent"></div>
              <div className="w-12 h-12 bg-purple-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v10a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-purple-400 mb-1 relative z-10">{analysisData.consistencyScore}%</div>
              <div className="text-sm text-gray-400 relative z-10">일관성 지수</div>
              <div className="absolute top-2 right-2 text-purple-600 opacity-50 animate-pulse">📊</div>
            </div>
          </div>

          {/* 📊 과목별 피드백 - 무서운 스타일 */}
          <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-red-900">
            <h3 className="text-2xl font-bold text-red-400 mb-8 flex items-center">
              📊 과목별 피드백 - Subject Analysis from the Abyss
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Object.keys(subjectAnalysisData).map((subject) => {
                const subjectName = subject === 'korean' ? '💀 국어' : subject === 'english' ? '👻 영어' : '🕷️ 수학';
                const subjectIcon = subject === 'korean' ? '📘' : subject === 'english' ? '📗' : '📕';
                const isSelected = visibleSubjects[subject];
                const data = subjectAnalysisData[subject];
                
                // 선택된 과목만 표시
                if (!isSelected) return null;
                
                return (
                  <div key={subject} className={`rounded-2xl p-6 border-2 transition-all duration-300 relative overflow-hidden ${
                    subject === 'korean' ? 'bg-red-950/50 border-red-800' :
                    subject === 'english' ? 'bg-purple-950/50 border-purple-800' :
                    'bg-orange-950/50 border-orange-800'
                  }`}>
                    <div className="absolute inset-0 bg-gradient-to-br from-black/20 to-transparent"></div>
                    <div className="text-center mb-6 relative z-10">
                      <div className="text-3xl mb-2 animate-pulse">{subjectIcon}</div>
                      <h4 className="text-xl font-bold text-gray-300">{subjectName}</h4>
                    </div>
                    
                    {/* 강점 */}
                    <div className="mb-6 relative z-10">
                      <div className="flex items-center mb-3">
                        <span className="text-lg text-green-400">✓</span>
                        <span className="ml-2 font-semibold text-green-300">어둠 속의 강점</span>
                      </div>
                      <div className="space-y-2">
                        {data.strengths.map((strength, index) => (
                          <div key={index} className="text-sm text-gray-400 pl-6">
                            💀 {strength}
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    {/* 개선점 */}
                    <div className="relative z-10">
                      <div className="flex items-center mb-3">
                        <span className="text-lg text-red-400">△</span>
                        <span className="ml-2 font-semibold text-red-300">극복해야 할 어둠</span>
                      </div>
                      <div className="space-y-2">
                        {data.improvements.map((improvement, index) => (
                          <div key={index} className="text-sm text-gray-400 pl-6">
                            🕷️ {improvement}
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    {/* 무서운 장식 */}
                    <div className="absolute top-2 right-2 text-red-600 opacity-30 animate-pulse">
                      {subject === 'korean' ? '💀' : subject === 'english' ? '👻' : '🕷️'}
                    </div>
                  </div>
                );
              })}
            </div>
            
            {/* 선택된 과목이 없을 때 안내 메시지 */}
            {!Object.values(visibleSubjects).some(Boolean) && (
              <div className="text-center py-12 text-gray-500">
                <div className="text-4xl mb-4">💀</div>
                <p className="text-lg text-gray-400">차트 상단의 과목 버튼을 클릭하여 어둠 속 피드백을 확인하세요!</p>
              </div>
            )}
          </div>

          {/* AI 맞춤 학습 추천 - 무서운 스타일 */}
          <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-purple-900">
            <h3 className="text-xl font-bold text-purple-400 mb-6">🤖 AI 맞춤 학습 추천 - Dark Learning Recommendations</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {analysisData.recommendations.map((rec, index) => (
                <div key={index} className="bg-gradient-to-br from-red-950/50 to-purple-950/50 rounded-2xl p-6 border-2 border-red-800 relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-red-900/10 to-purple-900/10"></div>
                  <h4 className="font-bold text-red-300 mb-3 relative z-10">💀 {rec.title}</h4>
                  <p className="text-gray-400 text-sm mb-4 relative z-10">{rec.description}</p>
                  
                  <div className="space-y-2 mb-4 relative z-10">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">🕰️ 예상 기간:</span>
                      <span className="font-medium text-gray-300">{rec.duration}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">📈 예상 향상:</span>
                      <span className="font-bold text-green-400">{rec.expectedImprovement}</span>
                    </div>
                  </div>
                  
                  <button className="w-full bg-gradient-to-r from-red-800 to-purple-800 text-white py-3 rounded-xl font-medium hover:from-red-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-red-500/50 relative z-10">
                    💀 지옥 훈련 시작하기
                  </button>
                  
                  {/* 무서운 장식 */}
                  <div className="absolute top-2 right-2 text-red-600 opacity-30 animate-pulse">
                    {index === 0 ? '💀' : index === 1 ? '👻' : '🕷️'}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 학습 목표 설정 - 무서운 버전 */}
          <div className="bg-gradient-to-r from-red-900 to-black rounded-3xl shadow-2xl p-8 text-white border-2 border-red-800 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-red-900/30 to-black/30"></div>
            <div className="flex items-center justify-between relative z-10">
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-2 text-red-300">🎯 다음 목표 - The Next Challenge</h3>
                <p className="text-red-200 mb-4">
                  현재의 어둠 속 학습으로 <span className="font-bold text-red-300">3개월 후 95점</span> 달성 가능합니다!
                </p>
                <div className="flex space-x-4">
                  <button className="bg-red-800 text-white px-6 py-3 rounded-xl font-bold hover:bg-red-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-red-500/50 border border-red-700">
                    💀 다음 시험지 풀기
                  </button>
                  <button className="bg-black/40 text-red-300 border-2 border-red-800 px-6 py-3 rounded-xl font-bold hover:bg-black/60 transition-all duration-300 transform hover:scale-105">
                    👻 오답 복습하기
                  </button>
                </div>
              </div>
              <div className="ml-8 text-6xl animate-pulse">
                💀
              </div>
            </div>
            
            {/* 무서운 장식 */}
            <div className="absolute top-4 right-20 text-red-600 opacity-50 animate-pulse">🕷️</div>
            <div className="absolute bottom-4 left-8 text-red-600 opacity-30 animate-pulse">👻</div>
          </div>
        </div>
      </div>
    </div>
  );
}