// ============================================
// 🌸 Spring Blossom TopBar.jsx - 벚꽃 정원 상단 공지
// ============================================
// src/components/TopBar.jsx

import React from 'react';

export default function TopBar() {
  return (
    <div className="bg-gradient-to-r from-pink-400/80 via-rose-300 to-pink-400/80 border-b border-white/40 relative overflow-hidden">
      {/* 벚꽃 정원 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-r from-white/40 via-pink-100/50 to-white/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_70%,rgba(253,125,191,0.15)_100%)]"></div>
      
      {/* 흩날리는 벚꽃 꽃잎 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1 left-1/4 w-1 h-1 bg-pink-400/50 rounded-full animate-pulse shadow-sm transform rotate-45"></div>
        <div className="absolute top-2 right-1/3 w-1 h-1 bg-rose-400/40 rounded-full animate-pulse delay-700 shadow-sm transform rotate-12"></div>
        <div className="absolute bottom-1 left-1/2 w-1 h-1 bg-pink-300/40 rounded-full animate-pulse delay-1000 shadow-sm transform -rotate-12"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-rose-500/50 rounded-full animate-pulse delay-500 shadow-sm"></div>
      </div>

      <div className="container mx-auto px-4 py-2 text-center relative z-10">
        <div className="flex items-center justify-center space-x-2 text-sm">
          <span className="animate-pulse text-pink-600 drop-shadow-lg">🌺</span>
          <span className="font-medium text-pink-700 drop-shadow-sm">
            벚꽃 정원 서비스 오픈! AI 자동 채점을 무료로 체험해보세요
          </span>
          <span className="animate-pulse text-rose-600 drop-shadow-lg">🌸</span>
        </div>
      </div>

      {/* 하단 로즈 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-pink-400/60 to-transparent shadow-sm"></div>
    </div>
  );
}