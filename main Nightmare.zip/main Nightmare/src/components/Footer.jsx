// ============================================
// 💀 간소화된 Dark Horror Footer.jsx - 어둠의 발끝
// ============================================
import React from 'react';

export default function SimpleFooter() {
  return (
    <footer className="bg-gradient-to-b from-black via-gray-900 to-red-900 text-red-300 py-12 relative overflow-hidden">
      {/* 어둠의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-gray-900/60 to-red-900/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,black_100%)]"></div>
      
      {/* 움직이는 어둠의 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-4 left-1/4 w-2 h-2 bg-red-500/30 rounded-full animate-pulse"></div>
        <div className="absolute top-8 right-1/3 w-1 h-1 bg-red-400/40 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-6 left-1/2 w-1 h-1 bg-gray-500/30 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-red-600/40 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-red-300/30 rounded-full animate-pulse delay-1500"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between">
          {/* 어둠의 로고 */}
          <div className="flex items-center space-x-3 mb-6 md:mb-0">
            <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-black rounded-xl flex items-center justify-center shadow-lg shadow-red-500/50 border border-red-700/50">
              <span className="text-red-300 font-bold text-lg drop-shadow-lg">💀</span>
            </div>
            <div>
              <h3 className="text-xl font-bold text-red-300 drop-shadow-lg">DarkCheck</h3>
              <p className="text-red-500/80 text-sm drop-shadow-sm">👹 AI 악마 심판 시스템</p>
            </div>
          </div>
          
          {/* 어둠의 간단한 정보 */}
          <div className="text-center md:text-right">
            <p className="text-red-500/80 text-sm mb-2 drop-shadow-sm">
              © 2025 DarkCheck. All souls reserved.
            </p>
            <div className="flex items-center justify-center md:justify-end space-x-4 text-xs text-red-600/70">
              <span>지옥 문의</span>
              <span>•</span>
              <span>hellsupport@darkcheck.co.kr</span>
            </div>
          </div>
        </div>
                
        {/* 어둠의 기술 스택 */}
        <div className="mt-8 pt-8 border-t border-red-800/50 text-center">
          <p className="text-red-500/80 text-sm drop-shadow-sm">
            Powered by <span className="text-red-400 font-semibold">👁️ YOLO8 악마의 눈</span> •
            <span className="text-gray-400 font-semibold"> 🔮 OCR 영혼 추출</span> •
            <span className="text-red-400 font-semibold"> 👹 GPT 저주</span>
          </p>
        </div>

        {/* 추가 어둠의 장식 */}
        <div className="mt-6 text-center">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-red-900/40 to-black/60 px-4 py-2 rounded-full border border-red-800/50 shadow-lg shadow-red-500/30">
            <span className="text-red-500/80 text-xs">⚡ 지옥 서버 상태:</span>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              <span className="text-red-400 text-xs font-semibold">운영중</span>
            </div>
          </div>
        </div>

        {/* 어둠의 경고 메시지 */}
        <div className="mt-6 text-center">
          <p className="text-red-600/60 text-xs italic drop-shadow-sm">
            "어둠 속에서 태어나 빛을 거부하는 자들을 위한 심판 시스템"
          </p>
        </div>
      </div>

      {/* 하단 어둠 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-black to-transparent pointer-events-none"></div>
      
      {/* 어둠의 테두리 */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-red-600/50 to-transparent"></div>
    </footer>
  );
}