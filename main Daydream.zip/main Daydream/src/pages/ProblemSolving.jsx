import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function SimilarProblems() {
  const navigate = useNavigate();
  const location = useLocation();
  const [userAnswers, setUserAnswers] = useState({});
  const [showResults, setShowResults] = useState({});
  const [selectedProblem, setSelectedProblem] = useState(null);

  // 🌟 밝은 효과 상태
  const [sparkleEffect, setSparkleEffect] = useState(false);
  const [glowPulse, setGlowPulse] = useState(false);
  const [starTwinkle, setStarTwinkle] = useState(false);
  const [angelAppear, setAngelAppear] = useState(false);

  // URL 파라미터에서 문제 ID 가져오기
  const problemId = location.state?.problemId || 1;
  const originalProblem = location.state?.originalProblem || {};

  // 🏠 뒤로가기
  const handleBackToNote = () => {
    navigate('/wrong-answer-note');
  };

  // 밝은 효과 트리거
  useEffect(() => {
    const sparkleInterval = setInterval(() => {
      setSparkleEffect(true);
      setTimeout(() => setSparkleEffect(false), 800);
    }, 8000 + Math.random() * 12000);

    const glowInterval = setInterval(() => {
      setGlowPulse(true);
      setTimeout(() => setGlowPulse(false), 2000);
    }, 10000 + Math.random() * 15000);

    const starInterval = setInterval(() => {
      setStarTwinkle(true);
      setTimeout(() => setStarTwinkle(false), 1500);
    }, 5000 + Math.random() * 8000);

    const angelInterval = setInterval(() => {
      setAngelAppear(true);
      setTimeout(() => setAngelAppear(false), 3000);
    }, 25000 + Math.random() * 35000);

    return () => {
      clearInterval(sparkleInterval);
      clearInterval(glowInterval);
      clearInterval(starInterval);
      clearInterval(angelInterval);
    };
  }, []);

  // 유사 기출문제 더미 데이터 (지문 포함) - 밝은 버전
  const similarProblems = {
    1: [
      {
        id: 101,
        year: '2023',
        exam: '수능',
        passage: `문화는 인간이 자연 환경에 적응하며 만들어낸 지혜의 총체이다. 각 지역과 민족은 그들만의 독특한 환경과 역사적 경험을 바탕으로 고유한 문화를 형성해 왔다. 이러한 문화의 다양성은 인류의 소중한 자산이다.

오늘날 세계화의 물결 속에서 서로 다른 문화들이 만나고 있다. 이때 중요한 것은 한 문화가 다른 문화를 일방적으로 흡수하거나 동화시키는 것이 아니라, 서로의 차이를 인정하고 존중하며 조화롭게 공존하는 것이다. 문화의 획일화는 인류의 창조적 잠재력을 제한할 수 있기 때문이다.

따라서 우리는 문화의 다양성을 보호하고 증진시키기 위해 노력해야 한다. 이는 곧 인류 문명의 발전을 위한 필수 조건이기도 하다.`,
        question: '다음 글에서 필자가 강조하고자 하는 바는?',
        options: [
          '① 문화의 획일성이 발전에 미치는 긍정적 영향',
          '② 전통문화의 보존이 현대 사회에서 갖는 의미',
          '③ 문화의 다양성이 인류 발전에 갖는 중요성',
          '④ 현대 문명의 발전이 문화 변화에 미치는 영향'
        ],
        answer: 3,
        explanation: '글 전체에서 문화의 다양성이 인류의 소중한 자산이며, 인류 문명의 발전을 위한 필수 조건임을 강조하고 있습니다. 특히 마지막 문단에서 이를 명확히 드러내고 있습니다.'
      },
      {
        id: 102,
        year: '2022',
        exam: '6월 모의평가',
        passage: `현대 사회에서 문화 간 교류가 활발해지면서 새로운 형태의 문화 융합 현상이 나타나고 있다. 이는 단순히 서로 다른 문화 요소들이 섞이는 것을 넘어서, 완전히 새로운 문화적 가치와 형태를 창출하는 과정이다.

예를 들어, 한국의 K-pop은 서양의 팝 문화와 동양의 전통적 요소가 만나 탄생한 독특한 문화 장르이다. 이처럼 문화 융합은 기존의 문화적 경계를 허물고 새로운 창조적 에너지를 발생시킨다.

중요한 것은 이러한 융합 과정에서 각 문화의 고유성을 잃지 않으면서도 새로운 문화적 가치를 만들어내는 것이다.`,
        question: '글의 화제로 가장 적절한 것은?',
        options: [
          '① 문화 간 충돌과 그 해결 방안',
          '② 현대 사회의 문화 융합 현상',
          '③ 전통문화의 보존 필요성',
          '④ 세계화가 문화에 미치는 부정적 영향'
        ],
        answer: 2,
        explanation: '글 전체에서 현대 사회에서 나타나는 문화 융합 현상에 대해 설명하고 있으며, K-pop을 구체적인 사례로 제시하면서 이 현상의 특징과 의미를 다루고 있습니다.'
      },
      {
        id: 103,
        year: '2021',
        exam: '9월 모의평가',
        passage: `문화적 정체성은 개인이나 집단이 특정한 문화에 소속감을 느끼며 형성하는 자아 인식이다. 이는 태어나면서부터 자연스럽게 습득되는 것이 아니라, 사회적 상호작용을 통해 점진적으로 구성되는 것이다.

현대의 다문화 사회에서 개인은 여러 문화에 동시에 노출되며, 이로 인해 복합적인 문화적 정체성을 형성하게 된다. 이는 과거의 단일한 문화적 정체성과는 다른 새로운 형태의 자아 인식이라고 할 수 있다.

이러한 변화는 개인에게 더 폭넓고 유연한 사고를 가능하게 하지만, 동시에 정체성의 혼란이라는 과제도 안겨준다. 따라서 현대인은 다양한 문화적 요소들을 조화롭게 통합하여 자신만의 고유한 정체성을 형성해 나가야 한다.`,
        question: '다음 글의 주제문은?',
        options: [
          '① 첫 번째 문단의 첫 번째 문장',
          '② 두 번째 문단의 두 번째 문장',
          '③ 세 번째 문단의 첫 번째 문장',
          '④ 마지막 문단의 마지막 문장'
        ],
        answer: 4,
        explanation: '마지막 문장에서 글 전체의 핵심 메시지인 "현대인이 다양한 문화적 요소들을 조화롭게 통합하여 자신만의 고유한 정체성을 형성해야 한다"는 주제를 요약하여 제시하고 있습니다.'
      }
    ],
    2: [
      {
        id: 201,
        year: '2023',
        exam: '수능',
        passage: `Technology has dramatically changed the way we communicate with each other. Social media platforms have made it easier than ever to stay connected with friends and family around the world. However, this convenience comes with certain challenges.

Many people now prefer digital communication over face-to-face interactions. While this may seem efficient, it can lead to a lack of genuine human connection. The nuances of body language and vocal tone are often lost in digital communication.

Furthermore, the constant availability of digital communication can create pressure to respond immediately to messages. This can lead to stress and anxiety, particularly among young people who feel obligated to maintain their online presence constantly.`,
        question: 'The word "however" in the passage can be replaced by:',
        options: [
          '① therefore',
          '② moreover',
          '③ nevertheless',
          '④ consequently'
        ],
        answer: 3,
        explanation: '"However"는 앞의 내용과 대조되는 내용을 이어갈 때 사용하는 역접 접속부사로, "nevertheless"와 같은 의미입니다.'
      },
      {
        id: 202,
        year: '2022',
        exam: '6월 모의평가',
        passage: `Climate change is one of the most pressing issues of our time. The Earth\'s temperature has been rising steadily due to increased greenhouse gas emissions. This warming trend is causing significant changes to weather patterns around the globe.

Scientists have been studying this phenomenon for decades. They have collected extensive data showing that human activities are the primary cause of recent climate change. The burning of fossil fuels releases carbon dioxide into the atmosphere, which traps heat and causes global warming.

The effects of climate change are already visible. We can see melting ice caps, rising sea levels, and more frequent extreme weather events. If we don\'t take action soon, these problems will only get worse.`,
        question: 'Which conjunction best fits the blank in "Scientists have been studying this phenomenon for decades, _____ they have strong evidence."?',
        options: [
          '① although',
          '② because',
          '③ and',
          '④ since'
        ],
        answer: 3,
        explanation: '문맥상 과학자들이 수십 년간 연구해왔다는 내용과 강력한 증거를 가지고 있다는 내용을 자연스럽게 연결하는 접속사 "and"가 적절합니다.'
      }
    ],
    3: [
      {
        id: 301,
        year: '2023',
        exam: '수능',
        passage: `이차함수는 y = ax² + bx + c (a ≠ 0) 형태로 나타낼 수 있으며, 그래프는 포물선 모양을 이룬다. 이차함수의 최댓값이나 최솟값은 포물선의 꼭짓점에서 나타난다.

이차함수 f(x) = ax² + bx + c에서 a > 0이면 아래로 볼록한 포물선이 되어 최솟값을 가지고, a < 0이면 위로 볼록한 포물선이 되어 최댓값을 가진다.

꼭짓점의 x좌표는 x = -b/2a로 구할 수 있으며, 이 값을 함수에 대입하면 최댓값 또는 최솟값을 구할 수 있다.`,
        question: 'f(x) = -3x² + 12x - 5의 최댓값은?',
        options: [
          '① 5',
          '② 7',
          '③ 9',
          '④ 11'
        ],
        answer: 2,
        explanation: 'a = -3 < 0이므로 최댓값을 가집니다. 꼭짓점의 x좌표는 x = -12/(2×(-3)) = 2입니다. f(2) = -3(4) + 12(2) - 5 = -12 + 24 - 5 = 7입니다.'
      },
      {
        id: 302,
        year: '2022',
        exam: '6월 모의평가',
        passage: `이차함수의 그래프를 이용하면 이차부등식을 쉽게 해결할 수 있다. 이차함수 y = ax² + bx + c의 그래프와 x축의 교점을 구하면, 이것이 이차방정식 ax² + bx + c = 0의 해가 된다.

판별식 D = b² - 4ac의 값에 따라 교점의 개수가 결정된다. D > 0이면 두 개의 서로 다른 실근을 가지고, D = 0이면 중근을 가지며, D < 0이면 실근이 없다.

이차부등식을 풀 때는 이차함수의 그래프를 그려서 x축보다 위에 있는 부분과 아래에 있는 부분을 구분하여 해를 구한다.`,
        question: '이차함수 y = -x² + 6x - 2의 꼭짓점의 y좌표는?',
        options: [
          '① 5',
          '② 6',
          '③ 7',
          '④ 8'
        ],
        answer: 3,
        explanation: '꼭짓점의 x좌표는 x = -6/(2×(-1)) = 3입니다. y = -(3)² + 6(3) - 2 = -9 + 18 - 2 = 7입니다.'
      }
    ]
  };

  const currentProblems = similarProblems[problemId] || [];

  const handleAnswerSelect = (problemId, optionIndex) => {
    setUserAnswers(prev => ({
      ...prev,
      [problemId]: optionIndex
    }));
  };

  const handleSubmitAnswer = (problemId) => {
    setShowResults(prev => ({
      ...prev,
      [problemId]: true
    }));
  };

  const handleShowProblem = (problemId) => {
    setSelectedProblem(selectedProblem === problemId ? null : problemId);
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 relative overflow-hidden ${sparkleEffect ? 'animate-pulse' : ''}`}>
      {/* 밝은 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 구름과 별 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-20">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,20 Q25,5 50,20 T100,20 L100,40 Q75,25 50,40 T0,40 Z" fill="url(#cloudGradient)" />
            <path d="M0,60 Q25,75 50,60 Q75,45 100,60" stroke="#60a5fa" strokeWidth="0.5" fill="none" opacity="0.4"/>
            <path d="M20,0 L20,100 M40,0 L40,100 M60,0 L60,100 M80,0 L80,100" stroke="#a78bfa" strokeWidth="0.3" opacity="0.3"/>
            <circle cx="30" cy="30" r="2" fill="#fbbf24" opacity="0.6"/>
            <circle cx="70" cy="70" r="1.5" fill="#f59e0b" opacity="0.5"/>
            <defs>
              <linearGradient id="cloudGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#60a5fa" stopOpacity="0.4" />
                <stop offset="50%" stopColor="#a78bfa" stopOpacity="0.2" />
                <stop offset="100%" stopColor="#c084fc" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 반짝임 효과 */}
        {starTwinkle && (
          <>
            <div className="absolute top-1/5 left-1/5 w-4 h-4 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full animate-ping opacity-70"></div>
            <div className="absolute top-1/3 right-1/4 w-2 h-2 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full animate-pulse opacity-60"></div>
            <div className="absolute top-2/3 left-3/4 w-3 h-3 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-full animate-bounce opacity-70"></div>
          </>
        )}
        
        {/* 글로우 펄스 */}
        {glowPulse && (
          <div className="absolute inset-0 bg-gradient-to-r from-blue-100/30 to-purple-100/30 animate-pulse"></div>
        )}
        
        {/* 천사 나타남 */}
        {angelAppear && (
          <div className="absolute top-1/3 right-10 w-20 h-32 bg-yellow-200 opacity-40 rounded-full blur-2xl animate-pulse"></div>
        )}
        
        {/* 빛 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-blue-100/30 to-transparent"></div>
        
        {/* 움직이는 빛들 */}
        <div className="absolute top-1/4 left-10 w-32 h-32 bg-blue-300 rounded-full blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-1/3 right-20 w-40 h-40 bg-purple-300 rounded-full blur-3xl opacity-15 animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-2/3 left-1/3 w-24 h-24 bg-pink-300 rounded-full blur-3xl opacity-25 animate-pulse" style={{ animationDelay: '4s' }}></div>
      </div>

      {/* 헤더 - 밝은 스타일 */}
      <div className="bg-white/80 shadow-lg border-b border-blue-200 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToNote}
                className="text-blue-600 hover:text-blue-700 mr-4 transition-all duration-300 transform hover:scale-110"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent ${sparkleEffect ? 'animate-bounce' : ''}`}>
                🔍 유사한 역대 기출문제 - Similar Tests with AI Angel
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          
          {/* 원본 문제 정보 - 밝은 스타일 */}
          {originalProblem.question && (
            <div className="bg-white/90 rounded-3xl shadow-lg p-6 mb-8 border border-blue-200 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-50/50 to-purple-50/50"></div>
              <h2 className="text-lg font-bold text-blue-600 mb-4 relative z-10">📝 원본 오답 문제 - Original Problem</h2>
              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 relative z-10">
                <p className="text-gray-700 font-medium">{originalProblem.question}</p>
                <div className="flex items-center justify-between mt-3">
                  <span className="text-orange-600">⭐ 내 답: <strong>{originalProblem.userAnswer}</strong></span>
                  <span className="text-green-600">✅ 정답: <strong>{originalProblem.correctAnswer}</strong></span>
                </div>
              </div>
              {/* 밝은 장식 */}
              <div className="absolute top-2 right-2 text-blue-500 opacity-70 animate-pulse">⭐</div>
              <div className="absolute bottom-2 left-2 text-purple-500 opacity-50 animate-pulse">✨</div>
            </div>
          )}

          {/* 유사 기출문제 목록 - 밝은 스타일 */}
          <div className="space-y-8">
            {currentProblems.map((problem) => (
              <div key={problem.id} className="bg-white/90 rounded-3xl shadow-lg p-8 border border-purple-200 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-50/20 to-blue-50/20"></div>
                
                {/* 문제 헤더 */}
                <div className="flex items-center justify-between mb-6 relative z-10">
                  <div className="flex items-center space-x-4">
                    <span className="bg-gradient-to-r from-purple-500 to-purple-600 text-white px-4 py-2 rounded-full font-bold shadow-lg shadow-purple-500/30">
                      ⭐ {problem.year}년 {problem.exam}
                    </span>
                    <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium border border-blue-200">
                      📚 기출문제
                    </span>
                  </div>
                  <button
                    onClick={() => handleShowProblem(problem.id)}
                    className={`px-6 py-3 rounded-2xl font-medium transition-all duration-300 transform hover:scale-105 ${
                      selectedProblem === problem.id
                        ? 'bg-gradient-to-r from-purple-500 to-purple-600 text-white shadow-lg shadow-purple-500/30'
                        : 'bg-white/80 text-gray-600 hover:bg-blue-50 border border-gray-200'
                    }`}
                  >
                    {selectedProblem === problem.id ? '✨ 문제 접기' : '⭐ 문제 풀어보기'}
                  </button>
                </div>

                {/* 지문 (있는 경우) - 밝은 스타일 */}
                {problem.passage && (
                  <div className="mb-6 relative z-10">
                    <h4 className="font-bold text-purple-600 mb-3">📄 지문 - Reading Passage</h4>
                    <div className="bg-gray-50 border border-gray-200 rounded-2xl p-6">
                      <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                        {problem.passage}
                      </p>
                    </div>
                  </div>
                )}

                {/* 문제 */}
                <div className="mb-6 relative z-10">
                  <h4 className="font-bold text-orange-600 mb-3">❓ 문제 - Question</h4>
                  <p className="text-lg font-semibold text-orange-700 mb-4">{problem.question}</p>
                </div>

                {/* 선택지 및 풀이 - 밝은 스타일 */}
                {selectedProblem === problem.id && (
                  <div className="space-y-4 relative z-10">
                    <div className="bg-blue-50/80 border border-blue-200 rounded-2xl p-6">
                      <h5 className="font-bold text-blue-700 mb-4">⭐ 선택지 - Choose Your Answer</h5>
                      <div className="space-y-3">
                        {problem.options.map((option, optionIndex) => (
                          <label key={optionIndex} className="flex items-center space-x-3 cursor-pointer hover:bg-blue-100/50 p-2 rounded-xl transition-all duration-300 transform hover:scale-105">
                            <input
                              type="radio"
                              name={`problem-${problem.id}`}
                              value={optionIndex}
                              onChange={() => handleAnswerSelect(problem.id, optionIndex)}
                              className="w-4 h-4 text-blue-600 bg-white border-gray-300 focus:ring-blue-500"
                            />
                            <span className={`text-lg ${
                              showResults[problem.id] && optionIndex === problem.answer - 1
                                ? 'text-green-600 font-bold'
                                : showResults[problem.id] && userAnswers[problem.id] === optionIndex && optionIndex !== problem.answer - 1
                                ? 'text-red-500 font-semibold'
                                : 'text-gray-700'
                            }`}>
                              {option}
                            </span>
                          </label>
                        ))}
                      </div>

                      <div className="flex space-x-3 mt-6">
                        <button
                          onClick={() => handleSubmitAnswer(problem.id)}
                          disabled={userAnswers[problem.id] === undefined}
                          className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-6 py-3 rounded-xl font-medium hover:from-blue-600 hover:to-blue-700 transition-all duration-300 disabled:bg-gray-300 disabled:cursor-not-allowed transform hover:scale-105 shadow-lg hover:shadow-blue-500/30"
                        >
                          ⭐ 정답 확인
                        </button>
                        {showResults[problem.id] && (
                          <div className="flex items-center space-x-2">
                            <span className="text-gray-600">✅ 정답:</span>
                            <span className="font-bold text-green-600">{problem.answer}번</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* 해설 - 밝은 스타일 */}
                    {showResults[problem.id] && (
                      <div className="bg-green-50/80 border border-green-200 rounded-2xl p-6">
                        <h6 className="font-bold text-green-700 mb-3">💡 해설 - Explanation</h6>
                        <p className="text-green-800 leading-relaxed">{problem.explanation}</p>
                      </div>
                    )}
                  </div>
                )}
                
                {/* 밝은 장식 */}
                <div className="absolute top-4 right-4 text-purple-500 opacity-60 animate-pulse">
                  {problem.id % 3 === 0 ? '⭐' : problem.id % 3 === 1 ? '✨' : '💫'}
                </div>
                <div className="absolute bottom-4 left-4 text-blue-500 opacity-50 animate-pulse">🌟</div>
              </div>
            ))}
          </div>

          {/* 문제가 없는 경우 */}
          {currentProblems.length === 0 && (
            <div className="bg-white/90 rounded-3xl shadow-lg p-12 border border-gray-200 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-gray-50/50 to-blue-50/50"></div>
              <div className="relative z-10">
                <div className="text-6xl mb-4 animate-pulse">✨</div>
                <h3 className="text-2xl font-bold text-gray-600 mb-4">유사한 문제를 찾을 수 없습니다</h3>
                <p className="text-gray-500 mb-8">이 문제 유형에 대한 기출문제가 아직 준비되지 않았습니다.</p>
                <button
                  onClick={() => navigate('/wrong-answer-note')}
                  className="bg-gradient-to-r from-purple-500 to-purple-600 text-white px-8 py-4 rounded-2xl font-bold transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-purple-500/30"
                >
                  ⭐ 오답노트로 돌아가기
                </button>
              </div>
            </div>
          )}

          {/* 하단 액션 버튼 - 밝은 스타일 */}
          {currentProblems.length > 0 && (
            <div className="mt-12 flex justify-center space-x-4">
              <button
                onClick={() => navigate('/wrong-answer-note')}
                className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-lg hover:shadow-blue-500/30 transition-all duration-300 transform hover:scale-105 border border-blue-300"
              >
                📚 오답노트로 돌아가기
              </button>
              <button
                onClick={() => navigate('/upload')}
                className="bg-gradient-to-r from-purple-500 to-purple-600 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-lg hover:shadow-purple-500/30 transition-all duration-300 transform hover:scale-105 border border-purple-300"
              >
                📝 새로운 시험지 풀기
              </button>
            </div>
          )}

          {/* 통계 정보 (문제를 푼 경우) */}
          {Object.keys(showResults).length > 0 && (
            <div className="mt-12 bg-white/90 rounded-3xl shadow-lg p-8 border border-orange-200 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-orange-50/50 to-yellow-50/50"></div>
              <div className="text-center relative z-10">
                <h3 className="text-2xl font-bold text-orange-600 mb-6">📊 학습 현황 - Learning Progress</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200">
                    <div className="text-3xl mb-2">🎯</div>
                    <div className="text-2xl font-bold text-blue-600 mb-1">
                      {Object.keys(showResults).filter(key => 
                        userAnswers[key] === currentProblems.find(p => p.id == key)?.answer - 1
                      ).length}
                    </div>
                    <div className="text-sm text-gray-600">정답 문제</div>
                  </div>
                  
                  <div className="bg-purple-50 rounded-2xl p-6 border border-purple-200">
                    <div className="text-3xl mb-2">📊</div>
                    <div className="text-2xl font-bold text-purple-600 mb-1">
                      {Object.keys(showResults).length > 0 ? 
                        Math.round((Object.keys(showResults).filter(key => 
                          userAnswers[key] === currentProblems.find(p => p.id == key)?.answer - 1
                        ).length / Object.keys(showResults).length) * 100) : 0}%
                    </div>
                    <div className="text-sm text-gray-600">정답률</div>
                  </div>
                  
                  <div className="bg-orange-50 rounded-2xl p-6 border border-orange-200">
                    <div className="text-3xl mb-2">📚</div>
                    <div className="text-2xl font-bold text-orange-600 mb-1">
                      {Object.keys(showResults).length}/{currentProblems.length}
                    </div>
                    <div className="text-sm text-gray-600">완료 문제</div>
                  </div>
                </div>
                
                {/* 개별 문제 결과 */}
                <div className="mt-8 bg-gray-50 rounded-2xl p-6 border border-gray-200">
                  <h4 className="font-bold text-gray-700 mb-4">🔍 문제별 결과</h4>
                  <div className="space-y-3">
                    {currentProblems.map(problem => {
                      const isAnswered = showResults[problem.id];
                      const isCorrect = userAnswers[problem.id] === problem.answer - 1;
                      
                      if (!isAnswered) return null;
                      
                      return (
                        <div key={problem.id} className="flex items-center justify-between p-3 bg-white rounded-xl border border-gray-200">
                          <span className="text-gray-700">
                            ⭐ {problem.year}년 {problem.exam}
                          </span>
                          <span className={`font-bold ${isCorrect ? 'text-green-600' : 'text-red-500'}`}>
                            {isCorrect ? '✅ 정답' : '❌ 오답'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
              
              {/* 밝은 장식 */}
              <div className="absolute top-4 right-4 text-orange-500 opacity-70 animate-pulse">📈</div>
              <div className="absolute bottom-4 left-4 text-yellow-500 opacity-50 animate-pulse">🏆</div>
            </div>
          )}

          {/* 추천 학습법 (일부 문제를 푼 경우) */}
          {Object.keys(showResults).length > 0 && Object.keys(showResults).length < currentProblems.length && (
            <div className="mt-8 bg-white/90 rounded-3xl shadow-lg p-8 border border-blue-200 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 to-purple-50/50"></div>
              <div className="relative z-10">
                <h3 className="text-xl font-bold text-blue-600 mb-4">💡 추천 학습법 - Recommended Learning</h3>
                <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200">
                  <div className="space-y-3 text-blue-800">
                    <div>✨ 남은 문제들도 풀어보세요! 더 많은 연습이 실력 향상에 도움됩니다.</div>
                    <div>📚 틀린 문제는 해설을 꼼꼼히 읽어보세요.</div>
                    <div>🎯 비슷한 유형의 문제를 더 찾아서 연습해보세요.</div>
                  </div>
                </div>
              </div>
              
              {/* 밝은 장식 */}
              <div className="absolute top-4 right-4 text-blue-500 opacity-70 animate-pulse">💡</div>
              <div className="absolute bottom-4 left-4 text-purple-500 opacity-50 animate-pulse">📖</div>
            </div>
          )}
        </div>
      </div>

      {/* 밝은 CSS 애니메이션 */}
      <style jsx>{`
        @keyframes bright-pulse {
          0%, 100% { 
            opacity: 0.7;
            transform: scale(1);
          }
          50% { 
            opacity: 1;
            transform: scale(1.05);
          }
        }
        
        @keyframes angel-appear {
          0% { 
            opacity: 0;
            transform: translateY(-20px) scale(0.8);
          }
          50% { 
            opacity: 0.8;
            transform: translateY(0px) scale(1);
          }
          100% { 
            opacity: 0;
            transform: translateY(20px) scale(1.2);
          }
        }
        
        @keyframes sparkle-flow {
          0% { 
            transform: translateY(-100%) scaleY(0);
            opacity: 0;
          }
          20% { 
            transform: translateY(0%) scaleY(1);
            opacity: 1;
          }
          80% { 
            transform: translateY(300%) scaleY(1);
            opacity: 0.8;
          }
          100% { 
            transform: translateY(400%) scaleY(0);
            opacity: 0;
          }
        }
        
        @keyframes light-shimmer {
          0%, 100% { 
            opacity: 0.2;
          }
          50% { 
            opacity: 0.5;
          }
        }
        
        .animate-bright-pulse {
          animation: bright-pulse 3s ease-in-out infinite;
        }
        
        .animate-angel-appear {
          animation: angel-appear 3s ease-in-out;
        }
        
        .animate-sparkle-flow {
          animation: sparkle-flow 2s ease-in-out;
        }
        
        .animate-light-shimmer {
          animation: light-shimmer 4s ease-in-out infinite;
        }
        
        /* 스크롤바 스타일링 */
        ::-webkit-scrollbar {
          width: 12px;
        }
        
        ::-webkit-scrollbar-track {
          background: #f1f5f9;
          border-radius: 6px;
        }
        
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #8b5cf6, #6366f1);
          border-radius: 6px;
          border: 2px solid #f1f5f9;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #7c3aed, #5b21b6);
        }
        
        /* 밝은 글로우 효과 */
        .glow-text {
          position: relative;
        }
        
        .glow-text::before,
        .glow-text::after {
          content: attr(data-text);
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
        }
        
        .glow-text::before {
          animation: glow-1 1s infinite;
          color: #60a5fa;
          z-index: -1;
        }
        
        .glow-text::after {
          animation: glow-2 1s infinite;
          color: #a78bfa;
          z-index: -2;
        }
        
        @keyframes glow-1 {
          0%, 14%, 15%, 49%, 50%, 99%, 100% {
            transform: translate(0, 0);
            opacity: 0.5;
          }
          15%, 49% {
            transform: translate(-1px, 0);
            opacity: 0.8;
          }
        }
        
        @keyframes glow-2 {
          0%, 20%, 21%, 62%, 63%, 99%, 100% {
            transform: translate(0, 0);
            opacity: 0.3;
          }
          21%, 62% {
            transform: translate(1px, 0);
            opacity: 0.6;
          }
        }
        
        /* 부드러운 호버 효과 */
        .hover-lift {
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .hover-lift:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        
        /* 성공 애니메이션 */
        @keyframes success-bounce {
          0%, 20%, 60%, 100% {
            transform: translateY(0);
          }
          40% {
            transform: translateY(-10px);
          }
          80% {
            transform: translateY(-3px);
          }
        }
        
        .animate-success-bounce {
          animation: success-bounce 1s ease-in-out;
        }
        
        /* 오답 흔들림 효과 */
        @keyframes shake {
          0%, 100% {
            transform: translateX(0);
          }
          10%, 30%, 50%, 70%, 90% {
            transform: translateX(-2px);
          }
          20%, 40%, 60%, 80% {
            transform: translateX(2px);
          }
        }
        
        .animate-shake {
          animation: shake 0.6s ease-in-out;
        }
        
        /* 별빛 트윙클 효과 */
        @keyframes twinkle {
          0%, 100% {
            opacity: 0.3;
            transform: scale(1);
          }
          25% {
            opacity: 1;
            transform: scale(1.2);
          }
          50% {
            opacity: 0.6;
            transform: scale(0.8);
          }
          75% {
            opacity: 1;
            transform: scale(1.1);
          }
        }
        
        .animate-twinkle {
          animation: twinkle 2s ease-in-out infinite;
        }
        
        /* 그라데이션 애니메이션 */
        @keyframes gradient-shift {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }
        
        .animate-gradient {
          background-size: 200% 200%;
          animation: gradient-shift 3s ease infinite;
        }
        
        /* 카드 플립 효과 */
        .flip-card {
          perspective: 1000px;
        }
        
        .flip-card-inner {
          position: relative;
          width: 100%;
          height: 100%;
          text-align: center;
          transition: transform 0.6s;
          transform-style: preserve-3d;
        }
        
        .flip-card:hover .flip-card-inner {
          transform: rotateY(180deg);
        }
        
        .flip-card-front, .flip-card-back {
          position: absolute;
          width: 100%;
          height: 100%;
          -webkit-backface-visibility: hidden;
          backface-visibility: hidden;
        }
        
        .flip-card-back {
          transform: rotateY(180deg);
        }
        
        /* 파티클 효과 */
        @keyframes particle-float {
          0% {
            transform: translateY(0px) rotate(0deg);
            opacity: 1;
          }
          100% {
            transform: translateY(-100px) rotate(360deg);
            opacity: 0;
          }
        }
        
        .animate-particle {
          animation: particle-float 3s linear infinite;
        }
        
        /* 웨이브 효과 */
        @keyframes wave {
          0% {
            transform: translateX(-100%);
          }
          100% {
            transform: translateX(100%);
          }
        }
        
        .animate-wave {
          animation: wave 2s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}