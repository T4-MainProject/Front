// ============================================
// src/components/MyPageModal.jsx - 마이페이지 모달
// ============================================
// 📱 주요 기능:
// - 사용자 정보 표시
// - 프로필 편집
// - 통계 정보 표시
// - 반응형 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { userRoles, memberTiers, pointsSystem, calculateUserTier, saveUserToStorage } from '../data/dummyUsers';

export default function MyPageModal({ isOpen, onClose, currentUser, onUserUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    school: ''
  });

  // 모달이 열릴 때 사용자 정보로 초기화
  useEffect(() => {
    if (currentUser) {
      setFormData({
        name: currentUser.name || '',
        phone: currentUser.phone || '',
        address: currentUser.address || '',
        school: currentUser.school || ''
      });
    }
  }, [currentUser]);

  // 모달이 열릴 때 body 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.keyCode === 27) onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    // 원래 데이터로 복원
    setFormData({
      name: currentUser.name || '',
      phone: currentUser.phone || '',
      address: currentUser.address || '',
      school: currentUser.school || ''
    });
  };

  const handleSave = () => {
    const updatedUser = {
      ...currentUser,
      ...formData
    };
    
    // 로컬 스토리지 업데이트
    saveUserToStorage(updatedUser);
    
    // 부모 컴포넌트에 업데이트 알림
    onUserUpdate(updatedUser);
    
    setIsEditing(false);
    alert('정보가 성공적으로 업데이트되었습니다!');
  };

  if (!isOpen || !currentUser) return null;

  const roleInfo = userRoles[currentUser.role] || userRoles.student;
  const joinDate = new Date(currentUser.joinDate).toLocaleDateString('ko-KR');
  
  // 회원등급 정보
  const currentTier = currentUser.role === 'admin' ? 'admin' : (currentUser.tier || calculateUserTier(currentUser.points || 0));
  const tierInfo = memberTiers[currentTier];
  const nextTier = currentTier === 'individual' ? 'pro' : 
                   currentTier === 'pro' ? 'proplus' : 
                   currentTier === 'proplus' ? 'ultra' : null;
  const nextTierInfo = nextTier ? memberTiers[nextTier] : null;
  
  // 포인트 및 등급 진행도
  const currentPoints = currentUser.points || 0;
  const pointsToNext = nextTierInfo ? nextTierInfo.pointsRequired - currentPoints : 0;
  const progressPercentage = nextTierInfo ? 
    ((currentPoints - tierInfo.pointsRequired) / (nextTierInfo.pointsRequired - tierInfo.pointsRequired)) * 100 : 100;

  // 일일 업로드 사용량 체크
  const today = new Date().toDateString();
  const hasResetToday = currentUser.dailyUploadsReset === today;
  const dailyUploadsUsed = hasResetToday ? (currentUser.dailyUploadsUsed || 0) : 0;
  const dailyUploadsRemaining = Math.max(0, tierInfo.dailyUploads - dailyUploadsUsed);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* 배경 오버레이 */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 transition-opacity duration-300"
        onClick={onClose}
      />
      
      {/* 모달 컨테이너 */}
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl transform transition-all duration-300 modal-enter">
          {/* 닫기 버튼 */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors duration-200 z-10"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          {/* 헤더 */}
          <div className="px-8 pt-8 pb-6">
            <div className="text-center mb-6">
              <div className="w-20 h-20 rounded-full overflow-hidden mx-auto mb-4 shadow-lg ring-4 ring-blue-100">
                <img 
                  src={currentUser.avatar} 
                  alt={currentUser.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">{currentUser.name}</h2>
              <div className="flex items-center justify-center space-x-2 mb-4">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  roleInfo.color === 'red' ? 'bg-red-100 text-red-600' :
                  roleInfo.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                  roleInfo.color === 'green' ? 'bg-green-100 text-green-600' :
                  'bg-purple-100 text-purple-600'
                }`}>
                  {roleInfo.name}
                </span>
                <span className="text-gray-500 text-sm">가입일: {joinDate}</span>
              </div>
            </div>

            {/* 회원등급 및 포인트 정보 */}
            <div className={`${tierInfo.bgColor} ${tierInfo.borderColor} border-2 rounded-2xl p-6 mb-6`}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <span className="text-3xl">{tierInfo.icon}</span>
                  <div>
                    <h3 className={`text-xl font-bold ${tierInfo.textColor}`}>{tierInfo.name}</h3>
                    <p className="text-sm text-gray-600">회원등급</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-blue-600">{currentPoints.toLocaleString()}</div>
                  <div className="text-sm text-gray-600">포인트</div>
                </div>
              </div>

              {/* 등급 진행도 */}
              {nextTierInfo && (
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-600">다음 등급까지</span>
                    <span className="font-medium">{pointsToNext.toLocaleString()}P 남음</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(100, Math.max(0, progressPercentage))}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-xs mt-1 text-gray-500">
                    <span>{tierInfo.name}</span>
                    <span>{nextTierInfo.name} {nextTierInfo.icon}</span>
                  </div>
                </div>
              )}

              {/* 일일 업로드 제한 */}
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">일일 업로드</span>
                <span className={`font-medium ${dailyUploadsRemaining > 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {dailyUploadsRemaining > 999 ? '무제한' : `${dailyUploadsRemaining}회 남음`}
                </span>
              </div>
            </div>
          </div>

          {/* 학습 통계 대시보드 */}
          <div className="px-8 pb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">📊 학습 통계</h3>
            
            {/* 주요 지표 */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-blue-600">{currentUser.loginCount || 0}</div>
                <div className="text-sm text-gray-600">로그인 횟수</div>
              </div>
              <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {currentUser.examHistory?.totalExams || 0}
                </div>
                <div className="text-sm text-gray-600">시험 완료</div>
              </div>
              <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-green-600">
                  {currentUser.examHistory?.averageScore || 0}점
                </div>
                <div className="text-sm text-gray-600">전체 평균</div>
              </div>
              <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-orange-600">
                  {currentUser.examHistory?.recentScores?.length ? 
                    Math.max(...currentUser.examHistory.recentScores) : 0}점
                </div>
                <div className="text-sm text-gray-600">최고 점수</div>
              </div>
            </div>

            {/* 과목별 성과 */}
            {currentUser.examHistory?.subjectScores && (
              <div className="bg-gray-50 rounded-xl p-6 mb-6">
                <h4 className="font-semibold text-gray-800 mb-4">📚 과목별 성과</h4>
                <div className="space-y-4">
                  {Object.entries(currentUser.examHistory.subjectScores).map(([subject, data]) => {
                    const subjectName = subject === 'korean' ? '국어' : 
                                       subject === 'english' ? '영어' : '수학';
                    const percentage = data.average || 0;
                    const color = subject === 'korean' ? 'blue' : 
                                 subject === 'english' ? 'green' : 'purple';
                    
                    return (
                      <div key={subject}>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="font-medium">{subjectName}</span>
                          <span className="text-gray-600">{data.total}회 응시 • 평균 {data.average}점</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`bg-${color}-500 h-2 rounded-full transition-all duration-500`}
                            style={{ width: `${percentage}%` }}
                          ></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 최근 성적 추이 */}
            {currentUser.examHistory?.recentScores?.length > 0 && (
              <div className="bg-white border rounded-xl p-6">
                <h4 className="font-semibold text-gray-800 mb-4">📈 최근 성적 추이</h4>
                <div className="flex items-end justify-between h-32 space-x-2">
                  {currentUser.examHistory.recentScores.map((score, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center">
                      <div 
                        className="w-full bg-gradient-to-t from-blue-500 to-blue-300 rounded-t transition-all duration-500 hover:from-blue-600 hover:to-blue-400"
                        style={{ height: `${(score / 100) * 100}%` }}
                      ></div>
                      <div className="text-xs font-medium text-gray-600 mt-2">{score}점</div>
                      <div className="text-xs text-gray-400">{index + 1}회</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 회원등급 혜택 */}
          <div className="px-8 pb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">🎁 {tierInfo.name} 등급 혜택</h3>
            <div className="bg-white border rounded-xl p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium text-gray-800 mb-3">현재 혜택</h4>
                  <ul className="space-y-2">
                    {tierInfo.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <svg className="w-4 h-4 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
                
                {nextTierInfo && (
                  <div>
                    <h4 className="font-medium text-gray-800 mb-3">
                      {nextTierInfo.name} 등급 승급시 추가 혜택
                    </h4>
                    <ul className="space-y-2">
                      {nextTierInfo.features.filter(f => !tierInfo.features.includes(f)).map((feature, index) => (
                        <li key={index} className="flex items-center text-sm text-gray-600">
                          <svg className="w-4 h-4 text-blue-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                          </svg>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                      <p className="text-sm text-blue-800">
                        <span className="font-medium">{pointsToNext.toLocaleString()}포인트</span> 더 모으면 승급됩니다!
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 사용자 정보 */}
          <div className="px-8 pb-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">👤 개인정보</h3>
              {!isEditing ? (
                <button
                  onClick={handleEdit}
                  className="text-blue-600 hover:text-blue-800 font-medium text-sm flex items-center"
                >
                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                  편집
                </button>
              ) : (
                <div className="flex space-x-2">
                  <button
                    onClick={handleCancel}
                    className="text-gray-600 hover:text-gray-800 font-medium text-sm px-3 py-1 rounded border"
                  >
                    취소
                  </button>
                  <button
                    onClick={handleSave}
                    className="bg-blue-600 text-white font-medium text-sm px-3 py-1 rounded hover:bg-blue-700"
                  >
                    저장
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 이메일 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  이메일
                </label>
                <input
                  type="email"
                  value={currentUser.email}
                  disabled
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-500"
                />
              </div>

              {/* 이름 */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  이름
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 ${
                    isEditing 
                      ? 'border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
                />
              </div>

              {/* 전화번호 */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  전화번호
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 ${
                    isEditing 
                      ? 'border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
                />
              </div>

              {/* 학교 */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  학교
                </label>
                <input
                  type="text"
                  name="school"
                  value={formData.school}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 ${
                    isEditing 
                      ? 'border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
                />
              </div>

              {/* 주소 */}
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  주소
                </label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 ${
                    isEditing 
                      ? 'border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
                />
              </div>

              {/* 생년월일 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  생년월일
                </label>
                <input
                  type="date"
                  value={currentUser.birthDate}
                  disabled
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-500"
                />
              </div>

              {/* 역할 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  역할
                </label>
                <input
                  type="text"
                  value={roleInfo.name}
                  disabled
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-500"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
} 