// ============================================
// src/pages/GradingProgress.jsx - 채점 대기 페이지
// ============================================
// 📊 주요 기능:
// - 채점 상태 추적 (대기중 → 채점 완료)
// - 실시간 카운트다운 타이머
// - 진행률 표시 (0% → 100%)
// - 서비스 소개 슬라이드
// - 반응형 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

export default function GradingProgress() {
  // 🧭 라우터 훅
  const location = useLocation();
  const navigate = useNavigate();
  
  // 📝 업로드된 데이터
  const uploadData = location.state?.uploadData;

  // 📊 상태 관리
  const [status, setStatus] = useState('대기중'); // '대기중' | '처리중' | '채점 완료'
  const [progress, setProgress] = useState(0); // 진행률 (0-100)
  const [timeLeft, setTimeLeft] = useState(2); // 남은 시간 (초)
  const [currentSlide, setCurrentSlide] = useState(0); // 현재 슬라이드 인덱스

  // 🎯 서비스 소개 슬라이드 데이터
  const serviceSlides = [
    {
      title: "🤖 AI 기반 자동 채점",
      description: "YOLO8 객체 인식 기술로 답안을 정확하게 인식하고 분석합니다",
      features: [
        "99.8% 정확도의 답안 인식",
        "실시간 채점 처리",
        "다양한 문제 유형 지원"
      ],
      color: "from-blue-500 to-cyan-500"
    },
    {
      title: "📝 OCR 텍스트 추출",
      description: "첨단 OCR 기술로 손글씨까지 정확하게 인식합니다",
      features: [
        "고화질 텍스트 인식",
        "다양한 폰트 지원",
        "손글씨 인식 가능"
      ],
      color: "from-purple-500 to-pink-500"
    },
    {
      title: "💡 GPT 해설 생성",
      description: "AI가 자동으로 상세한 해설과 피드백을 제공합니다",
      features: [
        "맞춤형 해설 생성",
        "오답 원인 분석",
        "학습 개선 제안"
      ],
      color: "from-green-500 to-teal-500"
    },
    {
      title: "⚡ 빠른 처리 속도",
      description: "평균 2초 만에 채점 결과를 확인할 수 있습니다",
      features: [
        "초고속 처리 엔진",
        "실시간 결과 제공",
        "대용량 파일 지원"
      ],
      color: "from-orange-500 to-red-500"
    }
  ];

  // ⏰ 타이머 및 진행률 관리
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          setStatus('채점 완료');
          setProgress(100);
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });

      // 진행률 업데이트 (2초 기준)
      setProgress(prev => {
        const newProgress = ((2 - timeLeft + 1) / 2) * 100;
        return Math.min(newProgress, 100);
      });

      // 상태 업데이트
      if (timeLeft <= 1 && timeLeft > 0) {
        setStatus('처리중');
      } else if (timeLeft <= 0) {
        setStatus('채점 완료');
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  // 🎠 슬라이드 자동 전환
  useEffect(() => {
    const slideTimer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % serviceSlides.length);
    }, 4000); // 4초마다 슬라이드 변경

    return () => clearInterval(slideTimer);
  }, [serviceSlides.length]);

  // 🏠 홈으로 돌아가기
  const handleBackToHome = () => {
    navigate('/');
  };

  // 📊 결과 보기 (채점 완료 시)
  const handleViewResults = () => {
    navigate('/grading-result', { 
      state: { 
        ...uploadData,
        score: 87,
        totalQuestions: 20,
        correctAnswers: 17,
        timeSpent: '25분 30초'
      }
    });
  };

  // 업로드 데이터가 없으면 홈으로 리다이렉트
  if (!uploadData) {
    navigate('/');
    return null;
  }

  // ⏰ 시간 포맷팅
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 📊 상태별 아이콘
  const getStatusIcon = () => {
    switch (status) {
      case '대기중':
        return (
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-blue-500 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
        );
      case '처리중':
        return (
          <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-purple-500 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </div>
        );
      case '채점 완료':
        return (
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* 헤더 */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToHome}
                className="text-gray-600 hover:text-gray-800 mr-4 transition-colors duration-200"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AI 채점 진행 중
              </h1>
            </div>
            
            {/* 진행률 표시 */}
            <div className="hidden md:flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                진행률: <span className="font-bold text-blue-600">{Math.round(progress)}%</span>
              </div>
              <div className="text-sm text-gray-600">
                남은 시간: <span className="font-bold text-purple-600">{formatTime(timeLeft)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* 왼쪽: 진행 상황 */}
            <div className="space-y-6">
              {/* 과목/학년 정보 카드 */}
              <div className="bg-white rounded-3xl shadow-xl p-6 border border-gray-100">
                <h3 className="text-lg font-semibold text-gray-800 mb-4 text-center">시험 정보</h3>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                    <span className="text-gray-600 text-sm">과목:</span>
                    <span className="font-medium text-gray-800 ml-2">{uploadData.subject}</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                    <span className="text-gray-600 text-sm">학년:</span>
                    <span className="font-medium text-gray-800 ml-2">{uploadData.grade}</span>
                  </div>
                  {uploadData.examType && (
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-purple-500 rounded-full mr-3"></div>
                      <span className="text-gray-600 text-sm">시험 유형:</span>
                      <span className="font-medium text-gray-800 ml-2">{uploadData.examType}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* 채점 진행 상황 통합 카드 */}
              <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
                <h3 className="text-xl font-bold text-gray-800 mb-6 text-center">채점 진행 상황</h3>
                
                {/* 상태, 시간, 진행률 테이블 */}
                <div className="space-y-6">
                  {/* 상태 섹션 */}
                  <div className="text-center border-b border-gray-100 pb-6">
                    <div className="flex justify-center mb-4">
                      {getStatusIcon()}
                    </div>
                    <h2 className="text-2xl font-bold text-gray-800 mb-2">
                      {status}
                    </h2>
                    <p className="text-gray-600">
                      {status === '대기중' && 'AI 채점 시스템이 시험지를 분석하고 있습니다'}
                      {status === '처리중' && 'YOLO8과 OCR이 답안을 인식하고 있습니다'}
                      {status === '채점 완료' && '모든 채점이 완료되었습니다!'}
                    </p>
                  </div>

                  {/* 시간 & 진행률 테이블 */}
                  <div className="grid grid-cols-2 gap-6">
                    {/* 남은 시간 */}
                    <div className="text-center">
                      <h4 className="text-sm font-semibold text-gray-600 mb-2">남은 시간</h4>
                      <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                        {formatTime(timeLeft)}
                      </div>
                      <p className="text-gray-500 text-xs mt-1">예상 완료시간</p>
                    </div>

                    {/* 진행률 */}
                    <div className="text-center">
                      <h4 className="text-sm font-semibold text-gray-600 mb-2">진행률</h4>
                      <div className="text-3xl font-bold text-blue-600">
                        {Math.round(progress)}%
                      </div>
                      <p className="text-gray-500 text-xs mt-1">처리 완료도</p>
                    </div>
                  </div>

                  {/* 진행률 바 */}
                  <div className="pt-4">
                    <div className="w-full bg-gray-200 rounded-full h-4 mb-4">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-purple-500 h-4 rounded-full transition-all duration-1000 relative overflow-hidden"
                        style={{ width: `${progress}%` }}
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent transform -skew-x-12 animate-pulse"></div>
                      </div>
                    </div>

                    {/* 진행 상태 */}
                    <div className="text-center">
                      {status === '대기중' && (
                        <div className="bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-medium">
                          파일 업로드 중입니다.
                        </div>
                      )}
                      {status === '처리중' && (
                        <div className="bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-medium">
                          파일 업로드 완료되었습니다.
                        </div>
                      )}
                      {status === '채점 완료' && (
                        <div className="bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-medium">
                          채점 결과 보기를 확인하세요
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* 완료 버튼 */}
              {status === '채점 완료' && (
                <div className="text-center">
                  <button
                    onClick={handleViewResults}
                    className="bg-gradient-to-r from-green-600 to-blue-600 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
                  >
                    📊 채점 결과 보기
                  </button>
                </div>
              )}
            </div>

            {/* 오른쪽: 서비스 소개 슬라이드 */}
            <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
              <div className="p-6 border-b border-gray-100">
                <h3 className="text-xl font-bold text-gray-800">
                  LangCheck 서비스 소개
                </h3>
                <p className="text-gray-600 text-sm mt-1">
                  AI 기반 자동 채점의 특징을 알아보세요
                </p>
              </div>

              {/* 슬라이드 컨테이너 */}
              <div className="relative h-96 overflow-hidden">
                {serviceSlides.map((slide, index) => (
                  <div
                    key={index}
                    className={`absolute inset-0 transition-transform duration-500 ease-in-out ${
                      index === currentSlide ? 'translate-x-0' : 
                      index < currentSlide ? '-translate-x-full' : 'translate-x-full'
                    }`}
                  >
                    <div className={`h-full bg-gradient-to-br ${slide.color} p-8 text-white`}>
                      <div className="flex flex-col justify-center h-full">
                        <h4 className="text-2xl font-bold mb-4">{slide.title}</h4>
                        <p className="text-lg mb-6 text-white/90">{slide.description}</p>
                        
                        <div className="space-y-3">
                          {slide.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center">
                              <div className="w-2 h-2 bg-white/80 rounded-full mr-3"></div>
                              <span className="text-white/90">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* 슬라이드 인디케이터 */}
              <div className="flex justify-center space-x-2 p-4 bg-gray-50">
                {serviceSlides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-200 ${
                      index === currentSlide ? 'bg-blue-500' : 'bg-gray-300 hover:bg-gray-400'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* 하단 업로드 정보 */}
          <div className="mt-8 bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <h4 className="text-lg font-semibold text-gray-800 mb-4">업로드된 파일 정보</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <span className="text-gray-500">파일명:</span>
                <p className="font-medium truncate">{uploadData.fileName}</p>
              </div>
              <div>
                <span className="text-gray-500">크기:</span>
                <p className="font-medium">{(uploadData.fileSize / 1024 / 1024).toFixed(2)} MB</p>
              </div>
              <div>
                <span className="text-gray-500">과목:</span>
                <p className="font-medium">{uploadData.subject}</p>
              </div>
              <div>
                <span className="text-gray-500">학년:</span>
                <p className="font-medium">{uploadData.grade}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
} 