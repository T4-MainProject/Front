// ============================================
// 💀 Dark Horror TopBar.jsx - 어둠의 상단 공지
// ============================================
// src/components/TopBar.jsx

import React from 'react';

export default function TopBar() {
  return (
    <div className="bg-gradient-to-r from-red-900/80 via-black to-red-900/80 border-b border-red-800/50 relative overflow-hidden">
      {/* 어둠의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-red-900/40 to-black/60"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_70%,black_100%)]"></div>
      
      {/* 움직이는 어둠 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1 left-1/4 w-1 h-1 bg-red-500/40 rounded-full animate-pulse"></div>
        <div className="absolute top-2 right-1/3 w-1 h-1 bg-red-400/30 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-1 left-1/2 w-1 h-1 bg-gray-500/30 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-red-600/40 rounded-full animate-pulse delay-500"></div>
      </div>

      <div className="container mx-auto px-4 py-2 text-center relative z-10">
        <div className="flex items-center justify-center space-x-2 text-sm">
          <span className="animate-pulse text-red-500 drop-shadow-lg">🔥</span>
          <span className="font-medium text-red-400 drop-shadow-sm">
            지옥 서비스 개방! AI 자동 심판을 무료로 체험해보세요
          </span>
          <span className="animate-pulse text-red-500 drop-shadow-lg">💀</span>
        </div>
      </div>

      {/* 하단 어둠 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-red-600/50 to-transparent"></div>
    </div>
  );
}