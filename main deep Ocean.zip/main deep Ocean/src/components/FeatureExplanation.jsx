// ============================================
// 🌊 Deep Ocean FeatureExplanation.jsx - 심해 기능 설명
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const features = [
  { 
    icon: '👁️', 
    title: 'YOLO8 심해의 눈', 
    description: '시험지에서 학습/성장란 영역 자동 탐지로 정확한 바다 분석', 
    accent: 'from-indigo-600 to-cyan-600',
    bgColor: 'from-slate-900/70 to-slate-800/90'
  },
  { 
    icon: '🔮', 
    title: 'OCR 바다 추출', 
    description: 'Vision OCR로 학습자의 답안 정확히 추출하여 심해 세계 디지털화', 
    accent: 'from-blue-600 to-cyan-600',
    bgColor: 'from-indigo-900/80 to-blue-900/90'
  },
  { 
    icon: '🌊', 
    title: 'GPT 바다 생성', 
    description: '오답 단계별 바다 및 개인 맞춤형 심해 피드백 자동 제공', 
    accent: 'from-cyan-600 to-teal-600',
    bgColor: 'from-blue-900/70 to-slate-800/80'
  },
];

export default function FeatureExplanation() {
  const sectionRef = useRef(null);
  const cardsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 🌊 카드들 순차 애니메이션 (심해 느낌으로)
      cardsRef.current.forEach((card, index) => {
        if (card) {
          gsap.fromTo(card, 
            { 
              y: 150, 
              opacity: 0, 
              scale: 0.6,
              rotationY: -60,
              rotationX: 30,
              filter: "blur(15px)"
            },
            {
              y: 0,
              opacity: 1,
              scale: 1,
              rotationY: 0,
              rotationX: 0,
              filter: "blur(0px)",
              duration: 1.2,
              ease: "power4.out",
              scrollTrigger: {
                trigger: card,
                start: "top 80%",
                end: "bottom 20%",
                toggleActions: "play none none reverse"
              },
              delay: index * 0.3
            }
          );

          // 🌊 호버 애니메이션 (심해 효과)
          card.addEventListener('mouseenter', () => {
            gsap.to(card, {
              y: -20,
              scale: 1.08,
              rotationX: 10,
              duration: 0.5,
              ease: "power3.out"
            });
          });

          card.addEventListener('mouseleave', () => {
            gsap.to(card, {
              y: 0,
              scale: 1,
              rotationX: 0,
              duration: 0.5,
              ease: "power3.out"
            });
          });
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-br from-slate-900 via-indigo-900 to-blue-950 overflow-hidden relative">
      {/* 🌊 심해 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900/90 via-indigo-900/70 to-blue-900/80"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(30,64,175,0.2)_0%,rgba(15,23,42,0.8)_50%,rgba(30,58,138,0.15)_80%)]"></div>
      
      {/* 🐠 흩날리는 바다 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-4 h-4 bg-blue-400/50 rounded-full animate-pulse shadow-lg shadow-blue-500/50 transform rotate-45"></div>
        <div className="absolute top-32 right-1/3 w-3 h-3 bg-cyan-400/60 rounded-full animate-pulse delay-700 shadow-lg shadow-cyan-500/50 transform rotate-12"></div>
        <div className="absolute bottom-24 left-1/2 w-3 h-3 bg-indigo-400/50 rounded-full animate-pulse delay-1000 shadow-lg shadow-indigo-500/50 transform -rotate-12"></div>
        <div className="absolute top-1/2 right-1/4 w-3 h-3 bg-teal-500/60 rounded-full animate-pulse delay-500 shadow-lg shadow-teal-500/50"></div>
        <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-blue-300/50 rounded-full animate-pulse delay-1500 shadow-lg shadow-blue-400/50 transform rotate-45"></div>
        <div className="absolute top-20 right-1/5 w-2 h-2 bg-cyan-300/40 rounded-full animate-pulse delay-300 shadow-lg shadow-cyan-400/50 transform -rotate-30"></div>
      </div>

      {/* 🐙 장식 산고 */}
      <div className="absolute top-24 right-12 opacity-20">
        <svg width="80" height="120" viewBox="0 0 80 120">
          <path d="M40 120 L40 60 M20 60 Q40 40 60 60 M15 55 Q40 35 65 55" stroke="#3b82f6" strokeWidth="3" fill="none"/>
          <circle cx="40" cy="50" r="8" fill="#1e40af"/>
          <path d="M32 50 Q20 35 8 40 M48 50 Q60 35 72 40" stroke="#2563eb" strokeWidth="2" fill="none"/>
          {/* 바다 생물들 */}
          <circle cx="25" cy="45" r="3" fill="#0891b2"/>
          <circle cx="55" cy="48" r="3" fill="#0891b2"/>
          <circle cx="35" cy="40" r="2" fill="#22d3ee"/>
          <circle cx="45" cy="42" r="2" fill="#22d3ee"/>
          <circle cx="30" cy="55" r="2" fill="#0891b2"/>
          <circle cx="50" cy="58" r="2" fill="#0891b2"/>
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* 🌊 헤더 */}
        <div className="text-center mb-16" data-aos="fade-up">
          <div className="inline-flex items-center space-x-3 bg-slate-800/50 backdrop-blur-md border border-slate-700/60 text-cyan-300 px-6 py-3 rounded-full text-sm font-bold mb-6 shadow-lg shadow-indigo-500/40 hover:shadow-xl hover:shadow-cyan-500/60 transition-all duration-300 hover:scale-105">
            <span>🌊</span>
            <span>심해 기술</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-cyan-300 mb-6 drop-shadow-2xl">
            심해 기술의 
            <span className="bg-gradient-to-r from-cyan-300 to-blue-300 bg-clip-text text-transparent"> 완벽한 조화</span>
          </h2>
          <p className="text-xl text-cyan-200 max-w-3xl mx-auto leading-relaxed drop-shadow-lg backdrop-blur-sm bg-slate-800/40 rounded-2xl p-6 border border-slate-700/60">
            최첨단 바다 기술들이 푸른 물결처럼 결합되어 <br className="hidden md:block" />
            정확하고 빠른 자동 학습 지원 서비스를 제공합니다
          </p>
        </div>

        {/* 🌊 기능 카드들 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {features.map((feature, index) => (
            <div 
              key={index}
              ref={el => cardsRef.current[index] = el}
              data-aos="fade-up" 
              data-aos-delay={index * 200}
              className={`relative group p-8 rounded-3xl bg-gradient-to-br ${feature.bgColor} backdrop-blur-md border border-slate-700/60 shadow-2xl shadow-indigo-500/30 hover:shadow-3xl hover:shadow-cyan-500/50 transition-all duration-500 cursor-pointer overflow-hidden`}
            >
              {/* 🐠 배경 글로우 */}
              <div className={`absolute inset-0 bg-gradient-to-br ${feature.accent} opacity-0 group-hover:opacity-25 transition-opacity duration-500 rounded-3xl`}></div>
              
              {/* 🌊 추가 심해 레이어 */}
              <div className="absolute inset-0 bg-gradient-to-br from-slate-800/80 via-indigo-900/50 to-blue-900/60 rounded-3xl"></div>
              
              {/* 🐠 바다 파티클들 */}
              <div className="absolute top-4 right-4 w-4 h-4 bg-blue-400/60 rounded-full animate-pulse shadow-lg shadow-blue-500/50 transform rotate-45"></div>
              <div className="absolute bottom-6 left-6 w-3 h-3 bg-cyan-400/70 rounded-full animate-ping shadow-lg shadow-cyan-500/50 transform rotate-12"></div>
              <div className="absolute top-1/2 right-8 w-3 h-3 bg-indigo-400/60 rounded-full animate-bounce shadow-lg shadow-indigo-500/50 transform -rotate-12"></div>
              
              {/* 🌊 아이콘 */}
              <div className="relative z-10 text-center mb-6">
                <div className="inline-flex items-center justify-center w-24 h-24 bg-slate-800/70 backdrop-blur-md rounded-3xl shadow-2xl shadow-indigo-500/60 group-hover:shadow-3xl group-hover:shadow-cyan-500/80 transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 border border-slate-700/70">
                  <span className="text-5xl drop-shadow-2xl">{feature.icon}</span>
                </div>
              </div>
              
              {/* 🌊 콘텐츠 */}
              <div className="relative z-10 text-center">
                <h3 className="text-2xl font-bold text-cyan-300 mb-4 group-hover:text-cyan-100 transition-colors duration-300 drop-shadow-lg">
                  {feature.title}
                </h3>
                <p className="text-cyan-200 leading-relaxed group-hover:text-cyan-100 transition-colors duration-300 drop-shadow-sm">
                  {feature.description}
                </p>
              </div>

              {/* 🌊 하단 바다 액센트 */}
              <div className={`absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r ${feature.accent} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 shadow-lg shadow-indigo-500/60`}></div>
              
              {/* 🐙 추가 심해 효과 */}
              <div className="absolute inset-0 rounded-3xl border border-slate-700/70 group-hover:border-cyan-400/70 transition-colors duration-300"></div>
              
              {/* 🐠 중앙 글로우 */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-gradient-radial from-cyan-300/25 via-blue-300/15 to-transparent rounded-full blur-3xl opacity-0 group-hover:opacity-70 transition-opacity duration-700"></div>
            </div>
          ))}
        </div>

        {/* 🌊 프로세스 플로우 */}
        <div className="mt-20 pt-16 border-t border-slate-700/60" data-aos="fade-up" data-aos-delay="600">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-cyan-300 mb-4 drop-shadow-lg">
              <span className="bg-gradient-to-r from-cyan-300 to-blue-300 bg-clip-text text-transparent">3단계</span> 
              심해 과정
            </h3>
            <p className="text-cyan-200 text-lg drop-shadow-sm backdrop-blur-sm bg-slate-800/40 rounded-xl p-4 border border-slate-700/60 inline-block">간단하고 빠른 자동 학습 지원 프로세스</p>
          </div>
          
          <div className="flex flex-col md:flex-row items-center justify-center space-y-8 md:space-y-0 md:space-x-12">
            {[
              { step: 1, title: '학습 업로드', desc: '시험지 바다 촬영', icon: '📤', color: 'indigo' },
              { step: 2, title: 'AI 심해 분석', desc: '자동 인식 및 바다화', icon: '🌊', color: 'cyan' },
              { step: 3, title: '바다 결과 제공', desc: '점수 및 심해 해설', icon: '🐠', color: 'blue' }
            ].map((process, index) => (
              <div key={index} className="flex flex-col items-center relative">
                <div className={`w-20 h-20 bg-gradient-to-br from-indigo-600 to-cyan-600 rounded-3xl flex items-center justify-center text-cyan-100 font-bold text-2xl mb-4 shadow-2xl shadow-indigo-500/60 hover:shadow-3xl hover:shadow-cyan-500/80 transition-all duration-300 hover:scale-110 border-2 border-slate-700/60 backdrop-blur-sm`}>
                  {process.step}
                </div>
                
                <div className="text-center mb-4 bg-slate-800/40 backdrop-blur-sm rounded-2xl p-4 border border-slate-700/60">
                  <div className="text-4xl mb-3 drop-shadow-lg">{process.icon}</div>
                  <h4 className="font-bold text-cyan-300 text-lg drop-shadow-sm">{process.title}</h4>
                  <p className="text-cyan-200 text-sm">{process.desc}</p>
                </div>

                {/* 🌊 바다 화살표 (마지막 제외) */}
                {index < 2 && (
                  <div className="hidden md:block absolute top-10 left-full text-cyan-400/70 transform translate-x-6 drop-shadow-sm">
                    <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* 🌊 추가 심해 장식 */}
          <div className="mt-16 text-center">
            <div className="inline-flex items-center space-x-4 bg-slate-800/50 backdrop-blur-md px-8 py-6 rounded-3xl border border-slate-700/60 shadow-2xl shadow-indigo-500/40">
              <span className="text-3xl">⚡</span>
              <div className="text-left">
                <div className="text-cyan-300 font-bold text-lg drop-shadow-sm">평균 처리 시간</div>
                <div className="text-cyan-200 text-sm">7.77초 내 완료</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 🌊 하단 심해 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-slate-900/70 to-transparent pointer-events-none backdrop-blur-sm"></div>
      
      <style jsx>{`
        .bg-gradient-radial {
          background: radial-gradient(circle, var(--tw-gradient-stops));
        }
        
        .shadow-3xl {
          box-shadow: 0 35px 60px -12px rgba(0, 0, 0, 0.25);
        }
      `}</style>
    </section>
  );
}