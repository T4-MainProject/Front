// 💀 Dark Horror PricingTable.jsx - 영혼 계약서
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const plans = [
  { 
    name: '영혼 초보자', 
    price: '무료', 
    period: '/월',
    originalPrice: null,
    features: [
      '일일 저주 심판 3회',
      '기본 악마 서비스',
      '지옥 이메일 지원',
      '제한된 어둠 기능 사용'
    ],
    popular: false,
    color: 'red',
    description: '어둠에 입문하는 영혼을 위한 기본 저주',
    icon: '👻'
  },
  { 
    name: '저주받은 PRO', 
    price: '66,600원', 
    period: '/월',
    originalPrice: '99,900원',
    features: [
      '일일 저주 심판 13회',
      '상세 악마 서비스',
      '어둠의 오답노트',
      '우선 지옥 지원',
      '기타 저주 기능 제한'
    ],
    popular: false,
    color: 'gray',
    description: '영혼과 보호령을 위한 어둠의 프로 플랜',
    icon: '💀'
  },
  { 
    name: '악마 PRO+', 
    price: '133,300원', 
    period: '/월',
    originalPrice: '199,900원',
    features: [
      '일일 저주 심판 66회',
      '프리미엄 악마 서비스',
      '어둠의 오답노트',
      '지옥 분석 기능',
      '고급 저주 리포트',
      '기타 어둠 기능 제한'
    ],
    popular: true,
    color: 'red',
    description: '어둠의 전달자와 소규모 지옥을 위한 악마 플러스',
    icon: '👹'
  },
  { 
    name: '지옥 ULTRA', 
    price: '666,600원', 
    period: '/월',
    originalPrice: '999,900원',
    features: [
      '무한 저주 심판',
      'AI 악마 맞춤 분석',
      '어둠의 오답노트',
      '지옥 분석 기능',
      '모든 어둠 기능 사용',
      '24/7 악마 지원',
      '전담 어둠 매니저'
    ],
    popular: false,
    color: 'black',
    description: '대규모 지옥 교육기관을 위한 궁극의 어둠',
    icon: '🔥'
  }
];

export default function PricingTable() {
  const sectionRef = useRef(null);
  const cardsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      cardsRef.current.forEach((card, index) => {
        if (!card) return;

        // 어둠의 스크롤 트리거 애니메이션 (더 극적으로)
        gsap.fromTo(card,
          { y: 120, opacity: 0, scale: 0.7, rotationY: -30, filter: "blur(10px)" },
          {
            y: 0,
            opacity: 1,
            scale: 1,
            rotationY: 0,
            filter: "blur(0px)",
            duration: 1.2,
            ease: 'power4.out',
            delay: index * 0.25,
            scrollTrigger: {
              trigger: card,
              start: 'top 90%',
              toggleActions: 'play none none reverse',
            },
          }
        );

        // 어둠의 호버 애니메이션 (더 강렬하게)
        card.addEventListener('mouseenter', () => {
          gsap.to(card, {
            y: -15,
            scale: 1.05,
            rotationX: 5,
            duration: 0.4,
            ease: 'power3.out',
          });
        });
        card.addEventListener('mouseleave', () => {
          gsap.to(card, {
            y: 0,
            scale: 1,
            rotationX: 0,
            duration: 0.4,
            ease: 'power3.out',
          });
        });
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const getCardStyle = (plan) => {
    if (plan.popular) {
      return 'bg-gradient-to-br from-red-900/60 via-black/80 to-red-800/60 border-2 border-red-600/70 shadow-2xl shadow-red-500/50 transform scale-105';
    }
    return 'bg-gradient-to-br from-gray-900/70 via-black/90 to-red-900/50 border border-red-800/50 shadow-xl shadow-red-500/30';
  };

  const getIconStyle = (plan) => {
    if (plan.popular) {
      return 'text-4xl animate-pulse drop-shadow-lg';
    }
    return 'text-3xl drop-shadow-md';
  };

  return (
    <section ref={sectionRef} className="py-16 bg-gradient-to-b from-black via-gray-900 to-red-900 relative overflow-hidden">
      {/* 어둠의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-gray-900/60 to-red-900/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_50%,black_80%)]"></div>
      
      {/* 움직이는 어둠 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-2 h-2 bg-red-500/30 rounded-full animate-pulse"></div>
        <div className="absolute top-32 right-1/3 w-1 h-1 bg-red-400/40 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-24 left-1/2 w-1 h-1 bg-gray-500/30 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-red-600/40 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-red-300/30 rounded-full animate-pulse delay-1500"></div>
      </div>

      <div className="container mx-auto px-4 text-center mb-8 relative z-10">
        <h2 className="text-3xl font-bold text-red-300 mb-4 drop-shadow-2xl">💀 영혼 계약 요금제</h2>
        <p className="text-red-400/80 mt-2 drop-shadow-lg">당신의 영혼에 맞는 저주를 선택하세요</p>
      </div>
      
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
        {plans.map((plan, i) => (
          <div
            key={i}
            ref={el => (cardsRef.current[i] = el)}
            className={`${getCardStyle(plan)} p-6 rounded-2xl flex flex-col relative overflow-hidden backdrop-blur-sm transition-all duration-300`}
          >
            {/* 어둠의 배경 레이어 */}
            <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-gray-900/30 to-red-900/20 rounded-2xl"></div>
            
            {/* 움직이는 어둠 파티클 (카드 내부) */}
            <div className="absolute inset-0 overflow-hidden rounded-2xl pointer-events-none">
              <div className="absolute top-4 right-4 w-1 h-1 bg-red-500/40 rounded-full animate-pulse"></div>
              <div className="absolute bottom-6 left-6 w-1 h-1 bg-red-400/30 rounded-full animate-pulse delay-700"></div>
            </div>

            <div className="relative z-10">
              {plan.popular && (
                <div className="text-center mb-4">
                  <div className="inline-flex items-center space-x-2 bg-red-700/50 text-red-300 px-3 py-1 rounded-full text-sm font-bold border border-red-600/50">
                    <span>🔥</span>
                    <span>666일 무료 저주 체험</span>
                  </div>
                </div>
              )}

              {/* 아이콘 */}
              <div className="text-center mb-4">
                <span className={getIconStyle(plan)}>{plan.icon}</span>
              </div>

              <h3 className="text-xl font-semibold mb-2 text-red-300 text-center drop-shadow-lg">{plan.name}</h3>
              
              <div className="text-center mb-4">
                <p className="text-3xl font-bold text-red-400 drop-shadow-lg">
                  {plan.price}
                  <span className="text-base font-normal text-red-500/80">{plan.period}</span>
                </p>
                {plan.originalPrice && (
                  <p className="text-sm text-red-600/70 line-through mt-1">
                    {plan.originalPrice}
                  </p>
                )}
              </div>

              <p className="text-red-400/80 mb-6 text-center text-sm leading-relaxed drop-shadow-sm">{plan.description}</p>
              
              <ul className="mb-6 space-y-3 flex-1">
                {plan.features.map((feat, j) => (
                  <li key={j} className="flex items-start space-x-3">
                    <span className="text-red-500 mt-1 drop-shadow-sm">💀</span>
                    <span className="text-red-400/90 text-sm drop-shadow-sm">{feat}</span>
                  </li>
                ))}
              </ul>
              
              <button className={`mt-auto w-full py-3 rounded-xl font-semibold transition-all duration-300 ${
                plan.popular 
                  ? 'bg-gradient-to-r from-red-700 to-black text-red-300 hover:from-red-600 hover:to-gray-900 shadow-lg shadow-red-500/50 hover:shadow-xl hover:shadow-red-500/70 hover:scale-105 border border-red-600/50'
                  : 'bg-gradient-to-r from-red-800/70 to-black/80 text-red-400 hover:from-red-700 hover:to-black border border-red-800/50 hover:border-red-700 hover:shadow-lg hover:shadow-red-500/40'
              }`}>
                {plan.popular ? '🔥 저주 시작하기' : '💀 영혼 선택하기'}
              </button>
            </div>

            {/* 인기 플랜 글로우 효과 */}
            {plan.popular && (
              <div className="absolute inset-0 bg-gradient-to-br from-red-600/20 to-transparent rounded-2xl animate-pulse pointer-events-none"></div>
            )}

            {/* 어둠의 테두리 효과 */}
            <div className="absolute inset-0 rounded-2xl border border-red-700/30 pointer-events-none"></div>
          </div>
        ))}
      </div>

      {/* 추가 어둠의 정보 */}
      <div className="container mx-auto px-4 mt-12 text-center relative z-10">
        <div className="bg-gradient-to-r from-red-900/40 to-black/60 rounded-2xl p-8 border border-red-800/50 shadow-lg shadow-red-500/30 backdrop-blur-sm">
          <h3 className="text-xl font-bold text-red-300 mb-4 drop-shadow-lg">🔮 모든 영혼 계약에 포함된 어둠의 혜택</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
            <div className="flex items-center justify-center space-x-2">
              <span className="text-red-500 text-lg">💀</span>
              <span className="text-red-400/90">무료 영혼 상담</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <span className="text-red-500 text-lg">🔥</span>
              <span className="text-red-400/90">24/7 지옥 지원</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <span className="text-red-500 text-lg">👹</span>
              <span className="text-red-400/90">악마 보안 보장</span>
            </div>
          </div>
          
          <div className="mt-6 pt-6 border-t border-red-800/50">
            <p className="text-red-500/80 text-xs italic">
              "모든 계약은 영혼의 동의 하에 이루어지며, 어둠의 법칙에 따라 보호됩니다"
            </p>
          </div>
        </div>
      </div>

      {/* 하단 어둠 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-black to-transparent pointer-events-none"></div>
    </section>
  );
}