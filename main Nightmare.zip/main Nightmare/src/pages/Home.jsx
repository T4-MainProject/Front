// ============================================
// 💀 다크 호러 스타일 Home.jsx - 암울하고 어둡고 무서운 분위기
// ============================================
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AOS from 'aos';
import 'aos/dist/aos.css';

// 기존 컴포넌트들 활용
import TopBar from '../components/TopBar';
import AppHeader from '../components/AppHeader';
import NavBar from '../components/NavBar';
import Hero from '../components/Hero';
import FeatureExplanation from '../components/FeatureExplanation';
import FeatureList from '../components/FeatureList';
import CustomerCarousel from '../components/CustomerCarousel';
import PricingTable from '../components/PricingTable';
import ContentLeft from '../components/ContentLeft';
import Sidebar from '../components/Sidebar';
import Footer from '../components/Footer';

// 모달 컴포넌트들
import LoginModal from '../components/LoginModal';
import SignupModal from '../components/SignupModal';
import MyPageModal from '../components/MyPageModal';

// 더미 데이터 및 유틸리티
import { getUserFromStorage, removeUserFromStorage } from '../data/dummyUsers';

export default function Home() {
  // 🔮 React Router 네비게이션 훅 (어둠 속 안내자)
  const navigate = useNavigate();
  
  // 🌑 모달 상태 관리 (그림자 속 모달들)
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isSignupModalOpen, setIsSignupModalOpen] = useState(false);
  const [isMyPageModalOpen, setIsMyPageModalOpen] = useState(false);
  
  // 👻 로그인 상태 관리 (유령 사용자)
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // 🕳️ 버튼 클릭 상태 관리 (공허한 클릭들)
  const [clickedButtons, setClickedButtons] = useState({
    login: false,
    signup: false,
    mypage: false,
    upload: false,
    demo: false
  });

  // 🌪️ 업로드 페이지로 이동 함수 (어둠 속으로)
  const handleNavigateToUpload = () => {
    // 어둠의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, upload: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, upload: false }));
    }, 200);
    
    // 영혼 존재 확인
    if (!currentUser) {
      alert('⚠️ 당신의 영혼이 확인되지 않습니다. 로그인하여 어둠에 참여하세요.');
      return;
    }
    
    navigate('/upload');
  };

  // 업로드 페이지로 이동하는 함수 (지옥문 열기)
  const handleStartUpload = () => {
    // 어둠의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, upload: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, upload: false }));
    }, 200);
    
    // 영혼 존재 확인
    if (!currentUser) {
      alert('🔥 지옥문에 들어가려면 먼저 당신의 영혼을 등록해야 합니다.');
      return;
    }
    
    navigate('/upload');
  };

  // 🌚 로그인 모달 관리 함수들 (어둠의 문)
  const handleOpenLogin = () => {
    // 어둠의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, login: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, login: false }));
    }, 200);
    
    setIsLoginModalOpen(true);
  };

  const handleCloseLogin = () => {
    setIsLoginModalOpen(false);
  };

  const handleOpenSignup = () => {
    // 어둠의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, signup: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, signup: false }));
    }, 200);
    
    setIsSignupModalOpen(true);
  };

  const handleCloseSignup = () => {
    setIsSignupModalOpen(false);
  };

  // 모달 간 전환 함수들 (차원 이동)
  const handleSwitchToSignup = () => {
    setIsLoginModalOpen(false);
    setIsSignupModalOpen(true);
  };

  const handleSwitchToLogin = () => {
    setIsSignupModalOpen(false);
    setIsLoginModalOpen(true);
  };

  // 👹 로그인 성공 핸들러 (영혼 결속)
  const handleLoginSuccess = (user) => {
    setCurrentUser(user);
    setIsLoginModalOpen(false);
  };

  // 👺 회원가입 성공 핸들러 (영혼 계약)
  const handleSignupSuccess = (user) => {
    setCurrentUser(user);
    setIsSignupModalOpen(false);
  };

  // 💀 로그아웃 핸들러 (영혼 해방)
  const handleLogout = () => {
    setCurrentUser(null);
    removeUserFromStorage();
  };

  // 🖤 마이페이지 핸들러 (영혼의 방)
  const handleOpenMyPage = () => {
    // 어둠의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, mypage: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, mypage: false }));
    }, 200);
    
    setIsMyPageModalOpen(true);
  };

  const handleCloseMyPage = () => {
    setIsMyPageModalOpen(false);
  };

  // 🌑 사용자 정보 업데이트 핸들러 (영혼 변화)
  const handleUserUpdate = (updatedUser) => {
    setCurrentUser(updatedUser);
  };

  // 🎭 데모 영상 핸들러 (악몽 시연)
  const handleDemoClick = () => {
    // 어둠의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, demo: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, demo: false }));
    }, 200);
    
    // 여기에 공포 데모 영상 로직 추가 가능
    console.log('🎬 어둠 속 데모 영상이 재생됩니다...');
  };

  useEffect(() => {
    // AOS 초기화 (어둠의 애니메이션)
    AOS.init({
      duration: 1200,
      easing: 'ease-out-cubic',
      once: true,
      offset: 50,
      delay: 200
    });

    // 스크롤 시 어둠의 새로고침
    const handleScroll = () => {
      AOS.refresh();
    };

    window.addEventListener('scroll', handleScroll);

    // 영혼 저장소에서 사용자 정보 확인
    const storedUser = getUserFromStorage();
    if (storedUser) {
      setCurrentUser(storedUser);
    }
    setIsLoading(false);

    // 페이지 로드 완료 후 어둠 속으로 스크롤
    window.scrollTo(0, 0);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div className="min-h-screen bg-black overflow-x-hidden relative">
      {/* 어둠의 배경 효과 */}
      <div className="fixed inset-0 bg-gradient-to-br from-black via-gray-900 to-red-900 opacity-90 z-0"></div>
      <div className="fixed inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,black_100%)] z-0"></div>
      
      {/* 움직이는 그림자들 */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute -top-40 -left-40 w-80 h-80 bg-red-900/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -right-40 w-80 h-80 bg-purple-900/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/4 w-60 h-60 bg-gray-800/30 rounded-full blur-2xl animate-pulse delay-500"></div>
      </div>

      {/* 메인 콘텐츠 (어둠 속 내용) */}
      <div className="relative z-10">
        {/* 최상단 바 (어둠의 경계) */}
        <TopBar />
        
        {/* 헤더 (어둠의 관문) */}
        <AppHeader 
          currentUser={currentUser}
          onOpenLogin={handleOpenLogin}
          onOpenSignup={handleOpenSignup}
          onLogout={handleLogout}
          onOpenMyPage={handleOpenMyPage}
        />

        {/* 네비게이션 (어둠의 길잡이) */}
        <NavBar />

        {/* 메인 콘텐츠 */}
        <main className="bg-black/50 backdrop-blur-sm">
          {/* 히어로 섹션 (어둠의 영웅) */}
          <Hero onNext={handleNavigateToUpload} />

          {/* 기능 설명 섹션 (어둠의 기능들) */}
          <FeatureExplanation />

          {/* 주요 특징 섹션 (악마의 특징들) */}
          <FeatureList />

          {/* 고객사 캐러셀 (어둠의 동맹) */}
          <CustomerCarousel />

          {/* 요금제 섹션 (영혼의 대가) */}
          <PricingTable />

          {/* 콘텐츠 + 사이드바 섹션 (어둠의 소굴) */}
          <section className="py-16 bg-gradient-to-b from-black via-gray-900 to-black relative">
            <div className="container mx-auto px-4">
              <div className="flex flex-col lg:flex-row gap-8 max-w-7xl mx-auto">
                {/* 왼쪽 콘텐츠 (어둠의 왼편) */}
                <ContentLeft />
                
                {/* 오른쪽 사이드바 (어둠의 오른편) */}
                <Sidebar onNext={handleStartUpload} />
              </div>
            </div>
          </section>

          {/* 체험 CTA (어둠의 유혹) */}
          <section className="py-20 bg-gradient-to-br from-black via-red-900 to-black relative overflow-hidden">
            {/* 지옥의 배경 장식 */}
            <div className="absolute inset-0 overflow-hidden">
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-red-500/10 rounded-full blur-3xl animate-pulse"></div>
              <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gray-800/20 rounded-full blur-3xl animate-pulse delay-500"></div>
              
              {/* 추가 어둠 효과 */}
              <div className="absolute inset-0 bg-black/60"></div>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_30%,black_70%)]"></div>
            </div>

            <div className="container mx-auto px-4 text-center relative z-10" data-aos="fade-up">
              <div className="max-w-4xl mx-auto">
                <h2 className="text-4xl md:text-5xl font-black text-red-400 mb-6 drop-shadow-2xl">
                  💀 어둠 속으로 들어오세요
                </h2>
                <p className="text-xl text-gray-300 mb-8 leading-relaxed max-w-2xl mx-auto drop-shadow-lg">
                  당신의 시험지를 어둠에 바치고 
                  <br className="hidden md:block" />
                  AI 악마의 정확한 심판을 받아보세요
                </p>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
                  <button 
                    onClick={handleNavigateToUpload}
                    className={`px-10 py-4 rounded-2xl font-bold text-lg shadow-2xl hover:shadow-red-500/50 transition-all duration-300 hover:scale-105 group border-2 border-red-500 ${
                      clickedButtons.upload 
                        ? 'bg-red-900/80 text-red-300 transform scale-95 border-red-600' 
                        : 'bg-red-800/20 text-red-400 hover:bg-red-700/40'
                    }`}
                  >
                    <span className="flex items-center justify-center">
                      🔥 어둠의 심판 시작
                      <svg className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                      </svg>
                    </span>
                  </button>
                  
                  <button 
                    onClick={handleDemoClick}
                    className={`px-8 py-4 rounded-2xl font-bold text-lg transition-all duration-300 hover:scale-105 border-2 ${
                      clickedButtons.demo
                        ? 'bg-gray-800/60 border-gray-600 text-gray-400 transform scale-95'
                        : 'bg-transparent border-gray-500 text-gray-400 hover:bg-gray-800/40 hover:text-gray-300 hover:border-gray-400'
                    }`}
                  >
                    👁️ 악몽 시연 보기
                  </button>
                </div>

                {/* 어둠의 성능 지표 */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-red-300/80">
                  <div className="text-center bg-black/40 p-4 rounded-lg border border-red-900/30">
                    <div className="text-3xl font-bold mb-2 text-red-400">666+</div>
                    <div className="text-sm">어둠의 기관</div>
                  </div>
                  <div className="text-center bg-black/40 p-4 rounded-lg border border-red-900/30">
                    <div className="text-3xl font-bold mb-2 text-red-400">13.3K+</div>
                    <div className="text-sm">저주받은 시험지</div>
                  </div>
                  <div className="text-center bg-black/40 p-4 rounded-lg border border-red-900/30">
                    <div className="text-3xl font-bold mb-2 text-red-400">99.9%</div>
                    <div className="text-sm">악마의 정확도</div>
                  </div>
                  <div className="text-center bg-black/40 p-4 rounded-lg border border-red-900/30">
                    <div className="text-3xl font-bold mb-2 text-red-400">6.66초</div>
                    <div className="text-sm">지옥 처리시간</div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </main>

        {/* 어둠의 푸터 */}
        <Footer />

        {/* 어둠으로 올라가는 버튼 */}
        <ScrollToTopButton />
      </div>

      {/* 모달 컴포넌트들 (어둠의 창문들) */}
      <LoginModal 
        isOpen={isLoginModalOpen}
        onClose={handleCloseLogin}
        onSwitchToSignup={handleSwitchToSignup}
        onLoginSuccess={handleLoginSuccess}
      />
      
      <SignupModal 
        isOpen={isSignupModalOpen}
        onClose={handleCloseSignup}
        onSwitchToLogin={handleSwitchToLogin}
        onSignupSuccess={handleSignupSuccess}
      />

      <MyPageModal 
        isOpen={isMyPageModalOpen}
        onClose={handleCloseMyPage}
        currentUser={currentUser}
        onUserUpdate={handleUserUpdate}
      />
    </div>
  );
}

// 어둠의 정상으로 올라가는 버튼 컴포넌트
function ScrollToTopButton() {
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  if (!isVisible) return null;

  return (
    <button
      onClick={scrollToTop}
      className="fixed bottom-8 right-8 w-14 h-14 bg-gradient-to-r from-red-900 to-black text-red-400 rounded-full shadow-lg shadow-red-500/50 hover:shadow-xl hover:shadow-red-500/70 transition-all duration-300 hover:scale-110 z-50 group border-2 border-red-800 hover:border-red-600"
      aria-label="어둠의 정상으로 스크롤"
    >
      <svg className="w-6 h-6 mx-auto group-hover:-translate-y-1 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
      </svg>
    </button>
  );
}