import React, { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';

const links = [
  { name: '파라다이스 소개', icon: '🏝️', href: '#' },
  { name: '크리스탈 공지', icon: '💎', href: '#' },
  { name: '열대 게시판', icon: '🌺', href: '#' },
  { name: '바다 문의', icon: '📞', href: '#' }
];

export default function NavBar() {
  const [activeLink, setActiveLink] = useState(0);
  const navRef = useRef(null);
  const linksRef = useRef([]);

  useEffect(() => {
    // 파라다이스 네비게이션 바 전체 애니메이션 (부드럽고 우아하게)
    gsap.fromTo(navRef.current,
      { y: -150, opacity: 0, rotationX: -90 },
      { y: 0, opacity: 1, rotationX: 0, duration: 1.2, ease: "power4.out", delay: 0.2 }
    );

    // 파라다이스 링크들 순차 애니메이션 (열대 느낌으로)
    gsap.fromTo(linksRef.current,
      { y: 80, opacity: 0, scale: 0.5, rotationY: -45 },
      { 
        y: 0, 
        opacity: 1, 
        scale: 1,
        rotationY: 0,
        duration: 0.8,
        stagger: 0.15,
        ease: "back.out(2)",
        delay: 0.6
      }
    );
  }, []);

  const handleLinkClick = (index) => {
    setActiveLink(index);
    
    // 파라다이스 클릭 애니메이션 (부드럽고 우아하게)
    gsap.to(linksRef.current[index], {
      scale: 1.15,
      rotationZ: 5,
      duration: 0.15,
      yoyo: true,
      repeat: 1,
      ease: "power3.inOut"
    });
  };

  return (
    <nav 
      ref={navRef}
      className="bg-gradient-to-r from-emerald-300/80 via-cyan-200/70 to-sky-300/80 backdrop-blur-md border-b border-white/40 sticky top-16 z-40 shadow-lg shadow-emerald-500/20 relative overflow-hidden"
    >
      {/* 파라다이스 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-r from-white/30 via-emerald-100/40 to-white/30"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.1)_0%,rgba(6,182,212,0.05)_50%,rgba(14,165,233,0.1)_100%)]"></div>
      
      {/* 움직이는 크리스탈 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-2 left-1/4 w-1 h-1 bg-emerald-400/40 rounded-full animate-pulse shadow-sm"></div>
        <div className="absolute top-4 right-1/3 w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse delay-700 shadow-sm"></div>
        <div className="absolute bottom-2 left-1/2 w-1 h-1 bg-sky-400/30 rounded-full animate-pulse delay-1000 shadow-sm"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-teal-500/40 rounded-full animate-pulse delay-500 shadow-sm"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex space-x-2 py-3 overflow-x-auto scrollbar-hide">
          {links.map((link, index) => (
            <button
              key={link.name}
              ref={el => linksRef.current[index] = el}
              onClick={() => handleLinkClick(index)}
              className={`
                relative flex items-center space-x-3 px-6 py-3 rounded-2xl font-medium 
                transition-all duration-300 whitespace-nowrap group min-w-fit backdrop-blur-sm
                ${activeLink === index 
                  ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-white shadow-lg shadow-emerald-500/50 transform scale-105 border-2 border-white/50' 
                  : 'text-emerald-700 hover:text-emerald-600 hover:bg-white/30 hover:shadow-md hover:shadow-emerald-500/30 border border-white/30 hover:border-white/50'
                }
              `}
            >
              <span className={`text-xl transition-all duration-300 drop-shadow-lg ${
                activeLink === index ? 'scale-110 animate-pulse' : 'group-hover:scale-110 group-hover:rotate-12'
              }`}>
                {link.icon}
              </span>
              <span className="font-semibold drop-shadow-sm">{link.name}</span>
              
              {/* 활성 상태 파라다이스 글로우 효과 */}
              {activeLink === index && (
                <div className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-cyan-400 rounded-2xl blur-lg opacity-40 -z-10 animate-pulse"></div>
              )}

              {/* 호버 크리스탈 파티클 효과 */}
              <div className="absolute inset-0 rounded-2xl overflow-hidden">
                <div className={`absolute inset-0 bg-gradient-to-r from-transparent via-emerald-400/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ${
                  activeLink !== index ? 'opacity-100' : 'opacity-0'
                }`}></div>
              </div>

              {/* 추가 파라다이스 효과 */}
              <div className="absolute top-0 right-0 w-2 h-2 overflow-hidden rounded-tr-2xl">
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-400/30 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-pulse"></div>
              </div>

              {/* 파라다이스 언더라인 */}
              <div className={`absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-emerald-500 to-cyan-500 transform origin-left transition-transform duration-300 shadow-sm ${
                activeLink === index ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'
              }`}></div>
            </button>
          ))}
        </div>
      </div>

      {/* 하단 파라다이스 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-emerald-400/50 to-transparent shadow-sm"></div>
    </nav>
  );
}