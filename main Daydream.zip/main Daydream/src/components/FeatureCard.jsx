// ============================================
// ✨ Angelic Light FeatureCard.jsx - 희망의 특징 카드
// ============================================
import React, { useRef, useEffect } from 'react';
import { gsap } from 'gsap';

export default function FeatureCard({ 
  icon, 
  title, 
  description, 
  gradient = 'from-blue-500 to-sky-500',
  bgGradient = 'from-blue-100/30 to-white/60',
  className = '',
  delay = 0,
  ...props 
}) {
  const cardRef = useRef(null);
  const iconRef = useRef(null);

  useEffect(() => {
    const card = cardRef.current;
    const iconEl = iconRef.current;

    if (!card || !iconEl) return;

    // 빛의 초기 진입 애니메이션 (더 우아하게)
    gsap.fromTo(card, 
      { 
        y: 80, 
        opacity: 0, 
        scale: 0.7,
        rotationY: -30,
        filter: "blur(10px)"
      },
      { 
        y: 0, 
        opacity: 1, 
        scale: 1,
        rotationY: 0,
        filter: "blur(0px)",
        duration: 1.2, 
        ease: "power4.out",
        delay: delay 
      }
    );

    // 빛의 호버 애니메이션 설정 (더 부드럽게)
    const handleMouseEnter = () => {
      gsap.to(card, {
        y: -12,
        scale: 1.05,
        rotationX: 5,
        duration: 0.4,
        ease: "power3.out"
      });

      gsap.to(iconEl, {
        scale: 1.25,
        rotation: 12,
        y: -5,
        duration: 0.4,
        ease: "back.out(2)"
      });
    };

    const handleMouseLeave = () => {
      gsap.to(card, {
        y: 0,
        scale: 1,
        rotationX: 0,
        duration: 0.4,
        ease: "power3.out"
      });

      gsap.to(iconEl, {
        scale: 1,
        rotation: 0,
        y: 0,
        duration: 0.4,
        ease: "power3.out"
      });
    };

    card.addEventListener('mouseenter', handleMouseEnter);
    card.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      card.removeEventListener('mouseenter', handleMouseEnter);
      card.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [delay]);

  return (
    <div 
      ref={cardRef}
      className={`
        bg-gradient-to-br ${bgGradient} p-8 rounded-3xl shadow-2xl shadow-blue-500/20 hover:shadow-2xl hover:shadow-blue-500/40
        border border-blue-300/50 transition-all duration-500 cursor-pointer group 
        relative overflow-hidden backdrop-blur-sm ${className}
      `}
      {...props}
    >
      {/* 빛의 배경 호버 효과 */}
      <div className={`
        absolute inset-0 bg-gradient-to-br ${gradient} opacity-0 
        group-hover:opacity-20 transition-opacity duration-500 rounded-3xl
      `}></div>
      
      {/* 빛의 배경 레이어 */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/60 via-sky-50/40 to-blue-100/30 rounded-3xl"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,rgba(255,255,255,0.4)_40%)] rounded-3xl"></div>
      
      {/* 떠다니는 천사 파티클들 */}
      <div className="absolute top-4 right-4 w-2 h-2 bg-blue-400/40 rounded-full animate-pulse"></div>
      <div className="absolute bottom-6 left-6 w-1 h-1 bg-sky-400/60 rounded-full animate-ping"></div>
      <div className="absolute top-1/2 right-8 w-1.5 h-1.5 bg-indigo-400/50 rounded-full animate-bounce"></div>
      <div className="absolute top-1/3 left-4 w-1 h-1 bg-blue-500/40 rounded-full animate-pulse delay-700"></div>
      <div className="absolute bottom-1/3 right-6 w-1 h-1 bg-sky-300/30 rounded-full animate-ping delay-1000"></div>
      
      {/* 빛의 아이콘 */}
      <div className="relative z-10 text-center mb-6">
        <div className="relative inline-block">
          <div 
            ref={iconRef}
            className={`
              inline-flex items-center justify-center w-20 h-20 
              bg-gradient-to-br from-white/80 to-blue-100/60 rounded-2xl shadow-lg shadow-blue-500/50 group-hover:shadow-xl group-hover:shadow-blue-500/70
              transition-all duration-300 relative z-10 border border-blue-300/50
            `}
          >
            <span className="text-4xl drop-shadow-lg filter">{icon}</span>
          </div>
          
          {/* 아이콘 빛의 글로우 효과 */}
          <div className={`
            absolute inset-0 bg-gradient-to-br ${gradient} rounded-2xl 
            blur-lg opacity-0 group-hover:opacity-50 transition-opacity duration-300
          `}></div>
          
          {/* 추가 빛 효과 */}
          <div className="absolute inset-0 bg-blue-400/20 rounded-2xl blur-md opacity-0 group-hover:opacity-30 transition-opacity duration-500"></div>
        </div>
      </div>
      
      {/* 빛의 콘텐츠 */}
      <div className="relative z-10 text-center">
        <h3 className="text-xl font-bold text-blue-700 mb-4 group-hover:text-blue-800 transition-colors duration-300 drop-shadow-lg">
          {title}
        </h3>
        <p className="text-blue-600/90 leading-relaxed group-hover:text-blue-700 transition-colors duration-300 drop-shadow-sm">
          {description}
        </p>
      </div>

      {/* 하단 빛의 액센트 라인 */}
      <div className={`
        absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${gradient} 
        transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 
        origin-left rounded-b-3xl shadow-lg shadow-blue-500/50
      `}></div>

      {/* 빛의 코너 장식 */}
      <div className="absolute top-0 right-0 w-20 h-20 overflow-hidden rounded-tr-3xl">
        <div className={`
          absolute -top-8 -right-8 w-16 h-16 bg-gradient-to-br ${gradient} 
          rounded-full opacity-30 group-hover:opacity-60 transition-opacity duration-300 animate-pulse
        `}></div>
      </div>

      {/* 추가 빛의 장식 요소들 */}
      <div className="absolute top-0 left-0 w-16 h-16 overflow-hidden rounded-tl-3xl">
        <div className="absolute -top-6 -left-6 w-12 h-12 bg-blue-300/20 rounded-full opacity-40 group-hover:opacity-60 transition-opacity duration-300 animate-pulse delay-500"></div>
      </div>

      {/* 빛의 경계선 효과 */}
      <div className="absolute inset-0 rounded-3xl border border-blue-300/30 group-hover:border-blue-400/50 transition-colors duration-300"></div>
      
      {/* 중앙 빛 효과 */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-white/10 rounded-full blur-3xl opacity-0 group-hover:opacity-40 transition-opacity duration-700"></div>

      {/* 하단 빛 그라데이션 */}
      <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-white/30 to-transparent rounded-b-3xl pointer-events-none"></div>
    </div>
  );
}