// ============================================
// 🌊 Deep Ocean LoginModal.jsx - 심해 로그인 모달
// ============================================
// 📝 주요 기능:
// - 모달 형태의 심해 로그인 폼
// - 이메일/비밀번호 입력
// - 심해 입장, 바다 가입, 비밀번호 복원 버튼
// - 반응형 디자인 및 심해 애니메이션
// ============================================

import React, { useState, useEffect } from 'react';
import { validateLogin, saveUserToStorage } from '../data/dummyUsers';
import ForgotPasswordModal from './ForgotPasswordModal';

export default function LoginModal({ isOpen, onClose, onSwitchToSignup, onLoginSuccess }) {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);

  // 모달이 열릴 때 body 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.keyCode === 27) onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  // 심해 로그인 모달이 닫힐 때 비밀번호 찾기 모달도 닫기
  useEffect(() => {
    if (!isOpen) {
      setShowForgotPassword(false);
    }
  }, [isOpen]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // 에러 메시지 클리어
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    // 심해 이메일 검증
    if (!formData.email) {
      newErrors.email = '이메일을 입력해주세요.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = '올바른 이메일 형식이 아닙니다.';
    }

    // 심해 비밀번호 검증
    if (!formData.password) {
      newErrors.password = '비밀번호를 입력해주세요.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);
    
    try {
      // 시뮬레이션된 로딩 (실제 심해 API 호출 시뮬레이션)
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // 더미 데이터로 바다 인증 검증
      const result = validateLogin(formData.email, formData.password);
      
      if (result.success) {
        // 심해 스토리지에 바다 정보 저장
        saveUserToStorage(result.user);
        
        // 부모 컴포넌트에 심해 입장 성공 알림
        onLoginSuccess(result.user);
        
        // 성공 메시지 표시
        alert(`${result.message}\n심해에 오신 것을 환영합니다, ${result.user.name}님!`);
      } else {
        // 심해 입장 실패 에러 표시
        setErrors({ general: result.message });
      }
    } catch (error) {
      console.error('심해 입장 오류:', error);
      setErrors({ general: '로그인 처리 중 오류가 발생했습니다.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = () => {
    setShowForgotPassword(true);
  };

  const handleForgotPasswordClose = () => {
    setShowForgotPassword(false);
  };

  const handleForgotPasswordSuccess = () => {
    setShowForgotPassword(false);
    // 심해 비밀번호 재설정 성공 후 로그인 모달로 돌아가기
    alert('비밀번호가 성공적으로 변경되었습니다. 새로운 비밀번호로 로그인해주세요.');
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 overflow-y-auto">
        {/* 심해 배경 오버레이 */}
        <div 
          className="fixed inset-0 bg-indigo-500/20 backdrop-blur-sm transition-opacity duration-300"
          onClick={onClose}
        />
        
        {/* 심해 모달 컨테이너 */}
        <div className="flex min-h-full items-center justify-center p-4">
          <div className="relative bg-slate-800/40 backdrop-blur-md rounded-2xl shadow-2xl shadow-indigo-500/50 w-full max-w-md transform transition-all duration-300 modal-enter border border-slate-700/50">
            
            {/* 심해 배경 효과 */}
            <div className="absolute inset-0 bg-gradient-to-br from-slate-800/60 via-indigo-900/40 to-blue-900/60 rounded-2xl"></div>
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(30,64,175,0.15)_0%,rgba(15,23,42,0.8)_50%,rgba(30,58,138,0.1)_100%)] rounded-2xl"></div>
            
            {/* 움직이는 바다 파티클 */}
            <div className="absolute inset-0 overflow-hidden rounded-2xl pointer-events-none">
              <div className="absolute top-4 left-8 w-1 h-1 bg-blue-400/40 rounded-full animate-pulse shadow-sm"></div>
              <div className="absolute top-12 right-12 w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse delay-700 shadow-sm"></div>
              <div className="absolute bottom-8 left-12 w-1 h-1 bg-indigo-400/30 rounded-full animate-pulse delay-1000 shadow-sm"></div>
              <div className="absolute top-1/2 right-8 w-1 h-1 bg-teal-500/40 rounded-full animate-pulse delay-500 shadow-sm"></div>
            </div>

            {/* 심해 닫기 버튼 */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-cyan-300 hover:text-cyan-100 transition-colors duration-200 z-10 bg-slate-800/50 rounded-full p-2 backdrop-blur-sm border border-slate-700/50"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            {/* 심해 헤더 */}
            <div className="px-8 pt-8 pb-6 text-center relative z-10">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-600 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-indigo-500/50 border-2 border-slate-700/50">
                <svg className="w-8 h-8 text-cyan-100" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-cyan-300 mb-2 drop-shadow-lg">🌊 심해 입장</h2>
              <p className="text-cyan-200/80 drop-shadow-sm">OceanCheck 바다 세계에 오신 것을 환영합니다</p>
            </div>

            {/* 심해 폼 */}
            <form onSubmit={handleSubmit} className="px-8 pb-8 relative z-10">
              {/* 전체 에러 메시지 */}
              {errors.general && (
                <div className="mb-4 p-3 bg-red-900/60 border border-red-600/50 text-red-300 rounded-lg text-sm backdrop-blur-sm">
                  {errors.general}
                </div>
              )}

              {/* 심해 이메일 입력 */}
              <div className="mb-4">
                <label className="block text-sm font-semibold text-cyan-300 mb-2 drop-shadow-sm">
                  이메일
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="ocean@deepwater.co.kr"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:border-transparent transition-all duration-200 bg-slate-800/60 text-cyan-100 placeholder-cyan-300/50 backdrop-blur-sm ${
                    errors.email 
                      ? 'border-red-400 focus:ring-red-400' 
                      : 'border-slate-600/50 focus:ring-cyan-500'
                  }`}
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-400">{errors.email}</p>
                )}
              </div>

              {/* 심해 비밀번호 입력 */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-cyan-300 mb-2 drop-shadow-sm">
                  비밀번호
                </label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  placeholder="비밀번호를 입력하세요"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:border-transparent transition-all duration-200 bg-slate-800/60 text-cyan-100 placeholder-cyan-300/50 backdrop-blur-sm ${
                    errors.password 
                      ? 'border-red-400 focus:ring-red-400' 
                      : 'border-slate-600/50 focus:ring-cyan-500'
                  }`}
                />
                {errors.password && (
                  <p className="mt-1 text-sm text-red-400">{errors.password}</p>
                )}
              </div>

              {/* 심해 입장 버튼 */}
              <button
                type="submit"
                disabled={isLoading}
                className={`w-full py-3 px-4 rounded-xl font-semibold text-cyan-100 transition-all duration-300 mb-4 border-2 ${
                  isLoading
                    ? 'bg-slate-700/60 cursor-not-allowed border-slate-600 text-cyan-300/50'
                    : 'bg-gradient-to-r from-indigo-600 to-cyan-600 hover:shadow-lg hover:shadow-indigo-500/50 hover:scale-105 border-slate-700/50 backdrop-blur-sm'
                }`}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center">
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-cyan-300" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    심해 입장 중...
                  </div>
                ) : (
                  '🌊 심해 입장'
                )}
              </button>

              {/* 심해 비밀번호 복원 */}
              <button
                type="button"
                onClick={handleForgotPassword}
                className="w-full text-center text-sm text-cyan-300 hover:text-cyan-100 transition-colors duration-200 mb-4"
              >
                🔐 비밀번호를 잊으셨나요?
              </button>

              {/* 심해 구분선 */}
              <div className="relative mb-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-cyan-400/50" />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-4 bg-gradient-to-r from-slate-800/80 to-indigo-900/80 text-cyan-300/80 rounded-full backdrop-blur-sm">또는</span>
                </div>
              </div>

              {/* 바다 가입 버튼 */}
              <button
                type="button"
                onClick={onSwitchToSignup}
                className="w-full py-3 px-4 border border-slate-600/50 rounded-xl font-semibold text-cyan-300 hover:bg-slate-800/60 hover:border-cyan-400 transition-all duration-200 bg-slate-800/40 backdrop-blur-sm"
              >
                계정이 없으신가요? 🐠 바다 가입하기
              </button>
            </form>

            {/* 추가 심해 장식 */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
              <div className="flex items-center space-x-1 text-xs text-cyan-300/60">
                <span>✨</span>
                <span>심해 서버 연결됨</span>
                <div className="w-1 h-1 bg-cyan-400 rounded-full animate-pulse"></div>
              </div>
            </div>

            {/* 심해 테두리 효과 */}
            <div className="absolute inset-0 rounded-2xl border border-cyan-400/30 pointer-events-none"></div>
          </div>
        </div>
      </div>

      {/* 심해 비밀번호 복원 모달 */}
      <ForgotPasswordModal
        isOpen={showForgotPassword}
        onClose={handleForgotPasswordClose}
        onSuccess={handleForgotPasswordSuccess}
      />
    </>
  );
}