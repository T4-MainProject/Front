// ============================================
// ✨ Angelic Light GradingProgress.jsx - 축복 대기 페이지
// ============================================
// 📊 주요 기능:
// - 축복 상태 추적 (천사 대기 → 축복 완료)
// - 실시간 빛의 카운트다운 타이머
// - 빛의 진행률 표시 (0% → 100%)
// - 천국 서비스 소개 슬라이드
// - 반응형 빛 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

export default function GradingProgress() {
  // 🧭 빛의 라우터 훅
  const location = useLocation();
  const navigate = useNavigate();
  
  // 📝 업로드된 천사 데이터
  const uploadData = location.state?.uploadData;

  // 📊 상태 관리
  const [status, setStatus] = useState('천사 대기'); // '천사 대기' | '축복 진행' | '축복 완료'
  const [progress, setProgress] = useState(0); // 빛의 진행률 (0-100)
  const [timeLeft, setTimeLeft] = useState(6); // 남은 시간 (초) - 777초의 축약
  const [currentSlide, setCurrentSlide] = useState(0); // 현재 슬라이드 인덱스

  // 🎯 빛의 학습법 및 활용팁 슬라이드 데이터
  const serviceSlides = [
    {
      title: "📚 빛의 효과적인 학습 전략",
      description: "천국의 체계적인 학습 계획으로 천사의 성적을 향상시키는 방법을 알아보세요",
      features: [
        "주기적인 천사 모의고사 활용",
        "천사의 취약점 집중 축복",
        "빛의 학습 진도 체크리스트 작성"
      ],
      color: "from-blue-500 to-sky-400"
    },
    {
      title: "📝 축복받은 오답노트 활용법",
      description: "틀린 문제를 천국의 체계로 정리하여 천사의 실력을 키우는 방법입니다",
      features: [
        "오답 원인 천사 분석하기",
        "유사 문제 축복 반복 학습",
        "정기적인 천국 복습 스케줄"
      ],
      color: "from-sky-500 to-blue-600"
    },
    {
      title: "🔄 빛의 반복학습 전략",
      description: "천사의 과학적인 반복 학습으로 천사의 장기 기억을 강화하는 방법입니다",
      features: [
        "망각 곡선 천사 활용한 복습",
        "단계별 천국 난이도 조절",
        "성취도 기반 축복 학습량 조정"
      ],
      color: "from-indigo-500 to-blue-500"
    },
    {
      title: "📊 천사의 성취도 추적 관리",
      description: "학습 성과를 빛으로 시각화하여 축복 동기부여와 목표 달성을 도와드립니다",
      features: [
        "성적 변화 천국 그래프 분석",
        "과목별 천사 강약점 파악",
        "학습 목표 축복 설정과 달성"
      ],
      color: "from-blue-600 to-indigo-600"
    }
  ];

  // ⏰ 빛의 타이머 및 진행률 관리
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          setStatus('축복 완료');
          setProgress(100);
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });

      // 빛의 진행률 업데이트 (6초 기준)
      setProgress(prev => {
        const newProgress = ((6 - timeLeft + 1) / 6) * 100;
        return Math.min(newProgress, 100);
      });

      // 빛의 상태 업데이트
      if (timeLeft <= 3 && timeLeft > 1) {
        setStatus('축복 진행');
      } else if (timeLeft <= 1) {
        setStatus('축복 완료');
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  // 🎠 빛의 슬라이드 자동 전환
  useEffect(() => {
    const slideTimer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % serviceSlides.length);
    }, 4000); // 4초마다 슬라이드 변경

    return () => clearInterval(slideTimer);
  }, [serviceSlides.length]);

  // 🏠 천국으로 돌아가기
  const handleBackToHome = () => {
    navigate('/');
  };

  // 📊 축복 결과 보기 (축복 완료 시)
  const handleViewResults = () => {
    navigate('/grading-result', { 
      state: { 
        ...uploadData,
        score: 88,
        totalQuestions: 15,
        correctAnswers: 13,
        timeSpent: '77분 7초'
      }
    });
  };

  // 업로드 데이터가 없으면 천국으로 리다이렉트
  if (!uploadData) {
    navigate('/');
    return null;
  }

  // ⏰ 빛의 시간 포맷팅
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 📊 상태별 빛의 아이콘
  const getStatusIcon = () => {
    switch (status) {
      case '천사 대기':
        return (
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center border border-blue-300 shadow-lg shadow-blue-500/50">
            <svg className="w-8 h-8 text-blue-600 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
        );
      case '축복 진행':
        return (
          <div className="w-16 h-16 bg-sky-100 rounded-full flex items-center justify-center border border-sky-300 shadow-lg shadow-sky-500/50">
            <svg className="w-8 h-8 text-sky-600 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </div>
        );
      case '축복 완료':
        return (
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center border border-green-300 shadow-lg shadow-green-500/50">
            <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-blue-50 to-sky-100 relative overflow-hidden">
      {/* 빛의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/90 via-blue-50/80 to-sky-100/60"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_50%,rgba(255,255,255,0.8)_80%)]"></div>
      
      {/* 움직이는 빛의 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-1/4 w-2 h-2 bg-blue-400/40 rounded-full animate-pulse"></div>
        <div className="absolute top-40 right-1/3 w-1 h-1 bg-sky-400/50 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-32 left-1/2 w-1 h-1 bg-indigo-400/40 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-blue-500/50 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-sky-300/40 rounded-full animate-pulse delay-1500"></div>
      </div>

      {/* 빛의 헤더 */}
      <div className="bg-gradient-to-r from-white/90 to-blue-100/80 shadow-lg shadow-blue-500/20 border-b border-blue-200 relative z-10 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToHome}
                className="text-blue-500 hover:text-blue-600 mr-4 transition-colors duration-200"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent drop-shadow-lg">
                ✨ AI 축복 진행 중
              </h1>
            </div>
            
            {/* 빛의 진행률 표시 */}
            <div className="hidden md:flex items-center space-x-4">
              <div className="text-sm text-blue-600">
                축복률: <span className="font-bold text-blue-700">{Math.round(progress)}%</span>
              </div>
              <div className="text-sm text-blue-600">
                남은 빛: <span className="font-bold text-blue-700">{formatTime(timeLeft)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* 왼쪽: 축복 진행 상황 */}
            <div className="space-y-6">
              {/* 과목/학년 정보 카드 */}
              <div className="bg-gradient-to-br from-blue-100/60 to-sky-50/80 rounded-3xl shadow-2xl shadow-blue-500/20 p-6 border border-blue-200 backdrop-blur-sm">
                <h3 className="text-lg font-semibold text-blue-700 mb-4 text-center drop-shadow-lg">✨ 축복 정보</h3>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                    <span className="text-blue-600 text-sm">축복받은 과목:</span>
                    <span className="font-medium text-blue-700 ml-2">{uploadData.subject}</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-sky-500 rounded-full mr-3"></div>
                    <span className="text-blue-600 text-sm">천사 학년:</span>
                    <span className="font-medium text-blue-700 ml-2">{uploadData.grade}</span>
                  </div>
                  {uploadData.examType && (
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-indigo-500 rounded-full mr-3"></div>
                      <span className="text-blue-600 text-sm">축복 유형:</span>
                      <span className="font-medium text-blue-700 ml-2">{uploadData.examType}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* 축복 진행 상황 통합 카드 */}
              <div className="bg-gradient-to-br from-blue-100/60 to-sky-50/80 rounded-3xl shadow-2xl shadow-blue-500/20 p-8 border border-blue-200 backdrop-blur-sm">
                <h3 className="text-xl font-bold text-blue-700 mb-6 text-center drop-shadow-lg">✨ 축복 진행 상황</h3>
                
                {/* 상태, 시간, 진행률 테이블 */}
                <div className="space-y-6">
                  {/* 상태 섹션 */}
                  <div className="text-center border-b border-blue-200 pb-6">
                    <div className="flex justify-center mb-4">
                      {getStatusIcon()}
                    </div>
                    <h2 className="text-2xl font-bold text-blue-700 mb-2 drop-shadow-lg">
                      {status}
                    </h2>
                    <p className="text-blue-600 drop-shadow-sm">
                      {status === '천사 대기' && 'AI 천사 시스템이 천사 시험지를 분석하고 있습니다'}
                      {status === '축복 진행' && 'YOLO8과 천사 OCR이 천사 답안을 인식하고 있습니다'}
                      {status === '축복 완료' && '모든 빛의 축복이 완료되었습니다!'}
                    </p>
                  </div>

                  {/* 시간 & 진행률 테이블 */}
                  <div className="grid grid-cols-2 gap-6">
                    {/* 남은 시간 */}
                    <div className="text-center">
                      <h4 className="text-sm font-semibold text-blue-600 mb-2">남은 빛</h4>
                      <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent drop-shadow-lg">
                        {formatTime(timeLeft)}
                      </div>
                      <p className="text-blue-500 text-xs mt-1">예상 완료시간</p>
                    </div>

                    {/* 진행률 */}
                    <div className="text-center">
                      <h4 className="text-sm font-semibold text-blue-600 mb-2">축복률</h4>
                      <div className="text-3xl font-bold text-blue-700 drop-shadow-lg">
                        {Math.round(progress)}%
                      </div>
                      <p className="text-blue-500 text-xs mt-1">처리 완료도</p>
                    </div>
                  </div>

                  {/* 빛의 진행률 바 */}
                  <div className="pt-4">
                    <div className="w-full bg-blue-200/50 rounded-full h-4 mb-4 border border-blue-300">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-sky-400 h-4 rounded-full transition-all duration-1000 relative overflow-hidden"
                        style={{ width: `${progress}%` }}
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent transform -skew-x-12 animate-pulse"></div>
                      </div>
                    </div>

                    {/* 빛의 진행 상태 */}
                    <div className="text-center">
                      {status === '천사 대기' && (
                        <div className="bg-blue-100/80 text-blue-600 px-4 py-2 rounded-full text-sm font-medium border border-blue-300 backdrop-blur-sm">
                          천사 파일 업로드 중입니다.
                        </div>
                      )}
                      {status === '축복 진행' && (
                        <div className="bg-sky-100/80 text-sky-600 px-4 py-2 rounded-full text-sm font-medium border border-sky-300 backdrop-blur-sm">
                          천사 파일 업로드 완료되었습니다.
                        </div>
                      )}
                      {status === '축복 완료' && (
                        <div className="bg-green-100/80 text-green-600 px-4 py-2 rounded-full text-sm font-medium border border-green-300 backdrop-blur-sm">
                          ✨ 축복 결과 보기를 확인하세요
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* 빛의 완료 버튼 */}
              {status === '축복 완료' && (
                <div className="text-center">
                  <button
                    onClick={handleViewResults}
                    className="bg-gradient-to-r from-blue-600 to-sky-500 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-2xl shadow-blue-500/50 hover:shadow-2xl hover:shadow-blue-500/70 transition-all duration-300 hover:scale-105 border border-blue-400"
                  >
                    ✨ 축복 결과 보기
                  </button>
                </div>
              )}
            </div>

            {/* 오른쪽: 빛의 서비스 소개 슬라이드 */}
            <div className="bg-gradient-to-br from-blue-100/60 to-sky-50/80 rounded-3xl shadow-2xl shadow-blue-500/20 overflow-hidden border border-blue-200 backdrop-blur-sm">
              <div className="p-6 border-b border-blue-200">
                <h3 className="text-xl font-bold text-blue-700 drop-shadow-lg">
                  빛의 학습법 및 활용팁
                </h3>
                <p className="text-blue-600 text-sm mt-1 drop-shadow-sm">
                  효과적인 천국 학습 전략과 천사 성적 향상 방법을 알아보세요
                </p>
              </div>

              {/* 빛의 슬라이드 컨테이너 */}
              <div className="relative h-96 overflow-hidden">
                {serviceSlides.map((slide, index) => (
                  <div
                    key={index}
                    className={`absolute inset-0 transition-transform duration-500 ease-in-out ${
                      index === currentSlide ? 'translate-x-0' : 
                      index < currentSlide ? '-translate-x-full' : 'translate-x-full'
                    }`}
                  >
                    <div className={`h-full bg-gradient-to-br ${slide.color} p-8 text-white relative overflow-hidden`}>
                      {/* 빛의 배경 효과 */}
                      <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-blue-100/10 to-transparent"></div>
                      
                      <div className="flex flex-col justify-center h-full relative z-10">
                        <h4 className="text-2xl font-bold mb-4 drop-shadow-lg">{slide.title}</h4>
                        <p className="text-lg mb-6 text-white/90 drop-shadow-sm">{slide.description}</p>
                        
                        <div className="space-y-3">
                          {slide.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center">
                              <div className="w-2 h-2 bg-white/80 rounded-full mr-3"></div>
                              <span className="text-white/90 drop-shadow-sm">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* 빛의 슬라이드 인디케이터 */}
              <div className="flex justify-center space-x-2 p-4 bg-white/80 backdrop-blur-sm">
                {serviceSlides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-200 ${
                      index === currentSlide ? 'bg-blue-500' : 'bg-blue-300 hover:bg-blue-400'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* 하단 업로드 정보 */}
          <div className="mt-8 bg-gradient-to-br from-blue-100/60 to-sky-50/80 rounded-2xl shadow-lg shadow-blue-500/20 p-6 border border-blue-200 backdrop-blur-sm">
            <h4 className="text-lg font-semibold text-blue-700 mb-4 drop-shadow-lg">업로드된 천사 파일 정보</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <span className="text-blue-500">천사 파일명:</span>
                <p className="font-medium truncate text-blue-700">{uploadData.fileName}</p>
              </div>
              <div>
                <span className="text-blue-500">크기:</span>
                <p className="font-medium text-blue-700">{(uploadData.fileSize / 1024 / 1024).toFixed(2)} MB</p>
              </div>
              <div>
                <span className="text-blue-500">축복받은 과목:</span>
                <p className="font-medium text-blue-700">{uploadData.subject}</p>
              </div>
              <div>
                <span className="text-blue-500">천사 학년:</span>
                <p className="font-medium text-blue-700">{uploadData.grade}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}