// ============================================
// ✨ Angelic Light ProblemSolving.jsx - 축복 문제 해결 페이지
// ============================================
// 📚 주요 기능:
// - 천사의 문제 풀이 시스템
// - 빛의 실시간 타이머
// - 축복받은 즉시 피드백
// - 희망 학습 진도 추적
// - 반응형 빛 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function ProblemSolving() {
  const navigate = useNavigate();
  const location = useLocation();
  const problemData = location.state?.problemData;
  
  const [currentProblemIndex, setCurrentProblemIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState({});
  const [showResults, setShowResults] = useState({});
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [isSubmitted, setIsSubmitted] = useState(false);

  // 축복 효과 상태
  const [blessingEffect, setBlessingEffect] = useState(false);
  const [lightShine, setLightShine] = useState(false);
  const [angelFlicker, setAngelFlicker] = useState(false);
  const [holyGlow, setHolyGlow] = useState(false);

  // 뒤로가기
  const handleBackToNote = () => {
    navigate('/wrong-answer-note');
  };

  // 축복 효과 트리거
  useEffect(() => {
    const blessingInterval = setInterval(() => {
      setBlessingEffect(true);
      setTimeout(() => setBlessingEffect(false), 250);
    }, 8000 + Math.random() * 12000);

    const lightInterval = setInterval(() => {
      setLightShine(true);
      setTimeout(() => setLightShine(false), 3500);
    }, 12000 + Math.random() * 18000);

    const angelInterval = setInterval(() => {
      setAngelFlicker(true);
      setTimeout(() => setAngelFlicker(false), 400);
    }, 6000 + Math.random() * 14000);

    const glowInterval = setInterval(() => {
      setHolyGlow(true);
      setTimeout(() => setHolyGlow(false), 300);
    }, 15000 + Math.random() * 25000);

    return () => {
      clearInterval(blessingInterval);
      clearInterval(lightInterval);
      clearInterval(angelInterval);
      clearInterval(glowInterval);
    };
  }, []);

  // 타이머
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeElapsed(prev => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // 축복받은 문제 데이터 (더미)
  const problems = problemData || [
    {
      id: 1,
      subject: '✨ 희망의 국어',
      difficulty: '중급',
      question: '다음 글에서 필자의 주장으로 가장 적절한 것은?',
      passage: `독서는 단순히 정보를 얻는 행위를 넘어서 인간의 정신적 성장을 돕는 중요한 활동이다. 책을 읽을 때 우리는 작가의 사고와 경험을 간접적으로 체험하며, 이를 통해 자신의 사고의 폭을 넓힐 수 있다.

특히 문학 작품을 읽을 때 독자는 등장인물의 감정과 행동을 이해하려고 노력하며, 이 과정에서 공감 능력과 상상력이 발달한다. 또한 다양한 장르의 책을 읽음으로써 세상을 바라보는 다각적인 시각을 기를 수 있다.

따라서 우리는 일상에서 독서 시간을 확보하고, 양질의 도서를 선별하여 읽는 습관을 길러야 한다.`,
      options: [
        '독서는 정보 습득의 수단일 뿐이다',
        '문학 작품만이 진정한 독서의 대상이다',
        '독서를 통해 정신적 성장을 추구해야 한다',
        '독서보다 실제 경험이 더 중요하다',
        '모든 책이 똑같은 가치를 지닌다'
      ],
      correctAnswer: 2,
      explanation: '글에서 필자는 독서가 정신적 성장을 돕는 중요한 활동이며, 사고의 폭을 넓히고 공감 능력을 기를 수 있다고 주장하면서, 일상에서 독서 습관을 길러야 한다고 강조하고 있습니다.'
    },
    {
      id: 2,
      subject: '🌟 빛의 영어',
      difficulty: '고급',
      question: 'Choose the best answer to complete the passage.',
      passage: `The concept of sustainable development has gained significant attention in recent years. It refers to meeting the needs of the present _____ compromising the ability of future generations to meet their own needs. This approach requires balancing economic growth, environmental protection, and social equity.`,
      options: [
        'without',
        'despite',
        'through',
        'beyond',
        'within'
      ],
      correctAnswer: 0,
      explanation: '"without compromising"은 "~을 손상시키지 않으면서"라는 의미로, 지속가능한 발전의 정의에서 현재 세대의 필요를 충족시키면서도 미래 세대의 능력을 손상시키지 않는다는 개념을 나타냅니다.'
    },
    {
      id: 3,
      subject: '💫 천사의 수학',
      difficulty: '중급',
      question: '다음 방정식의 해를 구하시오: 2x² - 8x + 6 = 0',
      passage: null,
      options: [
        'x = 1, 3',
        'x = 2, 4',
        'x = 1, 2',
        'x = 3, 4',
        'x = 2, 3'
      ],
      correctAnswer: 0,
      explanation: '2x² - 8x + 6 = 0을 2로 나누면 x² - 4x + 3 = 0이 됩니다. 이를 인수분해하면 (x-1)(x-3) = 0이므로 x = 1 또는 x = 3입니다.'
    }
  ];

  const currentProblem = problems[currentProblemIndex];

  // 답안 선택
  const handleAnswerSelect = (optionIndex) => {
    setUserAnswers(prev => ({
      ...prev,
      [currentProblemIndex]: optionIndex
    }));
  };

  // 정답 확인
  const handleSubmitAnswer = () => {
    setShowResults(prev => ({
      ...prev,
      [currentProblemIndex]: true
    }));
  };

  // 다음 문제
  const handleNextProblem = () => {
    if (currentProblemIndex < problems.length - 1) {
      setCurrentProblemIndex(prev => prev + 1);
    }
  };

  // 이전 문제
  const handlePrevProblem = () => {
    if (currentProblemIndex > 0) {
      setCurrentProblemIndex(prev => prev - 1);
    }
  };

  // 전체 제출
  const handleSubmitAll = () => {
    // 모든 문제의 결과 표시
    const allResults = {};
    problems.forEach((_, index) => {
      allResults[index] = true;
    });
    setShowResults(allResults);
    setIsSubmitted(true);
  };

  // 시간 포맷팅
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 난이도 색상 - 축복 버전
  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case '초급': return 'text-green-600 bg-green-100';
      case '중급': return 'text-yellow-600 bg-yellow-100';
      case '고급': return 'text-red-600 bg-red-100';
      default: return 'text-blue-600 bg-blue-100';
    }
  };

  // 점수 계산
  const calculateScore = () => {
    let correct = 0;
    problems.forEach((problem, index) => {
      if (userAnswers[index] === problem.correctAnswer) {
        correct++;
      }
    });
    return {
      correct,
      total: problems.length,
      percentage: Math.round((correct / problems.length) * 100)
    };
  };

  const getSubjectColor = (subject) => {
    if (subject.includes('국어')) return 'text-blue-600 bg-blue-100';
    if (subject.includes('영어')) return 'text-sky-600 bg-sky-100';
    if (subject.includes('수학')) return 'text-indigo-600 bg-indigo-100';
    return 'text-blue-600 bg-blue-100';
  };

  if (!problems || problems.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-white via-sky-50 to-blue-100 flex items-center justify-center">
        <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-blue-200 text-center">
          <div className="text-4xl mb-4">👼</div>
          <h2 className="text-xl font-bold text-blue-600 mb-4">문제 데이터가 없습니다</h2>
          <button
            onClick={handleBackToNote}
            className="bg-gradient-to-r from-blue-500 to-sky-400 text-white px-6 py-3 rounded-xl hover:from-blue-400 hover:to-sky-300 transition-all duration-300 font-medium"
          >
            ✨ 돌아가기
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br from-white via-sky-50 to-blue-100 relative overflow-hidden ${blessingEffect ? 'animate-pulse' : ''}`}>
      {/* 천사 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 천사 날개 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,0 Q50,30 100,0 L100,20 Q50,50 0,20 Z" fill="url(#angelGradient)" />
            <defs>
              <linearGradient id="angelGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#60a5fa" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 빛 효과 */}
        {lightShine && (
          <div className="absolute top-0 left-1/4 w-2 h-32 bg-gradient-to-b from-blue-400 to-transparent animate-ping opacity-70"></div>
        )}
        
        {/* 성스러운 빛 */}
        {holyGlow && (
          <div className="absolute inset-0 bg-gradient-to-r from-blue-200/20 to-sky-200/20 animate-pulse"></div>
        )}
        
        {/* 구름 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-white/30 to-transparent"></div>
      </div>

      {/* 헤더 */}
      <div className="bg-white bg-opacity-90 shadow-2xl border-b border-blue-200 backdrop-blur-sm relative z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToNote}
                className="text-blue-600 hover:text-blue-500 mr-4 transition-all duration-300 transform hover:scale-110"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-bold bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent ${blessingEffect ? 'animate-bounce' : ''}`}>
                ✨ 축복 문제 해결 - Problem Solving Blessing
              </h1>
            </div>
            
            {/* 타이머 */}
            <div className="flex items-center space-x-4">
              <div className="bg-blue-100 bg-opacity-50 text-blue-600 px-4 py-2 rounded-xl font-semibold border border-blue-200">
                ⏰ {formatTime(timeElapsed)}
              </div>
              <div className="bg-sky-100 bg-opacity-50 text-sky-600 px-4 py-2 rounded-xl font-semibold border border-sky-200">
                📝 {currentProblemIndex + 1}/{problems.length}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto space-y-8">
          
          {/* 진도 표시 */}
          <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-6 border-2 border-blue-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-blue-600">📊 문제 진행 상황</h3>
              <span className="text-blue-500 text-sm">
                {Object.keys(showResults).length}/{problems.length} 문제 완료
              </span>
            </div>
            
            <div className="w-full bg-blue-200 bg-opacity-50 rounded-full h-3 border border-blue-200">
              <div 
                className="bg-gradient-to-r from-blue-500 to-sky-400 h-3 rounded-full transition-all duration-500"
                style={{ width: `${(Object.keys(showResults).length / problems.length) * 100}%` }}
              ></div>
            </div>
            
            <div className="flex justify-between mt-2 text-sm text-blue-500">
              <span>시작</span>
              <span>완료</span>
            </div>
          </div>

          {/* 현재 문제 */}
          <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl border-2 border-blue-200 overflow-hidden relative">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 to-white/80"></div>
            
            {/* 문제 헤더 */}
            <div className="p-6 border-b border-blue-200 relative z-10">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getSubjectColor(currentProblem.subject)}`}>
                    {currentProblem.subject}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getDifficultyColor(currentProblem.difficulty)}`}>
                    {currentProblem.difficulty}
                  </span>
                </div>
                
                <div className="text-blue-600 font-semibold">
                  문제 {currentProblemIndex + 1}
                </div>
              </div>
            </div>

            {/* 문제 내용 */}
            <div className="p-6 relative z-10">
              <div className="space-y-6">
                {/* 문제 */}
                <div>
                  <h3 className="text-lg font-bold text-blue-600 mb-4">
                    📝 문제
                  </h3>
                  <p className="text-blue-700 mb-4 leading-relaxed">
                    {currentProblem.question}
                  </p>
                  
                  {/* 지문 */}
                  {currentProblem.passage && (
                    <div className="bg-blue-50 bg-opacity-50 p-4 rounded-xl border border-blue-200 mb-4">
                      <pre className="whitespace-pre-wrap text-blue-700 font-sans leading-relaxed">
                        {currentProblem.passage}
                      </pre>
                    </div>
                  )}
                </div>

                {/* 선택지 */}
                <div>
                  <h4 className="font-semibold text-blue-600 mb-3">선택지:</h4>
                  <div className="space-y-2">
                    {currentProblem.options.map((option, index) => (
                      <label
                        key={index}
                        className={`block p-3 rounded-xl border-2 cursor-pointer transition-all duration-300 hover:scale-105 ${
                          userAnswers[currentProblemIndex] === index
                            ? 'border-blue-500 bg-blue-100 text-blue-700'
                            : 'border-blue-200 bg-white hover:border-blue-300 hover:bg-blue-50'
                        }`}
                      >
                        <input
                          type="radio"
                          name={`problem-${currentProblemIndex}`}
                          value={index}
                          checked={userAnswers[currentProblemIndex] === index}
                          onChange={() => handleAnswerSelect(index)}
                          className="sr-only"
                        />
                        <div className="flex items-center">
                          <span className="w-6 h-6 bg-blue-200 rounded-full flex items-center justify-center text-blue-600 font-medium text-sm mr-3">
                            {index + 1}
                          </span>
                          <span>{option}</span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {/* 제출 버튼 */}
                <div className="text-center">
                  <button
                    onClick={handleSubmitAnswer}
                    disabled={userAnswers[currentProblemIndex] === undefined || showResults[currentProblemIndex]}
                    className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 ${
                      userAnswers[currentProblemIndex] !== undefined && !showResults[currentProblemIndex]
                        ? 'bg-gradient-to-r from-blue-600 to-sky-500 text-white hover:from-blue-500 hover:to-sky-400 shadow-lg hover:shadow-blue-500/50'
                        : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    {showResults[currentProblemIndex] ? '✅ 제출 완료' : '✨ 답안 제출'}
                  </button>
                </div>

                {/* 결과 및 해설 */}
                {showResults[currentProblemIndex] && (
                  <div className="mt-6 space-y-4">
                    <div className={`p-4 rounded-xl border-2 ${
                      userAnswers[currentProblemIndex] === currentProblem.correctAnswer
                        ? 'border-green-500 bg-green-100'
                        : 'border-red-500 bg-red-100'
                    }`}>
                      <div className="flex items-center space-x-3 mb-3">
                        <span className="text-2xl">
                          {userAnswers[currentProblemIndex] === currentProblem.correctAnswer ? '🎉' : '💫'}
                        </span>
                        <span className={`font-bold text-lg ${
                          userAnswers[currentProblemIndex] === currentProblem.correctAnswer
                            ? 'text-green-600'
                            : 'text-red-600'
                        }`}>
                          {userAnswers[currentProblemIndex] === currentProblem.correctAnswer ? '정답입니다!' : '틀렸습니다'}
                        </span>
                      </div>
                      
                      <div className="text-sm space-y-2">
                        <div>
                          <span className="font-medium text-blue-600">정답: </span>
                          <span className="text-blue-700">{currentProblem.correctAnswer + 1}번</span>
                        </div>
                        <div>
                          <span className="font-medium text-blue-600">내 답: </span>
                          <span className="text-blue-700">{userAnswers[currentProblemIndex] + 1}번</span>
                        </div>
                      </div>
                    </div>

                    {/* 해설 */}
                    <div className="bg-blue-50 bg-opacity-50 p-4 rounded-xl border border-blue-200">
                      <h5 className="font-bold text-blue-600 mb-3 flex items-center">
                        <span className="text-xl mr-2">💡</span>
                        해설
                      </h5>
                      <p className="text-blue-700 leading-relaxed">
                        {currentProblem.explanation}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 네비게이션 */}
          <div className="flex items-center justify-between">
            <button
              onClick={handlePrevProblem}
              disabled={currentProblemIndex === 0}
              className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 ${
                currentProblemIndex === 0
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-sky-500 to-blue-500 text-white hover:from-sky-400 hover:to-blue-400 shadow-lg hover:shadow-sky-500/50'
              }`}
            >
              ⬅️ 이전 문제
            </button>

            <div className="flex space-x-2">
              {problems.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentProblemIndex(index)}
                  className={`w-10 h-10 rounded-full font-semibold transition-all duration-300 transform hover:scale-110 ${
                    index === currentProblemIndex
                      ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/50'
                      : showResults[index]
                      ? 'bg-green-500 text-white'
                      : userAnswers[index] !== undefined
                      ? 'bg-yellow-500 text-white'
                      : 'bg-blue-200 text-blue-600 hover:bg-blue-300'
                  }`}
                >
                  {index + 1}
                </button>
              ))}
            </div>

            <button
              onClick={handleNextProblem}
              disabled={currentProblemIndex === problems.length - 1}
              className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 ${
                currentProblemIndex === problems.length - 1
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-blue-500 to-sky-500 text-white hover:from-blue-400 hover:to-sky-400 shadow-lg hover:shadow-blue-500/50'
              }`}
            >
              다음 문제 ➡️
            </button>
          </div>

          {/* 전체 제출 */}
          {!isSubmitted && (
            <div className="text-center">
              <button
                onClick={handleSubmitAll}
                className="bg-gradient-to-r from-green-600 to-green-500 text-white px-8 py-4 rounded-xl font-bold text-lg hover:from-green-500 hover:to-green-400 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-green-500/50"
              >
                🎯 모든 문제 제출하기
              </button>
            </div>
          )}

          {/* 최종 결과 */}
          {isSubmitted && (
            <div className="bg-gradient-to-r from-blue-500 to-sky-400 rounded-3xl shadow-2xl p-8 text-white border-2 border-blue-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/30 to-sky-400/30"></div>
              <div className="text-center relative z-10">
                <div className="text-4xl mb-4 animate-bounce">🏆</div>
                <h3 className="text-2xl font-bold mb-4">
                  축복받은 문제 해결 완료!
                </h3>
                
                {(() => {
                  const score = calculateScore();
                  return (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                      <div className="bg-white/20 rounded-xl p-4 backdrop-blur-sm">
                        <div className="text-2xl font-bold">{score.correct}</div>
                        <div className="text-blue-100 text-sm">정답 개수</div>
                      </div>
                      
                      <div className="bg-white/20 rounded-xl p-4 backdrop-blur-sm">
                        <div className="text-2xl font-bold">{score.percentage}%</div>
                        <div className="text-blue-100 text-sm">정답률</div>
                      </div>
                      
                      <div className="bg-white/20 rounded-xl p-4 backdrop-blur-sm">
                        <div className="text-2xl font-bold">{formatTime(timeElapsed)}</div>
                        <div className="text-blue-100 text-sm">소요 시간</div>
                      </div>
                    </div>
                  );
                })()}
                
                <button
                  onClick={handleBackToNote}
                  className="bg-white text-blue-600 px-8 py-3 rounded-xl font-semibold hover:bg-blue-50 transition-all duration-300 transform hover:scale-105"
                >
                  ✨ 완료하기
                </button>
              </div>
              {/* 천사 장식 */}
              <div className="absolute top-4 right-4 text-white opacity-50 animate-pulse">✨</div>
              <div className="absolute bottom-4 left-4 text-white opacity-30 animate-pulse">🌟</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}