// ============================================
// ✨ Angelic Light ForgotPasswordModal.jsx - 빛의 비밀번호 복원 모달
// ============================================
// 📝 주요 기능:
// - 모달 형태의 천사 비밀번호 재설정 폼
// - 축복받은 이메일 인증 시스템
// - 빛의 보안 복원 처리
// - 반응형 디자인 및 천사 애니메이션
// ============================================

import React, { useState, useEffect } from 'react';

export default function ForgotPasswordModal({ isOpen, onClose, onBackToLogin }) {
  const [formData, setFormData] = useState({
    email: ''
  });
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [isEmailSent, setIsEmailSent] = useState(false);

  // 모달이 열릴 때 body 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.keyCode === 27) onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  // 모달이 닫힐 때 상태 초기화
  useEffect(() => {
    if (!isOpen) {
      setFormData({ email: '' });
      setErrors({});
      setIsEmailSent(false);
      setIsLoading(false);
    }
  }, [isOpen]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // 에러 메시지 클리어
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    // 이메일 유효성 검사
    if (!formData.email) {
      newErrors.email = '천사의 이메일을 입력해주세요.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = '올바른 이메일 형식을 입력해주세요.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);
    
    try {
      // 시뮬레이션된 로딩 (실제 천국 API 호출 시뮬레이션)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // 더미 데이터로 비밀번호 재설정 이메일 발송 처리
      // 실제로는 서버에서 이메일 발송 로직을 수행
      
      setIsEmailSent(true);
      setErrors({});
      
    } catch (error) {
      console.error('빛의 비밀번호 복원 오류:', error);
      setErrors({ general: '비밀번호 복원 처리 중 예상치 못한 오류가 발생했습니다.' });
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* 빛의 배경 오버레이 */}
      <div 
        className="fixed inset-0 bg-white bg-opacity-95 transition-opacity duration-300"
        onClick={onClose}
      />
      
      {/* 천사의 모달 컨테이너 */}
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="relative bg-white rounded-3xl shadow-2xl shadow-blue-500/20 w-full max-w-md transform transition-all duration-300 modal-enter border-2 border-blue-200">
          {/* 천사의 배경 효과 */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50/80 via-white/90 to-sky-100/60 rounded-3xl"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,rgba(255,255,255,0.9)_100%)] rounded-3xl"></div>
          
          {/* 움직이는 빛의 파티클 */}
          <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
            <div className="absolute top-8 left-12 w-1 h-1 bg-blue-400/60 rounded-full animate-pulse"></div>
            <div className="absolute top-16 right-16 w-1 h-1 bg-sky-400/50 rounded-full animate-pulse delay-700"></div>
            <div className="absolute bottom-12 left-16 w-1 h-1 bg-indigo-400/40 rounded-full animate-pulse delay-1000"></div>
            <div className="absolute top-1/2 right-12 w-1 h-1 bg-blue-500/60 rounded-full animate-pulse delay-500"></div>
          </div>

          {/* 천사의 닫기 버튼 */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-blue-400 hover:text-blue-500 transition-colors duration-200 z-10 p-2 hover:bg-blue-100/50 rounded-xl"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          {/* 천사의 헤더 */}
          <div className="px-8 pt-8 pb-6 text-center relative z-10">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-sky-400 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/50 border border-blue-300">
              <span className="text-3xl text-white">🔑</span>
            </div>
            <h2 className="text-2xl font-bold text-blue-600 mb-2 drop-shadow-lg">💫 빛의 비밀번호 복원</h2>
            <p className="text-blue-500 drop-shadow-sm">
              {isEmailSent 
                ? '축복의 이메일을 발송했습니다' 
                : '등록된 이메일로 복원 링크를 보내드립니다'
              }
            </p>
          </div>

          {/* 이메일 발송 완료 화면 */}
          {isEmailSent ? (
            <div className="px-8 pb-8 relative z-10">
              <div className="text-center space-y-6">
                <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-400 rounded-full flex items-center justify-center mx-auto shadow-lg shadow-green-500/50">
                  <span className="text-4xl text-white">📧</span>
                </div>
                
                <div className="space-y-3">
                  <h3 className="text-lg font-bold text-green-600">✨ 축복 이메일 발송 완료!</h3>
                  <p className="text-blue-600 text-sm leading-relaxed">
                    <strong>{formData.email}</strong>로<br/>
                    빛의 비밀번호 복원 링크를 발송했습니다.
                  </p>
                  <div className="bg-blue-50 bg-opacity-50 p-4 rounded-xl border border-blue-200">
                    <p className="text-blue-600 text-xs leading-relaxed">
                      💌 이메일이 도착하지 않았다면 스팸함을 확인해주세요.<br/>
                      🕐 링크는 24시간 동안 유효합니다.
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  <button
                    onClick={onBackToLogin}
                    className="w-full py-3 px-6 bg-gradient-to-r from-blue-600 to-sky-500 text-white rounded-xl font-semibold hover:from-blue-500 hover:to-sky-400 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-blue-500/50"
                  >
                    🚪 천국문으로 돌아가기
                  </button>
                  
                  <button
                    onClick={() => setIsEmailSent(false)}
                    className="w-full py-3 px-6 bg-sky-100 text-sky-600 rounded-xl font-semibold hover:bg-sky-200 transition-all duration-300"
                  >
                    🔄 다른 이메일로 재시도
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* 이메일 입력 폼 */
            <form onSubmit={handleSubmit} className="px-8 pb-8 relative z-10">
              {/* 전체 에러 메시지 */}
              {errors.general && (
                <div className="mb-4 p-3 bg-red-100 border border-red-300 text-red-600 rounded-xl text-sm backdrop-blur-sm">
                  {errors.general}
                </div>
              )}

              <div className="space-y-4">
                {/* 천사 이메일 */}
                <div>
                  <label className="block text-sm font-semibold text-blue-600 mb-2 drop-shadow-sm">
                    등록된 천사의 이메일 <span className="text-blue-500">*</span>
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    disabled={isLoading}
                    className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 transition-all duration-200 backdrop-blur-sm ${
                      errors.email 
                        ? 'border-red-300 focus:ring-red-500 bg-red-50' 
                        : 'border-blue-300 focus:ring-blue-500 focus:border-transparent bg-blue-50/30'
                    }`}
                    placeholder="angel@example.com"
                  />
                  {errors.email && <p className="mt-1 text-sm text-red-500">{errors.email}</p>}
                </div>

                {/* 안내 메시지 */}
                <div className="bg-blue-50 bg-opacity-50 p-4 rounded-xl border border-blue-200">
                  <div className="flex items-start space-x-3">
                    <div className="text-blue-500 mt-1">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-semibold text-blue-600 mb-1">💡 빛의 안내</h4>
                      <p className="text-blue-600 text-sm leading-relaxed">
                        등록하신 이메일 주소로 안전한 비밀번호 복원 링크를 발송해드립니다. 
                        이메일을 확인하시고 안내에 따라 새로운 빛의 비밀번호를 설정해주세요.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* 복원 요청 버튼 */}
              <div className="mt-6 space-y-4">
                <button
                  type="submit"
                  disabled={isLoading}
                  className={`w-full py-4 px-6 rounded-xl font-semibold text-white transition-all duration-300 transform hover:scale-105 ${
                    isLoading 
                      ? 'bg-blue-300 cursor-not-allowed' 
                      : 'bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 hover:to-sky-400 shadow-lg hover:shadow-blue-500/50'
                  }`}
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      ✨ 축복 이메일 발송 중...
                    </div>
                  ) : '📧 복원 링크 발송하기'}
                </button>

                {/* 돌아가기 링크 */}
                <div className="text-center">
                  <button
                    type="button"
                    onClick={onBackToLogin}
                    disabled={isLoading}
                    className="text-blue-500 hover:text-blue-400 text-sm transition-colors duration-200 hover:underline"
                  >
                    🚪 천국문으로 돌아가기
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* 천사 장식 */}
          <div className="absolute top-4 right-16 text-blue-400 opacity-30 animate-pulse">✨</div>
          <div className="absolute bottom-4 left-8 text-blue-400 opacity-20 animate-pulse">🌟</div>
        </div>
      </div>
    </div>
  );
}