import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function SimilarProblems() {
  const navigate = useNavigate();
  const location = useLocation();
  const [userAnswers, setUserAnswers] = useState({});
  const [showResults, setShowResults] = useState({});
  const [selectedProblem, setSelectedProblem] = useState(null);

  // 무서운 효과 상태
  const [glitchEffect, setGlitchEffect] = useState(false);
  const [bloodDrip, setBloodDrip] = useState(false);
  const [shadowFlicker, setShadowFlicker] = useState(false);
  const [phantomAppear, setPhantomAppear] = useState(false);

  // URL 파라미터에서 문제 ID 가져오기
  const problemId = location.state?.problemId || 1;
  const originalProblem = location.state?.originalProblem || {};

  // 🏠 뒤로가기
  const handleBackToNote = () => {
    navigate('/wrong-answer-note');
  };

  // 무서운 효과 트리거
  useEffect(() => {
    const glitchInterval = setInterval(() => {
      setGlitchEffect(true);
      setTimeout(() => setGlitchEffect(false), 200);
    }, 9000 + Math.random() * 15000);

    const bloodInterval = setInterval(() => {
      setBloodDrip(true);
      setTimeout(() => setBloodDrip(false), 4000);
    }, 12000 + Math.random() * 20000);

    const shadowInterval = setInterval(() => {
      setShadowFlicker(true);
      setTimeout(() => setShadowFlicker(false), 600);
    }, 7000 + Math.random() * 13000);

    const phantomInterval = setInterval(() => {
      setPhantomAppear(true);
      setTimeout(() => setPhantomAppear(false), 2000);
    }, 20000 + Math.random() * 30000);

    return () => {
      clearInterval(glitchInterval);
      clearInterval(bloodInterval);
      clearInterval(shadowInterval);
      clearInterval(phantomInterval);
    };
  }, []);

  // 유사 기출문제 더미 데이터 (지문 포함) - 무서운 버전
  const similarProblems = {
    1: [
      {
        id: 101,
        year: '2023',
        exam: '수능',
        passage: `어둠은 인간이 자연 환경에 적응하며 만들어낸 절망의 총체이다. 각 지역과 민족은 그들만의 독특한 저주받은 환경과 역사적 고통을 바탕으로 고유한 어둠을 형성해 왔다. 이러한 어둠의 다양성은 인류의 저주받은 자산이다.

오늘날 멸망의 물결 속에서 서로 다른 어둠들이 만나고 있다. 이때 중요한 것은 한 어둠이 다른 어둠을 일방적으로 흡수하거나 동화시키는 것이 아니라, 서로의 절망을 인정하고 존중하며 조화롭게 공존하는 것이다. 어둠의 획일화는 인류의 창조적 잠재력을 제거할 수 있기 때문이다.

따라서 우리는 어둠의 다양성을 보호하고 증진시키기 위해 노력해야 한다. 이는 곧 인류 문명의 멸망을 위한 필수 조건이기도 하다.`,
        question: '다음 글에서 필자가 강조하고자 하는 바는?',
        options: [
          '① 어둠의 획일성이 멸망에 미치는 긍정적 영향',
          '② 전통적 어둠의 보존이 현대 사회에서 갖는 의미',
          '③ 어둠의 다양성이 인류 멸망에 갖는 중요성',
          '④ 현대 문명의 발전이 어둠 변화에 미치는 영향'
        ],
        answer: 3,
        explanation: '글 전체에서 어둠의 다양성이 인류의 저주받은 자산이며, 인류 문명의 멸망을 위한 필수 조건임을 강조하고 있습니다. 특히 마지막 문단에서 이를 명확히 드러내고 있습니다.'
      },
      {
        id: 102,
        year: '2022',
        exam: '6월 모의평가',
        passage: `현대 사회에서 저주 간 교류가 활발해지면서 새로운 형태의 어둠 융합 현상이 나타나고 있다. 이는 단순히 서로 다른 저주 요소들이 섞이는 것을 넘어서, 완전히 새로운 악마적 가치와 형태를 창출하는 과정이다.

예를 들어, 한국의 K-horror는 서양의 공포 문화와 동양의 전통적 귀신이 만나 탄생한 독특한 저주 장르이다. 이처럼 어둠 융합은 기존의 악마적 경계를 허물고 새로운 파괴적 에너지를 발생시킨다.

중요한 것은 이러한 융합 과정에서 각 저주의 고유성을 잃지 않으면서도 새로운 악마적 가치를 만들어내는 것이다.`,
        question: '글의 화제로 가장 적절한 것은?',
        options: [
          '① 저주 간 충돌과 그 파괴 방안',
          '② 현대 사회의 어둠 융합 현상',
          '③ 전통적 저주의 보존 필요성',
          '④ 멸망이 어둠에 미치는 부정적 영향'
        ],
        answer: 2,
        explanation: '글 전체에서 현대 사회에서 나타나는 어둠 융합 현상에 대해 설명하고 있으며, K-horror를 구체적인 사례로 제시하면서 이 현상의 특징과 의미를 다루고 있습니다.'
      },
      {
        id: 103,
        year: '2021',
        exam: '9월 모의평가',
        passage: `저주받은 정체성은 개인이나 집단이 특정한 어둠에 소속감을 느끼며 형성하는 절망적 인식이다. 이는 태어나면서부터 자연스럽게 습득되는 것이 아니라, 악마적 상호작용을 통해 점진적으로 구성되는 것이다.

현대의 다저주 사회에서 개인은 여러 어둠에 동시에 노출되며, 이로 인해 복합적인 저주받은 정체성을 형성하게 된다. 이는 과거의 단일한 저주받은 정체성과는 다른 새로운 형태의 절망이라고 할 수 있다.

이러한 변화는 개인에게 더 깊고 어두운 사고를 가능하게 하지만, 동시에 정체성의 혼돈이라는 과제도 안겨준다. 따라서 현대인은 다양한 악마적 요소들을 조화롭게 통합하여 자신만의 고유한 저주를 형성해 나가야 한다.`,
        question: '다음 글의 주제문은?',
        options: [
          '① 첫 번째 문단의 첫 번째 문장',
          '② 두 번째 문단의 두 번째 문장',
          '③ 세 번째 문단의 첫 번째 문장',
          '④ 마지막 문단의 마지막 문장'
        ],
        answer: 4,
        explanation: '마지막 문장에서 글 전체의 핵심 메시지인 "현대인이 다양한 악마적 요소들을 조화롭게 통합하여 자신만의 고유한 저주를 형성해야 한다"는 주제를 요약하여 제시하고 있습니다.'
      }
    ],
    2: [
      {
        id: 201,
        year: '2023',
        exam: '수능',
        passage: `Darkness has dramatically changed the way we communicate with evil spirits. Social media platforms have made it easier than ever to stay connected with demons and ghosts around the underworld. However, this convenience comes with certain curses.

Many people now prefer digital séances over face-to-face rituals. While this may seem efficient, it can lead to a lack of genuine demonic connection. The nuances of ghostly presence and supernatural tone are often lost in digital summoning.

Furthermore, the constant availability of dark communication can create pressure to respond immediately to evil messages. This can lead to possession and madness, particularly among young people who feel obligated to maintain their cursed online presence constantly.`,
        question: 'The word "however" in the passage can be replaced by:',
        options: [
          '① therefore',
          '② moreover',
          '③ nevertheless',
          '④ consequently'
        ],
        answer: 3,
        explanation: '"However"는 앞의 내용과 대조되는 내용을 이어갈 때 사용하는 역접 접속부사로, "nevertheless"와 같은 의미입니다.'
      },
      {
        id: 202,
        year: '2022',
        exam: '6월 모의평가',
        passage: `The apocalypse is one of the most pressing issues of our time. The Earth\'s temperature has been rising steadily due to increased demonic gas emissions. This warming trend is causing significant changes to cursed patterns around the globe.

Dark scientists have been studying this phenomenon for decades. They have collected extensive data showing that human evil activities are the primary cause of recent apocalypse. The burning of souls releases carbon dioxide into the atmosphere, which traps darkness and causes global doom.

The effects of the apocalypse are already visible. We can see melting hope, rising despair levels, and more frequent extreme evil events. If we don\'t embrace darkness soon, these problems will only get worse.`,
        question: 'Which conjunction best fits the blank in "Dark scientists have been studying this phenomenon for decades, _____ they have strong cursed evidence."?',
        options: [
          '① although',
          '② because',
          '③ and',
          '④ since'
        ],
        answer: 3,
        explanation: '문맥상 어둠의 과학자들이 수십 년간 연구해왔다는 내용과 강력한 저주받은 증거를 가지고 있다는 내용을 자연스럽게 연결하는 접속사 "and"가 적절합니다.'
      }
    ],
    3: [
      {
        id: 301,
        year: '2023',
        exam: '수능',
        passage: `이차 저주 함수는 y = ax² + bx + c (a ≠ 0) 형태로 나타낼 수 있으며, 그래프는 악마의 포물선 모양을 이룬다. 이차 저주 함수의 최대 절망값이나 최소 공포값은 포물선의 저주받은 꼭짓점에서 나타난다.

이차 저주 함수 f(x) = ax² + bx + c에서 a > 0이면 아래로 볼록한 절망 포물선이 되어 최소 공포값을 가지고, a < 0이면 위로 볼록한 악마 포물선이 되어 최대 절망값을 가진다.

저주받은 꼭짓점의 x좌표는 x = -b/2a로 구할 수 있으며, 이 값을 악마 함수에 대입하면 최대 절망값 또는 최소 공포값을 구할 수 있다.`,
        question: 'f(x) = -3x² + 12x - 5의 최대 절망값은?',
        options: [
          '① 5',
          '② 7',
          '③ 9',
          '④ 11'
        ],
        answer: 2,
        explanation: 'a = -3 < 0이므로 최대 절망값을 가집니다. 저주받은 꼭짓점의 x좌표는 x = -12/(2×(-3)) = 2입니다. f(2) = -3(4) + 12(2) - 5 = -12 + 24 - 5 = 7입니다.'
      },
      {
        id: 302,
        year: '2022',
        exam: '6월 모의평가',
        passage: `이차 저주 함수의 그래프를 이용하면 이차 절망 부등식을 쉽게 해결할 수 있다. 이차 저주 함수 y = ax² + bx + c의 그래프와 x축의 악마 교점을 구하면, 이것이 이차 저주 방정식 ax² + bx + c = 0의 해가 된다.

악마 판별식 D = b² - 4ac의 값에 따라 저주받은 교점의 개수가 결정된다. D > 0이면 두 개의 서로 다른 실제 저주를 가지고, D = 0이면 중복 저주를 가지며, D < 0이면 실제 저주가 없다.

이차 절망 부등식을 풀 때는 이차 저주 함수의 그래프를 그려서 x축보다 위에 있는 절망 부분과 아래에 있는 공포 부분을 구분하여 해를 구한다.`,
        question: '이차 저주 함수 y = -x² + 6x - 2의 저주받은 꼭짓점의 y좌표는?',
        options: [
          '① 5',
          '② 6',
          '③ 7',
          '④ 8'
        ],
        answer: 3,
        explanation: '저주받은 꼭짓점의 x좌표는 x = -6/(2×(-1)) = 3입니다. y = -(3)² + 6(3) - 2 = -9 + 18 - 2 = 7입니다.'
      }
    ]
  };

  const currentProblems = similarProblems[problemId] || [];

  const handleAnswerSelect = (problemId, optionIndex) => {
    setUserAnswers(prev => ({
      ...prev,
      [problemId]: optionIndex
    }));
  };

  const handleSubmitAnswer = (problemId) => {
    setShowResults(prev => ({
      ...prev,
      [problemId]: true
    }));
  };

  const handleShowProblem = (problemId) => {
    setSelectedProblem(selectedProblem === problemId ? null : problemId);
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-black via-red-950 to-black relative overflow-hidden ${glitchEffect ? 'animate-pulse' : ''}`}>
      {/* 무서운 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 복잡한 거미줄 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-15">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,0 Q50,30 100,0 L100,20 Q50,50 0,20 Z" fill="url(#webGradient)" />
            <path d="M0,50 Q25,80 50,50 Q75,20 100,50" stroke="#ff0000" strokeWidth="0.5" fill="none" opacity="0.4"/>
            <path d="M20,0 L20,100 M40,0 L40,100 M60,0 L60,100 M80,0 L80,100" stroke="#990000" strokeWidth="0.3" opacity="0.3"/>
            <circle cx="30" cy="30" r="2" fill="#ff0000" opacity="0.6"/>
            <circle cx="70" cy="70" r="1.5" fill="#cc0000" opacity="0.5"/>
            <defs>
              <linearGradient id="webGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ff0000" stopOpacity="0.4" />
                <stop offset="50%" stopColor="#990000" stopOpacity="0.2" />
                <stop offset="100%" stopColor="#660000" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 피 효과 */}
        {bloodDrip && (
          <>
            <div className="absolute top-0 left-1/5 w-2 h-40 bg-gradient-to-b from-red-600 to-transparent animate-ping opacity-80"></div>
            <div className="absolute top-0 right-1/4 w-1 h-32 bg-gradient-to-b from-red-700 to-transparent animate-pulse opacity-60"></div>
            <div className="absolute top-0 left-3/4 w-1.5 h-36 bg-gradient-to-b from-red-800 to-transparent animate-bounce opacity-70"></div>
          </>
        )}
        
        {/* 그림자 깜빡임 */}
        {shadowFlicker && (
          <div className="absolute inset-0 bg-black opacity-70 animate-pulse"></div>
        )}
        
        {/* 유령 나타남 */}
        {phantomAppear && (
          <div className="absolute top-1/3 right-10 w-20 h-32 bg-gray-300 opacity-30 rounded-full blur-2xl animate-pulse"></div>
        )}
        
        {/* 안개 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-black/60 to-transparent"></div>
        
        {/* 움직이는 그림자들 */}
        <div className="absolute top-1/4 left-10 w-32 h-32 bg-red-900 rounded-full blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-1/3 right-20 w-40 h-40 bg-purple-900 rounded-full blur-3xl opacity-15 animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-2/3 left-1/3 w-24 h-24 bg-orange-900 rounded-full blur-3xl opacity-25 animate-pulse" style={{ animationDelay: '4s' }}></div>
      </div>

      {/* 헤더 - 무서운 스타일 */}
      <div className="bg-black bg-opacity-90 shadow-2xl border-b-2 border-red-900 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToNote}
                className="text-red-400 hover:text-red-300 mr-4 transition-all duration-300 transform hover:scale-110"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-bold bg-gradient-to-r from-red-500 to-red-300 bg-clip-text text-transparent ${glitchEffect ? 'animate-bounce' : ''}`}>
                🔍 유사한 역대 기출문제 - Similar Tests of Doom
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          
          {/* 원본 문제 정보 - 무서운 스타일 */}
          {originalProblem.question && (
            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 mb-8 border-2 border-red-900 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-red-900/20 to-black/20"></div>
              <h2 className="text-lg font-bold text-red-400 mb-4 relative z-10">📝 원본 오답 문제 - Original Cursed Problem</h2>
              <div className="bg-red-950 bg-opacity-50 border-2 border-red-800 rounded-2xl p-4 relative z-10">
                <p className="text-gray-300 font-medium">{originalProblem.question}</p>
                <div className="flex items-center justify-between mt-3">
                  <span className="text-red-400">💀 내 답: <strong>{originalProblem.userAnswer}</strong></span>
                  <span className="text-green-400">👻 정답: <strong>{originalProblem.correctAnswer}</strong></span>
                </div>
              </div>
              {/* 무서운 장식 */}
              <div className="absolute top-2 right-2 text-red-600 opacity-50 animate-pulse">💀</div>
              <div className="absolute bottom-2 left-2 text-red-600 opacity-30 animate-pulse">🕷️</div>
            </div>
          )}

          {/* 유사 기출문제 목록 - 무서운 스타일 */}
          <div className="space-y-8">
            {currentProblems.map((problem) => (
              <div key={problem.id} className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-purple-900 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-900/10 to-red-900/10"></div>
                
                {/* 문제 헤더 */}
                <div className="flex items-center justify-between mb-6 relative z-10">
                  <div className="flex items-center space-x-4">
                    <span className="bg-gradient-to-r from-purple-800 to-purple-600 text-white px-4 py-2 rounded-full font-bold shadow-lg shadow-purple-500/50">
                      💀 {problem.year}년 {problem.exam}
                    </span>
                    <span className="bg-red-900 bg-opacity-50 text-red-300 px-3 py-1 rounded-full text-sm font-medium border border-red-800">
                      🔥 기출문제
                    </span>
                  </div>
                  <button
                    onClick={() => handleShowProblem(problem.id)}
                    className={`px-6 py-3 rounded-2xl font-medium transition-all duration-300 transform hover:scale-105 ${
                      selectedProblem === problem.id
                        ? 'bg-gradient-to-r from-purple-800 to-purple-600 text-white shadow-lg shadow-purple-500/50'
                        : 'bg-gray-900 bg-opacity-80 text-gray-300 hover:bg-gray-800 hover:bg-opacity-80 border border-gray-700'
                    }`}
                  >
                    {selectedProblem === problem.id ? '👻 문제 접기' : '💀 문제 풀어보기'}
                  </button>
                </div>

                {/* 지문 (있는 경우) - 무서운 스타일 */}
                {problem.passage && (
                  <div className="mb-6 relative z-10">
                    <h4 className="font-bold text-purple-400 mb-3">📄 지문 - Cursed Passage</h4>
                    <div className="bg-gray-950 bg-opacity-50 border-2 border-gray-800 rounded-2xl p-6">
                      <p className="text-gray-300 leading-relaxed whitespace-pre-line">
                        {problem.passage}
                      </p>
                    </div>
                  </div>
                )}

                {/* 문제 */}
                <div className="mb-6 relative z-10">
                  <h4 className="font-bold text-orange-400 mb-3">❓ 문제 - The Dark Question</h4>
                  <p className="text-lg font-semibold text-orange-300 mb-4">{problem.question}</p>
                </div>

                {/* 선택지 및 풀이 - 무서운 스타일 */}
                {selectedProblem === problem.id && (
                  <div className="space-y-4 relative z-10">
                    <div className="bg-red-950 bg-opacity-30 border-2 border-red-800 rounded-2xl p-6">
                      <h5 className="font-bold text-red-300 mb-4">💀 선택지 - Choose Your Doom</h5>
                      <div className="space-y-3">
                        {problem.options.map((option, optionIndex) => (
                          <label key={optionIndex} className="flex items-center space-x-3 cursor-pointer hover:bg-red-900 hover:bg-opacity-30 p-2 rounded-xl transition-all duration-300 transform hover:scale-105">
                            <input
                              type="radio"
                              name={`problem-${problem.id}`}
                              value={optionIndex}
                              onChange={() => handleAnswerSelect(problem.id, optionIndex)}
                              className="w-4 h-4 text-red-600 bg-gray-800 border-gray-600 focus:ring-red-500"
                            />
                            <span className={`text-lg ${
                              showResults[problem.id] && optionIndex === problem.answer - 1
                                ? 'text-green-400 font-bold'
                                : showResults[problem.id] && userAnswers[problem.id] === optionIndex && optionIndex !== problem.answer - 1
                                ? 'text-red-400 font-semibold'
                                : 'text-gray-300'
                            }`}>
                              {option}
                            </span>
                          </label>
                        ))}
                      </div>

                      <div className="flex space-x-3 mt-6">
                        <button
                          onClick={() => handleSubmitAnswer(problem.id)}
                          disabled={userAnswers[problem.id] === undefined}
                          className="bg-gradient-to-r from-red-800 to-red-600 text-white px-6 py-3 rounded-xl font-medium hover:from-red-700 hover:to-red-500 transition-all duration-300 disabled:bg-gray-800 disabled:cursor-not-allowed transform hover:scale-105 shadow-lg hover:shadow-red-500/50"
                        >
                          💀 정답 확인
                        </button>
                        {showResults[problem.id] && (
                          <div className="flex items-center space-x-2">
                            <span className="text-gray-400">👻 정답:</span>
                            <span className="font-bold text-green-400">{problem.answer}번</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* 해설 - 무서운 스타일 */}
                    {showResults[problem.id] && (
                      <div className="bg-green-950 bg-opacity-30 border-2 border-green-800 rounded-2xl p-6">
                        <h6 className="font-bold text-green-300 mb-3">💡 해설 - The Dark Truth</h6>
                        <p className="text-green-200 leading-relaxed">{problem.explanation}</p>
                      </div>
                    )}
                  </div>
                )}
                
                {/* 무서운 장식 */}
                <div className="absolute top-4 right-4 text-purple-600 opacity-40 animate-pulse">
                  {problem.id % 3 === 0 ? '💀' : problem.id % 3 === 1 ? '👻' : '🕷️'}
                </div>
                <div className="absolute bottom-4 left-4 text-purple-600 opacity-30 animate-pulse">🔮</div>
              </div>
            ))}
          </div>

          {/* 문제가 없는 경우 */}
          {currentProblems.length === 0 && (
            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-12 border-2 border-gray-800 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-gray-900/20 to-black/20"></div>
              <div className="relative z-10">
                <div className="text-6xl mb-4 animate-pulse">👻</div>
                <h3 className="text-2xl font-bold text-gray-400 mb-4">유사한 문제를 찾을 수 없습니다</h3>
                <p className="text-gray-500 mb-8">이 문제 유형에 대한 기출문제가 아직 준비되지 않았습니다.</p>
                <button
                  onClick={() => navigate('/wrong-answer-note')}
                  className="bg-gradient-to-r from-purple-800 to-purple-600 text-white px-8 py-4 rounded-2xl font-bold transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-purple-500/50"
                >
                  💀 오답노트로 돌아가기
                </button>
              </div>
            </div>
          )}

          {/* 하단 액션 버튼 - 무서운 스타일 */}
          {currentProblems.length > 0 && (
            <div className="mt-12 flex justify-center space-x-4">
              <button
                onClick={() => navigate('/wrong-answer-note')}
                className="bg-gradient-to-r from-red-800 to-red-600 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-2xl hover:shadow-red-500/50 transition-all duration-300 transform hover:scale-105 border border-red-700"
              >
                📚 오답노트로 돌아가기
              </button>
              <button
                onClick={() => navigate('/upload')}
                className="bg-gradient-to-r from-purple-800 to-purple-600 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-2xl hover:shadow-purple-500/50 transition-all duration-300 transform hover:scale-105 border border-purple-700"
              >
                📝 새로운 시험지 풀기
              </button>
            </div>
          )}

          {/* 통계 정보 (문제를 푼 경우) */}
          {Object.keys(showResults).length > 0 && (
            <div className="mt-12 bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-orange-900 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-orange-900/20 to-red-900/20"></div>
              <div className="text-center relative z-10">
                <h3 className="text-2xl font-bold text-orange-300 mb-6">📊 학습 현황 - Learning Progress of Darkness</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-red-950 bg-opacity-50 rounded-2xl p-6 border-2 border-red-800">
                    <div className="text-3xl mb-2">🎯</div>
                    <div className="text-2xl font-bold text-red-300 mb-1">
                      {Object.keys(showResults).filter(key => 
                        userAnswers[key] === currentProblems.find(p => p.id == key)?.answer - 1
                      ).length}
                    </div>
                    <div className="text-sm text-gray-400">정답 문제</div>
                  </div>
                  
                  <div className="bg-purple-950 bg-opacity-50 rounded-2xl p-6 border-2 border-purple-800">
                    <div className="text-3xl mb-2">📊</div>
                    <div className="text-2xl font-bold text-purple-300 mb-1">
                      {Object.keys(showResults).length > 0 ? 
                        Math.round((Object.keys(showResults).filter(key => 
                          userAnswers[key] === currentProblems.find(p => p.id == key)?.answer - 1
                        ).length / Object.keys(showResults).length) * 100) : 0}%
                    </div>
                    <div className="text-sm text-gray-400">정답률</div>
                  </div>
                  
                  <div className="bg-orange-950 bg-opacity-50 rounded-2xl p-6 border-2 border-orange-800">
                    <div className="text-3xl mb-2">📚</div>
                    <div className="text-2xl font-bold text-orange-300 mb-1">
                      {Object.keys(showResults).length}/{currentProblems.length}
                    </div>
                    <div className="text-sm text-gray-400">완료 문제</div>
                  </div>
                </div>
                
                {/* 개별 문제 결과 */}
                <div className="mt-8 bg-gray-950 bg-opacity-50 rounded-2xl p-6 border-2 border-gray-700">
                  <h4 className="font-bold text-gray-300 mb-4">🔍 문제별 결과</h4>
                  <div className="space-y-3">
                    {currentProblems.map(problem => {
                      const isAnswered = showResults[problem.id];
                      const isCorrect = userAnswers[problem.id] === problem.answer - 1;
                      
                      if (!isAnswered) return null;
                      
                      return (
                        <div key={problem.id} className="flex items-center justify-between p-3 bg-gray-900 bg-opacity-50 rounded-xl">
                          <span className="text-gray-300">
                            💀 {problem.year}년 {problem.exam}
                          </span>
                          <span className={`font-bold ${isCorrect ? 'text-green-400' : 'text-red-400'}`}>
                            {isCorrect ? '✅ 정답' : '❌ 오답'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
              
              {/* 무서운 장식 */}
              <div className="absolute top-4 right-4 text-orange-600 opacity-50 animate-pulse">📈</div>
              <div className="absolute bottom-4 left-4 text-orange-600 opacity-30 animate-pulse">🏆</div>
            </div>
          )}

          {/* 추천 학습법 (일부 문제를 푼 경우) */}
          {Object.keys(showResults).length > 0 && Object.keys(showResults).length < currentProblems.length && (
            <div className="mt-8 bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-blue-900 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-purple-900/20"></div>
              <div className="relative z-10">
                <h3 className="text-xl font-bold text-blue-300 mb-4">💡 추천 학습법 - Recommended Dark Learning</h3>
                <div className="bg-blue-950 bg-opacity-50 rounded-2xl p-6 border border-blue-800">
                  <div className="space-y-3 text-blue-200">
                    <div>🔥 남은 문제들도 풀어보세요! 더 많은 연습이 실력 향상에 도움됩니다.</div>
                    <div>👻 틀린 문제는 해설을 꼼꼼히 읽어보세요.</div>
                    <div>💀 비슷한 유형의 문제를 더 찾아서 연습해보세요.</div>
                  </div>
                </div>
              </div>
              
              {/* 무서운 장식 */}
              <div className="absolute top-4 right-4 text-blue-600 opacity-50 animate-pulse">💡</div>
              <div className="absolute bottom-4 left-4 text-blue-600 opacity-30 animate-pulse">📖</div>
            </div>
          )}
        </div>
      </div>

      {/* 무서운 CSS 애니메이션 */}
      <style jsx>{`
        @keyframes dark-pulse {
          0%, 100% { 
            opacity: 0.5;
            transform: scale(1);
          }
          50% { 
            opacity: 1;
            transform: scale(1.05);
          }
        }
        
        @keyframes phantom-appear {
          0% { 
            opacity: 0;
            transform: translateY(20px) scale(0.8);
          }
          50% { 
            opacity: 0.7;
            transform: translateY(0px) scale(1);
          }
          100% { 
            opacity: 0;
            transform: translateY(-20px) scale(1.2);
          }
        }
        
        @keyframes blood-flow {
          0% { 
            transform: translateY(-100%) scaleY(0);
            opacity: 0;
          }
          20% { 
            transform: translateY(0%) scaleY(1);
            opacity: 1;
          }
          80% { 
            transform: translateY(300%) scaleY(1);
            opacity: 0.8;
          }
          100% { 
            transform: translateY(400%) scaleY(0);
            opacity: 0;
          }
        }
        
        @keyframes web-shimmer {
          0%, 100% { 
            opacity: 0.1;
          }
          50% { 
            opacity: 0.3;
          }
        }
        
        .animate-dark-pulse {
          animation: dark-pulse 3s ease-in-out infinite;
        }
        
        .animate-phantom-appear {
          animation: phantom-appear 2s ease-in-out;
        }
        
        .animate-blood-flow {
          animation: blood-flow 4s ease-in-out;
        }
        
        .animate-web-shimmer {
          animation: web-shimmer 5s ease-in-out infinite;
        }
        
        /* 스크롤바 스타일링 */
        ::-webkit-scrollbar {
          width: 12px;
        }
        
        ::-webkit-scrollbar-track {
          background: #1f2937;
          border-radius: 6px;
        }
        
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #7c3aed, #5b21b6);
          border-radius: 6px;
          border: 2px solid #1f2937;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #8b5cf6, #7c3aed);
        }
        
        /* 글리치 효과 */
        .glitch-text {
          position: relative;
        }
        
        .glitch-text::before,
        .glitch-text::after {
          content: attr(data-text);
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
        }
        
        .glitch-text::before {
          animation: glitch-1 0.5s infinite;
          color: #ff0000;
          z-index: -1;
        }
        
        .glitch-text::after {
          animation: glitch-2 0.5s infinite;
          color: #00ff00;
          z-index: -2;
        }
        
        @keyframes glitch-1 {
          0%, 14%, 15%, 49%, 50%, 99%, 100% {
            transform: translate(0, 0);
          }
          15%, 49% {
            transform: translate(-2px, 0);
          }
        }
        
        @keyframes glitch-2 {
          0%, 20%, 21%, 62%, 63%, 99%, 100% {
            transform: translate(0, 0);
          }
          21%, 62% {
            transform: translate(2px, 0);
          }
        }
      `}</style>
    </div>
  );
}