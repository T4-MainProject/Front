// ============================================
// 🌸 Spring Blossom MyPageModal.jsx - 로즈 가든 모달
// ============================================
// 📱 주요 기능:
// - 로즈 정보 표시
// - 벚꽃 정원 프로필 편집
// - 학습 통계 정보 표시
// - 반응형 벚꽃 정원 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { userRoles, memberTiers, pointsSystem, calculateUserTier, saveUserToStorage } from '../data/dummyUsers';

export default function MyPageModal({ isOpen, onClose, currentUser, onUserUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    school: ''
  });

  // 모달이 열릴 때 로즈 정보로 초기화
  useEffect(() => {
    if (currentUser) {
      setFormData({
        name: currentUser.name || '',
        phone: currentUser.phone || '',
        address: currentUser.address || '',
        school: currentUser.school || ''
      });
    }
  }, [currentUser]);

  // 모달이 열릴 때 body 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.keyCode === 27) onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    // 원래 벚꽃 정원 데이터로 복원
    setFormData({
      name: currentUser.name || '',
      phone: currentUser.phone || '',
      address: currentUser.address || '',
      school: currentUser.school || ''
    });
  };

  const handleSave = () => {
    const updatedUser = {
      ...currentUser,
      ...formData
    };
    
    // 벚꽃 정원 스토리지 업데이트
    saveUserToStorage(updatedUser);
    
    // 부모 컴포넌트에 벚꽃 정원 업데이트 알림
    onUserUpdate(updatedUser);
    
    setIsEditing(false);
    alert('벚꽃 정원 정보가 성공적으로 업데이트되었습니다!');
  };

  if (!isOpen || !currentUser) return null;

  const roleInfo = userRoles[currentUser.role] || userRoles.student;
  const joinDate = new Date(currentUser.joinDate).toLocaleDateString('ko-KR');
  
  // 벚꽃 정원 회원등급 정보
  const currentTier = currentUser.role === 'admin' ? 'admin' : (currentUser.tier || calculateUserTier(currentUser.points || 0));
  const tierInfo = memberTiers[currentTier];
  const nextTier = currentTier === 'individual' ? 'pro' : 
                   currentTier === 'pro' ? 'proplus' : 
                   currentTier === 'proplus' ? 'ultra' : null;
  const nextTierInfo = nextTier ? memberTiers[nextTier] : null;
  
  // 벚꽃 정원 포인트 및 등급 진행도
  const currentPoints = currentUser.points || 0;
  const pointsToNext = nextTierInfo ? nextTierInfo.pointsRequired - currentPoints : 0;
  const progressPercentage = nextTierInfo ? 
    ((currentPoints - tierInfo.pointsRequired) / (nextTierInfo.pointsRequired - tierInfo.pointsRequired)) * 100 : 100;

  // 일일 채점 업로드 사용량 체크
  const today = new Date().toDateString();
  const hasResetToday = currentUser.dailyUploadsReset === today;
  const dailyUploadsUsed = hasResetToday ? (currentUser.dailyUploadsUsed || 0) : 0;
  const dailyUploadsRemaining = Math.max(0, tierInfo.dailyUploads - dailyUploadsUsed);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* 벚꽃 정원 배경 오버레이 */}
      <div 
        className="fixed inset-0 bg-pink-500/20 backdrop-blur-sm transition-opacity duration-300"
        onClick={onClose}
      />
      
      {/* 벚꽃 정원 모달 컨테이너 */}
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="relative bg-white/30 backdrop-blur-md rounded-2xl shadow-2xl shadow-pink-500/60 w-full max-w-2xl transform transition-all duration-300 modal-enter border border-white/40">
          {/* 벚꽃 정원 배경 효과 */}
          <div className="absolute inset-0 bg-gradient-to-br from-pink-100/50 via-white/70 to-rose-100/50 rounded-2xl"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(253,125,191,0.15)_0%,rgba(251,207,232,0.08)_50%,rgba(244,114,182,0.15)_100%)] rounded-2xl"></div>
          
          {/* 흩날리는 벚꽃 꽃잎 */}
          <div className="absolute inset-0 overflow-hidden rounded-2xl pointer-events-none">
            <div className="absolute top-8 left-12 w-2 h-2 bg-pink-400/50 rounded-full animate-pulse shadow-sm transform rotate-45"></div>
            <div className="absolute top-16 right-16 w-1 h-1 bg-rose-400/40 rounded-full animate-pulse delay-700 shadow-sm transform rotate-12"></div>
            <div className="absolute bottom-12 left-16 w-1 h-1 bg-pink-300/40 rounded-full animate-pulse delay-1000 shadow-sm transform -rotate-12"></div>
            <div className="absolute top-1/2 right-12 w-1 h-1 bg-rose-500/50 rounded-full animate-pulse delay-500 shadow-sm"></div>
          </div>

          {/* 벚꽃 정원 닫기 버튼 */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-pink-600 hover:text-pink-500 transition-colors duration-200 z-10 bg-white/40 rounded-full p-2 backdrop-blur-sm border border-white/40"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          {/* 벚꽃 정원 헤더 */}
          <div className="px-8 pt-8 pb-6 relative z-10">
            <div className="text-center mb-6">
              <div className="w-20 h-20 rounded-full overflow-hidden mx-auto mb-4 shadow-lg shadow-pink-500/60 ring-4 ring-white/60">
                <img 
                  src={currentUser.avatar} 
                  alt={currentUser.name}
                  className="w-full h-full object-cover brightness-110 saturate-150"
                />
              </div>
              <h2 className="text-2xl font-bold text-pink-700 mb-2 drop-shadow-lg">{currentUser.name}</h2>
              <div className="flex items-center justify-center space-x-2 mb-4">
                <span className="bg-pink-100/70 text-pink-700 px-3 py-1 rounded-full text-sm font-medium border border-pink-300/60">
                  {roleInfo.name === '관리자' ? '🌸 벚꽃 정원지기' :
                   roleInfo.name === '선생님' ? '🌺 교육 전문가' :
                   roleInfo.name === '학생' ? '🌷 로즈 학습자' :
                   roleInfo.name === '학부모' ? '💐 보호자' : '🌹 벚꽃 정원 멤버'}
                </span>
                <span className="text-pink-600/80 text-sm">가입일: {joinDate}</span>
              </div>
            </div>

            {/* 벚꽃 정원 회원등급 및 포인트 정보 */}
            <div className="bg-white/40 backdrop-blur-md border border-white/40 rounded-2xl p-6 mb-6 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <span className="text-3xl drop-shadow-lg">{tierInfo.icon}</span>
                  <div>
                    <h3 className="text-xl font-bold text-pink-700 drop-shadow-sm">{tierInfo.name}</h3>
                    <p className="text-sm text-pink-600/80">벚꽃 정원 등급</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-pink-600 drop-shadow-sm">{currentPoints.toLocaleString()}</div>
                  <div className="text-sm text-pink-600/80">로즈 포인트</div>
                </div>
              </div>

              {/* 벚꽃 정원 등급 진행도 */}
              {nextTierInfo && (
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-pink-600/80">다음 등급까지</span>
                    <span className="font-medium text-pink-700">{pointsToNext.toLocaleString()}P 남음</span>
                  </div>
                  <div className="w-full bg-pink-100/50 rounded-full h-2 border border-pink-300/60">
                    <div 
                      className="bg-gradient-to-r from-pink-500 to-rose-500 h-2 rounded-full transition-all duration-300 shadow-sm"
                      style={{ width: `${Math.min(100, Math.max(0, progressPercentage))}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-xs mt-1 text-pink-600/70">
                    <span>{tierInfo.name}</span>
                    <span>{nextTierInfo.name} {nextTierInfo.icon}</span>
                  </div>
                </div>
              )}

              {/* 일일 채점 업로드 제한 */}
              <div className="flex items-center justify-between text-sm">
                <span className="text-pink-600/80">일일 채점 업로드</span>
                <span className={`font-medium ${dailyUploadsRemaining > 0 ? 'text-pink-700' : 'text-red-600'}`}>
                  {dailyUploadsRemaining > 999 ? '무제한' : `${dailyUploadsRemaining}회 남음`}
                </span>
              </div>
            </div>
          </div>

          {/* 벚꽃 정원 학습 통계 대시보드 */}
          <div className="px-8 pb-6 relative z-10">
            <h3 className="text-lg font-semibold text-pink-700 mb-4 drop-shadow-sm">📊 벚꽃 정원 통계</h3>
            
            {/* 주요 학습 지표 */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-white/40 backdrop-blur-sm rounded-xl p-4 text-center border border-white/40">
                <div className="text-2xl font-bold text-pink-600 drop-shadow-sm">{currentUser.loginCount || 0}</div>
                <div className="text-sm text-pink-600/80">로그인 횟수</div>
              </div>
              <div className="bg-pink-100/50 backdrop-blur-sm rounded-xl p-4 text-center border border-pink-300/60">
                <div className="text-2xl font-bold text-pink-700 drop-shadow-sm">
                  {currentUser.examHistory?.totalExams || 0}
                </div>
                <div className="text-sm text-pink-600/80">채점 완료</div>
              </div>
              <div className="bg-rose-100/50 backdrop-blur-sm rounded-xl p-4 text-center border border-rose-300/60">
                <div className="text-2xl font-bold text-rose-700 drop-shadow-sm">
                  {currentUser.examHistory?.averageScore || 0}점
                </div>
                <div className="text-sm text-pink-600/80">평균 점수</div>
              </div>
              <div className="bg-pink-200/50 backdrop-blur-sm rounded-xl p-4 text-center border border-pink-400/60">
                <div className="text-2xl font-bold text-pink-800 drop-shadow-sm">
                  {currentUser.examHistory?.recentScores?.length ? 
                    Math.max(...currentUser.examHistory.recentScores) : 0}점
                </div>
                <div className="text-sm text-pink-600/80">최고 점수</div>
              </div>
            </div>

            {/* 과목별 벚꽃 정원 성과 */}
            {currentUser.examHistory?.subjectScores && (
              <div className="bg-white/40 backdrop-blur-md rounded-xl p-6 mb-6 border border-white/40 shadow-lg">
                <h4 className="font-semibold text-pink-700 mb-4 drop-shadow-sm">📚 과목별 학습 성과</h4>
                <div className="space-y-4">
                  {Object.entries(currentUser.examHistory.subjectScores).map(([subject, data]) => {
                    const subjectName = subject === 'korean' ? '🌺 벚꽃 국어' : 
                                       subject === 'english' ? '🌷 로즈 영어' : '🌹 로즈 수학';
                    const percentage = data.average || 0;
                    
                    return (
                      <div key={subject}>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="font-medium text-pink-700">{subjectName}</span>
                          <span className="text-pink-600/80">{data.total}회 채점 • 평균 {data.average}점</span>
                        </div>
                        <div className="w-full bg-pink-100/50 rounded-full h-2 border border-pink-300/60">
                          <div 
                            className="bg-gradient-to-r from-pink-500 to-rose-500 h-2 rounded-full transition-all duration-500 shadow-sm"
                            style={{ width: `${percentage}%` }}
                          ></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 최근 학습 성적 추이 */}
            {currentUser.examHistory?.recentScores?.length > 0 && (
              <div className="bg-white/40 backdrop-blur-md border border-white/40 rounded-xl p-6 shadow-lg">
                <h4 className="font-semibold text-pink-700 mb-4 drop-shadow-sm">📈 최근 성적 추이</h4>
                <div className="flex items-end justify-between h-32 space-x-2">
                  {currentUser.examHistory.recentScores.map((score, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center">
                      <div 
                        className="w-full bg-gradient-to-t from-pink-500 to-rose-500 rounded-t transition-all duration-500 hover:from-pink-400 hover:to-rose-400 shadow-sm"
                        style={{ height: `${(score / 100) * 100}%` }}
                      ></div>
                      <div className="text-xs font-medium text-pink-700 mt-2">{score}점</div>
                      <div className="text-xs text-pink-600/70">{index + 1}회</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 벚꽃 정원 회원등급 혜택 */}
          <div className="px-8 pb-6 relative z-10">
            <h3 className="text-lg font-semibold text-pink-700 mb-4 drop-shadow-sm">🎁 {tierInfo.name} 등급 혜택</h3>
            <div className="bg-white/40 backdrop-blur-md border border-white/40 rounded-xl p-6 shadow-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium text-pink-700 mb-3">현재 벚꽃 정원 혜택</h4>
                  <ul className="space-y-2">
                    {tierInfo.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <svg className="w-4 h-4 text-pink-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span className="text-pink-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                {nextTierInfo && (
                  <div>
                    <h4 className="font-medium text-pink-700 mb-3">
                      {nextTierInfo.name} 등급 업그레이드시 추가 혜택
                    </h4>
                    <ul className="space-y-2">
                      {nextTierInfo.features.filter(f => !tierInfo.features.includes(f)).map((feature, index) => (
                        <li key={index} className="flex items-center text-sm text-pink-600/80">
                          <svg className="w-4 h-4 text-rose-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                          </svg>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <div className="mt-4 p-3 bg-pink-100/70 rounded-lg border border-pink-300/60">
                      <p className="text-sm text-pink-700">
                        <span className="font-medium">{pointsToNext.toLocaleString()}로즈 포인트</span> 더 모으면 업그레이드됩니다!
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 로즈 정보 */}
          <div className="px-8 pb-8 relative z-10">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-pink-700 drop-shadow-sm">👤 개인 정보</h3>
              {!isEditing ? (
                <button
                  onClick={handleEdit}
                  className="text-pink-600 hover:text-pink-500 font-medium text-sm flex items-center transition-colors duration-200"
                >
                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                  편집
                </button>
              ) : (
                <div className="flex space-x-2">
                  <button
                    onClick={handleCancel}
                    className="text-pink-600 hover:text-pink-500 font-medium text-sm px-3 py-1 rounded border border-pink-300/60 bg-white/40 transition-colors duration-200"
                  >
                    취소
                  </button>
                  <button
                    onClick={handleSave}
                    className="bg-pink-500 text-white font-medium text-sm px-3 py-1 rounded hover:bg-pink-400 transition-colors duration-200 shadow-sm"
                  >
                    저장
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 이메일 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-pink-700 mb-2">
                  이메일
                </label>
                <input
                  type="email"
                  value={currentUser.email}
                  disabled
                  className="w-full px-4 py-3 border border-pink-300/60 rounded-xl bg-white/50 text-pink-600/80 backdrop-blur-sm"
                />
              </div>

              {/* 이름 */}
              <div>
                <label className="block text-sm font-semibold text-pink-700 mb-2">
                  이름
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-pink-400/60 focus:ring-2 focus:ring-pink-500 focus:border-transparent bg-white/70 text-pink-800 placeholder-pink-600/60' 
                      : 'border-pink-300/60 bg-white/50 text-pink-600/80'
                  }`}
                />
              </div>

              {/* 전화번호 */}
              <div>
                <label className="block text-sm font-semibold text-pink-700 mb-2">
                  전화번호
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-pink-400/60 focus:ring-2 focus:ring-pink-500 focus:border-transparent bg-white/70 text-pink-800 placeholder-pink-600/60' 
                      : 'border-pink-300/60 bg-white/50 text-pink-600/80'
                  }`}
                />
              </div>

              {/* 학교 */}
              <div>
                <label className="block text-sm font-semibold text-pink-700 mb-2">
                  학교
                </label>
                <input
                  type="text"
                  name="school"
                  value={formData.school}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-pink-400/60 focus:ring-2 focus:ring-pink-500 focus:border-transparent bg-white/70 text-pink-800 placeholder-pink-600/60' 
                      : 'border-pink-300/60 bg-white/50 text-pink-600/80'
                  }`}
                />
              </div>

              {/* 주소 */}
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-pink-700 mb-2">
                  주소
                </label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-pink-400/60 focus:ring-2 focus:ring-pink-500 focus:border-transparent bg-white/70 text-pink-800 placeholder-pink-600/60' 
                      : 'border-pink-300/60 bg-white/50 text-pink-600/80'
                  }`}
                />
              </div>

              {/* 생년월일 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-pink-700 mb-2">
                  생년월일
                </label>
                <input
                  type="date"
                  value={currentUser.birthDate}
                  disabled
                  className="w-full px-4 py-3 border border-pink-300/60 rounded-xl bg-white/50 text-pink-600/80 backdrop-blur-sm"
                />
              </div>

              {/* 역할 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-pink-700 mb-2">
                  역할
                </label>
                <input
                  type="text"
                  value={roleInfo.name === '관리자' ? '🌸 벚꽃 정원지기' :
                         roleInfo.name === '선생님' ? '🌺 교육 전문가' :
                         roleInfo.name === '학생' ? '🌷 로즈 학습자' :
                         roleInfo.name === '학부모' ? '💐 보호자' : '🌹 벚꽃 정원 멤버'}
                  disabled
                  className="w-full px-4 py-3 border border-pink-300/60 rounded-xl bg-white/50 text-pink-600/80 backdrop-blur-sm"
                />
              </div>
            </div>
          </div>

          {/* 벚꽃 정원 테두리 효과 */}
          <div className="absolute inset-0 rounded-2xl border border-pink-300/40 pointer-events-none"></div>
        </div>
      </div>
    </div>
  );
}