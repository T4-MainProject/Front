// ============================================
// ✨ Angelic Light Footer.jsx - 희망의 발끝
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const footerSections = [
  {
    title: '천사 서비스',
    links: [
      { name: 'AI 자동 축복', href: '#' },
      { name: '대량 희망 처리', href: '#' },
      { name: '천국 API 서비스', href: '#' },
      { name: '빛의 교육기관 솔루션', href: '#' }
    ]
  },
  {
    title: '천국 지원',
    links: [
      { name: '천사 사용자 가이드', href: '#' },
      { name: '축복받은 질문들', href: '#' },
      { name: '빛의 기술 지원', href: '#' },
      { name: '천국 문의하기', href: '#' }
    ]
  },
  {
    title: '희망의 회사',
    links: [
      { name: '천국 소개', href: '#' },
      { name: '천사 채용 정보', href: '#' },
      { name: '희망의 보도자료', href: '#' },
      { name: '빛의 파트너십', href: '#' }
    ]
  }
];

const socialLinks = [
  { name: 'LightTwitter', icon: '🦅', href: '#', color: 'hover:bg-blue-500' },
  { name: 'HeavenBook', icon: '📖', href: '#', color: 'hover:bg-sky-500' },
  { name: 'HopeGram', icon: '📸', href: '#', color: 'hover:bg-blue-400' },
  { name: 'AngelIn', icon: '💼', href: '#', color: 'hover:bg-indigo-500' },
  { name: 'LightTube', icon: '📺', href: '#', color: 'hover:bg-blue-600' }
];

export default function Footer() {
  const footerRef = useRef(null);
  const sectionsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 빛의 푸터 섹션들 애니메이션 (더 우아하게)
      gsap.fromTo(sectionsRef.current,
        {
          y: 80,
          opacity: 0,
          scale: 0.9,
          filter: "blur(5px)"
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          filter: "blur(0px)",
          duration: 1.2,
          stagger: 0.3,
          ease: "power3.out",
          scrollTrigger: {
            trigger: footerRef.current,
            start: "top 80%",
            end: "bottom 60%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, footerRef);

    return () => ctx.revert();
  }, []);

  return (
    <footer 
      ref={footerRef}
      className="bg-gradient-to-b from-white via-sky-50 to-blue-100 border-t border-blue-200/50 relative overflow-hidden"
    >
      {/* 빛의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/80 via-sky-50/60 to-blue-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_50%,rgba(59,130,246,0.1)_80%)]"></div>
      
      {/* 움직이는 빛 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-2 h-2 bg-blue-400/30 rounded-full animate-pulse"></div>
        <div className="absolute top-32 right-1/3 w-1 h-1 bg-sky-400/40 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-24 left-1/2 w-1 h-1 bg-blue-300/30 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-blue-500/40 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-sky-300/30 rounded-full animate-pulse delay-1500"></div>
      </div>

      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* 천국 브랜드 섹션 */}
          <div ref={el => sectionsRef.current[0] = el} className="md:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-sky-400 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/50">
                <span className="text-white text-2xl font-bold">✨</span>
              </div>
              <div>
                <h3 className="text-xl font-bold text-blue-600">천국 AI</h3>
                <p className="text-sm text-blue-400">축복의 학습 지원</p>
              </div>
            </div>
            <p className="text-blue-500 mb-4 leading-relaxed">
              AI 기술로 모든 학습자가 빛의 길을 걸을 수 있도록 축복을 전하는 희망의 서비스입니다.
            </p>
            <div className="flex space-x-3">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className={`w-10 h-10 bg-blue-100 bg-opacity-50 rounded-lg flex items-center justify-center text-blue-600 ${social.color} transition-all duration-300 hover:scale-110 hover:shadow-lg border border-blue-200/50 hover:border-blue-300`}
                  title={social.name}
                >
                  <span className="text-lg">{social.icon}</span>
                </a>
              ))}
            </div>
          </div>

          {/* 희망의 링크 섹션들 */}
          {footerSections.map((section, sectionIndex) => (
            <div key={sectionIndex} ref={el => sectionsRef.current[sectionIndex + 1] = el}>
              <h4 className="text-lg font-semibold text-blue-600 mb-6">{section.title}</h4>
              <ul className="space-y-3">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href={link.href}
                      className="text-blue-500 hover:text-blue-400 transition-all duration-300 text-sm hover:translate-x-2 inline-block"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* 하단 빛의 정보 */}
        <div className="border-t border-blue-200/50 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-sm text-blue-400">
              © 2024 천국 AI. 모든 권리가 빛의 보호 하에 있습니다.
            </div>
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-blue-500 hover:text-blue-400 transition-colors duration-300">천국 개인정보처리방침</a>
              <a href="#" className="text-blue-500 hover:text-blue-400 transition-colors duration-300">축복 이용약관</a>
              <a href="#" className="text-blue-500 hover:text-blue-400 transition-colors duration-300">희망 문의</a>
            </div>
          </div>
          
          <div className="mt-6 text-center">
            <p className="text-xs text-blue-300 italic">
              "모든 학습자의 성장과 희망을 위해 천사들이 함께합니다" ✨
            </p>
          </div>
        </div>
      </div>

      {/* 하단 빛 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-blue-400/50 to-transparent"></div>
    </footer>
  );
}