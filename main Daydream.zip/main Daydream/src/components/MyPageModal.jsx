// ============================================
// ✨ Angelic Light MyPageModal.jsx - 천사의 방 모달
// ============================================
// 📱 주요 기능:
// - 천사 정보 표시
// - 빛의 프로필 편집
// - 천국 통계 정보 표시
// - 반응형 빛 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { userRoles, memberTiers, pointsSystem, calculateUserTier, saveUserToStorage } from '../data/dummyUsers';

export default function MyPageModal({ isOpen, onClose, currentUser, onUserUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    school: ''
  });

  // 모달이 열릴 때 천사 정보로 초기화
  useEffect(() => {
    if (currentUser) {
      setFormData({
        name: currentUser.name || '',
        phone: currentUser.phone || '',
        address: currentUser.address || '',
        school: currentUser.school || ''
      });
    }
  }, [currentUser]);

  // 모달이 열릴 때 body 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.keyCode === 27) onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    // 원래 빛의 데이터로 복원
    setFormData({
      name: currentUser.name || '',
      phone: currentUser.phone || '',
      address: currentUser.address || '',
      school: currentUser.school || ''
    });
  };

  const handleSave = () => {
    const updatedUser = {
      ...currentUser,
      ...formData
    };
    
    // 천국 스토리지 업데이트
    saveUserToStorage(updatedUser);
    
    // 부모 컴포넌트에 빛의 업데이트 알림
    onUserUpdate(updatedUser);
    
    setIsEditing(false);
    alert('천사의 정보가 성공적으로 축복되었습니다!');
  };

  if (!isOpen || !currentUser) return null;

  const roleInfo = userRoles[currentUser.role] || userRoles.student;
  const joinDate = new Date(currentUser.joinDate).toLocaleDateString('ko-KR');
  
  // 빛의 회원등급 정보
  const currentTier = currentUser.role === 'admin' ? 'admin' : (currentUser.tier || calculateUserTier(currentUser.points || 0));
  const tierInfo = memberTiers[currentTier];
  const nextTier = currentTier === 'individual' ? 'pro' : 
                   currentTier === 'pro' ? 'proplus' : 
                   currentTier === 'proplus' ? 'ultra' : null;
  const nextTierInfo = nextTier ? memberTiers[nextTier] : null;
  
  // 빛의 포인트 및 등급 진행도
  const currentPoints = currentUser.points || 0;
  const pointsToNext = nextTierInfo ? nextTierInfo.pointsRequired - currentPoints : 0;
  const progressPercentage = nextTierInfo ? 
    ((currentPoints - tierInfo.pointsRequired) / (nextTierInfo.pointsRequired - tierInfo.pointsRequired)) * 100 : 100;

  // 일일 축복 업로드 사용량 체크
  const today = new Date().toDateString();
  const hasResetToday = currentUser.dailyUploadsReset === today;
  const dailyUploadsUsed = hasResetToday ? (currentUser.dailyUploadsUsed || 0) : 0;
  const dailyUploadsRemaining = Math.max(0, tierInfo.dailyUploads - dailyUploadsUsed);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* 빛의 배경 오버레이 */}
      <div 
        className="fixed inset-0 bg-white bg-opacity-95 transition-opacity duration-300"
        onClick={onClose}
      />
      
      {/* 빛의 모달 컨테이너 */}
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="relative bg-white rounded-3xl shadow-2xl shadow-blue-500/20 w-full max-w-2xl transform transition-all duration-300 modal-enter border-2 border-blue-200">
          {/* 빛의 배경 효과 */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50/80 via-white/90 to-sky-100/60 rounded-3xl"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,rgba(255,255,255,0.9)_100%)] rounded-3xl"></div>
          
          {/* 움직이는 빛의 파티클 */}
          <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
            <div className="absolute top-8 left-12 w-1 h-1 bg-blue-400/60 rounded-full animate-pulse"></div>
            <div className="absolute top-16 right-16 w-1 h-1 bg-sky-400/50 rounded-full animate-pulse delay-700"></div>
            <div className="absolute bottom-12 left-16 w-1 h-1 bg-indigo-400/40 rounded-full animate-pulse delay-1000"></div>
            <div className="absolute top-1/2 right-12 w-1 h-1 bg-blue-500/60 rounded-full animate-pulse delay-500"></div>
          </div>

          {/* 빛의 닫기 버튼 */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-blue-400 hover:text-blue-500 transition-colors duration-200 z-10 p-2 hover:bg-blue-100/50 rounded-xl"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          {/* 빛의 헤더 */}
          <div className="px-8 pt-8 pb-6 relative z-10">
            <div className="text-center mb-6">
              <div className="w-20 h-20 rounded-full overflow-hidden mx-auto mb-4 shadow-lg shadow-blue-500/50 ring-4 ring-blue-200">
                <img 
                  src={currentUser.avatar} 
                  alt={currentUser.name}
                  className="w-full h-full object-cover filter brightness-110"
                />
              </div>
              <h2 className="text-2xl font-bold text-blue-600 mb-2 drop-shadow-lg">{currentUser.name}</h2>
              <div className="flex items-center justify-center space-x-2 mb-4">
                <span className="px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-600 border border-blue-200">
                  {roleInfo.name === '관리자' ? '👼 빛의 수호자' :
                   roleInfo.name === '선생님' ? '🌟 빛의 전달자' :
                   roleInfo.name === '학생' ? '✨ 천사 학습자' :
                   roleInfo.name === '학부모' ? '🕊️ 보호천사' : '💫 빛의 존재'}
                </span>
                <span className="text-blue-400 text-sm">천국 입천일: {joinDate}</span>
              </div>
            </div>

            {/* 빛의 회원등급 및 포인트 정보 */}
            <div className="bg-gradient-to-br from-blue-100/50 to-sky-50/80 border-2 border-blue-200 rounded-3xl p-6 mb-6 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <span className="text-3xl drop-shadow-lg">{tierInfo.icon}</span>
                  <div>
                    <h3 className="text-xl font-bold text-blue-600 drop-shadow-sm">{tierInfo.name}</h3>
                    <p className="text-sm text-blue-500">빛의 등급</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-blue-600 drop-shadow-sm">{currentPoints.toLocaleString()}</div>
                  <div className="text-sm text-blue-500">축복 포인트</div>
                </div>
              </div>

              {/* 빛의 등급 진행도 */}
              {nextTierInfo && (
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-blue-500">다음 빛 등급까지</span>
                    <span className="font-medium text-blue-600">{pointsToNext.toLocaleString()}P 남음</span>
                  </div>
                  <div className="w-full bg-blue-200/50 rounded-full h-2 border border-blue-300">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-sky-400 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(100, Math.max(0, progressPercentage))}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-xs mt-1 text-blue-400">
                    <span>{tierInfo.name}</span>
                    <span>{nextTierInfo.name} {nextTierInfo.icon}</span>
                  </div>
                </div>
              )}

              {/* 일일 축복 업로드 제한 */}
              <div className="flex items-center justify-between text-sm">
                <span className="text-blue-500">일일 축복 업로드</span>
                <span className={`font-medium ${dailyUploadsRemaining > 0 ? 'text-blue-600' : 'text-blue-400'}`}>
                  {dailyUploadsRemaining > 999 ? '무한 축복' : `${dailyUploadsRemaining}회 남음`}
                </span>
              </div>
            </div>
          </div>

          {/* 빛의 학습 통계 대시보드 */}
          <div className="px-8 pb-6 relative z-10">
            <h3 className="text-lg font-semibold text-blue-600 mb-4 drop-shadow-sm">📊 천국 통계</h3>
            
            {/* 주요 천사 지표 */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-gradient-to-br from-blue-100/60 to-sky-50/80 rounded-xl p-4 text-center border border-blue-200">
                <div className="text-2xl font-bold text-blue-600 drop-shadow-sm">{currentUser.loginCount || 0}</div>
                <div className="text-sm text-blue-500">천국 접속</div>
              </div>
              <div className="bg-gradient-to-br from-sky-100/60 to-blue-50/80 rounded-xl p-4 text-center border border-blue-200">
                <div className="text-2xl font-bold text-blue-600 drop-shadow-sm">
                  {currentUser.examHistory?.totalExams || 0}
                </div>
                <div className="text-sm text-blue-500">시험 완료</div>
              </div>
              <div className="bg-gradient-to-br from-indigo-100/60 to-sky-50/80 rounded-xl p-4 text-center border border-blue-200">
                <div className="text-2xl font-bold text-blue-600 drop-shadow-sm">
                  {currentUser.examHistory?.averageScore || 0}점
                </div>
                <div className="text-sm text-blue-500">천사 평균</div>
              </div>
              <div className="bg-gradient-to-br from-blue-50/80 to-indigo-100/60 rounded-xl p-4 text-center border border-blue-200">
                <div className="text-2xl font-bold text-blue-600 drop-shadow-sm">
                  {currentUser.examHistory?.recentScores?.length ? 
                    Math.max(...currentUser.examHistory.recentScores) : 0}점
                </div>
                <div className="text-sm text-blue-500">최고 축복</div>
              </div>
            </div>

            {/* 과목별 빛의 성과 */}
            {currentUser.examHistory?.subjectScores && (
              <div className="bg-gradient-to-br from-blue-50/60 to-sky-100/50 rounded-xl p-6 mb-6 border border-blue-200 backdrop-blur-sm">
                <h4 className="font-semibold text-blue-600 mb-4 drop-shadow-sm">📚 과목별 축복 성과</h4>
                <div className="space-y-4">
                  {Object.entries(currentUser.examHistory.subjectScores).map(([subject, data]) => {
                    const subjectName = subject === 'korean' ? '✨ 빛의 국어' : 
                                       subject === 'english' ? '🌟 천사의 영어' : '💫 축복의 수학';
                    const percentage = data.average || 0;
                    
                    return (
                      <div key={subject}>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="font-medium text-blue-600">{subjectName}</span>
                          <span className="text-blue-500">{data.total}회 시험 • 평균 {data.average}점</span>
                        </div>
                        <div className="w-full bg-blue-200/50 rounded-full h-2 border border-blue-300">
                          <div 
                            className="bg-gradient-to-r from-blue-500 to-sky-400 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${percentage}%` }}
                          ></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 최근 축복 성적 추이 */}
            {currentUser.examHistory?.recentScores?.length > 0 && (
              <div className="bg-gradient-to-br from-blue-50/60 to-sky-100/50 border border-blue-200 rounded-xl p-6 backdrop-blur-sm">
                <h4 className="font-semibold text-blue-600 mb-4 drop-shadow-sm">📈 최근 축복 성적 추이</h4>
                <div className="flex items-end justify-between h-32 space-x-2">
                  {currentUser.examHistory.recentScores.map((score, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center">
                      <div 
                        className="w-full bg-gradient-to-t from-blue-500 to-sky-400 rounded-t transition-all duration-500 hover:from-blue-600 hover:to-sky-500"
                        style={{ height: `${(score / 100) * 100}%` }}
                      ></div>
                      <div className="text-xs font-medium text-blue-600 mt-2">{score}점</div>
                      <div className="text-xs text-blue-400">{index + 1}회</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 빛의 회원등급 혜택 */}
          <div className="px-8 pb-6 relative z-10">
            <h3 className="text-lg font-semibold text-blue-600 mb-4 drop-shadow-sm">🎁 {tierInfo.name} 등급 축복 혜택</h3>
            <div className="bg-gradient-to-br from-blue-50/60 to-sky-100/50 border border-blue-200 rounded-xl p-6 backdrop-blur-sm">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium text-blue-600 mb-3">현재 빛의 혜택</h4>
                  <ul className="space-y-2">
                    {tierInfo.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <svg className="w-4 h-4 text-blue-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span className="text-blue-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                {nextTierInfo && (
                  <div>
                    <h4 className="font-medium text-blue-600 mb-3">
                      {nextTierInfo.name} 등급 승급시 추가 축복
                    </h4>
                    <ul className="space-y-2">
                      {nextTierInfo.features.filter(f => !tierInfo.features.includes(f)).map((feature, index) => (
                        <li key={index} className="flex items-center text-sm text-blue-500">
                          <svg className="w-4 h-4 text-blue-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                          </svg>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <div className="mt-4 p-3 bg-blue-100/60 rounded-lg border border-blue-300">
                      <p className="text-sm text-blue-600">
                        <span className="font-medium">{pointsToNext.toLocaleString()}축복 포인트</span> 더 모으면 빛의 승급됩니다!
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 천사 정보 */}
          <div className="px-8 pb-8 relative z-10">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-blue-600 drop-shadow-sm">👤 천사 정보</h3>
              {!isEditing ? (
                <button
                  onClick={handleEdit}
                  className="text-blue-500 hover:text-blue-400 font-medium text-sm flex items-center transition-colors duration-200"
                >
                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                  축복 편집
                </button>
              ) : (
                <div className="flex space-x-2">
                  <button
                    onClick={handleCancel}
                    className="text-blue-400 hover:text-blue-500 font-medium text-sm px-3 py-1 rounded border border-blue-300 bg-blue-50/50 transition-colors duration-200"
                  >
                    취소
                  </button>
                  <button
                    onClick={handleSave}
                    className="bg-blue-500 text-white font-medium text-sm px-3 py-1 rounded hover:bg-blue-600 transition-colors duration-200"
                  >
                    축복 저장
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 천사 이메일 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-blue-600 mb-2">
                  천사 이메일
                </label>
                <input
                  type="email"
                  value={currentUser.email}
                  disabled
                  className="w-full px-4 py-3 border border-blue-300 rounded-xl bg-blue-50/30 text-blue-500 backdrop-blur-sm"
                />
              </div>

              {/* 천사 이름 */}
              <div>
                <label className="block text-sm font-semibold text-blue-600 mb-2">
                  천사 이름
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-blue-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-blue-50/30 text-blue-700 placeholder-blue-400' 
                      : 'border-blue-300 bg-blue-50/30 text-blue-500'
                  }`}
                />
              </div>

              {/* 축복받은 전화번호 */}
              <div>
                <label className="block text-sm font-semibold text-blue-600 mb-2">
                  축복받은 전화번호
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-blue-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-blue-50/30 text-blue-700 placeholder-blue-400' 
                      : 'border-blue-300 bg-blue-50/30 text-blue-500'
                  }`}
                />
              </div>

              {/* 천국 학교 */}
              <div>
                <label className="block text-sm font-semibold text-blue-600 mb-2">
                  천국 학교
                </label>
                <input
                  type="text"
                  name="school"
                  value={formData.school}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-blue-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-blue-50/30 text-blue-700 placeholder-blue-400' 
                      : 'border-blue-300 bg-blue-50/30 text-blue-500'
                  }`}
                />
              </div>

              {/* 빛의 주소 */}
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-blue-600 mb-2">
                  빛의 주소
                </label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-blue-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-blue-50/30 text-blue-700 placeholder-blue-400' 
                      : 'border-blue-300 bg-blue-50/30 text-blue-500'
                  }`}
                />
              </div>

              {/* 축복받은 생년월일 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-blue-600 mb-2">
                  축복받은 생년월일
                </label>
                <input
                  type="date"
                  value={currentUser.birthDate}
                  disabled
                  className="w-full px-4 py-3 border border-blue-300 rounded-xl bg-blue-50/30 text-blue-500 backdrop-blur-sm"
                />
              </div>

              {/* 빛의 역할 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-blue-600 mb-2">
                  빛의 역할
                </label>
                <input
                  type="text"
                  value={roleInfo.name === '관리자' ? '👼 빛의 수호자' :
                         roleInfo.name === '선생님' ? '🌟 빛의 전달자' :
                         roleInfo.name === '학생' ? '✨ 천사 학습자' :
                         roleInfo.name === '학부모' ? '🕊️ 보호천사' : '💫 빛의 존재'}
                  disabled
                  className="w-full px-4 py-3 border border-blue-300 rounded-xl bg-blue-50/30 text-blue-500 backdrop-blur-sm"
                />
              </div>
            </div>
          </div>

          {/* 빛의 테두리 효과 */}
          <div className="absolute inset-0 rounded-3xl border border-blue-300/30 pointer-events-none"></div>
          
          {/* 천사 장식 */}
          <div className="absolute top-4 right-16 text-blue-400 opacity-30 animate-pulse">✨</div>
          <div className="absolute bottom-4 left-8 text-blue-400 opacity-20 animate-pulse">🌟</div>
        </div>
      </div>
    </div>
  );
}