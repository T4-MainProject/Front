// ============================================
// src/data/dummyUsers.js - 더미 사용자 데이터
// ============================================
// 🧪 테스트용 계정들 (실제 서비스에서는 보안상 제거 필요)
// ============================================

export const dummyUsers = [
  {
    id: 1,
    email: '1234@email.com',
    password: 'abcd1234',
    name: '관리자',
    phone: '010-1234-5678',
    birthDate: '1990-01-01',
    address: '서울시 강남구',
    school: '서울대학교',
    securityQuestion: '가장 좋아하는 음식은 무엇입니까?',
    securityAnswer: '피자',
    role: 'admin',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=admin',
    joinDate: '2024-01-01',
    loginCount: 127
  },
  {
    id: 2,
    email: 'teacher@langcheck.com',
    password: 'teacher123',
    name: '김선생',
    phone: '010-2345-6789',
    birthDate: '1985-05-15',
    address: '서울시 서초구',
    school: '서울중학교',
    securityQuestion: '첫 번째 반려동물의 이름은 무엇입니까?',
    securityAnswer: '뽀삐',
    role: 'teacher',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=teacher',
    joinDate: '2024-02-15',
    loginCount: 89
  },
  {
    id: 3,
    email: 'student@langcheck.com',
    password: 'student123',
    name: '이학생',
    phone: '010-3456-7890',
    birthDate: '2008-12-25',
    address: '서울시 종로구',
    school: '종로중학교',
    securityQuestion: '가장 좋아하는 영화는 무엇입니까?',
    securityAnswer: '어벤져스',
    role: 'student',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=student',
    joinDate: '2024-03-10',
    loginCount: 45
  },
  {
    id: 4,
    email: 'parent@langcheck.com',
    password: 'parent123',
    name: '박학부모',
    phone: '010-4567-8901',
    birthDate: '1978-08-30',
    address: '서울시 마포구',
    school: '마포중학교',
    securityQuestion: '어머니의 성함은 무엇입니까?',
    securityAnswer: '김영희',
    role: 'parent',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=parent',
    joinDate: '2024-01-20',
    loginCount: 72
  },
  {
    id: 5,
    email: 'test@test.com',
    password: 'test123',
    name: '테스트',
    phone: '010-0000-0000',
    birthDate: '2000-01-01',
    address: '서울시 강서구',
    school: '테스트중학교',
    securityQuestion: '태어난 병원의 이름은 무엇입니까?',
    securityAnswer: '서울병원',
    role: 'student',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=test',
    joinDate: '2024-04-01',
    loginCount: 12
  }
];

// 🔐 로그인 검증 함수
export const validateLogin = (email, password) => {
  const user = dummyUsers.find(u => u.email === email && u.password === password);
  if (user) {
    // 로그인 카운트 증가 (실제로는 서버에서 처리)
    user.loginCount += 1;
    user.lastLogin = new Date().toISOString();
    
    // 민감한 정보 제거 후 반환
    const { password: _, securityAnswer: __, ...safeUser } = user;
    return {
      success: true,
      user: safeUser,
      message: '로그인 성공!'
    };
  }
  
  return {
    success: false,
    user: null,
    message: '이메일 또는 비밀번호가 올바르지 않습니다.'
  };
};

// 📧 이메일 중복 확인 함수
export const checkEmailExists = (email) => {
  return dummyUsers.some(user => user.email === email);
};

// 👥 회원가입 함수 (더미)
export const registerUser = (userData) => {
  // 이메일 중복 확인
  if (checkEmailExists(userData.email)) {
    return {
      success: false,
      message: '이미 존재하는 이메일입니다.'
    };
  }

  // 새 사용자 ID 생성
  const newId = Math.max(...dummyUsers.map(u => u.id)) + 1;
  
  // 새 사용자 객체 생성
  const newUser = {
    id: newId,
    ...userData,
    role: 'student', // 기본 역할
    avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${userData.email}`,
    joinDate: new Date().toISOString(),
    loginCount: 0
  };

  // 더미 데이터에 추가 (실제로는 서버 API 호출)
  dummyUsers.push(newUser);

  // 민감한 정보 제거 후 반환
  const { password: _, securityAnswer: __, ...safeUser } = newUser;
  
  return {
    success: true,
    user: safeUser,
    message: '회원가입이 완료되었습니다!'
  };
};

// 🎭 역할별 권한 정의
export const userRoles = {
  admin: {
    name: '관리자',
    permissions: ['all'],
    color: 'red'
  },
  teacher: {
    name: '선생님',
    permissions: ['grade', 'view_results', 'manage_students'],
    color: 'blue'
  },
  student: {
    name: '학생',
    permissions: ['submit_exam', 'view_own_results'],
    color: 'green'
  },
  parent: {
    name: '학부모',
    permissions: ['view_child_results'],
    color: 'purple'
  }
};

// 🔧 로컬 스토리지 관리 함수들
export const saveUserToStorage = (user) => {
  localStorage.setItem('langcheck_user', JSON.stringify(user));
};

export const getUserFromStorage = () => {
  const stored = localStorage.getItem('langcheck_user');
  return stored ? JSON.parse(stored) : null;
};

export const removeUserFromStorage = () => {
  localStorage.removeItem('langcheck_user');
}; 