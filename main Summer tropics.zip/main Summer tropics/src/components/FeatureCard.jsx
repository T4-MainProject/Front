// ============================================
// 🏝️ Tropical Paradise FeatureCard.jsx - 열대 특징 카드
// ============================================
import React, { useRef, useEffect } from 'react';
import { gsap } from 'gsap';

export default function FeatureCard({ 
  icon, 
  title, 
  description, 
  gradient = 'from-emerald-500 to-cyan-500',
  bgGradient = 'from-emerald-100/40 to-white/70',
  className = '',
  delay = 0,
  ...props 
}) {
  const cardRef = useRef(null);
  const iconRef = useRef(null);

  useEffect(() => {
    const card = cardRef.current;
    const iconEl = iconRef.current;

    if (!card || !iconEl) return;

    // 🌊 초기 진입 애니메이션 (열대 느낌으로)
    gsap.fromTo(card, 
      { 
        y: 80, 
        opacity: 0, 
        scale: 0.7,
        rotationY: -30,
        filter: "blur(10px)"
      },
      { 
        y: 0, 
        opacity: 1, 
        scale: 1,
        rotationY: 0,
        filter: "blur(0px)",
        duration: 1.2, 
        ease: "power4.out",
        delay: delay 
      }
    );

    // 🏝️ 호버 애니메이션 (파라다이스 효과)
    const handleMouseEnter = () => {
      gsap.to(card, {
        y: -16,
        scale: 1.06,
        rotationX: 8,
        duration: 0.5,
        ease: "power3.out"
      });

      gsap.to(iconEl, {
        scale: 1.3,
        rotation: 15,
        y: -8,
        duration: 0.5,
        ease: "back.out(2)"
      });
    };

    const handleMouseLeave = () => {
      gsap.to(card, {
        y: 0,
        scale: 1,
        rotationX: 0,
        duration: 0.5,
        ease: "power3.out"
      });

      gsap.to(iconEl, {
        scale: 1,
        rotation: 0,
        y: 0,
        duration: 0.5,
        ease: "power3.out"
      });
    };

    card.addEventListener('mouseenter', handleMouseEnter);
    card.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      card.removeEventListener('mouseenter', handleMouseEnter);
      card.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [delay]);

  return (
    <div 
      ref={cardRef}
      className={`
        bg-gradient-to-br ${bgGradient} backdrop-blur-md p-8 rounded-3xl shadow-2xl shadow-emerald-500/20 hover:shadow-3xl hover:shadow-cyan-500/40
        border border-white/30 transition-all duration-500 cursor-pointer group 
        relative overflow-hidden ${className}
      `}
      {...props}
    >
      {/* 🌺 배경 호버 효과 */}
      <div className={`
        absolute inset-0 bg-gradient-to-br ${gradient} opacity-0 
        group-hover:opacity-25 transition-opacity duration-500 rounded-3xl
      `}></div>
      
      {/* 🏖️ 열대 배경 레이어 */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/60 via-emerald-50/40 to-cyan-100/30 rounded-3xl"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(16,185,129,0.15)_0%,rgba(6,182,212,0.1)_40%,rgba(14,165,233,0.15)_80%)] rounded-3xl"></div>
      
      {/* 🌊 떠다니는 크리스탈 파티클들 */}
      <div className="absolute top-4 right-4 w-3 h-3 bg-emerald-400/50 rounded-full animate-pulse shadow-lg"></div>
      <div className="absolute bottom-6 left-6 w-2 h-2 bg-cyan-400/60 rounded-full animate-ping shadow-lg"></div>
      <div className="absolute top-1/2 right-8 w-2 h-2 bg-sky-400/50 rounded-full animate-bounce shadow-lg"></div>
      <div className="absolute top-1/3 left-4 w-1 h-1 bg-teal-500/60 rounded-full animate-pulse delay-700"></div>
      <div className="absolute bottom-1/3 right-6 w-1 h-1 bg-emerald-300/50 rounded-full animate-ping delay-1000"></div>
      
      {/* 🏝️ 아이콘 */}
      <div className="relative z-10 text-center mb-6">
        <div className="relative inline-block">
          <div 
            ref={iconRef}
            className={`
              inline-flex items-center justify-center w-24 h-24 
              bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-emerald-500/50 group-hover:shadow-3xl group-hover:shadow-cyan-500/70
              transition-all duration-300 relative z-10 border border-white/40
            `}
          >
            <span className="text-5xl drop-shadow-xl filter">{icon}</span>
          </div>
          
          {/* 🌺 아이콘 크리스탈 글로우 효과 */}
          <div className={`
            absolute inset-0 bg-gradient-to-br ${gradient} rounded-3xl 
            blur-xl opacity-0 group-hover:opacity-60 transition-opacity duration-500
          `}></div>
          
          {/* ☀️ 추가 열대 효과 */}
          <div className="absolute inset-0 bg-gradient-radial from-yellow-200/20 via-emerald-200/10 to-transparent rounded-3xl blur-lg opacity-0 group-hover:opacity-40 transition-opacity duration-700"></div>
        </div>
      </div>
      
      {/* 🌊 콘텐츠 */}
      <div className="relative z-10 text-center">
        <h3 className="text-xl font-bold text-emerald-700 mb-4 group-hover:text-cyan-700 transition-colors duration-300 drop-shadow-lg">
          {title}
        </h3>
        <p className="text-emerald-600 leading-relaxed group-hover:text-cyan-600 transition-colors duration-300 drop-shadow-sm">
          {description}
        </p>
      </div>

      {/* 🏖️ 하단 크리스탈 액센트 라인 */}
      <div className={`
        absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r ${gradient} 
        transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 
        origin-left rounded-b-3xl shadow-lg shadow-emerald-500/50
      `}></div>

      {/* 🌺 열대 코너 장식 */}
      <div className="absolute top-0 right-0 w-24 h-24 overflow-hidden rounded-tr-3xl">
        <div className={`
          absolute -top-8 -right-8 w-20 h-20 bg-gradient-to-br ${gradient} 
          rounded-full opacity-20 group-hover:opacity-50 transition-opacity duration-300 animate-pulse
        `}></div>
      </div>

      {/* 🏝️ 추가 장식 요소들 */}
      <div className="absolute top-0 left-0 w-20 h-20 overflow-hidden rounded-tl-3xl">
        <div className="absolute -top-6 -left-6 w-16 h-16 bg-emerald-300/20 rounded-full opacity-30 group-hover:opacity-60 transition-opacity duration-300 animate-pulse delay-500"></div>
      </div>

      {/* 🌊 크리스탈 경계선 효과 */}
      <div className="absolute inset-0 rounded-3xl border border-white/40 group-hover:border-emerald-300/60 transition-colors duration-300"></div>
      
      {/* 💎 중앙 크리스탈 효과 */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-40 h-40 bg-gradient-radial from-white/15 via-emerald-100/10 to-transparent rounded-full blur-3xl opacity-0 group-hover:opacity-60 transition-opacity duration-700"></div>

      {/* 🏖️ 하단 그라데이션 */}
      <div className="absolute bottom-0 left-0 right-0 h-10 bg-gradient-to-t from-white/40 to-transparent rounded-b-3xl pointer-events-none"></div>
      
      {/* 🌴 미니 야자수 장식 */}
      <div className="absolute bottom-2 right-2 opacity-20 group-hover:opacity-40 transition-opacity duration-300">
        <svg width="16" height="20" viewBox="0 0 16 20">
          <path d="M8 20 L8 12 M4 12 Q8 8 12 12" stroke="#059669" strokeWidth="1" fill="none"/>
          <circle cx="8" cy="10" r="2" fill="#059669"/>
        </svg>
      </div>
      
      <style jsx>{`
        .bg-gradient-radial {
          background: radial-gradient(circle, var(--tw-gradient-stops));
        }
        
        .shadow-3xl {
          box-shadow: 0 35px 60px -12px rgba(0, 0, 0, 0.25);
        }
      `}</style>
    </div>
  );
}