// ============================================
// 🌊 Deep Ocean TopBar.jsx - 심해 상단 공지
// ============================================
// src/components/TopBar.jsx

import React from 'react';

export default function TopBar() {
  return (
    <div className="bg-gradient-to-r from-indigo-600/80 via-blue-500 to-cyan-500/80 border-b border-slate-700/30 relative overflow-hidden">
      {/* 심해 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-r from-slate-800/30 via-indigo-900/40 to-slate-800/30"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_70%,rgba(30,64,175,0.1)_100%)]"></div>
      
      {/* 움직이는 심해 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1 left-1/4 w-1 h-1 bg-blue-400/40 rounded-full animate-pulse shadow-lg shadow-blue-500/50"></div>
        <div className="absolute top-2 right-1/3 w-1 h-1 bg-indigo-400/30 rounded-full animate-pulse delay-700 shadow-lg shadow-indigo-500/50"></div>
        <div className="absolute bottom-1 left-1/2 w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse delay-1000 shadow-lg shadow-cyan-500/50"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-teal-500/40 rounded-full animate-pulse delay-500 shadow-lg shadow-teal-500/50"></div>
      </div>

      <div className="container mx-auto px-4 py-2 text-center relative z-10">
        <div className="flex items-center justify-center space-x-2 text-sm">
          <span className="animate-pulse text-cyan-200 drop-shadow-lg">🐠</span>
          <span className="font-medium text-cyan-100 drop-shadow-sm">
            🌊 심해 서비스 오픈! AI 자동 채점을 무료로 체험해보세요
          </span>
          <span className="animate-pulse text-blue-200 drop-shadow-lg">🌊</span>
        </div>
      </div>

      {/* 하단 바다 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent shadow-lg shadow-cyan-500/50"></div>
    </div>
  );
}