import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function ParadiseLearningAnalysis() {
  const navigate = useNavigate();
  const [selectedPeriod, setSelectedPeriod] = useState('최근 6개월');

  // 파라다이스 축복 효과 상태
  const [blessingEffect, setBlessingEffect] = useState(false);
  const [lightShine, setLightShine] = useState(false);
  const [petalFlutter, setPetalFlutter] = useState(false);

  // 🏠 홈으로 가기
  const handleBackToHome = () => {
    navigate(-1);
  };

  // 🎨 개별 과목 표시/숨김 토글 상태
  const [visibleSubjects, setVisibleSubjects] = useState({
    korean: true,
    english: true,
    math: true
  });

  // 🎨 선택된 회차들 상태
  const [selectedExams, setSelectedExams] = useState(new Set());

  // 🆕 비교 모드 상태 (내 점수만, 회원평균, 전국평균)
  const [comparisonMode, setComparisonMode] = useState('mine');

  // 파라다이스 축복 효과 트리거
  useEffect(() => {
    const blessingInterval = setInterval(() => {
      setBlessingEffect(true);
      setTimeout(() => setBlessingEffect(false), 300);
    }, 7000 + Math.random() * 15000);

    const lightInterval = setInterval(() => {
      setLightShine(true);
      setTimeout(() => setLightShine(false), 4000);
    }, 10000 + Math.random() * 20000);

    const petalInterval = setInterval(() => {
      setPetalFlutter(true);
      setTimeout(() => setPetalFlutter(false), 500);
    }, 5000 + Math.random() * 10000);

    return () => {
      clearInterval(blessingInterval);
      clearInterval(lightInterval);
      clearInterval(petalInterval);
    };
  }, []);

  // 과목 토글 함수
  const toggleSubject = (subject) => {
    setVisibleSubjects(prev => ({
      ...prev,
      [subject]: !prev[subject]
    }));
  };

  // 🎯 회차 토글 함수
  const toggleExam = (examIndex) => {
    // 평균 모드일 때는 단일 선택만 가능
    if (comparisonMode !== 'mine') {
      setSelectedExams(new Set([examIndex]));
      return;
    }
    
    setSelectedExams(prev => {
      const newSet = new Set(prev);
      if (newSet.has(examIndex)) {
        newSet.delete(examIndex);
      } else {
        newSet.add(examIndex);
      }
      return newSet;
    });
  };

  // 모든 회차 선택/해제 함수
  const toggleAllExams = () => {
    // 평균 모드일 때는 동작하지 않음
    if (comparisonMode !== 'mine') return;
    
    const allIndices = currentData.map((_, index) => index);
    if (selectedExams.size === currentData.length) {
      setSelectedExams(new Set());
    } else {
      setSelectedExams(new Set(allIndices));
    }
  };

  // 🆕 비교 모드 변경 시 선택 초기화
  const handleComparisonModeChange = (mode) => {
    setComparisonMode(mode);
    if (mode !== 'mine') {
      // 평균 모드로 변경시 첫 번째 회차만 선택
      setSelectedExams(new Set([0]));
    } else {
      // 내 점수 모드로 변경시 선택 초기화
      setSelectedExams(new Set());
    }
  };

  // 더미 성적 데이터 (회원평균, 전국평균 추가)
  const scoreData = {
    '최근 6개월': [
      { 
        exam: '1회', 
        date: '2024-01', 
        total: 72, 
        korean: 68, 
        english: 75, 
        math: 73,
        memberAvg: { total: 75, korean: 72, english: 76, math: 77 },
        nationalAvg: { total: 70, korean: 68, english: 71, math: 72 }
      },
      { 
        exam: '2회', 
        date: '2024-02', 
        total: 76, 
        korean: 72, 
        english: 78, 
        math: 78,
        memberAvg: { total: 77, korean: 74, english: 78, math: 79 },
        nationalAvg: { total: 72, korean: 70, english: 73, math: 74 }
      },
      { 
        exam: '3회', 
        date: '2024-03', 
        total: 82, 
        korean: 85, 
        english: 80, 
        math: 81,
        memberAvg: { total: 79, korean: 76, english: 80, math: 81 },
        nationalAvg: { total: 74, korean: 72, english: 75, math: 76 }
      },
      { 
        exam: '4회', 
        date: '2024-04', 
        total: 78, 
        korean: 82, 
        english: 75, 
        math: 77,
        memberAvg: { total: 80, korean: 78, english: 81, math: 82 },
        nationalAvg: { total: 75, korean: 73, english: 76, math: 77 }
      },
      { 
        exam: '5회', 
        date: '2024-05', 
        total: 86, 
        korean: 88, 
        english: 85, 
        math: 85,
        memberAvg: { total: 82, korean: 80, english: 83, math: 84 },
        nationalAvg: { total: 77, korean: 75, english: 78, math: 79 }
      },
      { 
        exam: '6회', 
        date: '2024-06', 
        total: 89, 
        korean: 92, 
        english: 87, 
        math: 88,
        memberAvg: { total: 84, korean: 82, english: 85, math: 86 },
        nationalAvg: { total: 79, korean: 77, english: 80, math: 81 }
      }
    ],
    '최근 1년': [
      { 
        exam: '1회', 
        date: '2023-06', 
        total: 65, 
        korean: 62, 
        english: 68, 
        math: 65,
        memberAvg: { total: 68, korean: 65, english: 70, math: 69 },
        nationalAvg: { total: 63, korean: 61, english: 65, math: 64 }
      },
      { 
        exam: '2회', 
        date: '2023-08', 
        total: 68, 
        korean: 65, 
        english: 70, 
        math: 69,
        memberAvg: { total: 70, korean: 67, english: 72, math: 71 },
        nationalAvg: { total: 65, korean: 63, english: 67, math: 66 }
      },
      { 
        exam: '3회', 
        date: '2023-10', 
        total: 71, 
        korean: 67, 
        english: 73, 
        math: 73,
        memberAvg: { total: 72, korean: 69, english: 74, math: 73 },
        nationalAvg: { total: 67, korean: 65, english: 69, math: 68 }
      },
      { 
        exam: '4회', 
        date: '2023-12', 
        total: 74, 
        korean: 70, 
        english: 76, 
        math: 76,
        memberAvg: { total: 74, korean: 71, english: 76, math: 75 },
        nationalAvg: { total: 69, korean: 67, english: 71, math: 70 }
      },
      { 
        exam: '5회', 
        date: '2024-02', 
        total: 78, 
        korean: 75, 
        english: 80, 
        math: 79,
        memberAvg: { total: 76, korean: 73, english: 78, math: 77 },
        nationalAvg: { total: 71, korean: 69, english: 73, math: 72 }
      },
      { 
        exam: '6회', 
        date: '2024-04', 
        total: 83, 
        korean: 85, 
        english: 82, 
        math: 82,
        memberAvg: { total: 80, korean: 78, english: 81, math: 82 },
        nationalAvg: { total: 75, korean: 73, english: 76, math: 77 }
      },
      { 
        exam: '7회', 
        date: '2024-06', 
        total: 89, 
        korean: 92, 
        english: 87, 
        math: 88,
        memberAvg: { total: 84, korean: 82, english: 85, math: 86 },
        nationalAvg: { total: 79, korean: 77, english: 80, math: 81 }
      }
    ]
  };

  const currentData = scoreData[selectedPeriod];

  // 과목별 강점과 개선점 데이터 (파라다이스 버전)
  const subjectAnalysisData = {
    korean: {
      strengths: [
        '파라다이스 문학의 아름다운 감성을 잘 이해함',
        '고전 시가의 황홀한 의미를 정확히 해석함',
        '화자의 희망과 열정을 깊이 공감함'
      ],
      improvements: [
        '비문학 지문의 더 깊은 신비를 탐구해야 함',
        '문법의 다채로운 규칙을 체계화해야 함',
        '독해 속도를 높여 시간의 축복을 받아야 함'
      ]
    },
    english: {
      strengths: [
        '파라다이스 영어 독해 능력이 꽃피고 있음',
        '어휘의 무지개가 점점 넓어지고 있음',
        '긴 지문 속 황홀한 의미에 집중력 탁월'
      ],
      improvements: [
        '어법/문법의 정원을 더 가꿔야 함',
        '빈칸추론의 보물찾기를 완성해야 함',
        '듣기 영역의 멜로디를 더 연습해야 함'
      ]
    },
    math: {
      strengths: [
        '수학의 파라다이스에서 기초 연산 능력 빛남',
        '기본 공식의 마법을 아름답게 활용함',
        '계산의 정확도가 황금빛으로 반짝임'
      ],
      improvements: [
        '응용 문제의 신비로운 세계를 탐험해야 함',
        '복잡한 사고의 꽃밭을 헤쳐나가야 함',
        '시간의 선물을 더 효율적으로 활용해야 함'
      ]
    }
  };

  const analysisData = {
    totalExams: 12,
    averageScore: 87.5,
    improvementRate: 15.2,
    totalImprovement: 17,
    bestSubject: '🌺 국어',
    weakestSubject: '🌻 수학',
    consistencyScore: 92,
    
    // 월별 성적 데이터 (파라다이스 테마)
    monthlyScores: [
      { month: '2024-01', korean: 75, english: 70, math: 68, date: '1월' },
      { month: '2024-02', korean: 78, english: 73, math: 71, date: '2월' },
      { month: '2024-03', korean: 82, english: 76, math: 74, date: '3월' },
      { month: '2024-04', korean: 85, english: 79, math: 77, date: '4월' },
      { month: '2024-05', korean: 88, english: 82, math: 80, date: '5월' },
      { month: '2024-06', korean: 92, english: 85, math: 83, date: '6월' }
    ],

    // AI 맞춤 학습 추천 (파라다이스 테마)
    recommendations: [
      {
        title: '🌺 국어 감성 향상',
        description: '문학 작품의 아름다운 감정을 더 깊이 이해하고 표현력을 키워보세요.',
        duration: '2주',
        expectedImprovement: '+5점'
      },
      {
        title: '🌟 영어 어휘 확장',
        description: '다양한 어휘와 표현을 익혀 파라다이스 영어 실력을 완성하세요.',
        duration: '3주',
        expectedImprovement: '+7점'
      },
      {
        title: '🌻 수학 응용력 강화',
        description: '기본기를 바탕으로 복잡한 응용 문제까지 완벽하게 해결하세요.',
        duration: '4주',
        expectedImprovement: '+8점'
      }
    ]
  };

  // 선택된 과목별 강점과 개선점 필터링
  const getFilteredAnalysisData = () => {
    const selectedSubjects = Object.keys(visibleSubjects).filter(subject => visibleSubjects[subject]);
    
    const filteredStrengths = [];
    const filteredImprovements = [];
    
    selectedSubjects.forEach(subject => {
      if (subjectAnalysisData[subject]) {
        filteredStrengths.push(...subjectAnalysisData[subject].strengths);
        filteredImprovements.push(...subjectAnalysisData[subject].improvements);
      }
    });
    
    return {
      strengths: filteredStrengths,
      improvements: filteredImprovements
    };
  };

  const filteredData = getFilteredAnalysisData();

  const renderLineChart = () => {
    const koreanData = currentData.map(d => d.korean);
    const englishData = currentData.map(d => d.english);
    const mathData = currentData.map(d => d.math);
    
    // 🆕 비교 데이터 추가
    const koreanAvgData = comparisonMode === 'member' ? currentData.map(d => d.memberAvg.korean) : 
                         comparisonMode === 'national' ? currentData.map(d => d.nationalAvg.korean) : [];
    const englishAvgData = comparisonMode === 'member' ? currentData.map(d => d.memberAvg.english) : 
                          comparisonMode === 'national' ? currentData.map(d => d.nationalAvg.english) : [];
    const mathAvgData = comparisonMode === 'member' ? currentData.map(d => d.memberAvg.math) : 
                       comparisonMode === 'national' ? currentData.map(d => d.nationalAvg.math) : [];
    
    const maxValue = 100;
    const minValue = 60;
    const range = maxValue - minValue;
    
    const width = 500;
    const height = 350;
    const padding = 50;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    
    const getX = (index) => padding + (index / (currentData.length - 1)) * chartWidth;
    const getY = (value) => padding + ((maxValue - value) / range) * chartHeight;
    
    const createPath = (data) => data.map((value, index) => `${index === 0 ? 'M' : 'L'} ${getX(index)} ${getY(value)}`).join(' ');
    
    return (
      <div className="relative bg-gradient-to-br from-pink-50 via-orange-50 to-yellow-50 rounded-2xl border-2 border-pink-300 p-4 shadow-lg">
        <h4 className="text-center font-bold text-pink-600 mb-4">📈 성적 변화 추이 - The Paradise Evolution</h4>
        
        {/* 🆕 비교 모드 선택 - 파라다이스 스타일 */}
        <div className="flex justify-center space-x-2 mb-4">
          <button 
            onClick={() => handleComparisonModeChange('mine')}
            className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
              comparisonMode === 'mine' 
                ? 'bg-gradient-to-r from-pink-500 to-orange-400 text-white shadow-lg shadow-pink-500/50 border border-pink-400' 
                : 'bg-white/80 text-pink-500 hover:bg-pink-50 border border-pink-200'
            }`}
          >
            🌺 내 점수만
          </button>
          <button 
            onClick={() => handleComparisonModeChange('member')}
            className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
              comparisonMode === 'member' 
                ? 'bg-gradient-to-r from-purple-500 to-pink-400 text-white shadow-lg shadow-purple-500/50 border border-purple-400' 
                : 'bg-white/80 text-purple-500 hover:bg-purple-50 border border-purple-200'
            }`}
          >
            🌸 회원평균 비교
          </button>
          <button 
            onClick={() => handleComparisonModeChange('national')}
            className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
              comparisonMode === 'national' 
                ? 'bg-gradient-to-r from-orange-500 to-yellow-400 text-white shadow-lg shadow-orange-500/50 border border-orange-400' 
                : 'bg-white/80 text-orange-500 hover:bg-orange-50 border border-orange-200'
            }`}
          >
            🌻 전국평균 비교
          </button>
        </div>
        
        <div className="flex justify-center space-x-2 md:space-x-4 mb-6">
          <button onClick={() => toggleSubject('korean')} className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-300 ${visibleSubjects.korean ? 'bg-gradient-to-r from-pink-500/20 to-pink-400/20 text-pink-600 shadow-lg border-2 border-pink-400/70' : 'bg-white/80 text-pink-400 hover:bg-pink-50 border-2 border-pink-200/50'}`}>
            <div className={`w-3 h-3 rounded-full ${visibleSubjects.korean ? 'bg-gradient-to-r from-pink-500 to-pink-400 shadow-md shadow-pink-500/50' : 'bg-pink-300'}`}></div>
            <span className="text-sm font-medium">🌺 국어</span>
          </button>
          <button onClick={() => toggleSubject('english')} className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-300 ${visibleSubjects.english ? 'bg-gradient-to-r from-purple-500/20 to-purple-400/20 text-purple-600 shadow-lg border-2 border-purple-400/70' : 'bg-white/80 text-purple-400 hover:bg-purple-50 border-2 border-purple-200/50'}`}>
            <div className={`w-3 h-3 rounded-full ${visibleSubjects.english ? 'bg-gradient-to-r from-purple-500 to-purple-400 shadow-md shadow-purple-500/50' : 'bg-purple-300'}`}></div>
            <span className="text-sm font-medium">🌸 영어</span>
          </button>
          <button onClick={() => toggleSubject('math')} className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-300 ${visibleSubjects.math ? 'bg-gradient-to-r from-orange-500/20 to-orange-400/20 text-orange-600 shadow-lg border-2 border-orange-400/70' : 'bg-white/80 text-orange-400 hover:bg-orange-50 border-2 border-orange-200/50'}`}>
            <div className={`w-3 h-3 rounded-full ${visibleSubjects.math ? 'bg-gradient-to-r from-orange-500 to-orange-400 shadow-md shadow-orange-500/50' : 'bg-orange-300'}`}></div>
            <span className="text-sm font-medium">🌻 수학</span>
          </button>
        </div>
        
        <svg width="100%" viewBox={`0 0 ${width} ${height}`}>
          <defs>
            <linearGradient id="gradient-korean" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#ec4899" /><stop offset="30%" stopColor="#f472b6" /><stop offset="70%" stopColor="#fb7185" /><stop offset="100%" stopColor="#f97316" /></linearGradient>
            <linearGradient id="gradient-english" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#8b5cf6" /><stop offset="30%" stopColor="#a78bfa" /><stop offset="70%" stopColor="#c084fc" /><stop offset="100%" stopColor="#ec4899" /></linearGradient>
            <linearGradient id="gradient-math" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#f97316" /><stop offset="30%" stopColor="#fb923c" /><stop offset="70%" stopColor="#fbbf24" /><stop offset="100%" stopColor="#eab308" /></linearGradient>
            
            {/* 🆕 평균 선을 위한 점선 패턴 */}
            <pattern id="dashed" patternUnits="userSpaceOnUse" width="10" height="2">
              <rect width="6" height="2" fill="currentColor"/>
            </pattern>
          </defs>
          
          {[60, 70, 80, 90, 100].map(value => <g key={value}><line x1={padding} y1={getY(value)} x2={width - padding} y2={getY(value)} stroke="#fbbf24" strokeWidth="1" opacity="0.3"/><text x={padding - 10} y={getY(value) + 4} textAnchor="end" fontSize="12" fill="#f97316">{value}</text></g>)}
          {currentData.map((item, index) => <text key={index} x={getX(index)} y={height - padding + 20} textAnchor="middle" fontSize="12" fill="#f97316">{item.exam}</text>)}
          
          {/* 내 점수 선 */}
          {visibleSubjects.korean && <path d={createPath(koreanData)} fill="none" stroke="url(#gradient-korean)" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" className="drop-shadow-md" style={{ filter: 'drop-shadow(0 0 8px #ec4899)' }}/>}
          {visibleSubjects.english && <path d={createPath(englishData)} fill="none" stroke="url(#gradient-english)" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" className="drop-shadow-md" style={{ filter: 'drop-shadow(0 0 8px #8b5cf6)' }}/>}
          {visibleSubjects.math && <path d={createPath(mathData)} fill="none" stroke="url(#gradient-math)" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" className="drop-shadow-md" style={{ filter: 'drop-shadow(0 0 8px #f97316)' }}/>}
          
          {/* 🆕 평균 점수 선 (점선) */}
          {comparisonMode !== 'mine' && (
            <>
              {visibleSubjects.korean && koreanAvgData.length > 0 && <path d={createPath(koreanAvgData)} fill="none" stroke="#ec4899" strokeWidth="3" strokeDasharray="8,4" opacity="0.7"/>}
              {visibleSubjects.english && englishAvgData.length > 0 && <path d={createPath(englishAvgData)} fill="none" stroke="#8b5cf6" strokeWidth="3" strokeDasharray="8,4" opacity="0.7"/>}
              {visibleSubjects.math && mathAvgData.length > 0 && <path d={createPath(mathAvgData)} fill="none" stroke="#f97316" strokeWidth="3" strokeDasharray="8,4" opacity="0.7"/>}
            </>
          )}
          
          {currentData.map((item, index) => (
            <g key={`points-${index}`}>
              {visibleSubjects.korean && <circle cx={getX(index)} cy={getY(item.korean)} r="6" fill={selectedExams.has(index) ? "#ec4899" : "url(#gradient-korean)"} stroke="#fff" strokeWidth="2" className="cursor-pointer drop-shadow-lg hover:r-8 transition-all duration-300" onClick={() => toggleExam(index)} style={{ filter: 'drop-shadow(0 0 10px #ec4899)' }}/>}
              {visibleSubjects.english && <circle cx={getX(index)} cy={getY(item.english)} r="6" fill={selectedExams.has(index) ? "#8b5cf6" : "url(#gradient-english)"} stroke="#fff" strokeWidth="2" className="cursor-pointer drop-shadow-lg hover:r-8 transition-all duration-300" onClick={() => toggleExam(index)} style={{ filter: 'drop-shadow(0 0 10px #8b5cf6)' }}/>}
              {visibleSubjects.math && <circle cx={getX(index)} cy={getY(item.math)} r="6" fill={selectedExams.has(index) ? "#f97316" : "url(#gradient-math)"} stroke="#fff" strokeWidth="2" className="cursor-pointer drop-shadow-lg hover:r-8 transition-all duration-300" onClick={() => toggleExam(index)} style={{ filter: 'drop-shadow(0 0 10px #f97316)' }}/>}
              
              {/* 🆕 평균 점수 점 */}
              {comparisonMode !== 'mine' && (
                <>
                  {visibleSubjects.korean && <circle cx={getX(index)} cy={getY(comparisonMode === 'member' ? item.memberAvg.korean : item.nationalAvg.korean)} r="4" fill="#ec4899" stroke="#fff" strokeWidth="2" opacity="0.7"/>}
                  {visibleSubjects.english && <circle cx={getX(index)} cy={getY(comparisonMode === 'member' ? item.memberAvg.english : item.nationalAvg.english)} r="4" fill="#8b5cf6" stroke="#fff" strokeWidth="2" opacity="0.7"/>}
                  {visibleSubjects.math && <circle cx={getX(index)} cy={getY(comparisonMode === 'member' ? item.memberAvg.math : item.nationalAvg.math)} r="4" fill="#f97316" stroke="#fff" strokeWidth="2" opacity="0.7"/>}
                </>
              )}
            </g>
          ))}
        </svg>
        
        {/* 🆕 범례 업데이트 */}
        {comparisonMode !== 'mine' && (
          <div className="mt-4 text-center text-xs text-pink-600">
            <div className="flex justify-center items-center space-x-4">
              <div className="flex items-center space-x-1">
                <div className="w-4 h-0.5 bg-gradient-to-r from-pink-500 to-orange-400"></div>
                <span>내 점수</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-4 h-0.5 border-t-2 border-dashed border-pink-400"></div>
                <span>{comparisonMode === 'member' ? '회원평균' : '전국평균'}</span>
              </div>
            </div>
          </div>
        )}
        
        <div className="mt-2 text-center">
          <button 
            onClick={toggleAllExams} 
            className={`text-xs px-3 py-1 rounded-full transition-all duration-300 backdrop-blur-sm ${
              comparisonMode !== 'mine' 
                ? 'bg-pink-100 text-pink-400 cursor-not-allowed border border-pink-200' 
                : 'bg-white/80 hover:bg-pink-50 text-pink-500 border border-pink-300'
            }`}
            disabled={comparisonMode !== 'mine'}
          >
            {comparisonMode !== 'mine' 
              ? '🌺 평균 비교시 개별 선택만 가능' 
              : (selectedExams.size === currentData.length ? '🌸 모두 해제' : '🌻 모두 선택')
            }
          </button>
        </div>
      </div>
    );
  };

  const renderStackedBarChart = () => {
    // 🆕 평균 모드일 때는 선택된 회차만, 아닐 때는 기존 로직
    const displayData = comparisonMode !== 'mine' 
      ? (selectedExams.size > 0 ? currentData.filter((_, index) => selectedExams.has(index)) : [currentData[0]])
      : (selectedExams.size > 0 
          ? currentData.filter((_, index) => selectedExams.has(index))
          : currentData.slice(-5));
    
    const activeSubjects = Object.entries(visibleSubjects).filter(([_, value]) => value);
    const isOnlyOneSubject = activeSubjects.length === 1;

    const width = 450;
    const height = 400;
    const padding = { top: 40, right: 20, bottom: 100, left: 50 };

    const subjectDetails = {
      korean: { name: '🌺 국어', color: 'url(#gradient-korean-bar)' },
      english: { name: '🌸 영어', color: 'url(#gradient-english-bar)' },
      math: { name: '🌻 수학', color: 'url(#gradient-math-bar)' }
    };
    
    const visibleSubjectKeys = activeSubjects.map(([key]) => key);

    return (
      <div className="bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 rounded-2xl border-2 border-purple-300 p-4 shadow-lg">
        <h4 className="text-center font-bold text-purple-600 mb-4 px-4">
          📊 {comparisonMode !== 'mine' 
                ? `${comparisonMode === 'member' ? '🌸 회원평균' : '🌻 전국평균'} 비교`
                : (isOnlyOneSubject 
                    ? `${subjectDetails[visibleSubjectKeys[0]]?.name || ''} 점수 비교` 
                    : `🌺 과목별 점수 비교`)}
        </h4>
        
        <svg width="100%" viewBox={`0 0 ${width} ${height}`}>
          <defs>
              <linearGradient id="gradient-korean-bar" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#ec4899" /><stop offset="50%" stopColor="#f472b6" /><stop offset="100%" stopColor="#fb7185" /></linearGradient>
              <linearGradient id="gradient-english-bar" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#8b5cf6" /><stop offset="50%" stopColor="#a78bfa" /><stop offset="100%" stopColor="#c084fc" /></linearGradient>
              <linearGradient id="gradient-math-bar" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#f97316" /><stop offset="50%" stopColor="#fb923c" /><stop offset="100%" stopColor="#fbbf24" /></linearGradient>
              
              {/* 🌈 세로 파라다이스 그라데이션 (다중 과목용) */}
              <linearGradient id="aurora-korean" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fce7f3" />
                <stop offset="25%" stopColor="#fbcfe8" />
                <stop offset="50%" stopColor="#f9a8d4" />
                <stop offset="75%" stopColor="#ec4899" />
                <stop offset="100%" stopColor="#be185d" />
              </linearGradient>
              
              <linearGradient id="aurora-english" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#ede9fe" />
                <stop offset="25%" stopColor="#ddd6fe" />
                <stop offset="50%" stopColor="#c4b5fd" />
                <stop offset="75%" stopColor="#8b5cf6" />
                <stop offset="100%" stopColor="#7c3aed" />
              </linearGradient>
              
              <linearGradient id="aurora-math" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fed7aa" />
                <stop offset="25%" stopColor="#fdba74" />
                <stop offset="50%" stopColor="#fb923c" />
                <stop offset="75%" stopColor="#f97316" />
                <stop offset="100%" stopColor="#ea580c" />
              </linearGradient>
              
              {/* 🆕 평균용 파라다이스 그라데이션 */}
              <linearGradient id="avg-korean" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fbcfe8" />
                <stop offset="50%" stopColor="#f9a8d4" />
                <stop offset="100%" stopColor="#ec4899" />
              </linearGradient>
              
              <linearGradient id="avg-english" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#ddd6fe" />
                <stop offset="50%" stopColor="#c4b5fd" />
                <stop offset="100%" stopColor="#8b5cf6" />
              </linearGradient>
              
              <linearGradient id="avg-math" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fdba74" />
                <stop offset="50%" stopColor="#fb923c" />
                <stop offset="100%" stopColor="#f97316" />
              </linearGradient>
              
              <linearGradient id="text-gradient" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#1f2937" /><stop offset="50%" stopColor="#ec4899" /><stop offset="100%" stopColor="#8b5cf6" /></linearGradient>
          </defs>

          {isOnlyOneSubject ? (
            comparisonMode !== 'mine' ? (
              /* 평균 비교 모드: 세로 막대 그래프 - 파라다이스 스타일 */
              (() => {
                const chartWidth = width - padding.left - padding.right;
                const chartHeight = height - padding.top - padding.bottom;
                const subjectKey = visibleSubjectKeys[0];
                const getY = (value) => padding.top + (1 - value / 100) * chartHeight;

                const groupWidth = chartWidth / displayData.length;
                const groupPadding = 0.3;
                const barGroupWidth = groupWidth * (1 - groupPadding);
                const barWidth = barGroupWidth / 2; // 2개 바 (내 점수 + 평균)
                const actualBarWidth = barWidth * 0.7;
                const barSpacing = barWidth * 0.3;

                return (
                  <g>
                    {[0, 20, 40, 60, 80, 100].map(value => {
                        const y = getY(value);
                        return <g key={value}><line x1={padding.left} y1={y} x2={width - padding.right} y2={y} stroke="#fbbf24" strokeWidth="1" opacity="0.3"/><text x={padding.left - 10} y={y} textAnchor="end" dominantBaseline="middle" fontSize="10" fill="#f97316">{value}</text></g>
                    })}
                    
                    {displayData.map((item, index) => {
                      const groupX = padding.left + index * groupWidth + (groupWidth * groupPadding / 2);
                      const myScore = item[subjectKey];
                      const avgScore = comparisonMode === 'member' ? item.memberAvg[subjectKey] : 
                                     comparisonMode === 'national' ? item.nationalAvg[subjectKey] : null;
                      
                      return (
                        <g key={`${item.exam}-${myScore}`}>
                          {/* 회차명 라벨 */}
                          <text x={groupX + barGroupWidth / 2} y={height - padding.bottom + 15} textAnchor="middle" fontSize="12" fill="#f97316" fontWeight="600">{item.exam}</text>
                          
                          {/* 평균 바 */}
                          <rect 
                            x={groupX} 
                            y={getY(avgScore)} 
                            width={actualBarWidth} 
                            height={height - padding.bottom - getY(avgScore)} 
                            fill={`url(#avg-${subjectKey})`} 
                            rx="3" 
                            opacity="0.7"
                            className="animate-bar-grow-vertical" 
                            style={{ 
                              animation: `bar-grow-vertical 0.8s ease-out forwards ${index * 200}ms`, 
                              transformOrigin: 'bottom center',
                              filter: `drop-shadow(0 0 8px ${subjectKey === 'korean' ? '#ec4899' : subjectKey === 'english' ? '#8b5cf6' : '#f97316'})`
                            }} 
                          />
                          <text 
                            x={groupX + actualBarWidth / 2} 
                            y={getY(avgScore) - 5} 
                            textAnchor="middle" 
                            fontSize="11" 
                            fill="#6b7280" 
                            fontWeight="500" 
                            className="animate-text-fade" 
                            style={{ animationDelay: `${index * 200 + 400}ms` }}
                          >
                            {avgScore}
                          </text>
                          
                          {/* 내 점수 바 */}
                          <rect 
                            x={groupX + actualBarWidth + barSpacing} 
                            y={getY(myScore)} 
                            width={actualBarWidth} 
                            height={height - padding.bottom - getY(myScore)} 
                            fill={`url(#aurora-${subjectKey})`} 
                            rx="4" 
                            className="animate-bar-grow-vertical drop-shadow-lg" 
                            style={{ 
                              animation: `bar-grow-vertical 0.8s ease-out forwards ${index * 200 + 100}ms, paradise-sparkle-glow 3s ease-in-out infinite ${index * 0.5 + 1}s`, 
                              transformOrigin: 'bottom center',
                              filter: `drop-shadow(0 4px 12px rgba(0, 0, 0, 0.1)) brightness(1.1) drop-shadow(0 0 12px ${subjectKey === 'korean' ? '#ec4899' : subjectKey === 'english' ? '#8b5cf6' : '#f97316'})`
                            }} 
                          />
                          <text 
                            x={groupX + actualBarWidth + barSpacing + actualBarWidth / 2} 
                            y={getY(myScore) - 5} 
                            textAnchor="middle" 
                            fontSize="11" 
                            fill="#1f2937" 
                            fontWeight="600" 
                            className="animate-text-fade" 
                            style={{ 
                              animationDelay: `${index * 200 + 500}ms`,
                              textShadow: '0 0 8px rgba(255, 255, 255, 0.8)'
                            }}
                          >
                            {myScore}
                          </text>
                          
                          {/* 범례 라벨 (첫 번째 바에만) */}
                          {index === 0 && (
                            <>
                              <text 
                                x={groupX + actualBarWidth / 2} 
                                y={height - padding.bottom + 35} 
                                textAnchor="middle" 
                                fontSize="9" 
                                fill="#f97316" 
                                fontWeight="500"
                              >
                                {comparisonMode === 'member' ? '🌸 회원평균' : '🌻 전국평균'}
                              </text>
                              <text 
                                x={groupX + actualBarWidth + barSpacing + actualBarWidth / 2} 
                                y={height - padding.bottom + 35} 
                                textAnchor="middle" 
                                fontSize="9" 
                                fill="#f97316" 
                                fontWeight="500"
                              >
                                🌺 내 점수
                              </text>
                            </>
                          )}
                        </g>
                      );
                    })}
                  </g>
                )
              })()
            ) : (
              /* 내 점수만 모드: 가로 막대 그래프 - 파라다이스 스타일 */
              (() => {
                const chartWidth = width - padding.left - padding.right;
                const chartHeight = height - padding.top - padding.bottom;
                const barHeight = Math.min(chartHeight / displayData.length * 0.7, 30);
                const subjectKey = visibleSubjectKeys[0];

                return (
                  <g>
                    {[0, 20, 40, 60, 80, 100].map(value => {
                        const x = padding.left + (value / 100) * chartWidth;
                        return <g key={value}><line x1={x} y1={padding.top} x2={x} y2={height - padding.bottom} stroke="#fbbf24" strokeWidth="1" opacity="0.3"/><text x={x} y={height - padding.bottom + 15} textAnchor="middle" fontSize="10" fill="#f97316">{value}</text></g>
                    })}
                    {displayData.map((item, index) => {
                      const y = padding.top + index * (chartHeight / displayData.length) + (chartHeight / displayData.length - barHeight) / 2;
                      const score = item[subjectKey];
                      const barWidth = (score / 100) * chartWidth;
                      
                      return (
                        <g key={`${item.exam}-${score}`}>
                          <text x={padding.left - 10} y={y + barHeight / 2} textAnchor="end" dominantBaseline="middle" fontSize="12" fill="#f97316" fontWeight="600">{item.exam}</text>
                          
                          {/* 내 점수 막대 */}
                          <rect 
                            x={padding.left} 
                            y={y} 
                            width={barWidth} 
                            height={barHeight} 
                            fill={`url(#gradient-${subjectKey}-bar)`} 
                            rx="4" 
                            className="animate-bar-grow" 
                            style={{ 
                              animation: `bar-grow 0.6s ease-out forwards, paradise-sparkle-glow 3s ease-in-out infinite ${index * 0.5}s`, 
                              transformOrigin: 'left center',
                              filter: `drop-shadow(0 0 8px ${subjectKey === 'korean' ? '#ec4899' : subjectKey === 'english' ? '#8b5cf6' : '#f97316'})`
                            }}
                          />
                          
                          {/* 점수 라벨 */}
                          <text 
                            x={padding.left + barWidth + 8} 
                            y={y + barHeight / 2} 
                            dominantBaseline="middle" 
                            fontSize="14" 
                            fill="url(#text-gradient)" 
                            fontWeight="700" 
                            className="animate-text-fade" 
                            style={{ 
                              animationDelay: `${index * 100 + 300}ms`,
                              textShadow: '0 0 8px rgba(255, 255, 255, 0.8)'
                            }}
                          >
                            {score}점
                          </text>
                        </g>
                      );
                    })}
                  </g>
                )
              })()
            )
          ) : (
            /* 다중 과목 선택 시: 세로 그룹 막대 그래프 - 파라다이스 스타일 */
            (() => {
                const chartWidth = width - padding.left - padding.right;
                const chartHeight = height - padding.top - padding.bottom;
                const getY = (value) => padding.top + (1 - value / 100) * chartHeight;

                // 🆕 평균 비교 모드일 때 바 배치 조정
                const groupWidth = chartWidth / displayData.length;
                const groupPadding = 0.3; // 그룹 간 간격 증가
                const barGroupWidth = groupWidth * (1 - groupPadding);
                
                // 평균 비교시에는 각 과목마다 2개씩 (내 점수 + 평균)
                const barsPerSubject = comparisonMode !== 'mine' ? 2 : 1;
                const totalBars = visibleSubjectKeys.length * barsPerSubject;
                const barWidth = barGroupWidth / totalBars;
                const barSpacing = barWidth * 0.3; // 바 간 간격 추가
                const actualBarWidth = barWidth * 0.7; // 바 너비 조정

                return (
                    <g>
                        {/* Y축 눈금 */}
                        {[0, 20, 40, 60, 80, 100].map(value => (
                            <g key={value}>
                                <line x1={padding.left} y1={getY(value)} x2={width - padding.right} y2={getY(value)} stroke="#fbbf24" strokeWidth="1" opacity="0.3"/>
                                <text x={padding.left - 10} y={getY(value)} textAnchor="end" dominantBaseline="middle" fontSize="10" fill="#f97316">{value}</text>
                            </g>
                        ))}

                        {/* 각 회차별 그룹 */}
                        {displayData.map((item, examIndex) => {
                            const groupX = padding.left + examIndex * groupWidth + (groupWidth * groupPadding / 2);
                            let barIndex = 0;
                            
                            return (
                                <g key={`${item.exam}-${selectedExams.size}`}>
                                    {/* 회차명 라벨 */}
                                    <text x={groupX + barGroupWidth / 2} y={height - padding.bottom + 20} textAnchor="middle" fontSize="12" fill="#f97316" fontWeight="600">{item.exam}</text>
                                    
                                    {/* 각 과목별 바 */}
                                    {visibleSubjectKeys.map((subjectKey, subIndex) => {
                                        const myScore = item[subjectKey];
                                        const avgScore = comparisonMode === 'member' ? item.memberAvg[subjectKey] : 
                                                       comparisonMode === 'national' ? item.nationalAvg[subjectKey] : null;

                                        const elements = [];
                                        
                                        if (comparisonMode !== 'mine' && avgScore) {
                                            // 평균 바
                                            const avgBarX = groupX + barIndex * (actualBarWidth + barSpacing);
                                            const avgBarY = getY(avgScore);
                                            const avgBarH = height - padding.bottom - avgBarY;
                                            
                                            elements.push(
                                                <g key={`${subjectKey}-avg`}>
                                                    <rect 
                                                        x={avgBarX} 
                                                        y={avgBarY} 
                                                        width={actualBarWidth} 
                                                        height={avgBarH} 
                                                        fill={`url(#avg-${subjectKey})`} 
                                                        rx="3" 
                                                        opacity="0.7"
                                                        className="animate-bar-grow-vertical" 
                                                        style={{ 
                                                            animation: `bar-grow-vertical 0.8s ease-out forwards ${examIndex * 200 + barIndex * 100}ms`, 
                                                            transformOrigin: 'bottom center',
                                                            filter: `drop-shadow(0 0 8px ${subjectKey === 'korean' ? '#ec4899' : subjectKey === 'english' ? '#8b5cf6' : '#f97316'})`
                                                        }} 
                                                    />
                                                    <text 
                                                        x={avgBarX + actualBarWidth / 2} 
                                                        y={avgBarY - 5} 
                                                        textAnchor="middle" 
                                                        fontSize="9" 
                                                        fill="#6b7280" 
                                                        fontWeight="500" 
                                                        className="animate-text-fade" 
                                                        style={{ animationDelay: `${examIndex * 200 + barIndex * 100 + 400}ms` }}
                                                    >
                                                        {avgScore}
                                                    </text>
                                                </g>
                                            );
                                            barIndex++;
                                        }
                                        
                                        // 내 점수 바
                                        const myBarX = groupX + barIndex * (actualBarWidth + barSpacing);
                                        const myBarY = getY(myScore);
                                        const myBarH = height - padding.bottom - myBarY;
                                        
                                        elements.push(
                                            <g key={`${subjectKey}-mine`}>
                                                <rect 
                                                    x={myBarX} 
                                                    y={myBarY} 
                                                    width={actualBarWidth} 
                                                    height={myBarH} 
                                                    fill={`url(#aurora-${subjectKey})`} 
                                                    rx="4" 
                                                    className="animate-bar-grow-vertical drop-shadow-lg" 
                                                    style={{ 
                                                        animation: `bar-grow-vertical 0.8s ease-out forwards ${examIndex * 200 + barIndex * 100}ms, paradise-sparkle-glow 3s ease-in-out infinite ${examIndex * 0.5 + barIndex * 0.2 + 1}s`, 
                                                        transformOrigin: 'bottom center',
                                                        filter: `drop-shadow(0 4px 12px rgba(0, 0, 0, 0.1)) brightness(1.1) drop-shadow(0 0 12px ${subjectKey === 'korean' ? '#ec4899' : subjectKey === 'english' ? '#8b5cf6' : '#f97316'})`
                                                    }} 
                                                />
                                                <text 
                                                    x={myBarX + actualBarWidth / 2} 
                                                    y={myBarY - 5} 
                                                    textAnchor="middle" 
                                                    fontSize="11" 
                                                    fill="#1f2937" 
                                                    fontWeight="600" 
                                                    className="animate-text-fade" 
                                                    style={{ 
                                                        animationDelay: `${examIndex * 200 + barIndex * 100 + 400}ms`,
                                                        textShadow: '0 0 8px rgba(255, 255, 255, 0.8)'
                                                    }}
                                                >
                                                    {myScore}
                                                </text>
                                            </g>
                                        );
                                        barIndex++;
                                        
                                        return elements;
                                    })}
                                    
                                    {/* 과목명 라벨 (첫 번째 회차에만) */}
                                    {examIndex === 0 && visibleSubjectKeys.map((subjectKey, subIndex) => {
                                        const labelX = groupX + (subIndex * barsPerSubject + barsPerSubject / 2 - 0.5) * (actualBarWidth + barSpacing) + actualBarWidth / 2;
                                        return (
                                            <text 
                                                key={`label-${subjectKey}`}
                                                x={labelX} 
                                                y={height - padding.bottom + 35} 
                                                textAnchor="middle" 
                                                fontSize="9" 
                                                fill="#f97316" 
                                                fontWeight="500"
                                            >
                                                {subjectDetails[subjectKey]?.name}
                                            </text>
                                        );
                                    })}
                                </g>
                            )
                        })}
                    </g>
                )
            })()
          )}
        </svg>
        
        {/* 🆕 범례 업데이트 - 파라다이스 스타일 */}
        <div className="flex justify-center flex-wrap gap-x-4 gap-y-2 mt-4 text-sm px-4">
          {visibleSubjectKeys.map(key => (
            <div key={key} className="flex items-center space-x-2">
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 rounded shadow-sm border border-white" style={{ 
                  background: isOnlyOneSubject ? 
                    (key === 'korean' ? 'linear-gradient(to right, #ec4899, #f472b6, #fb7185)' : 
                     key === 'english' ? 'linear-gradient(to right, #8b5cf6, #a78bfa, #c084fc)' : 
                     'linear-gradient(to right, #f97316, #fb923c, #fbbf24)') :
                    (key === 'korean' ? 'linear-gradient(to bottom, #fce7f3, #fbcfe8, #f9a8d4, #ec4899, #be185d)' :
                     key === 'english' ? 'linear-gradient(to bottom, #ede9fe, #ddd6fe, #c4b5fd, #8b5cf6, #7c3aed)' :
                     'linear-gradient(to bottom, #fed7aa, #fdba74, #fb923c, #f97316, #ea580c)')
                }}></div>
                <span className="text-gray-700 font-medium">{subjectDetails[key]?.name}</span>
              </div>
              {comparisonMode !== 'mine' && (
                <div className="flex items-center space-x-1 ml-2">
                  <div className="w-3 h-3 rounded shadow-sm opacity-70 border border-white" style={{ 
                    background: key === 'korean' ? 'linear-gradient(to bottom, #fbcfe8, #f9a8d4, #ec4899)' :
                               key === 'english' ? 'linear-gradient(to bottom, #ddd6fe, #c4b5fd, #8b5cf6)' :
                               'linear-gradient(to bottom, #fdba74, #fb923c, #f97316)'
                  }}></div>
                  <span className="text-gray-500 text-xs">
                    {comparisonMode === 'member' ? '🌸 회원평균' : '🌻 전국평균'}
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* 선택 초기화 버튼 */}
        {comparisonMode === 'mine' && selectedExams.size > 0 && (
          <div className="text-center mt-4">
            <button
              onClick={() => setSelectedExams(new Set())}
              className="text-sm px-4 py-2 bg-gradient-to-r from-pink-100 to-orange-100 hover:from-pink-200 hover:to-orange-200 rounded-lg transition-all duration-300 backdrop-blur-sm border border-pink-300 text-pink-600"
            >
              🌺 선택 초기화 (최근 5회 보기)
            </button>
          </div>
        )}
        
        {/* 🆕 평균 비교 모드 안내 */}
        {comparisonMode !== 'mine' && (
          <div className="text-center mt-4">
            <div className="text-xs text-pink-600 bg-pink-50 rounded-lg px-3 py-2 backdrop-blur-sm border border-pink-200">
              💡 {comparisonMode === 'member' ? '🌸 회원평균' : '🌻전국평균'} 비교 모드에서는 개별 회차만 선택할 수 있습니다
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-pink-100 via-orange-100 to-yellow-100 relative overflow-hidden ${blessingEffect ? 'animate-pulse' : ''}`}>
      {/* 파라다이스 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 파라다이스 날개 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-20">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,0 Q50,30 100,0 L100,20 Q50,50 0,20 Z" fill="url(#paradiseGradient)" />
            <defs>
              <linearGradient id="paradiseGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ec4899" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#f97316" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 빛 효과 */}
        {lightShine && (
          <div className="absolute top-0 left-1/4 w-2 h-32 bg-gradient-to-b from-pink-400 to-transparent animate-ping opacity-70"></div>
        )}
        
        {/* 꽃잎 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-pink-200/30 to-transparent"></div>
        
        {/* 떠다니는 꽃잎들 */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-2 h-2 bg-pink-400 rounded-full animate-pulse opacity-60"></div>
          <div className="absolute top-40 right-20 w-1 h-1 bg-orange-400 rounded-full animate-pulse delay-700 opacity-50"></div>
          <div className="absolute bottom-32 left-20 w-1 h-1 bg-yellow-400 rounded-full animate-pulse delay-1000 opacity-40"></div>
          <div className="absolute top-1/2 right-16 w-1 h-1 bg-pink-500 rounded-full animate-pulse delay-500 opacity-60"></div>
          <div className="absolute top-1/3 left-32 w-1 h-1 bg-orange-500 rounded-full animate-pulse delay-300 opacity-50"></div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-pink-200/80 to-orange-200/80 shadow-2xl border-b border-pink-300 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToHome}
                className="text-pink-600 hover:text-pink-500 mr-4 transition-all duration-300 transform hover:scale-110"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-bold bg-gradient-to-r from-pink-600 to-orange-500 bg-clip-text text-transparent ${blessingEffect ? 'animate-bounce' : ''}`}>
                📊 학습 분석 - Paradise Learning Analytics
              </h1>
            </div>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-6xl mx-auto space-y-8">
          
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-6 border-2 border-pink-300">
            <div className="flex flex-wrap gap-4">
              {['최근 6개월', '최근 1년'].map(period => 
                <button 
                  key={period} 
                  onClick={() => setSelectedPeriod(period)} 
                  className={`px-6 py-3 rounded-2xl font-medium transition-all duration-300 transform hover:scale-105 ${
                    selectedPeriod === period 
                      ? 'bg-gradient-to-r from-pink-500 to-orange-400 text-white shadow-lg shadow-pink-500/50 border border-pink-400' 
                      : 'bg-white/80 text-pink-500 hover:bg-pink-50 border border-pink-300'
                  }`}
                >
                  🌺 {period}
                </button>
              )}
            </div>
          </div>
          
          <div className="relative bg-gradient-to-br from-pink-100/80 via-orange-100/80 to-yellow-100/80 backdrop-blur-sm rounded-3xl shadow-2xl p-8 border-2 border-pink-300 overflow-hidden">
            {/* 🌟 움직이는 파라다이스 오로라 효과 */}
            <div className="absolute inset-0 opacity-20 pointer-events-none">
              <div className="absolute -top-10 -left-20 w-40 h-40 bg-gradient-to-r from-pink-400/60 via-orange-400/40 to-yellow-400/40 rounded-full blur-3xl animate-paradise-aurora-1"></div>
              <div className="absolute top-20 -right-20 w-60 h-60 bg-gradient-to-r from-purple-400/40 via-pink-400/40 to-orange-400/60 rounded-full blur-3xl animate-paradise-aurora-2"></div>
              <div className="absolute bottom-10 left-1/3 w-50 h-50 bg-gradient-to-r from-orange-400/60 via-yellow-400/60 to-pink-400/40 rounded-full blur-3xl animate-paradise-aurora-3"></div>
            </div>
            
            <div className="relative z-10">
              <h3 className="text-2xl font-bold bg-gradient-to-r from-pink-600 via-purple-500 to-orange-500 bg-clip-text text-transparent drop-shadow-sm mb-6 text-center lg:text-left">
                ✨ 성적 변화 추이 & 과목별 비교 - The Evolution of Paradise
              </h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                {renderLineChart()}
                {renderStackedBarChart()}
              </div>
            </div>

            {/* 🌟 파라다이스 CSS 애니메이션 정의 */}
            <style jsx>{`
              @keyframes paradise-aurora-1 { 
                0% { transform: translateX(-100px) translateY(0px) rotate(0deg); } 
                33% { transform: translateX(100px) translateY(-50px) rotate(120deg); } 
                66% { transform: translateX(50px) translateY(20px) rotate(240deg); } 
                100% { transform: translateX(-100px) translateY(0px) rotate(360deg); } 
              }
              .animate-paradise-aurora-1 { animation: paradise-aurora-1 20s ease-in-out infinite; }
              
              @keyframes paradise-aurora-2 { 
                0% { transform: translateX(100px) translateY(0px) rotate(0deg); } 
                33% { transform: translateX(-50px) translateY(30px) rotate(-120deg); } 
                66% { transform: translateX(-100px) translateY(-40px) rotate(-240deg); } 
                100% { transform: translateX(100px) translateY(0px) rotate(-360deg); } 
              }
              .animate-paradise-aurora-2 { animation: paradise-aurora-2 25s ease-in-out infinite reverse; }
              
              @keyframes paradise-aurora-3 { 
                0% { transform: translateX(-50px) translateY(0px) rotate(0deg); } 
                50% { transform: translateX(100px) translateY(-30px) rotate(180deg); } 
                100% { transform: translateX(-50px) translateY(0px) rotate(360deg); } 
              }
              .animate-paradise-aurora-3 { animation: paradise-aurora-3 18s ease-in-out infinite; }

              .animate-bar-grow { animation: bar-grow 0.6s ease-out forwards; }
              @keyframes bar-grow { from { transform: scaleX(0); } to { transform: scaleX(1); } }
              
              .animate-bar-grow-vertical { animation: bar-grow-vertical 0.8s ease-out forwards; }
              @keyframes bar-grow-vertical { from { transform: scaleY(0); } to { transform: scaleY(1); } }

              .animate-text-fade { animation: text-fade 0.5s ease-out forwards; opacity: 0; }
              @keyframes text-fade { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

              @keyframes paradise-sparkle-glow {
                0%, 100% { filter: drop-shadow(0 0 8px rgba(236, 72, 153, 0.8)) brightness(1.1); }
                50% { filter: drop-shadow(0 0 20px rgba(236, 72, 153, 1.2)) brightness(1.4) contrast(1.2); }
              }
            `}</style>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-6 text-center border-2 border-green-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-green-100/20 to-transparent"></div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-green-600 mb-1 relative z-10">+{analysisData.totalImprovement}점</div>
              <div className="text-sm text-gray-600 relative z-10">총 향상도</div>
              <div className="absolute top-2 right-2 text-green-500 opacity-50 animate-pulse">📈</div>
            </div>
            
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-6 text-center border-2 border-pink-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-pink-100/20 to-transparent"></div>
              <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-pink-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-pink-600 mb-1 relative z-10">{analysisData.bestSubject}</div>
              <div className="text-sm text-gray-600 relative z-10">최우수 과목</div>
              <div className="absolute top-2 right-2 text-pink-500 opacity-50 animate-pulse">👑</div>
            </div>
            
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-6 text-center border-2 border-orange-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-orange-100/20 to-transparent"></div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.864-.833-2.5 0L5.268 16.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-orange-600 mb-1 relative z-10">{analysisData.weakestSubject}</div>
              <div className="text-sm text-gray-600 relative z-10">집중 필요 과목</div>
              <div className="absolute top-2 right-2 text-orange-500 opacity-50 animate-pulse">⚠️</div>
            </div>
            
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-6 text-center border-2 border-purple-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-100/20 to-transparent"></div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v10a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-purple-600 mb-1 relative z-10">{analysisData.consistencyScore}%</div>
              <div className="text-sm text-gray-600 relative z-10">일관성 지수</div>
              <div className="absolute top-2 right-2 text-purple-500 opacity-50 animate-pulse">📊</div>
            </div>
          </div>

          {/* 📊 과목별 피드백 - 파라다이스 스타일 */}
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-8 border-2 border-pink-300">
            <h3 className="text-2xl font-bold text-pink-600 mb-8 flex items-center">
              📊 과목별 피드백 - Subject Analysis from Paradise
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Object.keys(subjectAnalysisData).map((subject) => {
                const subjectName = subject === 'korean' ? '🌺 국어' : subject === 'english' ? '🌸 영어' : '🌻 수학';
                const subjectIcon = subject === 'korean' ? '📘' : subject === 'english' ? '📗' : '📕';
                const isSelected = visibleSubjects[subject];
                const data = subjectAnalysisData[subject];
                
                // 선택된 과목만 표시
                if (!isSelected) return null;
                
                return (
                  <div key={subject} className={`rounded-2xl p-6 border-2 transition-all duration-300 relative overflow-hidden ${
                    subject === 'korean' ? 'bg-pink-50/80 border-pink-300' :
                    subject === 'english' ? 'bg-purple-50/80 border-purple-300' :
                    'bg-orange-50/80 border-orange-300'
                  }`}>
                    <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent"></div>
                    <div className="text-center mb-6 relative z-10">
                      <div className="text-3xl mb-2 animate-pulse">{subjectIcon}</div>
                      <h4 className="text-xl font-bold text-gray-700">{subjectName}</h4>
                    </div>
                    
                    {/* 강점 */}
                    <div className="mb-6 relative z-10">
                      <div className="flex items-center mb-3">
                        <span className="text-lg text-green-500">✓</span>
                        <span className="ml-2 font-semibold text-green-600">파라다이스 강점</span>
                      </div>
                      <div className="space-y-2">
                        {data.strengths.map((strength, index) => (
                          <div key={index} className="text-sm text-gray-600 pl-6">
                            🌺 {strength}
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    {/* 개선점 */}
                    <div className="relative z-10">
                      <div className="flex items-center mb-3">
                        <span className="text-lg text-orange-500">△</span>
                        <span className="ml-2 font-semibold text-orange-600">발전의 여지</span>
                      </div>
                      <div className="space-y-2">
                        {data.improvements.map((improvement, index) => (
                          <div key={index} className="text-sm text-gray-600 pl-6">
                            🌻 {improvement}
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    {/* 파라다이스 장식 */}
                    <div className="absolute top-2 right-2 text-pink-400 opacity-50 animate-pulse">
                      {subject === 'korean' ? '🌺' : subject === 'english' ? '🌸' : '🌻'}
                    </div>
                  </div>
                );
              })}
            </div>
            
            {/* 선택된 과목이 없을 때 안내 메시지 */}
            {!Object.values(visibleSubjects).some(Boolean) && (
              <div className="text-center py-12 text-gray-500">
                <div className="text-4xl mb-4">🌺</div>
                <p className="text-lg text-gray-600">차트 상단의 과목 버튼을 클릭하여 파라다이스 피드백을 확인하세요!</p>
              </div>
            )}
          </div>

          {/* AI 맞춤 학습 추천 - 파라다이스 스타일 */}
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-8 border-2 border-purple-300">
            <h3 className="text-xl font-bold text-purple-600 mb-6">🤖 AI 맞춤 학습 추천 - Paradise Learning Recommendations</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {analysisData.recommendations.map((rec, index) => (
                <div key={index} className="bg-gradient-to-br from-pink-50/80 to-purple-50/80 rounded-2xl p-6 border-2 border-pink-300 relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-pink-100/10 to-purple-100/10"></div>
                  <h4 className="font-bold text-pink-600 mb-3 relative z-10">{rec.title}</h4>
                  <p className="text-gray-600 text-sm mb-4 relative z-10">{rec.description}</p>
                  
                  <div className="space-y-2 mb-4 relative z-10">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">🕰️ 예상 기간:</span>
                      <span className="font-medium text-gray-700">{rec.duration}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">📈 예상 향상:</span>
                      <span className="font-bold text-green-500">{rec.expectedImprovement}</span>
                    </div>
                  </div>
                  
                  <button className="w-full bg-gradient-to-r from-pink-500 to-purple-500 text-white py-3 rounded-xl font-medium hover:from-pink-400 hover:to-purple-400 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-pink-500/50 relative z-10">
                    🌺 파라다이스 여행 시작하기
                  </button>
                  
                  {/* 파라다이스 장식 */}
                  <div className="absolute top-2 right-2 text-pink-400 opacity-50 animate-pulse">
                    {index === 0 ? '🌺' : index === 1 ? '🌸' : '🌻'}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 학습 목표 설정 - 파라다이스 버전 */}
          <div className="bg-gradient-to-r from-pink-400 to-orange-400 rounded-3xl shadow-2xl p-8 text-white border-2 border-pink-300 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-pink-500/30 to-orange-500/30"></div>
            <div className="flex items-center justify-between relative z-10">
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-2 text-white">🎯 다음 목표 - The Next Paradise</h3>
                <p className="text-pink-100 mb-4">
                  현재의 파라다이스 학습으로 <span className="font-bold text-white">3개월 후 95점</span> 달성 가능합니다!
                </p>
                <div className="flex space-x-4">
                  <button className="bg-white/20 backdrop-blur-sm text-white px-6 py-3 rounded-xl font-bold hover:bg-white/30 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-white/20 border border-white/30">
                    🌺 다음 시험지 풀기
                  </button>
                  <button className="bg-orange-500/40 text-white border-2 border-white/50 px-6 py-3 rounded-xl font-bold hover:bg-orange-500/60 transition-all duration-300 transform hover:scale-105">
                    🌸 오답 복습하기
                  </button>
                </div>
              </div>
              <div className="ml-8 text-6xl animate-pulse">
                🌺
              </div>
            </div>
            
            {/* 파라다이스 장식 */}
            <div className="absolute top-4 right-20 text-orange-300 opacity-50 animate-pulse">🌻</div>
            <div className="absolute bottom-4 left-8 text-pink-300 opacity-50 animate-pulse">🌸</div>
          </div>
        </div>
      </div>
    </div>
  );
}