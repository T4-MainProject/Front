// ============================================
// ✨ Angelic Light ExamUpload.jsx - 천사 시험지 업로드 페이지
// ============================================
// 📝 주요 기능:
// - 축복받은 라디오버튼 방식의 과목/학년 선택
// - JPG/PNG 형식만 지원하는 빛의 드래그 앤 드롭 파일 업로드
// - 실시간 축복 업로드 진행률 표시
// - 천국 폼 데이터 유효성 검사
// - 빛의 데이터베이스 스키마(blessed_uploads)와 매핑되는 필드 구조
// ============================================

import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';

export default function ExamUpload() {
  // 🧭 빛의 네비게이션 훅
  const navigate = useNavigate();

  // 🏠 천국으로 돌아가기 함수
  const handleBackToHome = () => {
    navigate('/');
  };
  
  // 📋 천사의 폼 데이터 상태 관리 (DB blessed_uploads 테이블과 매핑)
  const [formData, setFormData] = useState({
    uploadTitle: '',    // upload_title: 천사가 입력한 희망 제목
    subject: '',        // subject: 축복받은 과목 (ENUM으로 제한)
    examType: '',       // exam_type: 평가 유형
    examDate: '',       // exam_date: 평가 날짜
    schoolName: '',     // school_name: 천국 학교명
    grade: ''           // grade: 축복받은 학년 (추가 필드)
  });
  
  // 📎 파일 업로드 관련 상태
  const [selectedFiles, setSelectedFiles] = useState([]);        // 선택된 천사 파일들 배열로 변경
  const [dragActive, setDragActive] = useState(false);           // 빛의 드래그 상태 표시
  const [uploadProgress, setUploadProgress] = useState(0);       // 축복 업로드 진행률 (0-100)
  const [isUploading, setIsUploading] = useState(false);         // 축복 업로드 중 상태
  const fileInputRef = useRef(null);                             // 숨겨진 파일 input 참조

  // 📎 추가 파일 업로드 관련 상태 (선택사항)
  const [answerSheetFile, setAnswerSheetFile] = useState(null);     // 천사 답안지 파일
  const [listeningScriptFile, setListeningScriptFile] = useState(null); // 영어 축복 대본 파일
  const [answerSheetDragActive, setAnswerSheetDragActive] = useState(false);
  const [listeningScriptDragActive, setListeningScriptDragActive] = useState(false);
  const answerSheetInputRef = useRef(null);
  const listeningScriptInputRef = useRef(null);

  // 📚 축복받은 과목 옵션들 (DB 스키마의 ENUM과 일치)
  // 🔧 수정사항: 수학 과목 제거 (기존 7개 → 6개)
  const subjectOptions = [
    { value: 'korean', label: '✨ 희망의 국어', icon: '📚' },
    { value: 'english', label: '🌟 빛의 영어', icon: '🗣️' },
    { value: 'math', label: '💫 천사의 수학', icon: '🧮' },
    { value: 'science', label: '🪽 축복의 과학', icon: '🔬' },
    { value: 'social', label: '👼 사회의 사랑', icon: '🌍' },
    { value: 'history', label: '✨ 역사의 진실', icon: '📜' }
  ];

  // 🎓 축복받은 학년 옵션들 
  const gradeOptions = [
    { value: 'middle1', label: '중학교 1학년 👼', icon: '🌱' },
    { value: 'middle2', label: '중학교 2학년 ✨', icon: '🌿' },
    { value: 'middle3', label: '중학교 3학년 🌟', icon: '🌳' },
    { value: 'high1', label: '고등학교 1학년 💫', icon: '🌺' },
    { value: 'high2', label: '고등학교 2학년 🪽', icon: '🌸' },
    { value: 'high3', label: '고등학교 3학년 🎯', icon: '🌹' }
  ];

  // 📝 평가 유형 옵션들
  const examTypeOptions = [
    { value: 'mock', label: '✨ 희망 모의고사', icon: '📝' },
    { value: 'midterm', label: '🌟 중간 평가', icon: '📊' },
    { value: 'final', label: '💫 기말 평가', icon: '🎯' },
    { value: 'quiz', label: '👼 일반 평가', icon: '📋' },
    { value: 'practice', label: '🪽 연습 문제', icon: '✏️' }
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileSelect = (files) => {
    const validFiles = Array.from(files).filter(file => {
      const isValidType = file.type.startsWith('image/') || file.type === 'application/pdf';
      const isValidSize = file.size <= 10 * 1024 * 1024; // 10MB 제한
      
      if (!isValidType) {
        alert(`❌ ${file.name}은(는) 지원하지 않는 파일 형식입니다. JPG, PNG, PDF 파일만 업로드할 수 있습니다.`);
        return false;
      }
      
      if (!isValidSize) {
        alert(`❌ ${file.name}은(는) 파일 크기가 너무 큽니다. 10MB 이하의 파일만 업로드할 수 있습니다.`);
        return false;
      }
      
      return true;
    });

    if (validFiles.length > 0) {
      setSelectedFiles(prev => {
        const newFiles = [...prev, ...validFiles];
        if (newFiles.length > 10) {
          alert('✨ 최대 10개 파일까지만 업로드할 수 있습니다.');
          return prev;
        }
        return newFiles;
      });
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleFileSelect(files);
  };

  const handleFileInputChange = (e) => {
    const files = Array.from(e.target.files);
    handleFileSelect(files);
  };

  const handleAnswerSheetSelect = (files) => {
    const validFiles = Array.from(files).filter(file => {
      const isValidType = file.type.startsWith('image/') || file.type === 'application/pdf';
      const isValidSize = file.size <= 10 * 1024 * 1024; // 10MB 제한
      
      if (!isValidType) {
        alert(`❌ ${file.name}은(는) 지원하지 않는 파일 형식입니다. JPG, PNG, PDF 파일만 업로드할 수 있습니다.`);
        return false;
      }
      
      if (!isValidSize) {
        alert(`❌ ${file.name}은(는) 파일 크기가 너무 큽니다. 10MB 이하의 파일만 업로드할 수 있습니다.`);
        return false;
      }
      
      return true;
    });

    if (validFiles.length > 0) {
      setAnswerSheetFile(validFiles[0]); // 하나의 파일만 허용
    }
  };

  const handleAnswerSheetDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setAnswerSheetDragActive(true);
    } else if (e.type === 'dragleave') {
      setAnswerSheetDragActive(false);
    }
  };

  const handleAnswerSheetDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setAnswerSheetDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleAnswerSheetSelect(files);
  };

  const handleAnswerSheetInputChange = (e) => {
    const files = Array.from(e.target.files);
    handleAnswerSheetSelect(files);
  };

  const handleListeningScriptSelect = (files) => {
    const validFiles = Array.from(files).filter(file => {
      const isValidType = file.type.startsWith('image/') || file.type === 'application/pdf';
      const isValidSize = file.size <= 10 * 1024 * 1024; // 10MB 제한
      
      if (!isValidType) {
        alert(`❌ ${file.name}은(는) 지원하지 않는 파일 형식입니다. JPG, PNG, PDF 파일만 업로드할 수 있습니다.`);
        return false;
      }
      
      if (!isValidSize) {
        alert(`❌ ${file.name}은(는) 파일 크기가 너무 큽니다. 10MB 이하의 파일만 업로드할 수 있습니다.`);
        return false;
      }
      
      return true;
    });

    if (validFiles.length > 0) {
      setListeningScriptFile(validFiles[0]); // 하나의 파일만 허용
    }
  };

  const handleListeningScriptDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setListeningScriptDragActive(true);
    } else if (e.type === 'dragleave') {
      setListeningScriptDragActive(false);
    }
  };

  const handleListeningScriptDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setListeningScriptDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleListeningScriptSelect(files);
  };

  const handleListeningScriptInputChange = (e) => {
    const files = Array.from(e.target.files);
    handleListeningScriptSelect(files);
  };

  const convertFileToBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = error => reject(error);
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // 기본 유효성 검사
    if (!formData.uploadTitle.trim()) {
      alert('⚠️ 업로드 제목을 입력해주세요.');
      return;
    }
    
    if (!formData.subject) {
      alert('⚠️ 과목을 선택해주세요.');
      return;
    }
    
    if (!formData.grade) {
      alert('⚠️ 학년을 선택해주세요.');
      return;
    }
    
    if (selectedFiles.length === 0) {
      alert('⚠️ 시험지 파일을 최소 1개 이상 업로드해주세요.');
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      // 파일들을 Base64로 변환
      const convertedFiles = [];
      
      for (let i = 0; i < selectedFiles.length; i++) {
        const file = selectedFiles[i];
        setUploadProgress(Math.round(((i + 0.5) / selectedFiles.length) * 80)); // 80%까지는 파일 변환
        
        const base64 = await convertFileToBase64(file);
        convertedFiles.push({
          name: file.name,
          size: file.size,
          type: file.type,
          url: base64
        });
      }

      // 추가 파일들도 변환
      let convertedAnswerSheet = null;
      let convertedListeningScript = null;

      if (answerSheetFile) {
        convertedAnswerSheet = {
          name: answerSheetFile.name,
          size: answerSheetFile.size,
          type: answerSheetFile.type,
          url: await convertFileToBase64(answerSheetFile)
        };
      }

      if (listeningScriptFile) {
        convertedListeningScript = {
          name: listeningScriptFile.name,
          size: listeningScriptFile.size,
          type: listeningScriptFile.type,
          url: await convertFileToBase64(listeningScriptFile)
        };
      }

      setUploadProgress(90);

      // 업로드 데이터 준비
      const uploadData = {
        ...formData,
        examImage: convertedFiles,
        answerSheet: convertedAnswerSheet,
        listeningScript: convertedListeningScript,
        uploadDate: new Date().toISOString(),
        status: 'uploaded'
      };

      // 시뮬레이션된 서버 업로드 (2초 지연)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setUploadProgress(100);
      
      // 성공 후 GradingProgress 페이지로 이동
      setTimeout(() => {
        navigate('/grading-progress', { 
          state: { uploadData }
        });
      }, 1000);

    } catch (error) {
      console.error('파일 업로드 오류:', error);
      alert('❌ 파일 업로드 중 오류가 발생했습니다. 다시 시도해주세요.');
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const removeFile = (indexToRemove) => {
    setSelectedFiles(prev => prev.filter((_, index) => index !== indexToRemove));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-sky-50 to-blue-100 relative overflow-hidden">
      {/* 천사 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 천사 날개 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,0 Q50,30 100,0 L100,20 Q50,50 0,20 Z" fill="url(#angelGradient)" />
            <defs>
              <linearGradient id="angelGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#60a5fa" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 빛 효과 */}
        <div className="absolute top-0 left-1/4 w-2 h-32 bg-gradient-to-b from-blue-400 to-transparent animate-ping opacity-70"></div>
        
        {/* 구름 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-white/30 to-transparent"></div>
      </div>

      {/* 헤더 */}
      <div className="bg-white bg-opacity-90 shadow-2xl border-b border-blue-200 backdrop-blur-sm relative z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToHome}
                className="text-blue-600 hover:text-blue-500 mr-4 transition-all duration-300 transform hover:scale-110"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent">
                ✨ 천사 시험지 업로드 - Angel Upload
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-8">
            
            {/* 기본 정보 입력 */}
            <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-blue-200">
              <h2 className="text-xl font-bold text-blue-600 mb-6 flex items-center">
                <span className="text-2xl mr-3">✨</span>
                기본 정보 입력
              </h2>
              
              <div className="space-y-6">
                {/* 업로드 제목 */}
                <div>
                  <label className="block text-blue-600 font-medium mb-2">
                    📝 업로드 제목 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="uploadTitle"
                    value={formData.uploadTitle}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-blue-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-blue-50/30"
                    placeholder="예: 2024년 3월 희망 모의고사"
                    required
                  />
                </div>

                {/* 과목 선택 */}
                <div>
                  <label className="block text-blue-600 font-medium mb-4">
                    📚 과목 선택 <span className="text-red-500">*</span>
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {subjectOptions.map((option) => (
                      <label
                        key={option.value}
                        className={`cursor-pointer p-4 rounded-xl border-2 transition-all duration-300 hover:scale-105 ${
                          formData.subject === option.value
                            ? 'border-blue-500 bg-blue-100 text-blue-600 shadow-lg shadow-blue-500/50'
                            : 'border-blue-200 bg-white hover:border-blue-300 hover:bg-blue-50'
                        }`}
                      >
                        <input
                          type="radio"
                          name="subject"
                          value={option.value}
                          checked={formData.subject === option.value}
                          onChange={handleInputChange}
                          className="sr-only"
                        />
                        <div className="text-center">
                          <div className="text-2xl mb-2">{option.icon}</div>
                          <div className="font-medium text-sm">{option.label}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {/* 학년 선택 */}
                <div>
                  <label className="block text-blue-600 font-medium mb-4">
                    🎓 학년 선택 <span className="text-red-500">*</span>
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {gradeOptions.map((option) => (
                      <label
                        key={option.value}
                        className={`cursor-pointer p-4 rounded-xl border-2 transition-all duration-300 hover:scale-105 ${
                          formData.grade === option.value
                            ? 'border-blue-500 bg-blue-100 text-blue-600 shadow-lg shadow-blue-500/50'
                            : 'border-blue-200 bg-white hover:border-blue-300 hover:bg-blue-50'
                        }`}
                      >
                        <input
                          type="radio"
                          name="grade"
                          value={option.value}
                          checked={formData.grade === option.value}
                          onChange={handleInputChange}
                          className="sr-only"
                        />
                        <div className="text-center">
                          <div className="text-2xl mb-2">{option.icon}</div>
                          <div className="font-medium text-sm">{option.label}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {/* 시험 유형 */}
                <div>
                  <label className="block text-blue-600 font-medium mb-4">
                    📊 시험 유형
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {examTypeOptions.map((option) => (
                      <label
                        key={option.value}
                        className={`cursor-pointer p-4 rounded-xl border-2 transition-all duration-300 hover:scale-105 ${
                          formData.examType === option.value
                            ? 'border-blue-500 bg-blue-100 text-blue-600 shadow-lg shadow-blue-500/50'
                            : 'border-blue-200 bg-white hover:border-blue-300 hover:bg-blue-50'
                        }`}
                      >
                        <input
                          type="radio"
                          name="examType"
                          value={option.value}
                          checked={formData.examType === option.value}
                          onChange={handleInputChange}
                          className="sr-only"
                        />
                        <div className="text-center">
                          <div className="text-2xl mb-2">{option.icon}</div>
                          <div className="font-medium text-sm">{option.label}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {/* 추가 정보 */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-blue-600 font-medium mb-2">
                      📅 시험 날짜
                    </label>
                    <input
                      type="date"
                      name="examDate"
                      value={formData.examDate}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-blue-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-blue-50/30"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-blue-600 font-medium mb-2">
                      🏫 학교명
                    </label>
                    <input
                      type="text"
                      name="schoolName"
                      value={formData.schoolName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-blue-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-blue-50/30"
                      placeholder="희망고등학교"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 파일 업로드 영역 */}
            <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-blue-200">
              <h2 className="text-xl font-bold text-blue-600 mb-6 flex items-center">
                <span className="text-2xl mr-3">📄</span>
                시험지 파일 업로드 <span className="text-red-500 ml-2">*</span>
              </h2>
              
              {/* 드래그 앤 드롭 영역 */}
              <div
                className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all duration-300 ${
                  dragActive
                    ? 'border-blue-500 bg-blue-100/50'
                    : 'border-blue-300 bg-blue-50/30 hover:border-blue-400 hover:bg-blue-100/40'
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileInputChange}
                  multiple
                  accept="image/*,application/pdf"
                  className="hidden"
                />
                
                <div className="space-y-4">
                  <div className="text-6xl text-blue-400">📁</div>
                  <div>
                    <p className="text-lg font-semibold text-blue-600 mb-2">
                      파일을 여기로 드래그하거나 클릭하여 업로드
                    </p>
                    <p className="text-sm text-blue-500">
                      JPG, PNG, PDF 파일 (최대 10MB, 최대 10개 파일)
                    </p>
                  </div>
                  
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-gradient-to-r from-blue-500 to-sky-400 text-white px-6 py-3 rounded-xl hover:from-blue-400 hover:to-sky-300 transition-all duration-300 font-medium transform hover:scale-105 shadow-lg hover:shadow-blue-500/50"
                  >
                    📂 파일 선택
                  </button>
                </div>
              </div>

              {/* 선택된 파일 목록 */}
              {selectedFiles.length > 0 && (
                <div className="mt-6">
                  <h3 className="text-lg font-semibold text-blue-600 mb-4">선택된 파일들:</h3>
                  <div className="space-y-2">
                    {selectedFiles.map((file, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-blue-100/50 rounded-xl border border-blue-200">
                        <div className="flex items-center space-x-3">
                          <span className="text-2xl">
                            {file.type.startsWith('image/') ? '🖼️' : '📄'}
                          </span>
                          <div>
                            <div className="font-medium text-blue-600">{file.name}</div>
                            <div className="text-sm text-blue-500">
                              {(file.size / 1024 / 1024).toFixed(2)} MB
                            </div>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeFile(index)}
                          className="text-red-500 hover:text-red-400 transition-colors duration-200 p-2 hover:bg-red-100 rounded-lg"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* 업로드 진행률 */}
            {isUploading && (
              <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-blue-200">
                <h3 className="text-lg font-semibold text-blue-600 mb-4">✨ 업로드 진행 중...</h3>
                <div className="w-full bg-blue-200 rounded-full h-4 overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-sky-400 h-4 rounded-full transition-all duration-500 animate-pulse"
                    style={{ width: `${uploadProgress}%` }}
                  ></div>
                </div>
                <p className="text-center text-blue-600 mt-2 font-medium">{uploadProgress}%</p>
              </div>
            )}

            {/* 제출 버튼 */}
            <div className="text-center">
              <button
                type="submit"
                disabled={isUploading}
                className={`px-8 py-4 rounded-xl font-semibold text-white transition-all duration-300 transform hover:scale-105 ${
                  isUploading
                    ? 'bg-blue-300 cursor-not-allowed'
                    : 'bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 hover:to-sky-400 shadow-lg hover:shadow-blue-500/50'
                }`}
              >
                {isUploading ? '✨ 업로드 중...' : '👼 천사 채점 시작하기'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}