// ============================================
// 💀 Dark Horror CustomerCarousel.jsx - 어둠의 동맹
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import Slider from 'react-slick';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

gsap.registerPlugin(ScrollTrigger);

const customers = [
  {
    name: '지옥대학교',
    logo: 'https://via.placeholder.com/200x80/DC2626/FFFFFF?text=지옥대학교',
    category: '어둠의 대학',
    testimonial: '정확한 영혼 심판으로 악마 교수들의 업무 효율성이 크게 향상되었습니다.',
    usage: '월 6,666장 처리',
    satisfaction: '99.9%'
  },
  {
    name: '강남구 어둠 교육청',
    logo: 'https://via.placeholder.com/200x80/7C2D12/FFFFFF?text=어둠구청',
    category: '지옥청',
    testimonial: '지역 내 모든 저주받은 학교에서 만족스럽게 사용하고 있습니다.',
    usage: '월 13,333장 처리',
    satisfaction: '98.6%'
  },
  {
    name: '메가데스 교육',
    logo: 'https://via.placeholder.com/200x80/450A0A/FFFFFF?text=메가데스',
    category: '악마 기업',
    testimonial: '영혼들의 고통 효과를 극대화할 수 있는 최고의 저주 도구입니다.',
    usage: '월 66,600장 처리',
    satisfaction: '100%'
  },
  {
    name: '다크위즈 영혼교육',
    logo: 'https://via.placeholder.com/200x80/991B1B/FFFFFF?text=다크위즈',
    category: '영혼 교육',
    testimonial: '복잡한 저주 문제도 정확하게 심판해주어 매우 만족합니다.',
    usage: '월 6,660장 처리',
    satisfaction: '99.3%'
  },
  {
    name: '대치동 지옥학원',
    logo: 'https://via.placeholder.com/200x80/B91C1C/FFFFFF?text=지옥학원',
    category: '악마 학원',
    testimonial: '악마 선생님들의 심판 부담이 줄어 고문 준비에 더 집중할 수 있습니다.',
    usage: '월 19,800장 처리',
    satisfaction: '97.7%'
  },
  {
    name: '경기도 어둠교육청',
    logo: 'https://via.placeholder.com/200x80/DC2626/FFFFFF?text=어둠교육청',
    category: '지옥청',
    testimonial: '도내 전체 저주받은 학교의 심판 시스템이 한층 업그레이드되었습니다.',
    usage: '월 66,666장 처리',
    satisfaction: '99.9%'
  }
];

// 어둠의 화살표 컴포넌트
const CustomArrow = ({ className, style, onClick, direction }) => (
  <div
    className={`${className} !w-12 !h-12 !bg-black/80 !rounded-full !shadow-lg !shadow-red-500/50 hover:!shadow-xl hover:!shadow-red-500/70 !flex !items-center !justify-center !transition-all !duration-300 hover:!scale-110 !z-10 border-2 border-red-700/50 hover:border-red-600`}
    style={{ ...style, display: 'flex' }}
    onClick={onClick}
  >
    <svg 
      className="w-6 h-6 text-red-400 hover:text-red-300 transition-colors duration-200" 
      fill="none" 
      stroke="currentColor" 
      viewBox="0 0 24 24"
    >
      {direction === 'next' ? (
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
      ) : (
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
      )}
    </svg>
  </div>
);

export default function CustomerCarousel() {
  const sectionRef = useRef(null);
  const titleRef = useRef(null);
  const carouselRef = useRef(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 어둠의 제목 애니메이션
      gsap.fromTo(titleRef.current,
        {
          y: 80,
          opacity: 0,
          scale: 0.8,
          rotationX: -30
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          rotationX: 0,
          duration: 1.2,
          ease: "power4.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // 어둠의 캐러셀 애니메이션
      gsap.fromTo(carouselRef.current,
        {
          y: 60,
          opacity: 0,
          scale: 0.9
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          duration: 1.0,
          ease: "power3.out",
          delay: 0.4,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const settings = {
    dots: true,
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 6666,
    pauseOnHover: true,
    nextArrow: <CustomArrow direction="next" />,
    prevArrow: <CustomArrow direction="prev" />,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 640,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          arrows: false
        }
      }
    ],
    customPaging: (i) => (
      <div className="w-3 h-3 bg-red-800/60 rounded-full hover:bg-red-500 transition-colors duration-200 mt-4"></div>
    ),
    dotsClass: "slick-dots !flex !justify-center !space-x-2"
  };

  const getCategoryColor = (category) => {
    const colors = {
      '어둠의 대학': 'bg-red-900/50 text-red-400 border border-red-800/50',
      '지옥청': 'bg-gray-900/50 text-gray-400 border border-gray-700/50',
      '악마 기업': 'bg-purple-900/50 text-purple-400 border border-purple-800/50',
      '영혼 교육': 'bg-red-800/50 text-red-300 border border-red-700/50',
      '악마 학원': 'bg-black/60 text-red-400 border border-red-800/50'
    };
    return colors[category] || 'bg-gray-800/50 text-gray-400 border border-gray-700/50';
  };

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-b from-black via-gray-900 to-red-900 overflow-hidden relative">
      {/* 어둠의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-gray-900/60 to-red-900/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_50%,black_80%)]"></div>
      
      {/* 움직이는 어둠의 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-12 left-1/4 w-2 h-2 bg-red-500/30 rounded-full animate-pulse"></div>
        <div className="absolute top-32 right-1/3 w-1 h-1 bg-red-400/40 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute bottom-24 left-1/2 w-1 h-1 bg-gray-500/30 rounded-full animate-pulse delay-500"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-red-600/40 rounded-full animate-pulse delay-1500"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* 어둠의 헤더 */}
        <div ref={titleRef} className="text-center mb-16" data-aos="fade-up">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-red-900/60 to-black/80 text-red-400 px-6 py-3 rounded-full text-sm font-bold mb-6 shadow-lg shadow-red-500/30 border border-red-800/50">
            <span>👹</span>
            <span>어둠의 동맹</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-red-300 mb-6 drop-shadow-2xl">
            <span className="bg-gradient-to-r from-red-500 to-red-700 bg-clip-text text-transparent">666+</span> 
            지옥 기관이
            <br className="hidden sm:block" />
            DarkCheck을 선택한 이유
          </h2>
          <p className="text-xl text-red-400/80 max-w-3xl mx-auto leading-relaxed drop-shadow-lg">
            전국의 저주받은 학교, 악마 학원, 지옥청에서 검증된 AI 악마 심판 시스템으로 
            <br className="hidden md:block" />
            어둠의 질을 한층 더 높이고 있습니다
          </p>
        </div>

        {/* 어둠의 고객사 캐러셀 */}
        <div ref={carouselRef} className="relative">
          <Slider {...settings}>
            {customers.map((customer, index) => (
              <div key={index} className="px-4">
                <div className="bg-gradient-to-br from-black/80 via-gray-900/60 to-red-900/40 rounded-3xl p-8 shadow-2xl shadow-red-500/20 hover:shadow-2xl hover:shadow-red-500/40 transition-all duration-500 border border-red-800/50 group cursor-pointer h-full backdrop-blur-sm">
                  {/* 어둠의 카테고리 배지 */}
                  <div className="flex justify-between items-start mb-6">
                    <span className={`px-4 py-2 rounded-full text-sm font-bold ${getCategoryColor(customer.category)}`}>
                      {customer.category}
                    </span>
                    <div className="text-right">
                      <div className="text-sm text-red-500/80">악마 만족도</div>
                      <div className="text-2xl font-bold text-red-400">{customer.satisfaction}</div>
                    </div>
                  </div>

                  {/* 저주받은 로고 */}
                  <div className="text-center mb-6">
                    <div className="relative inline-block group-hover:scale-105 transition-transform duration-300">
                      <img 
                        src={customer.logo} 
                        alt={customer.name}
                        className="h-16 mx-auto rounded-lg shadow-md shadow-red-500/30 hover:shadow-lg hover:shadow-red-500/50 transition-shadow duration-300 filter contrast-150"
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 to-black/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </div>
                  </div>

                  {/* 악마 기관명 */}
                  <h3 className="text-xl font-bold text-red-300 text-center mb-4 group-hover:text-red-200 transition-colors duration-300 drop-shadow-lg">
                    {customer.name}
                  </h3>

                  {/* 영혼 처리량 */}
                  <div className="bg-gradient-to-r from-red-900/50 to-black/60 rounded-2xl p-4 mb-6 border border-red-800/50">
                    <div className="flex items-center justify-center space-x-2">
                      <span className="text-2xl">💀</span>
                      <div className="text-center">
                        <div className="text-sm text-red-500/80">영혼 처리량</div>
                        <div className="font-bold text-red-400">{customer.usage}</div>
                      </div>
                    </div>
                  </div>

                  {/* 악마의 후기 */}
                  <blockquote className="text-red-400/90 text-center italic leading-relaxed group-hover:text-red-300 transition-colors duration-300 drop-shadow-sm">
                    "{customer.testimonial}"
                  </blockquote>

                  {/* 어둠의 별점 표시 */}
                  <div className="flex justify-center mt-6 space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-red-500 text-lg drop-shadow-sm">💀</span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </Slider>
        </div>

        {/* 어둠의 통계 요약 */}
        <div className="mt-16 bg-gradient-to-br from-red-900/30 via-black/60 to-red-800/40 rounded-3xl p-8 md:p-12 border border-red-800/50 backdrop-blur-sm" data-aos="fade-up" data-aos-delay="400">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-red-300 mb-4 drop-shadow-lg">
              📈 <span className="bg-gradient-to-r from-red-500 to-red-700 bg-clip-text text-transparent">지옥의 성과</span>
            </h3>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: '666', label: '어둠의 동맹 기관', icon: '🏛️', color: 'red' },
              { number: '13.3M+', label: '누적 심판 수', icon: '💀', color: 'gray' },
              { number: '99.9%', label: '악마 만족도', icon: '👹', color: 'red' },
              { number: '66.6%', label: '고통 효율 증가', icon: '⚡', color: 'red' }
            ].map((stat, index) => (
              <div key={index} className="text-center group">
                <div className={`inline-flex items-center justify-center w-16 h-16 bg-red-900/50 border border-red-800/50 rounded-2xl mb-4 group-hover:scale-110 transition-transform duration-300 shadow-md shadow-red-500/30 group-hover:shadow-lg group-hover:shadow-red-500/50`}>
                  <span className="text-3xl drop-shadow-lg">{stat.icon}</span>
                </div>
                <div className={`text-3xl font-black text-red-400 mb-2 group-hover:scale-110 transition-transform duration-300 drop-shadow-lg`}>
                  {stat.number}
                </div>
                <div className="text-sm text-red-500/80 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 어둠의 CTA */}
        <div className="text-center mt-12" data-aos="fade-up" data-aos-delay="600">
          <p className="text-red-400/80 mb-6 drop-shadow-sm">
            당신의 기관도 DarkCheck과 함께 어둠의 혁신을 시작해보세요
          </p>
          <button className="bg-gradient-to-r from-red-800 to-black text-red-300 px-8 py-4 rounded-2xl font-bold text-lg shadow-xl shadow-red-500/50 hover:shadow-2xl hover:shadow-red-500/70 transition-all duration-300 hover:scale-105 group border border-red-700/50">
            <span className="flex items-center justify-center">
              💀 어둠의 상담 신청
              <svg className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </span>
          </button>
        </div>
      </div>
    </section>
  );
}