// ============================================
// 🌸 Spring Blossom Footer.jsx - 벚꽃 정원 푸터
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const footerSections = [
  {
    title: '벚꽃 정원 서비스',
    links: [
      { name: 'AI 자동 채점', href: '#' },
      { name: '대량 채점 처리', href: '#' },
      { name: '벚꽃 정원 API 서비스', href: '#' },
      { name: '교육기관 솔루션', href: '#' }
    ]
  },
  {
    title: '로즈 지원',
    links: [
      { name: '사용자 가이드', href: '#' },
      { name: '자주 묻는 질문', href: '#' },
      { name: '기술 지원', href: '#' },
      { name: '문의하기', href: '#' }
    ]
  },
  {
    title: '벚꽃 정원 회사',
    links: [
      { name: '회사 소개', href: '#' },
      { name: '채용 정보', href: '#' },
      { name: '보도자료', href: '#' },
      { name: '파트너십', href: '#' }
    ]
  }
];

const socialLinks = [
  { name: 'Blossom Twitter', icon: '🐦', href: '#', color: 'hover:bg-pink-500' },
  { name: 'Rose Book', icon: '📖', href: '#', color: 'hover:bg-rose-500' },
  { name: 'Blossom Gram', icon: '📸', href: '#', color: 'hover:bg-pink-400' },
  { name: 'Rose In', icon: '💼', href: '#', color: 'hover:bg-rose-600' },
  { name: 'Blossom Tube', icon: '📺', href: '#', color: 'hover:bg-pink-600' }
];

export default function Footer() {
  const footerRef = useRef(null);
  const sectionsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 벚꽃 정원 푸터 섹션들 애니메이션 (부드럽고 우아하게)
      gsap.fromTo(sectionsRef.current,
        {
          y: 80,
          opacity: 0,
          scale: 0.9,
          filter: "blur(5px)"
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          filter: "blur(0px)",
          duration: 1.0,
          stagger: 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: footerRef.current,
            start: "top 90%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, footerRef);

    return () => ctx.revert();
  }, []);

  return (
    <footer ref={footerRef} className="bg-gradient-to-br from-pink-100 via-rose-50 to-pink-100 text-pink-700 relative overflow-hidden">
      {/* 벚꽃 정원 배경 장식 */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-gradient-to-br from-pink-400/25 to-rose-500/15 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-gradient-to-br from-rose-400/20 to-pink-300/25 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-br from-rose-400/15 to-pink-300/20 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* 추가 벚꽃 정원 레이어 */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/40 via-pink-50/50 to-rose-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(253,125,191,0.15)_0%,rgba(251,207,232,0.08)_50%,rgba(244,114,182,0.15)_100%)]"></div>

      {/* 흩날리는 벚꽃 꽃잎 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-3 h-3 bg-pink-400/50 rounded-full animate-pulse shadow-sm transform rotate-45"></div>
        <div className="absolute top-32 right-1/3 w-2 h-2 bg-rose-400/40 rounded-full animate-pulse delay-700 shadow-sm transform rotate-12"></div>
        <div className="absolute bottom-24 left-1/2 w-2 h-2 bg-pink-300/40 rounded-full animate-pulse delay-1000 shadow-sm transform -rotate-12"></div>
        <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-rose-500/50 rounded-full animate-pulse delay-500 shadow-sm"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-pink-300/40 rounded-full animate-pulse delay-1500 shadow-sm transform rotate-45"></div>
        <div className="absolute top-1/3 left-1/5 w-1 h-1 bg-pink-500/50 rounded-full animate-pulse delay-300 shadow-sm transform -rotate-30"></div>
      </div>

      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
          {/* 벚꽃 정원 회사 정보 */}
          <div 
            ref={el => sectionsRef.current[0] = el}
            className="lg:col-span-2"
          >
            <div className="flex items-center space-x-4 mb-6">
              <div className="relative group">
                <div className="w-14 h-14 bg-gradient-to-br from-pink-500 via-rose-400 to-pink-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-pink-500/60 group-hover:scale-110 transition-transform duration-300 border-2 border-white/40">
                  <span className="text-white font-bold text-2xl drop-shadow-lg">🌸</span>
                </div>
                <div className="absolute inset-0 bg-gradient-to-br from-pink-400/50 via-rose-300/30 to-pink-400/50 rounded-2xl blur opacity-60 group-hover:opacity-80 transition-opacity duration-300"></div>
              </div>
              <div>
                <h3 className="text-2xl font-bold bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent drop-shadow-lg">
                  BlossomCheck
                </h3>
                <p className="text-pink-600/80 text-sm font-medium tracking-wide">
                  🌺 AI POWERED BLOSSOM SYSTEM
                </p>
              </div>
            </div>
            
            <p className="text-pink-600/80 mb-6 leading-relaxed max-w-md drop-shadow-sm">
              첨단 로즈 기술로 벚꽃 정원의 미래를 만들어가는 BlossomCheck. 
              정확하고 빠른 자동 채점으로 더 나은 학습 경험을 제공합니다.
            </p>
            
            {/* 벚꽃 정원 소셜 미디어 */}
            <div className="flex space-x-3 mb-8">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className={`w-12 h-12 bg-white/50 backdrop-blur-sm ${social.color} rounded-xl flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-lg hover:shadow-pink-500/40 group border border-white/60 hover:border-pink-400`}
                  title={social.name}
                >
                  <span className="text-xl group-hover:scale-110 transition-transform duration-200 drop-shadow-sm">
                    {social.icon}
                  </span>
                </a>
              ))}
            </div>

            {/* 벚꽃 정원 연락처 정보 */}
            <div className="space-y-3 text-sm text-pink-600/80">
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-pink-100/70 rounded-lg flex items-center justify-center group-hover:bg-pink-200 transition-colors duration-200 border border-pink-300/60">
                  <span>📧</span>
                </div>
                <div>
                  <p className="text-pink-700 font-medium">support@blossom.co.kr</p>
                  <p className="text-xs text-pink-600/70">고객 지원 이메일</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-pink-100/70 rounded-lg flex items-center justify-center group-hover:bg-pink-200 transition-colors duration-200 border border-pink-300/60">
                  <span>📞</span>
                </div>
                <div>
                  <p className="text-pink-700 font-medium">02-1234-5678</p>
                  <p className="text-xs text-pink-600/70">평일 09:00 - 18:00</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-pink-100/70 rounded-lg flex items-center justify-center group-hover:bg-pink-200 transition-colors duration-200 border border-pink-300/60">
                  <span>📍</span>
                </div>
                <div>
                  <p className="text-pink-700 font-medium">서울특별시 강남구 테헤란로 123</p>
                  <p className="text-xs text-pink-600/70">BlossomCheck 본사</p>
                </div>
              </div>
            </div>
          </div>

          {/* 벚꽃 정원 링크 섹션들 */}
          {footerSections.map((section, index) => (
            <div 
              key={index}
              ref={el => sectionsRef.current[index + 1] = el}
              className="lg:col-span-1"
            >
              <h4 className="text-lg font-bold mb-6 text-pink-700 relative drop-shadow-sm">
                {section.title}
                <div className="absolute bottom-0 left-0 w-8 h-0.5 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full"></div>
              </h4>
              <ul className="space-y-4">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a 
                      href={link.href}
                      className="text-pink-600/80 hover:text-pink-700 transition-all duration-200 hover:translate-x-2 transform inline-block relative group py-1"
                    >
                      <span className="relative z-10 drop-shadow-sm">{link.name}</span>
                      <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-pink-500 to-rose-500 group-hover:w-full transition-all duration-300"></span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* 벚꽃 정원 구분선 */}
        <div className="my-12">
          <div className="h-px bg-gradient-to-r from-transparent via-pink-300/60 to-transparent"></div>
        </div>
        
        {/* 벚꽃 정원 하단 정보 */}
        <div 
          ref={el => sectionsRef.current[4] = el}
          className="flex flex-col lg:flex-row justify-between items-center text-sm text-pink-600/80"
        >
          <div className="space-y-2 lg:space-y-0 text-center lg:text-left mb-6 lg:mb-0">
            <p className="font-medium drop-shadow-sm">© 2025 BlossomCheck Co., Ltd. All rights reserved.</p>
            <p className="text-xs">
              사업자등록번호: 123-45-67890 | 대표: 🌸 김벚꽃정원 | 통신판매업신고: 2024-서울강남구-1234
            </p>
          </div>
          
          <div className="flex flex-wrap justify-center lg:justify-end gap-6">
            <a href="#" className="hover:text-pink-700 transition-colors duration-200 relative group">
              <span>이용약관</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-pink-500 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-pink-700 transition-colors duration-200 relative group font-semibold">
              <span>개인정보처리방침</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-rose-500 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-pink-700 transition-colors duration-200 relative group">
              <span>쿠키정책</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-pink-600 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-pink-700 transition-colors duration-200 relative group">
              <span>사이트맵</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-rose-600 group-hover:w-full transition-all duration-300"></span>
            </a>
          </div>
        </div>

        {/* 벚꽃 정원 인증 마크들 */}
        <div 
          ref={el => sectionsRef.current[5] = el}
          className="mt-12 pt-8 border-t border-pink-300/60 flex flex-wrap justify-center lg:justify-start items-center gap-4 text-xs text-pink-600/80"
        >
          <div className="flex items-center space-x-2 bg-white/50 backdrop-blur-sm px-4 py-2 rounded-xl border border-pink-300/60 hover:border-pink-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🔒</span>
            <span className="text-pink-700">보안 인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-white/50 backdrop-blur-sm px-4 py-2 rounded-xl border border-pink-300/60 hover:border-pink-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">✅</span>
            <span className="text-pink-700">개인정보보호 인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-white/50 backdrop-blur-sm px-4 py-2 rounded-xl border border-pink-300/60 hover:border-pink-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🏆</span>
            <span className="text-pink-700">ISO 27001 인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-white/50 backdrop-blur-sm px-4 py-2 rounded-xl border border-pink-300/60 hover:border-pink-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🛡️</span>
            <span className="text-pink-700">GDPR 준수</span>
          </div>
        </div>

        {/* 벚꽃 정원 추가 정보 */}
        <div 
          ref={el => sectionsRef.current[6] = el}
          className="mt-8 text-center"
        >
          <p className="text-xs text-pink-600/70 leading-relaxed max-w-2xl mx-auto drop-shadow-sm">
            BlossomCheck는 로즈 기술 혁신을 통해 더 나은 교육 환경을 만들어가고 있습니다. 
            우리의 AI 기술이 전 세계 교육자와 학습자들에게 도움이 되기를 바랍니다.
          </p>
          
          <div className="mt-6 flex justify-center items-center space-x-2 text-xs text-pink-600/80">
            <span>Made with</span>
            <span className="text-pink-500 animate-pulse">💖</span>
            <span>in Seoul, Korea</span>
          </div>
        </div>

        {/* 추가 벚꽃 정원 안내 */}
        <div 
          ref={el => sectionsRef.current[7] = el}
          className="mt-8 text-center"
        >
          <div className="inline-flex items-center space-x-2 bg-pink-100/70 text-pink-700 px-4 py-2 rounded-full text-xs border border-pink-300/60">
            <span>🌟</span>
            <span>이 사이트는 벚꽃 정원 보안 시스템으로 보호됩니다</span>
          </div>
        </div>
      </div>

      {/* 하단 벚꽃 정원 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-white/30 to-transparent pointer-events-none"></div>
    </footer>
  );
}