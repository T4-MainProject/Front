// ============================================
// ✨ Angelic Light Footer.jsx - 빛의 발끝
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const footerSections = [
  {
    title: '천사 서비스',
    links: [
      { name: 'AI 자동 축복', href: '#' },
      { name: '대량 빛 처리', href: '#' },
      { name: '천국 API 서비스', href: '#' },
      { name: '빛의 교육기관 솔루션', href: '#' }
    ]
  },
  {
    title: '천국 지원',
    links: [
      { name: '천사 사용자 가이드', href: '#' },
      { name: '축복받은 질문들', href: '#' },
      { name: '빛의 기술 지원', href: '#' },
      { name: '천국 문의하기', href: '#' }
    ]
  },
  {
    title: '빛의 회사',
    links: [
      { name: '천국 소개', href: '#' },
      { name: '천사 채용 정보', href: '#' },
      { name: '빛의 보도자료', href: '#' },
      { name: '하늘의 파트너십', href: '#' }
    ]
  }
];

const socialLinks = [
  { name: 'LightTwitter', icon: '🕊️', href: '#', color: 'hover:bg-blue-500' },
  { name: 'HeavenBook', icon: '📖', href: '#', color: 'hover:bg-sky-500' },
  { name: 'AngelGram', icon: '📸', href: '#', color: 'hover:bg-blue-400' },
  { name: 'AngelIn', icon: '💼', href: '#', color: 'hover:bg-indigo-500' },
  { name: 'LightTube', icon: '📺', href: '#', color: 'hover:bg-blue-600' }
];

export default function Footer() {
  const footerRef = useRef(null);
  const sectionsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 빛의 푸터 섹션들 애니메이션 (부드럽고 우아하게)
      gsap.fromTo(sectionsRef.current,
        {
          y: 50,
          opacity: 0,
          scale: 0.95,
          filter: "blur(3px)"
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          filter: "blur(0px)",
          duration: 0.8,
          stagger: 0.1,
          ease: "power2.out",
          scrollTrigger: {
            trigger: footerRef.current,
            start: "top 90%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, footerRef);

    return () => ctx.revert();
  }, []);

  return (
    <footer ref={footerRef} className="bg-gradient-to-br from-white via-blue-50 to-sky-100 text-blue-700 relative overflow-hidden">
      {/* 빛의 배경 장식 */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-gradient-to-br from-blue-400/20 to-sky-300/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-gradient-to-br from-sky-400/15 to-blue-300/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-br from-blue-300/10 to-sky-200/15 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* 추가 빛 레이어 */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/80 via-blue-50/60 to-sky-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,rgba(255,255,255,0.6)_100%)]"></div>

      {/* 움직이는 빛의 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-2 h-2 bg-blue-400/40 rounded-full animate-pulse"></div>
        <div className="absolute top-32 right-1/3 w-1 h-1 bg-sky-400/50 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-24 left-1/2 w-1 h-1 bg-indigo-400/40 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-blue-500/50 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-sky-300/40 rounded-full animate-pulse delay-1500"></div>
        <div className="absolute top-1/3 left-1/5 w-1 h-1 bg-blue-400/50 rounded-full animate-pulse delay-300"></div>
      </div>

      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
          {/* 빛의 회사 정보 */}
          <div 
            ref={el => sectionsRef.current[0] = el}
            className="lg:col-span-2"
          >
            <div className="flex items-center space-x-4 mb-6">
              <div className="relative group">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 via-sky-400 to-blue-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-blue-500/50 group-hover:scale-110 transition-transform duration-300 border border-blue-300">
                  <span className="text-white font-bold text-2xl drop-shadow-lg">✨</span>
                </div>
                <div className="absolute inset-0 bg-gradient-to-br from-blue-400/40 via-sky-300/30 to-blue-500/40 rounded-2xl blur opacity-50 group-hover:opacity-70 transition-opacity duration-300"></div>
              </div>
              <div>
                <h3 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent drop-shadow-lg">
                  AngelCheck
                </h3>
                <p className="text-blue-500 text-sm font-medium tracking-wide">
                  👼 AI POWERED HEAVEN SYSTEM
                </p>
              </div>
            </div>
            
            <p className="text-blue-600 mb-6 leading-relaxed max-w-md drop-shadow-sm">
              첨단 천사 기술로 천국의 미래를 만들어가는 AngelCheck. 
              정확하고 빠른 자동 축복으로 더 나은 빛의 경험을 제공합니다.
            </p>
            
            {/* 빛의 소셜 미디어 */}
            <div className="flex space-x-3 mb-8">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className={`w-12 h-12 bg-blue-100/80 backdrop-blur-sm ${social.color} rounded-xl flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-lg hover:shadow-blue-500/30 group border border-blue-200 hover:border-blue-400`}
                  title={social.name}
                >
                  <span className="text-xl group-hover:scale-110 transition-transform duration-200 drop-shadow-sm">
                    {social.icon}
                  </span>
                </a>
              ))}
            </div>

            {/* 빛의 연락처 정보 */}
            <div className="space-y-3 text-sm text-blue-600">
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors duration-200 border border-blue-300">
                  <span>📧</span>
                </div>
                <div>
                  <p className="text-blue-700 font-medium">heavensupport@angelcheck.co.kr</p>
                  <p className="text-xs text-blue-500">천사 지원 이메일</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors duration-200 border border-blue-300">
                  <span>📞</span>
                </div>
                <div>
                  <p className="text-blue-700 font-medium">02-7777-7777</p>
                  <p className="text-xs text-blue-500">천국시간 06:00 - 22:00</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors duration-200 border border-blue-300">
                  <span>📍</span>
                </div>
                <div>
                  <p className="text-blue-700 font-medium">천국특별시 빛구 축복로 777</p>
                  <p className="text-xs text-blue-500">AngelCheck 천국 본사</p>
                </div>
              </div>
            </div>
          </div>

          {/* 빛의 링크 섹션들 */}
          {footerSections.map((section, index) => (
            <div 
              key={index}
              ref={el => sectionsRef.current[index + 1] = el}
              className="lg:col-span-1"
            >
              <h4 className="text-lg font-bold mb-6 text-blue-700 relative drop-shadow-sm">
                {section.title}
                <div className="absolute bottom-0 left-0 w-8 h-0.5 bg-gradient-to-r from-blue-500 to-sky-400 rounded-full"></div>
              </h4>
              <ul className="space-y-4">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a 
                      href={link.href}
                      className="text-blue-600 hover:text-blue-500 transition-all duration-200 hover:translate-x-2 transform inline-block relative group py-1"
                    >
                      <span className="relative z-10 drop-shadow-sm">{link.name}</span>
                      <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-sky-400 group-hover:w-full transition-all duration-300"></span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* 빛의 구분선 */}
        <div className="my-12">
          <div className="h-px bg-gradient-to-r from-transparent via-blue-300/50 to-transparent"></div>
        </div>
        
        {/* 빛의 하단 정보 */}
        <div 
          ref={el => sectionsRef.current[4] = el}
          className="flex flex-col lg:flex-row justify-between items-center text-sm text-blue-600"
        >
          <div className="space-y-2 lg:space-y-0 text-center lg:text-left mb-6 lg:mb-0">
            <p className="font-medium drop-shadow-sm">© 2025 AngelCheck Co., Ltd. All angels blessed.</p>
            <p className="text-xs">
              천사등록번호: 777-77-77777 | 대표: 👼 김천사 | 천국판매업신고: 2025-천국빛구-7777
            </p>
          </div>
          
          <div className="flex flex-wrap justify-center lg:justify-end gap-6">
            <a href="#" className="hover:text-blue-500 transition-colors duration-200 relative group">
              <span>축복 이용약관</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-blue-500 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-blue-500 transition-colors duration-200 relative group font-semibold">
              <span>천사정보처리방침</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-sky-500 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-blue-500 transition-colors duration-200 relative group">
              <span>축복쿠키정책</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-blue-400 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-blue-500 transition-colors duration-200 relative group">
              <span>천국사이트맵</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-indigo-500 group-hover:w-full transition-all duration-300"></span>
            </a>
          </div>
        </div>

        {/* 빛의 인증 마크들 */}
        <div 
          ref={el => sectionsRef.current[5] = el}
          className="mt-12 pt-8 border-t border-blue-300/50 flex flex-wrap justify-center lg:justify-start items-center gap-4 text-xs text-blue-600"
        >
          <div className="flex items-center space-x-2 bg-blue-100/80 backdrop-blur-sm px-4 py-2 rounded-xl border border-blue-200 hover:border-blue-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🔒</span>
            <span className="text-blue-700">빛의 보안인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-blue-100/80 backdrop-blur-sm px-4 py-2 rounded-xl border border-blue-200 hover:border-blue-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">✅</span>
            <span className="text-blue-700">천사정보보호 인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-blue-100/80 backdrop-blur-sm px-4 py-2 rounded-xl border border-blue-200 hover:border-blue-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🏆</span>
            <span className="text-blue-700">ISO 777 인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-blue-100/80 backdrop-blur-sm px-4 py-2 rounded-xl border border-blue-200 hover:border-blue-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🛡️</span>
            <span className="text-blue-700">HEAVEN 준수</span>
          </div>
        </div>

        {/* 빛의 추가 정보 */}
        <div 
          ref={el => sectionsRef.current[6] = el}
          className="mt-8 text-center"
        >
          <p className="text-xs text-blue-500 leading-relaxed max-w-2xl mx-auto drop-shadow-sm">
            AngelCheck는 빛의 기술 혁신을 통해 더 나은 천국 환경을 만들어가고 있습니다. 
            우리의 천사 AI 기술이 전 세계 빛의 전달자와 천사 학습자들에게 축복이 되기를 바랍니다.
          </p>
          
          <div className="mt-6 flex justify-center items-center space-x-2 text-xs text-blue-500">
            <span>Made with</span>
            <span className="text-blue-600 animate-pulse">💙</span>
            <span>in Heaven, Skyworld</span>
          </div>
        </div>

        {/* 추가 빛의 축복 */}
        <div 
          ref={el => sectionsRef.current[7] = el}
          className="mt-8 text-center"
        >
          <div className="inline-flex items-center space-x-2 bg-blue-100/60 text-blue-600 px-4 py-2 rounded-full text-xs border border-blue-300">
            <span>✨</span>
            <span>이 사이트는 빛의 세계에서 운영됩니다</span>
          </div>
        </div>
      </div>

      {/* 하단 빛 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-white to-transparent pointer-events-none"></div>
    </footer>
  );
}