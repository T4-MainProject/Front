import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const features = [
  { 
    icon: '⚡', 
    title: '번개같은 심판 속도', 
    description: '평균 6.66초 내 심판 완료로 즉시 지옥 결과 확인',
    gradient: 'from-red-600 to-black',
    bgGradient: 'from-red-900/30 to-black/60'
  },
  { 
    icon: '👁️', 
    title: '악마의 정확도', 
    description: '99.9% 정확도로 신뢰할 수 있는 무자비한 심판 결과',
    gradient: 'from-gray-600 to-red-800',
    bgGradient: 'from-gray-900/40 to-red-900/50'
  },
  { 
    icon: '💀', 
    title: '상세한 저주 분석', 
    description: '문제별 악마 분석과 영혼 고통 패턴 리포트 제공',
    gradient: 'from-red-700 to-purple-900',
    bgGradient: 'from-red-800/40 to-purple-900/50'
  },
  { 
    icon: '🔒', 
    title: '지옥의 보안', 
    description: '영혼정보 보호와 데이터 저주 암호화로 안전한 어둠 서비스',
    gradient: 'from-black to-red-900',
    bgGradient: 'from-black/70 to-red-900/40'
  }
];

export default function FeatureList() {
  const sectionRef = useRef(null);
  const cardsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 어둠의 카드들 스태거 애니메이션 (더 극적으로)
      gsap.fromTo(cardsRef.current, 
        {
          y: 100,
          opacity: 0,
          scale: 0.6,
          rotationY: -45,
          filter: "blur(10px)"
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          rotationY: 0,
          filter: "blur(0px)",
          duration: 1.0,
          stagger: 0.2,
          ease: 'power4.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            end: 'bottom 20%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // 어둠의 개별 카드 호버 애니메이션 (더 강렬하게)
      cardsRef.current.forEach((card) => {
        if (card) {
          card.addEventListener('mouseenter', () => {
            gsap.to(card, {
              y: -12,
              scale: 1.05,
              rotationX: 5,
              duration: 0.4,
              ease: "power3.out"
            });
          });

          card.addEventListener('mouseleave', () => {
            gsap.to(card, {
              y: 0,
              scale: 1,
              rotationX: 0,
              duration: 0.4,
              ease: "power3.out"
            });
          });
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-b from-black via-gray-900 to-red-900 relative overflow-hidden">
      {/* 어둠의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-gray-900/60 to-red-900/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_40%,black_80%)]"></div>
      
      {/* 움직이는 어둠의 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-1/4 w-2 h-2 bg-red-500/30 rounded-full animate-pulse"></div>
        <div className="absolute top-40 right-1/3 w-1 h-1 bg-red-400/40 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-32 left-1/2 w-1 h-1 bg-gray-500/30 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-red-600/40 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-red-300/30 rounded-full animate-pulse delay-1500"></div>
        <div className="absolute top-1/3 left-1/5 w-1 h-1 bg-red-500/40 rounded-full animate-pulse delay-300"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* 어둠의 헤더 */}
        <div className="text-center mb-16" data-aos="fade-up">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-red-900/60 to-black/80 text-red-400 px-6 py-3 rounded-full text-sm font-bold mb-6 shadow-lg shadow-red-500/30 border border-red-800/50">
            <span>💀</span>
            <span>어둠의 특징</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-red-300 mb-6 drop-shadow-2xl">
            왜 
            <span className="bg-gradient-to-r from-red-500 to-red-700 bg-clip-text text-transparent"> DarkCheck</span>을 
            <br className="hidden sm:block" />
            선택해야 할까요?
          </h2>
          <p className="text-xl text-red-400/80 max-w-3xl mx-auto leading-relaxed drop-shadow-lg">
            최고의 악마 기술력과 지옥 사용자 경험을 바탕으로 한 <br className="hidden md:block" />
            차별화된 자동 심판 서비스를 제공합니다
          </p>
        </div>

        {/* 어둠의 기능 카드 그리드 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              ref={el => cardsRef.current[index] = el}
              className={`relative group p-8 rounded-3xl bg-gradient-to-br ${feature.bgGradient} border border-red-800/50 shadow-2xl shadow-red-500/20 hover:shadow-2xl hover:shadow-red-500/40 transition-all duration-500 cursor-pointer overflow-hidden backdrop-blur-sm`}
            >
              {/* 어둠의 배경 글로우 효과 */}
              <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-15 transition-opacity duration-500 rounded-3xl`}></div>
              
              {/* 추가 어둠 레이어 */}
              <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-gray-900/30 to-red-900/20 rounded-3xl"></div>
              
              {/* 어둠의 파티클들 */}
              <div className="absolute top-4 right-4 w-2 h-2 bg-red-500/40 rounded-full animate-pulse"></div>
              <div className="absolute bottom-6 left-6 w-1 h-1 bg-red-400/60 rounded-full animate-ping"></div>
              <div className="absolute top-1/2 right-8 w-1.5 h-1.5 bg-gray-500/50 rounded-full animate-bounce"></div>
              
              {/* 악마의 아이콘 */}
              <div className="relative z-10 mb-6">
                <div className={`inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br ${feature.gradient} rounded-2xl text-red-300 text-2xl shadow-lg shadow-red-500/50 group-hover:shadow-xl group-hover:shadow-red-500/70 transition-all duration-300 group-hover:scale-110 group-hover:rotate-12 border border-red-700/50`}>
                  {feature.icon}
                </div>
              </div>
              
              {/* 어둠의 콘텐츠 */}
              <div className="relative z-10">
                <h3 className="text-xl font-bold text-red-300 mb-3 group-hover:text-red-200 transition-colors duration-300 drop-shadow-lg">
                  {feature.title}
                </h3>
                
                <p className="text-red-400/90 text-sm leading-relaxed group-hover:text-red-300 transition-colors duration-300 drop-shadow-sm">
                  {feature.description}
                </p>
              </div>

              {/* 호버 시 나타나는 어둠의 액센트 */}
              <div className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${feature.gradient} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left shadow-lg shadow-red-500/50`}></div>
              
              {/* 추가 어둠 효과 */}
              <div className="absolute inset-0 rounded-3xl border border-red-700/30 group-hover:border-red-600/50 transition-colors duration-300"></div>
              
              {/* 중앙 어둠 효과 */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-24 h-24 bg-black/10 rounded-full blur-2xl opacity-0 group-hover:opacity-40 transition-opacity duration-500"></div>
            </div>
          ))}
        </div>

        {/* 어둠의 추가 통계 섹션 */}
        <div className="mt-20 pt-16 border-t border-red-800/50" data-aos="fade-up" data-aos-delay="400">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-red-300 mb-4 drop-shadow-lg">
              <span className="bg-gradient-to-r from-red-500 to-red-700 bg-clip-text text-transparent">실시간</span> 
              지옥 현황
            </h3>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: '66.6K+', label: '누적 심판수', icon: '💀', color: 'red' },
              { number: '99.9%', label: '악마 정확도', icon: '👁️', color: 'gray' },
              { number: '6.66초', label: '평균 심판시간', icon: '⚡', color: 'red' },
              { number: '666+', label: '활성 영혼', icon: '👻', color: 'red' }
            ].map((stat, index) => (
              <div key={index} className="text-center group">
                <div className={`inline-flex items-center justify-center w-12 h-12 bg-red-900/50 border border-red-800/50 rounded-xl mb-4 group-hover:scale-110 transition-transform duration-300 shadow-md shadow-red-500/30 group-hover:shadow-lg group-hover:shadow-red-500/50`}>
                  <span className="text-2xl drop-shadow-lg">{stat.icon}</span>
                </div>
                <div className={`text-3xl font-black text-red-400 mb-2 group-hover:scale-110 transition-transform duration-300 drop-shadow-lg`}>
                  {stat.number}
                </div>
                <div className="text-sm text-red-500/80 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>

          {/* 추가 어둠의 장식 */}
          <div className="mt-16 flex justify-center">
            <div className="bg-gradient-to-r from-red-900/40 to-black/60 px-8 py-6 rounded-2xl border border-red-800/50 shadow-lg shadow-red-500/30 max-w-md">
              <div className="text-center">
                <div className="text-red-300 font-bold text-lg mb-2 drop-shadow-sm">🔥 어둠의 성장</div>
                <div className="text-red-500/80 text-sm">매일 새로운 영혼들이 합류하고 있습니다</div>
                <div className="mt-3 flex justify-center space-x-4">
                  <div className="text-center">
                    <div className="text-red-400 font-bold">+13</div>
                    <div className="text-xs text-red-600/70">오늘</div>
                  </div>
                  <div className="text-center">
                    <div className="text-red-400 font-bold">+666</div>
                    <div className="text-xs text-red-600/70">이번 달</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 하단 어둠 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-black to-transparent pointer-events-none"></div>
    </section>
  );
}