// ============================================
// 🏝️ Tropical Paradise ContentLeft.jsx - 열대 좌측 콘텐츠
// ============================================
import React, { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function ContentLeft({ 
  title = "파라다이스 기능",
  subtitle = "크리스탈 학습 경험", 
  description = "열대 바다의 AI 기술로 완벽한 학습을 지원합니다.",
  features = [],
  image = null,
  ctaText = "파라다이스 체험하기",
  onCtaClick = () => {},
  className = "",
  ...props 
}) {
  const containerRef = useRef(null);
  const contentRef = useRef(null);
  const imageRef = useRef(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 🌊 좌측 콘텐츠 애니메이션 (열대 느낌으로)
      gsap.fromTo(contentRef.current,
        { 
          x: -100, 
          opacity: 0, 
          rotationY: -15,
          filter: "blur(10px)"
        },
        { 
          x: 0, 
          opacity: 1, 
          rotationY: 0,
          filter: "blur(0px)",
          duration: 1.2, 
          ease: "power4.out",
          scrollTrigger: {
            trigger: containerRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // 🏖️ 우측 이미지 애니메이션 (파라다이스 효과)
      if (imageRef.current) {
        gsap.fromTo(imageRef.current,
          { 
            x: 100, 
            opacity: 0, 
            scale: 0.8,
            rotationY: 15
          },
          { 
            x: 0, 
            opacity: 1, 
            scale: 1,
            rotationY: 0,
            duration: 1.2, 
            ease: "power4.out",
            delay: 0.3,
            scrollTrigger: {
              trigger: containerRef.current,
              start: "top 80%",
              end: "bottom 20%",
              toggleActions: "play none none reverse"
            }
          }
        );
      }
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={containerRef}
      className={`py-20 bg-gradient-to-br from-emerald-50 via-cyan-50 to-sky-100 relative overflow-hidden ${className}`}
      {...props}
    >
      {/* 🏝️ 열대 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/80 via-emerald-50/60 to-cyan-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_80%,rgba(16,185,129,0.15)_0%,rgba(6,182,212,0.1)_50%,rgba(14,165,233,0.15)_80%)]"></div>
      
      {/* 🌺 떠다니는 열대 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-3 h-3 bg-emerald-400/40 rounded-full animate-pulse shadow-lg"></div>
        <div className="absolute top-32 right-1/3 w-2 h-2 bg-cyan-400/50 rounded-full animate-pulse delay-700 shadow-lg"></div>
        <div className="absolute bottom-24 left-1/2 w-2 h-2 bg-sky-400/40 rounded-full animate-pulse delay-1000 shadow-lg"></div>
        <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-teal-500/50 rounded-full animate-pulse delay-500 shadow-lg"></div>
        <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-emerald-300/40 rounded-full animate-pulse delay-1500 shadow-lg"></div>
      </div>

      {/* 🌴 장식 야자수 */}
      <div className="absolute top-20 right-16 opacity-10">
        <svg width="80" height="120" viewBox="0 0 80 120">
          <path d="M40 120 L40 60 M20 60 Q40 40 60 60 M15 55 Q40 35 65 55" stroke="#059669" strokeWidth="3" fill="none"/>
          <circle cx="40" cy="50" r="8" fill="#059669"/>
          <path d="M32 50 Q20 35 8 40 M48 50 Q60 35 72 40" stroke="#16a34a" strokeWidth="2" fill="none"/>
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* 🌊 좌측 콘텐츠 */}
          <div ref={contentRef} className="order-2 lg:order-1">
            {/* 🏖️ 배지 */}
            <div className="inline-flex items-center space-x-3 bg-white/25 backdrop-blur-md border border-white/30 text-emerald-700 px-6 py-3 rounded-full text-sm font-bold mb-6 shadow-lg shadow-emerald-500/30 hover:shadow-xl hover:shadow-cyan-500/50 transition-all duration-300 hover:scale-105">
              <span>🏝️</span>
              <span>파라다이스 혁신</span>
            </div>

            {/* 🌺 타이틀 */}
            <h2 className="text-4xl md:text-5xl font-black text-emerald-700 mb-4 drop-shadow-2xl">
              <span className="bg-gradient-to-r from-emerald-600 to-cyan-600 bg-clip-text text-transparent">
                {title}
              </span>
            </h2>

            {/* 💎 서브타이틀 */}
            <h3 className="text-2xl font-bold text-cyan-600 mb-6 drop-shadow-lg">
              {subtitle}
            </h3>

            {/* 🏖️ 설명 */}
            <div className="bg-white/25 backdrop-blur-md rounded-2xl p-6 border border-white/30 shadow-lg mb-8">
              <p className="text-lg text-emerald-600 leading-relaxed drop-shadow-sm">
                {description}
              </p>
            </div>

            {/* 🌊 특징 목록 */}
            {features.length > 0 && (
              <div className="mb-8">
                <h4 className="text-xl font-bold text-emerald-700 mb-4 drop-shadow-sm">🌺 주요 특징</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {features.map((feature, index) => (
                    <div 
                      key={index}
                      className="flex items-start space-x-3 bg-white/20 backdrop-blur-sm rounded-xl p-4 border border-white/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
                    >
                      <span className="text-emerald-500 mt-1 drop-shadow-sm flex-shrink-0">
                        {feature.icon || '🏝️'}
                      </span>
                      <div>
                        <h5 className="font-semibold text-emerald-700 drop-shadow-sm">
                          {feature.title}
                        </h5>
                        <p className="text-emerald-600 text-sm drop-shadow-sm">
                          {feature.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 🏝️ CTA 버튼 */}
            <button
              onClick={onCtaClick}
              className="bg-gradient-to-r from-emerald-500 via-cyan-500 to-sky-500 text-white px-10 py-5 rounded-3xl font-bold text-xl shadow-2xl shadow-emerald-500/50 hover:shadow-3xl hover:shadow-cyan-500/70 transition-all duration-500 hover:scale-105 group border-2 border-white/30 backdrop-blur-sm relative overflow-hidden"
            >
              <span className="relative z-10 flex items-center justify-center">
                {ctaText}
                <svg className="ml-3 w-6 h-6 group-hover:translate-x-2 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-white/10 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
            </button>
          </div>

          {/* 🌊 우측 이미지/콘텐츠 */}
          <div ref={imageRef} className="order-1 lg:order-2">
            {image ? (
              <div className="relative">
                <div className="bg-white/30 backdrop-blur-md rounded-3xl p-8 shadow-3xl shadow-emerald-500/30 hover:shadow-3xl hover:shadow-cyan-500/40 border border-white/40 transition-all duration-500 hover:scale-105 relative overflow-hidden">
                  {/* 🏖️ 크리스탈 배경 효과 */}
                  <div className="absolute inset-0 bg-gradient-to-br from-emerald-100/20 to-cyan-100/20 rounded-3xl"></div>
                  
                  <img 
                    src={image} 
                    alt={title}
                    className="w-full h-auto rounded-2xl shadow-xl relative z-10"
                  />
                  
                  {/* 💎 크리스탈 파티클들 */}
                  <div className="absolute top-4 right-4 w-3 h-3 bg-emerald-400/50 rounded-full animate-pulse shadow-lg"></div>
                  <div className="absolute bottom-6 left-6 w-2 h-2 bg-cyan-400/60 rounded-full animate-ping shadow-lg"></div>
                  <div className="absolute top-1/2 right-8 w-2 h-2 bg-sky-400/50 rounded-full animate-bounce shadow-lg"></div>
                </div>

                {/* 🌺 떠다니는 장식 요소들 */}
                <div className="absolute -top-6 -right-6 w-16 h-16 bg-gradient-to-br from-emerald-500 to-cyan-500 rounded-3xl flex items-center justify-center shadow-2xl shadow-emerald-500/50 animate-bounce border-2 border-white/30 backdrop-blur-sm">
                  <span className="text-white text-2xl drop-shadow-lg">🌺</span>
                </div>
                
                <div className="absolute -bottom-6 -left-6 w-16 h-16 bg-gradient-to-br from-cyan-500 to-sky-500 rounded-3xl flex items-center justify-center shadow-2xl shadow-cyan-500/50 animate-pulse border-2 border-white/30 backdrop-blur-sm">
                  <span className="text-white text-2xl drop-shadow-lg">💎</span>
                </div>
              </div>
            ) : (
              /* 🏝️ 기본 일러스트레이션 */
              <div className="bg-white/30 backdrop-blur-md rounded-3xl p-12 shadow-3xl shadow-emerald-500/30 border border-white/40 relative overflow-hidden">
                {/* 🌊 크리스탈 배경 효과 */}
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-100/20 to-cyan-100/20 rounded-3xl"></div>
                
                <div className="text-center relative z-10">
                  <div className="w-32 h-32 bg-gradient-to-br from-emerald-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-emerald-500/50 border-4 border-white/30">
                    <span className="text-6xl text-white drop-shadow-2xl">🏝️</span>
                  </div>
                  
                  <h3 className="text-2xl font-bold text-emerald-700 mb-4 drop-shadow-lg">
                    파라다이스 경험
                  </h3>
                  
                  <p className="text-emerald-600 leading-relaxed drop-shadow-sm">
                    열대 바다의 크리스탈처럼 맑고 투명한 
                    <br />
                    AI 학습 경험을 만나보세요
                  </p>
                </div>

                {/* 💎 크리스탈 파티클들 */}
                <div className="absolute top-4 right-4 w-3 h-3 bg-emerald-400/50 rounded-full animate-pulse shadow-lg"></div>
                <div className="absolute bottom-6 left-6 w-2 h-2 bg-cyan-400/60 rounded-full animate-ping shadow-lg"></div>
                <div className="absolute top-1/2 right-8 w-2 h-2 bg-sky-400/50 rounded-full animate-bounce shadow-lg"></div>
                <div className="absolute top-1/3 left-8 w-1 h-1 bg-teal-500/60 rounded-full animate-pulse delay-700"></div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 🌈 하단 크리스탈 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white/40 to-transparent pointer-events-none backdrop-blur-sm"></div>
      
      <style jsx>{`
        .shadow-3xl {
          box-shadow: 0 35px 60px -12px rgba(0, 0, 0, 0.25);
        }
      `}</style>
    </section>
  );
}