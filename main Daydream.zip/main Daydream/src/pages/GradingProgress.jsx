// ============================================
// ✨ Angelic Light GradingProgress.jsx - 축복 진행 페이지
// ============================================
// 📊 주요 기능:
// - 축복 상태 추적 (천사 대기 → 축복 완료)
// - 실시간 희망 카운트다운 타이머
// - 빛의 진행률 표시 (0% → 100%)
// - 천국 서비스 소개 슬라이드
// - 반응형 빛 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

export default function GradingProgress() {
  // 🧭 빛의 라우터 훅
  const location = useLocation();
  const navigate = useNavigate();
  
  // 📝 업로드된 천사 데이터
  const uploadData = location.state?.uploadData;

  // 📊 상태 관리
  const [status, setStatus] = useState('천사 대기'); // '천사 대기' | '축복 진행' | '축복 완료'
  const [progress, setProgress] = useState(0); // 빛의 진행률 (0-100)
  const [timeLeft, setTimeLeft] = useState(6); // 남은 시간 (초) - 666초의 축약
  const [currentSlide, setCurrentSlide] = useState(0); // 현재 슬라이드 인덱스

  // 🎯 빛의 학습법 및 활용팁 슬라이드 데이터
  const serviceSlides = [
    {
      title: "📚 빛의 효과적인 학습 전략",
      description: "천국의 체계적인 학습 계획으로 천사의 성적을 향상시키는 방법을 알아보세요",
      features: [
        "주기적인 천사 모의고사 활용",
        "희망의 취약점 집중 보완",
        "빛의 학습 진도 체크리스트 작성"
      ],
      color: "from-blue-500 to-sky-400"
    },
    {
      title: "📝 축복받은 오답노트 활용법",
      description: "틀린 문제를 천국의 체계로 정리하여 희망의 실력을 키우는 방법입니다",
      features: [
        "오답 원인 천사 분석하기",
        "유사 문제 축복 반복 학습",
        "정기적인 천국 복습 스케줄"
      ],
      color: "from-sky-500 to-blue-600"
    },
    {
      title: "📊 천사의 성적 분석 활용",
      description: "AI 축복 분석을 통해 개인 맞춤형 희망 학습 계획을 세워보세요",
      features: [
        "과목별 희망 강약점 파악",
        "시간대별 집중력 빛 분석",
        "목표 점수 달성 축복 로드맵"
      ],
      color: "from-blue-600 to-indigo-500"
    },
    {
      title: "🎯 희망의 시험 전략",
      description: "실제 시험에서 빛을 발휘할 수 있는 천사의 실전 노하우입니다",
      features: [
        "시간 배분 축복 전략",
        "문제 유형별 희망 접근법",
        "멘탈 관리 빛의 기법"
      ],
      color: "from-indigo-500 to-purple-500"
    },
    {
      title: "💡 천사의 학습 동기부여",
      description: "꾸준한 희망 학습을 위한 동기부여와 목표 설정 방법을 제시합니다",
      features: [
        "단기/장기 축복 목표 설정",
        "성취감 빛의 보상 시스템",
        "학습 습관 천사 형성법"
      ],
      color: "from-purple-500 to-pink-500"
    }
  ];

  // ⏰ 타이머 및 진행률 업데이트
  useEffect(() => {
    if (timeLeft > 0 && status !== '축복 완료') {
      const timer = setTimeout(() => {
        setTimeLeft(prev => prev - 1);
        
        // 진행률 업데이트 (6초 동안 0% → 100%)
        const newProgress = Math.round(((6 - timeLeft + 1) / 6) * 100);
        setProgress(newProgress);
        
        // 상태 업데이트
        if (timeLeft === 4) {
          setStatus('축복 진행');
        } else if (timeLeft === 1) {
          setStatus('축복 완료');
        }
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [timeLeft, status]);

  // 🎠 슬라이드 자동 전환
  useEffect(() => {
    const slideTimer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % serviceSlides.length);
    }, 4000); // 4초마다 전환
    
    return () => clearInterval(slideTimer);
  }, [serviceSlides.length]);

  // 🏠 천국으로 돌아가기
  const handleBackToHome = () => {
    navigate('/');
  };

  // 📊 결과 보기
  const handleViewResults = () => {
    // 더미 채점 결과 데이터 생성
    const dummyResults = {
      score: 87,
      totalQuestions: 45,
      correctAnswers: 39,
      subject: uploadData?.subject || 'korean',
      examType: uploadData?.examType || 'mock',
      completedAt: new Date().toISOString(),
      // 업로드된 이미지 데이터를 결과에 포함
      examImage: uploadData?.examImage || [],
      uploadData: uploadData
    };
    
    navigate('/grading-result', { 
      state: {
        ...dummyResults,
        // examImage를 최상위 레벨로 이동 (GradingResult에서 우선적으로 확인)
        examImage: uploadData?.examImage || []
      }
    });
  };

  // ⏰ 시간 포맷팅 (MM:SS)
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 🎭 상태별 아이콘
  const getStatusIcon = () => {
    switch (status) {
      case '천사 대기':
        return '⏳';
      case '축복 진행':
        return '✨';
      case '축복 완료':
        return '🎯';
      default:
        return '👼';
    }
  };

  // 🎨 상태별 색상
  const getStatusColor = () => {
    switch (status) {
      case '천사 대기':
        return 'text-blue-600';
      case '축복 진행':
        return 'text-sky-600';
      case '축복 완료':
        return 'text-green-600';
      default:
        return 'text-blue-600';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-sky-50 to-blue-100 relative overflow-hidden">
      {/* 천사 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 천사 날개 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,0 Q50,30 100,0 L100,20 Q50,50 0,20 Z" fill="url(#angelGradient)" />
            <defs>
              <linearGradient id="angelGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#60a5fa" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 빛 효과 */}
        <div className="absolute top-0 left-1/4 w-2 h-32 bg-gradient-to-b from-blue-400 to-transparent animate-ping opacity-70"></div>
        
        {/* 구름 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-white/30 to-transparent"></div>
      </div>

      {/* 헤더 */}
      <div className="bg-white bg-opacity-90 shadow-2xl border-b border-blue-200 backdrop-blur-sm relative z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToHome}
                className="text-blue-600 hover:text-blue-500 mr-4 transition-all duration-300 transform hover:scale-110"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent">
                ✨ AI 축복 진행 중 - Angel Processing
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto space-y-8">
          
          {/* 진행 상태 카드 */}
          <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-blue-200 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-100/30 to-white/60"></div>
            <div className="relative z-10">
              <div className="text-6xl mb-4 animate-pulse">{getStatusIcon()}</div>
              <h2 className={`text-3xl font-bold mb-2 ${getStatusColor()}`}>
                {status}
              </h2>
              <p className="text-blue-500 mb-6">
                천사의 AI가 빛의 속도로 분석하고 있습니다...
              </p>
              
              {/* 진행률 바 */}
              <div className="w-full bg-blue-200 bg-opacity-50 rounded-full h-6 mb-4 overflow-hidden border border-blue-200">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-sky-400 h-6 rounded-full transition-all duration-1000 relative overflow-hidden"
                  style={{ width: `${progress}%` }}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 animate-pulse"></div>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-blue-600 font-semibold">{progress}% 완료</span>
                {timeLeft > 0 && (
                  <span className="text-blue-500">
                    예상 남은 시간: {formatTime(timeLeft)}
                  </span>
                )}
              </div>
              
              {/* 완료 시 결과 보기 버튼 */}
              {status === '축복 완료' && (
                <div className="mt-6">
                  <button
                    onClick={handleViewResults}
                    className="bg-gradient-to-r from-green-600 to-green-500 text-white px-8 py-4 rounded-xl font-semibold hover:from-green-500 hover:to-green-400 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-green-500/50"
                  >
                    🎯 축복 결과 확인하기
                  </button>
                </div>
              )}
            </div>
            {/* 천사 장식 */}
            <div className="absolute top-4 right-4 text-blue-400 opacity-30 animate-pulse">✨</div>
            <div className="absolute bottom-4 left-4 text-blue-400 opacity-30 animate-pulse">🪽</div>
          </div>

          {/* 업로드 정보 확인 */}
          {uploadData && (
            <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-blue-200">
              <h3 className="text-xl font-bold text-blue-600 mb-6 flex items-center">
                <span className="text-2xl mr-3">📋</span>
                업로드 정보 확인
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 bg-opacity-50 rounded-xl border border-blue-200">
                    <div className="text-sm text-blue-500 mb-1">제목</div>
                    <div className="font-semibold text-blue-600">{uploadData.uploadTitle || '제목 없음'}</div>
                  </div>
                  
                  <div className="p-4 bg-blue-50 bg-opacity-50 rounded-xl border border-blue-200">
                    <div className="text-sm text-blue-500 mb-1">과목</div>
                    <div className="font-semibold text-blue-600">
                      {uploadData.subject === 'korean' ? '✨ 희망의 국어' :
                       uploadData.subject === 'english' ? '🌟 빛의 영어' :
                       uploadData.subject === 'math' ? '💫 천사의 수학' :
                       uploadData.subject}
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 bg-opacity-50 rounded-xl border border-blue-200">
                    <div className="text-sm text-blue-500 mb-1">학년</div>
                    <div className="font-semibold text-blue-600">
                      {uploadData.grade === 'high3' ? '고등학교 3학년 🎯' :
                       uploadData.grade === 'high2' ? '고등학교 2학년 🪽' :
                       uploadData.grade === 'high1' ? '고등학교 1학년 💫' :
                       uploadData.grade}
                    </div>
                  </div>
                  
                  <div className="p-4 bg-blue-50 bg-opacity-50 rounded-xl border border-blue-200">
                    <div className="text-sm text-blue-500 mb-1">업로드된 파일</div>
                    <div className="font-semibold text-blue-600">
                      {uploadData.examImage ? `${uploadData.examImage.length}개 파일` : '0개 파일'}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 서비스 소개 슬라이드 */}
          <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-blue-200">
            <h3 className="text-xl font-bold text-blue-600 mb-6 flex items-center">
              <span className="text-2xl mr-3">💡</span>
              천사의 학습 도움말
            </h3>
            
            <div className="relative overflow-hidden rounded-2xl">
              <div 
                className={`bg-gradient-to-r ${serviceSlides[currentSlide].color} p-8 text-white transition-all duration-500`}
              >
                <h4 className="text-2xl font-bold mb-4">{serviceSlides[currentSlide].title}</h4>
                <p className="text-blue-100 mb-6">{serviceSlides[currentSlide].description}</p>
                
                <ul className="space-y-3">
                  {serviceSlides[currentSlide].features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <span className="text-blue-200 mr-3">✨</span>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              {/* 슬라이드 인디케이터 */}
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {serviceSlides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === currentSlide
                        ? 'bg-white shadow-lg'
                        : 'bg-white/50 hover:bg-white/75'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* 천사의 안내 메시지 */}
          <div className="bg-gradient-to-r from-blue-500 to-sky-400 rounded-3xl shadow-2xl p-8 text-white border-2 border-blue-300 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/30 to-sky-400/30"></div>
            <div className="text-center relative z-10">
              <div className="text-4xl mb-4 animate-bounce">👼</div>
              <h3 className="text-2xl font-bold mb-2">천사의 축복이 함께합니다</h3>
              <p className="text-blue-100">
                잠시만 기다려주세요. 빛의 속도로 최고의 분석 결과를 준비하고 있습니다.
              </p>
            </div>
            {/* 천사 장식 */}
            <div className="absolute top-4 right-4 text-white opacity-50 animate-pulse">✨</div>
            <div className="absolute bottom-4 left-4 text-white opacity-30 animate-pulse">🌟</div>
          </div>
        </div>
      </div>
    </div>
  );
}