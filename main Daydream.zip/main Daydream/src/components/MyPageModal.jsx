// ============================================
// ✨ Angelic Light MyPageModal.jsx - 희망의 방 모달
// ============================================
// 📱 주요 기능:
// - 천사 정보 표시
// - 빛의 프로필 편집
// - 천국 통계 정보 표시
// - 반응형 빛 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { userRoles, memberTiers, pointsSystem, calculateUserTier, saveUserToStorage } from '../data/dummyUsers';

export default function MyPageModal({ isOpen, onClose, currentUser, onUserUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    school: ''
  });

  // 모달이 열릴 때 천사 정보로 초기화
  useEffect(() => {
    if (currentUser) {
      setFormData({
        name: currentUser.name || '',
        phone: currentUser.phone || '',
        address: currentUser.address || '',
        school: currentUser.school || ''
      });
    }
  }, [currentUser]);

  // 모달이 열릴 때 body 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.keyCode === 27) onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    // 원래 천사 정보로 복원
    if (currentUser) {
      setFormData({
        name: currentUser.name || '',
        phone: currentUser.phone || '',
        address: currentUser.address || '',
        school: currentUser.school || ''
      });
    }
  };

  const handleSave = () => {
    // 천사 정보 업데이트
    const updatedUser = {
      ...currentUser,
      ...formData
    };
    
    // 축복 저장소에 저장
    saveUserToStorage(updatedUser);
    
    // 부모 컴포넌트에 알림
    if (onUserUpdate) {
      onUserUpdate(updatedUser);
    }
    
    setIsEditing(false);
    alert('✨ 천사 정보가 성공적으로 업데이트되었습니다!');
  };

  // 현재 사용자의 천사 등급 계산
  const currentTier = currentUser ? calculateUserTier(currentUser.totalPoints || 0) : memberTiers.기본;

  if (!isOpen || !currentUser) return null;

  return (
    <div className="fixed inset-0 bg-white bg-opacity-95 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto border-2 border-blue-200 relative">
        {/* 천사 배경 효과 */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 via-white/80 to-sky-100/40 rounded-3xl"></div>
        
        {/* 천사 헤더 */}
        <div className="relative p-8 bg-gradient-to-r from-blue-500 to-sky-400 text-white rounded-t-3xl">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500/90 to-sky-400/90 rounded-t-3xl"></div>
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm border border-blue-300">
                <span className="text-3xl">👼</span>
              </div>
              <div>
                <h2 className="text-2xl font-bold drop-shadow-lg">✨ 천사 정보 - Angel Profile</h2>
                <p className="text-blue-100 drop-shadow-sm">희망의 학습 여정을 관리하세요</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-blue-200 transition-colors duration-200 p-2 hover:bg-white/10 rounded-xl"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          {/* 천사 장식 */}
          <div className="absolute top-4 right-20 text-white opacity-30 animate-pulse">✨</div>
          <div className="absolute bottom-4 left-20 text-white opacity-20 animate-pulse">🌟</div>
        </div>

        <div className="relative p-8 space-y-8">
          {/* 천사 기본 정보 */}
          <div className="bg-gradient-to-r from-blue-100/50 to-sky-100/50 rounded-2xl p-6 border border-blue-200">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-blue-600">🌟 기본 천사 정보</h3>
              {!isEditing ? (
                <button
                  onClick={handleEdit}
                  className="bg-gradient-to-r from-blue-500 to-blue-400 text-white px-4 py-2 rounded-xl hover:from-blue-400 hover:to-blue-300 transition-all duration-300 font-medium transform hover:scale-105 shadow-lg hover:shadow-blue-500/50"
                >
                  ✏️ 편집
                </button>
              ) : (
                <div className="flex space-x-2">
                  <button
                    onClick={handleSave}
                    className="bg-gradient-to-r from-green-500 to-green-400 text-white px-4 py-2 rounded-xl hover:from-green-400 hover:to-green-300 transition-all duration-300 font-medium transform hover:scale-105 shadow-lg hover:shadow-green-500/50"
                  >
                    ✅ 저장
                  </button>
                  <button
                    onClick={handleCancel}
                    className="bg-gradient-to-r from-gray-500 to-gray-400 text-white px-4 py-2 rounded-xl hover:from-gray-400 hover:to-gray-300 transition-all duration-300 font-medium transform hover:scale-105 shadow-lg hover:shadow-gray-500/50"
                  >
                    ❌ 취소
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-blue-600 font-medium mb-2">📧 이메일</label>
                  <div className="bg-blue-50 bg-opacity-50 border border-blue-200 rounded-xl px-4 py-3 text-blue-600">
                    {currentUser.email}
                  </div>
                </div>
                
                <div>
                  <label className="block text-blue-600 font-medium mb-2">👼 이름</label>
                  {isEditing ? (
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full border border-blue-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="천사의 이름을 입력하세요"
                    />
                  ) : (
                    <div className="bg-blue-50 bg-opacity-50 border border-blue-200 rounded-xl px-4 py-3 text-blue-600">
                      {currentUser.name || '미설정'}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-blue-600 font-medium mb-2">📱 휴대폰</label>
                  {isEditing ? (
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full border border-blue-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="휴대폰 번호를 입력하세요"
                    />
                  ) : (
                    <div className="bg-blue-50 bg-opacity-50 border border-blue-200 rounded-xl px-4 py-3 text-blue-600">
                      {currentUser.phone || '미설정'}
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-blue-600 font-medium mb-2">🏠 주소</label>
                  {isEditing ? (
                    <input
                      type="text"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      className="w-full border border-blue-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="거주지 주소를 입력하세요"
                    />
                  ) : (
                    <div className="bg-blue-50 bg-opacity-50 border border-blue-200 rounded-xl px-4 py-3 text-blue-600">
                      {currentUser.address || '미설정'}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-blue-600 font-medium mb-2">🏫 학교</label>
                  {isEditing ? (
                    <input
                      type="text"
                      name="school"
                      value={formData.school}
                      onChange={handleInputChange}
                      className="w-full border border-blue-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="학교명을 입력하세요"
                    />
                  ) : (
                    <div className="bg-blue-50 bg-opacity-50 border border-blue-200 rounded-xl px-4 py-3 text-blue-600">
                      {currentUser.school || '미설정'}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-blue-600 font-medium mb-2">📅 가입일</label>
                  <div className="bg-blue-50 bg-opacity-50 border border-blue-200 rounded-xl px-4 py-3 text-blue-600">
                    {currentUser.createdAt ? new Date(currentUser.createdAt).toLocaleDateString('ko-KR') : '알 수 없음'}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 천사 등급 및 축복 포인트 */}
          <div className="bg-gradient-to-r from-sky-100/50 to-indigo-100/50 rounded-2xl p-6 border border-sky-200">
            <h3 className="text-xl font-bold text-sky-600 mb-6">👑 천사 등급 & 축복 포인트</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-sky-400 to-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <span className="text-3xl text-white">{currentTier.icon}</span>
                </div>
                <h4 className="font-bold text-sky-600 text-lg">{currentTier.name}</h4>
                <p className="text-sky-500 text-sm">{currentTier.description}</p>
              </div>

              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-indigo-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <span className="text-3xl text-white">✨</span>
                </div>
                <h4 className="font-bold text-blue-600 text-lg">{currentUser.totalPoints || 0}P</h4>
                <p className="text-blue-500 text-sm">보유 축복 포인트</p>
              </div>

              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-indigo-400 to-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <span className="text-3xl text-white">🎯</span>
                </div>
                <h4 className="font-bold text-indigo-600 text-lg">{currentUser.examCount || 0}회</h4>
                <p className="text-indigo-500 text-sm">천사 시험 횟수</p>
              </div>
            </div>
          </div>

          {/* 천사 활동 통계 */}
          <div className="bg-gradient-to-r from-green-100/50 to-blue-100/50 rounded-2xl p-6 border border-green-200">
            <h3 className="text-xl font-bold text-green-600 mb-6">📊 천사 활동 통계</h3>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-white/60 rounded-xl border border-green-200">
                <div className="text-2xl font-bold text-green-600">{currentUser.examCount || 0}</div>
                <div className="text-green-500 text-sm">총 시험 횟수</div>
              </div>
              
              <div className="text-center p-4 bg-white/60 rounded-xl border border-blue-200">
                <div className="text-2xl font-bold text-blue-600">{currentUser.averageScore || 0}점</div>
                <div className="text-blue-500 text-sm">평균 축복 점수</div>
              </div>
              
              <div className="text-center p-4 bg-white/60 rounded-xl border border-sky-200">
                <div className="text-2xl font-bold text-sky-600">{currentUser.streak || 0}일</div>
                <div className="text-sky-500 text-sm">연속 희망 일수</div>
              </div>
              
              <div className="text-center p-4 bg-white/60 rounded-xl border border-indigo-200">
                <div className="text-2xl font-bold text-indigo-600">{currentUser.badgesEarned || 0}개</div>
                <div className="text-indigo-500 text-sm">획득 천사 배지</div>
              </div>
            </div>
          </div>

          {/* 천사 권한 정보 */}
          <div className="bg-gradient-to-r from-purple-100/50 to-pink-100/50 rounded-2xl p-6 border border-purple-200">
            <h3 className="text-xl font-bold text-purple-600 mb-6">🔑 천사 권한 정보</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-white/60 rounded-xl border border-purple-200">
                <div>
                  <h4 className="font-bold text-purple-600">사용자 권한</h4>
                  <p className="text-purple-500 text-sm">{userRoles[currentUser.role]?.description || '기본 천사 권한'}</p>
                </div>
                <span className="bg-purple-100 text-purple-600 px-3 py-1 rounded-full text-sm font-medium">
                  {userRoles[currentUser.role]?.name || '천사'}
                </span>
              </div>
              
              <div className="flex items-center justify-between p-4 bg-white/60 rounded-xl border border-pink-200">
                <div>
                  <h4 className="font-bold text-pink-600">멤버십 혜택</h4>
                  <p className="text-pink-500 text-sm">월 {currentTier.monthlyQuota}장까지 천사 채점 가능</p>
                </div>
                <span className="bg-pink-100 text-pink-600 px-3 py-1 rounded-full text-sm font-medium">
                  {currentTier.name}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* 천사 푸터 */}
        <div className="relative p-6 bg-gradient-to-r from-blue-50/80 to-sky-50/80 rounded-b-3xl border-t border-blue-200">
          <div className="text-center text-blue-500 text-sm">
            ✨ 천사의 축복이 함께하는 학습 여정을 응원합니다! 🌟
          </div>
        </div>
      </div>
    </div>
  );
}