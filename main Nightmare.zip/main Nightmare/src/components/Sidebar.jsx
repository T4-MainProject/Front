// ============================================
// 💀 Dark Horror Footer.jsx - 어둠의 발끝
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const footerSections = [
  {
    title: '악마 서비스',
    links: [
      { name: 'AI 자동 심판', href: '#' },
      { name: '대량 저주 처리', href: '#' },
      { name: '지옥 API 서비스', href: '#' },
      { name: '어둠의 교육기관 솔루션', href: '#' }
    ]
  },
  {
    title: '지옥 지원',
    links: [
      { name: '악마 사용자 가이드', href: '#' },
      { name: '저주받은 질문들', href: '#' },
      { name: '어둠의 기술 지원', href: '#' },
      { name: '지옥 문의하기', href: '#' }
    ]
  },
  {
    title: '어둠의 회사',
    links: [
      { name: '지옥 소개', href: '#' },
      { name: '악마 채용 정보', href: '#' },
      { name: '어둠의 보도자료', href: '#' },
      { name: '사탄의 파트너십', href: '#' }
    ]
  }
];

const socialLinks = [
  { name: 'DarkTwitter', icon: '🦅', href: '#', color: 'hover:bg-red-700' },
  { name: 'HellBook', icon: '📖', href: '#', color: 'hover:bg-red-800' },
  { name: 'SoulGram', icon: '📸', href: '#', color: 'hover:bg-red-600' },
  { name: 'DevilIn', icon: '💼', href: '#', color: 'hover:bg-black' },
  { name: 'DarkTube', icon: '📺', href: '#', color: 'hover:bg-red-900' }
];

export default function Footer() {
  const footerRef = useRef(null);
  const sectionsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 어둠의 푸터 섹션들 애니메이션 (더 극적으로)
      gsap.fromTo(sectionsRef.current,
        {
          y: 80,
          opacity: 0,
          scale: 0.9,
          filter: "blur(5px)"
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          filter: "blur(0px)",
          duration: 1.0,
          stagger: 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: footerRef.current,
            start: "top 90%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, footerRef);

    return () => ctx.revert();
  }, []);

  return (
    <footer ref={footerRef} className="bg-gradient-to-br from-black via-gray-900 to-red-900 text-red-300 relative overflow-hidden">
      {/* 어둠의 배경 장식 */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-gradient-to-br from-red-600/20 to-red-800/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-gradient-to-br from-red-700/15 to-black/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-br from-red-500/10 to-gray-900/15 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* 추가 어둠 레이어 */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-gray-900/40 to-red-900/30"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,black_40%)]"></div>

      {/* 움직이는 어둠 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-2 h-2 bg-red-500/30 rounded-full animate-pulse"></div>
        <div className="absolute top-32 right-1/3 w-1 h-1 bg-red-400/40 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-24 left-1/2 w-1 h-1 bg-gray-500/30 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-red-600/40 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-red-300/30 rounded-full animate-pulse delay-1500"></div>
        <div className="absolute top-1/3 left-1/5 w-1 h-1 bg-red-500/40 rounded-full animate-pulse delay-300"></div>
      </div>

      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
          {/* 어둠의 회사 정보 */}
          <div 
            ref={el => sectionsRef.current[0] = el}
            className="lg:col-span-2"
          >
            <div className="flex items-center space-x-4 mb-6">
              <div className="relative group">
                <div className="w-14 h-14 bg-gradient-to-br from-red-600 via-black to-red-800 rounded-2xl flex items-center justify-center shadow-2xl shadow-red-500/50 group-hover:scale-110 transition-transform duration-300 border border-red-700/50">
                  <span className="text-red-300 font-bold text-2xl drop-shadow-lg">💀</span>
                </div>
                <div className="absolute inset-0 bg-gradient-to-br from-red-500/40 via-black/20 to-red-700/40 rounded-2xl blur opacity-50 group-hover:opacity-70 transition-opacity duration-300"></div>
              </div>
              <div>
                <h3 className="text-2xl font-bold bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent drop-shadow-lg">
                  DarkCheck
                </h3>
                <p className="text-red-500/80 text-sm font-medium tracking-wide">
                  👹 AI POWERED HELL SYSTEM
                </p>
              </div>
            </div>
            
            <p className="text-red-400/80 mb-6 leading-relaxed max-w-md drop-shadow-sm">
              첨단 악마 기술로 지옥의 미래를 만들어가는 DarkCheck. 
              정확하고 빠른 자동 심판으로 더 나은 저주 경험을 제공합니다.
            </p>
            
            {/* 어둠의 소셜 미디어 */}
            <div className="flex space-x-3 mb-8">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className={`w-12 h-12 bg-red-900/50 backdrop-blur-sm ${social.color} rounded-xl flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-lg hover:shadow-red-500/30 group border border-red-800/50 hover:border-red-600`}
                  title={social.name}
                >
                  <span className="text-xl group-hover:scale-110 transition-transform duration-200 drop-shadow-sm">
                    {social.icon}
                  </span>
                </a>
              ))}
            </div>

            {/* 어둠의 연락처 정보 */}
            <div className="space-y-3 text-sm text-red-400/80">
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-red-900/60 rounded-lg flex items-center justify-center group-hover:bg-red-700 transition-colors duration-200 border border-red-800/50">
                  <span>📧</span>
                </div>
                <div>
                  <p className="text-red-300 font-medium">hellsupport@darkcheck.co.kr</p>
                  <p className="text-xs text-red-600/70">악마 지원 이메일</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-red-900/60 rounded-lg flex items-center justify-center group-hover:bg-red-700 transition-colors duration-200 border border-red-800/50">
                  <span>📞</span>
                </div>
                <div>
                  <p className="text-red-300 font-medium">02-6666-6666</p>
                  <p className="text-xs text-red-600/70">지옥시간 00:00 - 23:59</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-red-900/60 rounded-lg flex items-center justify-center group-hover:bg-red-700 transition-colors duration-200 border border-red-800/50">
                  <span>📍</span>
                </div>
                <div>
                  <p className="text-red-300 font-medium">지옥특별시 어둠구 저주로 666</p>
                  <p className="text-xs text-red-600/70">DarkCheck 지옥 본사</p>
                </div>
              </div>
            </div>
          </div>

          {/* 어둠의 링크 섹션들 */}
          {footerSections.map((section, index) => (
            <div 
              key={index}
              ref={el => sectionsRef.current[index + 1] = el}
              className="lg:col-span-1"
            >
              <h4 className="text-lg font-bold mb-6 text-red-300 relative drop-shadow-sm">
                {section.title}
                <div className="absolute bottom-0 left-0 w-8 h-0.5 bg-gradient-to-r from-red-500 to-red-700 rounded-full"></div>
              </h4>
              <ul className="space-y-4">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a 
                      href={link.href}
                      className="text-red-400/80 hover:text-red-300 transition-all duration-200 hover:translate-x-2 transform inline-block relative group py-1"
                    >
                      <span className="relative z-10 drop-shadow-sm">{link.name}</span>
                      <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-red-500 to-red-700 group-hover:w-full transition-all duration-300"></span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* 어둠의 구분선 */}
        <div className="my-12">
          <div className="h-px bg-gradient-to-r from-transparent via-red-800/50 to-transparent"></div>
        </div>
        
        {/* 어둠의 하단 정보 */}
        <div 
          ref={el => sectionsRef.current[4] = el}
          className="flex flex-col lg:flex-row justify-between items-center text-sm text-red-400/80"
        >
          <div className="space-y-2 lg:space-y-0 text-center lg:text-left mb-6 lg:mb-0">
            <p className="font-medium drop-shadow-sm">© 2025 DarkCheck Co., Ltd. All souls reserved.</p>
            <p className="text-xs">
              악마등록번호: 666-66-66666 | 대표: 👹 김악마 | 지옥판매업신고: 2024-지옥어둠구-6666
            </p>
          </div>
          
          <div className="flex flex-wrap justify-center lg:justify-end gap-6">
            <a href="#" className="hover:text-red-300 transition-colors duration-200 relative group">
              <span>저주 이용약관</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-red-500 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-red-300 transition-colors duration-200 relative group font-semibold">
              <span>영혼정보처리방침</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-red-600 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-red-300 transition-colors duration-200 relative group">
              <span>저주쿠키정책</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-red-700 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-red-300 transition-colors duration-200 relative group">
              <span>지옥사이트맵</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-red-800 group-hover:w-full transition-all duration-300"></span>
            </a>
          </div>
        </div>

        {/* 어둠의 인증 마크들 */}
        <div 
          ref={el => sectionsRef.current[5] = el}
          className="mt-12 pt-8 border-t border-red-800/50 flex flex-wrap justify-center lg:justify-start items-center gap-4 text-xs text-red-500/80"
        >
          <div className="flex items-center space-x-2 bg-red-900/50 backdrop-blur-sm px-4 py-2 rounded-xl border border-red-800/50 hover:border-red-600 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🔒</span>
            <span className="text-red-300">어둠의 보안인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-red-900/50 backdrop-blur-sm px-4 py-2 rounded-xl border border-red-800/50 hover:border-red-600 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">✅</span>
            <span className="text-red-300">영혼정보보호 인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-red-900/50 backdrop-blur-sm px-4 py-2 rounded-xl border border-red-800/50 hover:border-red-600 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🏆</span>
            <span className="text-red-300">ISO 666 인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-red-900/50 backdrop-blur-sm px-4 py-2 rounded-xl border border-red-800/50 hover:border-red-600 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🛡️</span>
            <span className="text-red-300">HELL 준수</span>
          </div>
        </div>

        {/* 어둠의 추가 정보 */}
        <div 
          ref={el => sectionsRef.current[6] = el}
          className="mt-8 text-center"
        >
          <p className="text-xs text-red-500/70 leading-relaxed max-w-2xl mx-auto drop-shadow-sm">
            DarkCheck는 어둠의 기술 혁신을 통해 더 나은 지옥 환경을 만들어가고 있습니다. 
            우리의 악마 AI 기술이 전 세계 어둠의 전달자와 영혼 학습자들에게 저주가 되기를 바랍니다.
          </p>
          
          <div className="mt-6 flex justify-center items-center space-x-2 text-xs text-red-600/80">
            <span>Made with</span>
            <span className="text-red-500 animate-pulse">🖤</span>
            <span>in Hell, Underworld</span>
          </div>
        </div>

        {/* 추가 어둠의 경고 */}
        <div 
          ref={el => sectionsRef.current[7] = el}
          className="mt-8 text-center"
        >
          <div className="inline-flex items-center space-x-2 bg-red-900/40 text-red-400 px-4 py-2 rounded-full text-xs border border-red-800/50">
            <span>⚠️</span>
            <span>이 사이트는 어둠의 세계에서 운영됩니다</span>
          </div>
        </div>
      </div>

      {/* 하단 어둠 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-black to-transparent pointer-events-none"></div>
    </footer>
  );
}