// ============================================
// 💀 Dark Horror AppHeader.jsx - 어둠 속의 헤더
// ============================================
import React, { useState, useEffect } from 'react';

export default function AppHeader({ currentUser, onOpenLogin, onOpenSignup, onLogout, onOpenMyPage }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // 🌑 활성 버튼 상태 관리 (어떤 지옥문이 열려있는지)
  const [activeButton, setActiveButton] = useState(null); // 'login' | 'signup' | null
  
  // 🕳️ 버튼 클릭 상태 관리 (어둠의 클릭 애니메이션용)
  const [clickedButtons, setClickedButtons] = useState({
    login: false,
    signup: false,
    mypage: false
  });

  const handleLogin = () => {
    // 어둠의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, login: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, login: false }));
    }, 200);
    
    // 어둠의 활성 버튼 설정
    setActiveButton('login');
    
    // 지옥의 로그인 문 열기
    if (onOpenLogin) {
      onOpenLogin();
    }
  };

  const handleSignup = () => {
    // 어둠의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, signup: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, signup: false }));
    }, 200);
    
    // 어둠의 활성 버튼 설정
    setActiveButton('signup');
    
    // 영혼 계약 문서 열기
    if (onOpenSignup) {
      onOpenSignup();
    }
  };

  const handleLogout = () => {
    // 영혼 해방 확인
    if (window.confirm('💀 정말 어둠에서 벗어나시겠습니까?')) {
      setActiveButton(null); // 어둠의 활성 상태 초기화
      if (onLogout) {
        onLogout();
      }
    }
  };

  const handleMyPage = () => {
    // 어둠의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, mypage: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, mypage: false }));
    }, 200);
    
    // 영혼의 방 열기
    if (onOpenMyPage) {
      onOpenMyPage();
    }
  };

  // 지옥문이 닫힐 때 어둠의 활성 상태 해제
  useEffect(() => {
    // 영혼 상태가 변경되면 어둠의 활성 버튼 초기화
    if (currentUser) {
      setActiveButton(null);
    }
  }, [currentUser]);

  // 악마의 아바타 이미지 처리
  const getAvatarSrc = (avatar) => {
    if (!avatar) {
      return "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiMzMTMxMzEiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iI0Y4NEY0RiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iI0Y4NEY0RiIvPgo8L3N2Zz4K";
    }
    return avatar;
  };

  // 어둠의 역할 텍스트 변환
  const getRoleText = (role) => {
    switch(role) {
      case 'admin': return '👹 어둠의 지배자';
      case 'teacher': return '🔮 어둠의 전달자';
      case 'student': return '👻 영혼 학습자';
      case 'parent': return '💀 보호령';
      default: return '🌑 어둠의 존재';
    }
  };

  return (
    <header className="bg-gradient-to-r from-black via-gray-900 to-red-900 backdrop-blur-md shadow-2xl shadow-red-500/20 border-b border-red-800/50 sticky top-0 z-50 relative overflow-hidden">
      {/* 어둠의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-gray-900/60 to-red-900/80"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_50%,black_100%)]"></div>
      
      {/* 움직이는 어둠의 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-2 h-2 bg-red-500/30 rounded-full animate-pulse"></div>
        <div className="absolute top-2 right-1/3 w-1 h-1 bg-red-400/40 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1 left-1/2 w-1 h-1 bg-gray-400/30 rounded-full animate-pulse delay-1000"></div>
      </div>

      <div className="container mx-auto flex items-center justify-between py-4 px-4 lg:px-6 relative z-10">
        {/* 어둠의 로고 영역 */}
        <div className="flex items-center space-x-4">
          <div className="relative group">
            <div className="w-12 h-12 bg-gradient-to-br from-red-600 via-black to-red-800 rounded-xl flex items-center justify-center shadow-lg shadow-red-500/50 group-hover:shadow-xl group-hover:shadow-red-500/70 transition-all duration-300 group-hover:scale-105 border border-red-700/50">
              <span className="text-red-300 font-bold text-xl drop-shadow-lg">💀</span>
            </div>
            <div className="absolute inset-0 bg-gradient-to-br from-red-500/40 via-black/20 to-red-700/40 rounded-xl blur opacity-60 group-hover:opacity-80 transition-opacity duration-300"></div>
          </div>
          
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-red-400 via-red-500 to-red-600 bg-clip-text text-transparent drop-shadow-lg">
              DarkCheck
            </h1>
            <p className="text-xs text-red-400/80 font-medium tracking-wide drop-shadow-sm">
              👹 AI 악마 심판 시스템
            </p>
          </div>
        </div>

        {/* 어둠의 우측 상태 표시기 - 데스크탑 */}
        <div className="hidden lg:flex items-center space-x-6 flex-1 justify-end mr-8">
          <div className="flex items-center space-x-2 bg-gradient-to-r from-red-900/50 to-black/70 border border-red-700/50 px-4 py-2 rounded-full backdrop-blur-sm">
            <div className="relative">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
              <div className="absolute inset-0 w-3 h-3 bg-red-500 rounded-full animate-ping opacity-40"></div>
            </div>
            <span className="text-sm font-medium text-red-400">🔥 지옥 운영중</span>
          </div>
          
          <div className="text-sm text-red-300 bg-black/60 px-3 py-1 rounded-full border border-red-800/50">
            <span className="font-medium">악마의 정확도</span>
            <span className="ml-2 text-red-400 font-bold">99.9%</span>
          </div>
        </div>

        {/* 어둠의 우측 버튼들 */}
        <div className="flex items-center space-x-4">
          {/* 어둠의 데스크탑 버튼들 */}
          <div className="hidden md:flex items-center space-x-3">
            {currentUser ? (
              // 영혼이 결속된 상태
              <>
                {/* 영혼 정보 */}
                <div className="flex items-center space-x-3 text-sm">
                  <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-red-600/70 shadow-lg shadow-red-500/50">
                    <img 
                      src={getAvatarSrc(currentUser.avatar)} 
                      alt={currentUser.name || '어둠의 존재'}
                      className="w-full h-full object-cover filter grayscale contrast-150"
                      onError={(e) => {
                        e.target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiMzMTMxMzEiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iI0Y4NEY0RiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iI0Y4NEY0RiIvPgo8L3N2Zz4K";
                      }}
                    />
                  </div>
                  <div className="text-red-300">
                    <span className="font-medium drop-shadow-sm">{currentUser.name || '어둠의 존재'}</span>
                    <span className="ml-2 text-xs bg-red-900/70 text-red-400 px-2 py-1 rounded-full border border-red-700/50">
                      {getRoleText(currentUser.role)}
                    </span>
                  </div>
                </div>

                {/* 영혼의 방 버튼 */}
                <button
                  onClick={handleMyPage}
                  className={`font-medium px-4 py-2 rounded-lg transition-all duration-200 relative group border border-red-800/50 ${
                    clickedButtons.mypage 
                      ? 'text-red-300 bg-red-900/80 transform scale-95 shadow-lg shadow-red-500/50' 
                      : 'text-red-400 hover:text-red-300 hover:bg-red-900/60 hover:shadow-lg hover:shadow-red-500/40'
                  }`}
                >
                  🖤 영혼의 방
                  <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-red-500 group-hover:w-full transition-all duration-300"></span>
                </button>
                
                {/* 영혼 해방 버튼 */}
                <button
                  onClick={handleLogout}
                  className="bg-gradient-to-r from-red-800 to-black text-red-300 font-medium px-6 py-2 rounded-lg shadow-md shadow-red-500/50 hover:shadow-lg hover:shadow-red-500/70 transition-all duration-300 hover:scale-105 relative overflow-hidden group border border-red-700/50"
                >
                  <span className="relative z-10">💀 영혼 해방</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-red-400/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-500"></div>
                </button>
              </>
            ) : (
              // 영혼이 결속되지 않은 상태
              <>
                <button
                  onClick={handleLogin}
                  className={`font-medium px-6 py-3 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                    activeButton === 'login'
                      ? 'bg-gradient-to-r from-red-800 via-red-700 to-black border-red-600 text-red-300 shadow-lg shadow-red-500/50'
                      : clickedButtons.login 
                      ? 'bg-gradient-to-r from-red-800 via-red-700 to-black border-red-600 text-red-300 transform scale-95 shadow-lg shadow-red-500/50'
                      : 'bg-black/80 border-red-700/50 text-red-400 hover:bg-gradient-to-r hover:from-red-800 hover:via-red-700 hover:to-black hover:border-red-600 hover:text-red-300 hover:scale-105 hover:shadow-lg hover:shadow-red-500/50'
                  }`}
                >
                  {(activeButton === 'login' || clickedButtons.login) && (
                    <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 via-red-500/20 to-black/20 animate-pulse"></div>
                  )}
                  <span className="relative z-10">🔥 지옥문 열기</span>
                </button>
                
                <button
                  onClick={handleSignup}
                  className={`font-medium px-6 py-3 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                    activeButton === 'signup'
                      ? 'bg-gradient-to-r from-red-800 via-red-700 to-black border-red-600 text-red-300 shadow-lg shadow-red-500/50'
                      : clickedButtons.signup 
                      ? 'bg-gradient-to-r from-red-800 via-red-700 to-black border-red-600 text-red-300 transform scale-95 shadow-lg shadow-red-500/50'
                      : 'bg-black/80 border-red-700/50 text-red-400 hover:bg-gradient-to-r hover:from-red-800 hover:via-red-700 hover:to-black hover:border-red-600 hover:text-red-300 hover:scale-105 hover:shadow-lg hover:shadow-red-500/50'
                  }`}
                >
                  {(activeButton === 'signup' || clickedButtons.signup) && (
                    <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 via-red-500/20 to-black/20 animate-pulse"></div>
                  )}
                  <span className="relative z-10">👹 영혼 계약</span>
                </button>
              </>
            )}
          </div>

          {/* 어둠의 모바일 메뉴 버튼 */}
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-red-900/60 transition-colors duration-200 text-red-400 border border-red-800/50"
            aria-label="어둠의 메뉴 토글"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* 어둠의 모바일 메뉴 */}
      {isMenuOpen && (
        <div className="md:hidden bg-gradient-to-b from-black to-red-900 border-t border-red-800/50 py-4 px-4 shadow-lg shadow-red-500/30 backdrop-blur-sm">
          {/* 어둠의 모바일 상태 표시 */}
          <div className="flex items-center space-x-2 bg-red-900/50 px-3 py-2 rounded-lg mb-4 border border-red-700/50">
            <div className="relative">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              <div className="absolute inset-0 w-2 h-2 bg-red-500 rounded-full animate-ping opacity-30"></div>
            </div>
            <span className="text-sm text-red-400 font-medium">🔥 지옥 운영중</span>
            <span className="text-xs text-red-500 ml-auto">악마의 정확도 99.9%</span>
          </div>
          
          {currentUser ? (
            // 영혼이 결속된 상태 - 모바일
            <div className="space-y-4">
              {/* 영혼 정보 */}
              <div className="flex items-center space-x-3 bg-black/60 px-4 py-3 rounded-lg border border-red-800/50">
                <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-red-600/70 shadow-lg shadow-red-500/50">
                  <img 
                    src={getAvatarSrc(currentUser.avatar)} 
                    alt={currentUser.name || '어둠의 존재'}
                    className="w-full h-full object-cover filter grayscale contrast-150"
                    onError={(e) => {
                      e.target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiMzMTMxMzEiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iI0Y4NEY0RiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iI0Y4NEY0RiIvPgo8L3N2Zz4K";
                    }}
                  />
                </div>
                <div>
                  <div className="font-medium text-red-300">{currentUser.name || '어둠의 존재'}</div>
                  <div className="text-sm text-red-500">
                    {getRoleText(currentUser.role)}
                  </div>
                </div>
              </div>

              {/* 어둠의 모바일 버튼들 */}
              <div className="space-y-3">
                <button
                  onClick={handleMyPage}
                  className={`w-full text-left font-medium py-3 px-4 rounded-lg transition-all duration-200 border border-red-800/50 ${
                    clickedButtons.mypage 
                      ? 'text-red-300 bg-red-900/80 transform scale-95 shadow-lg shadow-red-500/50' 
                      : 'text-red-400 hover:text-red-300 hover:bg-red-900/60 hover:shadow-lg hover:shadow-red-500/40'
                  }`}
                >
                  🖤 영혼의 방
                </button>
                
                <button
                  onClick={handleLogout}
                  className="w-full bg-gradient-to-r from-red-800 to-black text-red-300 font-medium py-3 px-4 rounded-lg shadow-md shadow-red-500/50 hover:shadow-lg hover:shadow-red-500/70 transition-all duration-300 border border-red-700/50"
                >
                  💀 영혼 해방
                </button>
              </div>
            </div>
          ) : (
            // 영혼이 결속되지 않은 상태 - 모바일
            <div className="space-y-3">
              <button
                onClick={handleLogin}
                className={`w-full font-medium py-3 px-4 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                  activeButton === 'login'
                    ? 'bg-gradient-to-r from-red-800 via-red-700 to-black border-red-600 text-red-300 shadow-lg shadow-red-500/50'
                    : clickedButtons.login 
                    ? 'bg-gradient-to-r from-red-800 via-red-700 to-black border-red-600 text-red-300 transform scale-95 shadow-lg shadow-red-500/50'
                    : 'bg-black/80 border-red-700/50 text-red-400 hover:bg-gradient-to-r hover:from-red-800 hover:via-red-700 hover:to-black hover:border-red-600 hover:text-red-300 hover:shadow-lg hover:shadow-red-500/50'
                }`}
              >
                {(activeButton === 'login' || clickedButtons.login) && (
                  <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 via-red-500/20 to-black/20 animate-pulse"></div>
                )}
                <span className="relative z-10">🔥 지옥문 열기</span>
              </button>
              
              <button
                onClick={handleSignup}
                className={`w-full font-medium py-3 px-4 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                  activeButton === 'signup'
                    ? 'bg-gradient-to-r from-red-800 via-red-700 to-black border-red-600 text-red-300 shadow-lg shadow-red-500/50'
                    : clickedButtons.signup 
                    ? 'bg-gradient-to-r from-red-800 via-red-700 to-black border-red-600 text-red-300 transform scale-95 shadow-lg shadow-red-500/50'
                    : 'bg-black/80 border-red-700/50 text-red-400 hover:bg-gradient-to-r hover:from-red-800 hover:via-red-700 hover:to-black hover:border-red-600 hover:text-red-300 hover:shadow-lg hover:shadow-red-500/50'
                }`}
              >
                {(activeButton === 'signup' || clickedButtons.signup) && (
                  <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 via-red-500/20 to-black/20 animate-pulse"></div>
                )}
                <span className="relative z-10">👹 영혼 계약</span>
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
}