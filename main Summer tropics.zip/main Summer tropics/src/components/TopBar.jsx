// ============================================
// 🏝️ Tropical Paradise TopBar.jsx - 파라다이스 상단 공지
// ============================================
// src/components/TopBar.jsx

import React from 'react';

export default function TopBar() {
  return (
    <div className="bg-gradient-to-r from-emerald-400/80 via-cyan-300 to-sky-400/80 border-b border-white/30 relative overflow-hidden">
      {/* 파라다이스 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-r from-white/30 via-emerald-100/40 to-white/30"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_70%,rgba(16,185,129,0.1)_100%)]"></div>
      
      {/* 움직이는 크리스탈 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1 left-1/4 w-1 h-1 bg-emerald-400/40 rounded-full animate-pulse shadow-sm"></div>
        <div className="absolute top-2 right-1/3 w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse delay-700 shadow-sm"></div>
        <div className="absolute bottom-1 left-1/2 w-1 h-1 bg-sky-400/30 rounded-full animate-pulse delay-1000 shadow-sm"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-teal-500/40 rounded-full animate-pulse delay-500 shadow-sm"></div>
      </div>

      <div className="container mx-auto px-4 py-2 text-center relative z-10">
        <div className="flex items-center justify-center space-x-2 text-sm">
          <span className="animate-pulse text-emerald-600 drop-shadow-lg">🌺</span>
          <span className="font-medium text-emerald-700 drop-shadow-sm">
            파라다이스 서비스 오픈! AI 자동 채점을 무료로 체험해보세요
          </span>
          <span className="animate-pulse text-cyan-600 drop-shadow-lg">🏝️</span>
        </div>
      </div>

      {/* 하단 크리스탈 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-emerald-400/50 to-transparent shadow-sm"></div>
    </div>
  );
}