// ============================================
// ✨ Angelic Light Hero.jsx - 희망 속의 영웅 섹션
// ============================================
import React, { useLayoutEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function Hero({ onNext }) {
  const heroRef = useRef(null);
  const titleRef = useRef(null);
  const subtitleRef = useRef(null);
  const buttonsRef = useRef(null);
  const bgRef = useRef(null);
  const particlesRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 천국의 패럴랙스 효과
      gsap.to(bgRef.current, {
        yPercent: 50,
        ease: "none",
        scrollTrigger: {
          trigger: heroRef.current,
          start: "top bottom",
          end: "bottom top",
          scrub: true
        }
      });

      // 빛의 텍스트 애니메이션
      const tl = gsap.timeline();
      
      tl.fromTo(titleRef.current, 
        { 
          y: 150, 
          opacity: 0, 
          scale: 0.6,
          rotationX: -120,
          filter: "blur(20px)"
        },
        { 
          y: 0, 
          opacity: 1, 
          scale: 1,
          rotationX: 0,
          filter: "blur(0px)",
          duration: 1.8, 
          ease: "power4.out" 
        }
      )
      .fromTo(subtitleRef.current,
        { y: 80, opacity: 0, filter: "blur(10px)" },
        { y: 0, opacity: 1, filter: "blur(0px)", duration: 1.2, ease: "power3.out" },
        "-=0.8"
      )
      .fromTo(buttonsRef.current,
        { y: 60, opacity: 0, scale: 0.8, rotationY: 90 },
        { y: 0, opacity: 1, scale: 1, rotationY: 0, duration: 1.0, ease: "back.out(2)" },
        "-=0.6"
      );

      // 천사 파티클 애니메이션
      particlesRef.current.forEach((particle, index) => {
        if (particle) {
          gsap.to(particle, {
            y: "random(-40, 40)",
            x: "random(-40, 40)",
            rotation: "random(-360, 360)",
            scale: "random(0.5, 1.5)",
            duration: "random(3, 6)",
            repeat: -1,
            yoyo: true,
            ease: "sine.inOut",
            delay: index * 0.2
          });
        }
      });

    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={heroRef}
      className="relative min-h-screen bg-gradient-to-br from-white via-sky-50 to-blue-100 overflow-hidden flex items-center"
    >
      {/* 천국의 배경 요소들 */}
      <div ref={bgRef} className="absolute inset-0 overflow-hidden">
        {/* 빛의 그라데이션 블러 */}
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-br from-blue-300/30 to-sky-200/50 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-br from-indigo-200/30 to-blue-300/40 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-br from-sky-200/20 to-white/40 rounded-full blur-3xl animate-pulse delay-500"></div>
        
        {/* 빛의 추가 레이어 */}
        <div className="absolute inset-0 bg-white/60"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_20%,rgba(255,255,255,0.8)_80%)]"></div>
        
        {/* 떠다니는 천사 파티클들 */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            ref={el => particlesRef.current[i] = el}
            className={`absolute w-6 h-6 bg-gradient-to-br from-blue-400 to-sky-300 rounded-full opacity-30 blur-sm shadow-lg shadow-blue-500/50`}
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
          ></div>
        ))}

        {/* 추가 빛 효과들 */}
        {[...Array(6)].map((_, i) => (
          <div
            key={`light-${i}`}
            className={`absolute w-8 h-8 bg-sky-200/40 rounded-full blur-lg animate-pulse`}
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.5}s`
            }}
          ></div>
        ))}
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center min-h-screen py-20">
          {/* 빛의 텍스트 콘텐츠 */}
          <div className="flex-1 lg:pr-12 text-center lg:text-left">
            {/* 천국의 배지 */}
            <div 
              data-aos="fade-down" 
              data-aos-delay="100"
              className="inline-flex items-center space-x-3 bg-gradient-to-r from-blue-100/50 to-white/70 border border-blue-300/50 text-blue-600 px-6 py-3 rounded-full text-sm font-semibold mb-8 shadow-lg shadow-blue-500/30 hover:shadow-xl hover:shadow-blue-500/50 transition-all duration-300 hover:scale-105 backdrop-blur-sm"
            >
              <div className="relative">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <div className="absolute inset-0 w-2 h-2 bg-blue-500 rounded-full animate-ping opacity-75"></div>
              </div>
              <span>👼 AI 천사 축복 시스템</span>
              <span className="bg-gradient-to-r from-blue-500 to-sky-500 text-white px-2 py-1 rounded-full text-xs font-bold animate-pulse border border-blue-300">
                BLESSED
              </span>
            </div>
            
            {/* 빛의 메인 타이틀 */}
            <h1 
              ref={titleRef}
              className="text-5xl md:text-6xl lg:text-7xl font-black leading-tight mb-6 drop-shadow-2xl"
            >
              <span className="bg-gradient-to-r from-blue-500 via-sky-500 to-blue-600 bg-clip-text text-transparent drop-shadow-2xl">
                AI 천사의
              </span>
              <br />
              <span className="text-blue-700 drop-shadow-lg">
                따뜻한 축복,
              </span>
              <br />
              <span className="bg-gradient-to-r from-sky-500 to-blue-600 bg-clip-text text-transparent">
                천국 같은 정확성
              </span>
            </h1>
            
            {/* 빛의 서브타이틀 */}
            <p 
              ref={subtitleRef}
              className="text-xl md:text-2xl text-sky-700 mb-10 leading-relaxed max-w-3xl mx-auto lg:mx-0 drop-shadow-lg"
            >
              <span className="font-semibold text-blue-600">YOLO8 천사의 눈</span>, 
              <span className="font-semibold text-indigo-600"> OCR 지혜 추출</span>, 
              <span className="font-semibold text-sky-600"> GPT 천국 해설</span>이 
              결합된 차세대 천사 축복 솔루션
            </p>

            {/* 천국의 버튼들 */}
            <div 
              ref={buttonsRef}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12"
            >
              <button 
                onClick={onNext}
                className="group bg-gradient-to-r from-blue-500 to-sky-500 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-xl shadow-blue-500/50 hover:shadow-2xl hover:shadow-blue-500/70 transition-all duration-300 hover:scale-105 hover:from-blue-600 hover:to-sky-600 relative overflow-hidden border-2 border-blue-400 hover:border-blue-300"
              >
                <span className="relative z-10 flex items-center justify-center">
                  ✨ 천국문 열기
                  <svg className="ml-2 w-6 h-6 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-blue-300/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
              </button>
            </div>

            {/* 빛의 통계 */}
            <div 
              data-aos="fade-up" 
              data-aos-delay="400"
              className="grid grid-cols-3 gap-8 pt-8 border-t border-blue-200/50"
            >
              <div className="text-center group bg-white/40 p-4 rounded-lg border border-blue-200/30">
                <div className="text-3xl font-black bg-gradient-to-r from-blue-500 to-blue-700 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                  100%
                </div>
                <div className="text-sm text-blue-600 font-medium">천사의 정확도</div>
              </div>
              <div className="text-center group bg-white/40 p-4 rounded-lg border border-blue-200/30">
                <div className="text-3xl font-black bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                  7.77초
                </div>
                <div className="text-sm text-blue-600 font-medium">천국 처리시간</div>
              </div>
              <div className="text-center group bg-white/40 p-4 rounded-lg border border-blue-200/30">
                <div className="text-3xl font-black bg-gradient-to-r from-sky-500 to-blue-600 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                  999+
                </div>
                <div className="text-sm text-blue-600 font-medium">축복받은 시험지</div>
              </div>
            </div>
          </div>

          {/* 빛의 오른쪽 일러스트레이션 */}
          <div className="flex-1 lg:pl-12 mt-12 lg:mt-0">
            <div 
              data-aos="fade-left" 
              data-aos-delay="200"
              className="relative"
            >
              {/* 천국의 메인 카드 */}
              <div className="bg-gradient-to-br from-sky-50 to-white p-8 rounded-3xl shadow-2xl shadow-blue-500/30 transform rotate-3 hover:rotate-0 transition-all duration-700 hover:scale-105 border border-blue-300/50 relative overflow-hidden">
                {/* 카드 내부 빛 글로우 */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-100/20 to-white/80 rounded-3xl"></div>
                
                <div className="relative z-10">
                  {/* 천국의 브라우저 헤더 */}
                  <div className="flex items-center space-x-2 mb-6">
                    <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
                    <div className="w-3 h-3 bg-sky-400 rounded-full animate-pulse delay-100"></div>
                    <div className="w-3 h-3 bg-blue-600 rounded-full animate-pulse delay-200"></div>
                    <div className="flex-1 bg-sky-100 h-6 rounded-full ml-4 border border-blue-200/50"></div>
                  </div>
                  
                  {/* 빛의 콘텐츠 */}
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="h-4 bg-gradient-to-r from-blue-300 to-blue-400 rounded-lg w-3/4 animate-pulse shadow-lg"></div>
                      <div className="h-4 bg-gradient-to-r from-sky-300 to-sky-400 rounded-lg w-1/2 animate-pulse shadow-lg delay-100"></div>
                      <div className="h-4 bg-gradient-to-r from-blue-400 to-indigo-400 rounded-lg w-2/3 animate-pulse shadow-lg delay-200"></div>
                    </div>
                    
                    {/* 천국의 결과 카드 */}
                    <div className="bg-gradient-to-br from-blue-100/50 to-white/80 p-6 rounded-2xl shadow-lg shadow-blue-500/30 border border-blue-300/50 backdrop-blur-sm">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-sm font-bold text-blue-600 flex items-center">
                          <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          축복 완료
                        </span>
                        <span className="text-xs text-blue-600">7.77초</span>
                      </div>
                      <div className="text-4xl font-black bg-gradient-to-r from-blue-500 to-blue-700 bg-clip-text text-transparent drop-shadow-lg">
                        97점
                      </div>
                      <div className="text-sm text-blue-600 mt-2">
                        20문제 중 19문제 정답 ✨
                      </div>
                      <div className="text-xs text-sky-600 mt-1">
                        "훌륭합니다! 계속해서 빛나세요!"
                      </div>
                    </div>
                  </div>
                </div>

                {/* 빛의 추가 효과 */}
                <div className="absolute inset-0 bg-gradient-to-t from-blue-100/20 to-transparent rounded-3xl"></div>
              </div>

              {/* 떠다니는 천사 요소들 */}
              <div className="absolute -top-6 -right-6 w-16 h-16 bg-gradient-to-br from-blue-500 to-sky-500 rounded-2xl flex items-center justify-center shadow-xl shadow-blue-500/50 animate-bounce border-2 border-blue-400">
                <span className="text-white text-2xl">✨</span>
              </div>
              
              <div className="absolute -bottom-6 -left-6 w-16 h-16 bg-gradient-to-br from-sky-400 to-blue-500 rounded-2xl flex items-center justify-center shadow-xl shadow-blue-500/50 animate-pulse border-2 border-blue-300">
                <span className="text-white text-2xl">🌟</span>
              </div>

              {/* 추가 빛 장식 */}
              <div className="absolute top-1/2 -left-8 w-12 h-12 bg-gradient-to-br from-blue-400 to-sky-400 rounded-full flex items-center justify-center shadow-lg shadow-blue-500/40 animate-pulse delay-300">
                <span className="text-white text-lg">👁️</span>
              </div>

              <div className="absolute top-1/4 -right-8 w-12 h-12 bg-gradient-to-br from-indigo-400 to-blue-500 rounded-full flex items-center justify-center shadow-lg shadow-blue-500/40 animate-pulse delay-700">
                <span className="text-white text-lg">⚡</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 빛의 안개 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent"></div>
    </section>
  );
}