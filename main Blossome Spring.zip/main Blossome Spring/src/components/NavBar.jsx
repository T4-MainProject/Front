import React, { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';

const links = [
  { name: '벚꽃 정원 소개', icon: '🌸', href: '#' },
  { name: '로즈 공지', icon: '🌹', href: '#' },
  { name: '벚꽃 게시판', icon: '🌺', href: '#' },
  { name: '정원 문의', icon: '📞', href: '#' }
];

export default function NavBar() {
  const [activeLink, setActiveLink] = useState(0);
  const navRef = useRef(null);
  const linksRef = useRef([]);

  useEffect(() => {
    // 벚꽃 정원 네비게이션 바 전체 애니메이션 (부드럽고 우아하게)
    gsap.fromTo(navRef.current,
      { y: -150, opacity: 0, rotationX: -90 },
      { y: 0, opacity: 1, rotationX: 0, duration: 1.2, ease: "power4.out", delay: 0.2 }
    );

    // 벚꽃 정원 링크들 순차 애니메이션 (벚꽃 느낌으로)
    gsap.fromTo(linksRef.current,
      { y: 80, opacity: 0, scale: 0.5, rotationY: -45 },
      { 
        y: 0, 
        opacity: 1, 
        scale: 1,
        rotationY: 0,
        duration: 0.8,
        stagger: 0.15,
        ease: "back.out(2)",
        delay: 0.6
      }
    );
  }, []);

  const handleLinkClick = (index) => {
    setActiveLink(index);
    
    // 벚꽃 정원 클릭 애니메이션 (부드럽고 우아하게)
    gsap.to(linksRef.current[index], {
      scale: 1.15,
      rotationZ: 5,
      duration: 0.15,
      yoyo: true,
      repeat: 1,
      ease: "power3.inOut"
    });
  };

  return (
    <nav 
      ref={navRef}
      className="bg-gradient-to-r from-pink-300/80 via-rose-200/70 to-pink-300/80 backdrop-blur-md border-b border-white/50 sticky top-16 z-40 shadow-lg shadow-pink-500/30 relative overflow-hidden"
    >
      {/* 벚꽃 정원 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-r from-white/40 via-pink-100/50 to-white/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(253,125,191,0.15)_0%,rgba(251,207,232,0.08)_50%,rgba(244,114,182,0.15)_100%)]"></div>
      
      {/* 흩날리는 벚꽃 꽃잎 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-2 left-1/4 w-2 h-2 bg-pink-400/50 rounded-full animate-pulse shadow-sm transform rotate-45"></div>
        <div className="absolute top-4 right-1/3 w-1 h-1 bg-rose-400/40 rounded-full animate-pulse delay-700 shadow-sm transform rotate-12"></div>
        <div className="absolute bottom-2 left-1/2 w-1 h-1 bg-pink-300/40 rounded-full animate-pulse delay-1000 shadow-sm transform -rotate-12"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-rose-500/50 rounded-full animate-pulse delay-500 shadow-sm"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex space-x-2 py-3 overflow-x-auto scrollbar-hide">
          {links.map((link, index) => (
            <button
              key={link.name}
              ref={el => linksRef.current[index] = el}
              onClick={() => handleLinkClick(index)}
              className={`
                relative flex items-center space-x-3 px-6 py-3 rounded-2xl font-medium 
                transition-all duration-300 whitespace-nowrap group min-w-fit backdrop-blur-sm
                ${activeLink === index 
                  ? 'bg-gradient-to-r from-pink-500 to-rose-500 text-white shadow-lg shadow-pink-500/60 transform scale-105 border-2 border-white/60' 
                  : 'text-pink-700 hover:text-pink-600 hover:bg-white/40 hover:shadow-md hover:shadow-pink-500/40 border border-white/40 hover:border-white/60'
                }
              `}
            >
              <span className={`text-xl transition-all duration-300 drop-shadow-lg ${
                activeLink === index ? 'scale-110 animate-pulse' : 'group-hover:scale-110 group-hover:rotate-12'
              }`}>
                {link.icon}
              </span>
              <span className="font-semibold drop-shadow-sm">{link.name}</span>
              
              {/* 활성 상태 벚꽃 정원 글로우 효과 */}
              {activeLink === index && (
                <div className="absolute inset-0 bg-gradient-to-r from-pink-400 to-rose-400 rounded-2xl blur-lg opacity-50 -z-10 animate-pulse"></div>
              )}

              {/* 호버 로즈 꽃잎 효과 */}
              <div className="absolute inset-0 rounded-2xl overflow-hidden">
                <div className={`absolute inset-0 bg-gradient-to-r from-transparent via-pink-400/25 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ${
                  activeLink !== index ? 'opacity-100' : 'opacity-0'
                }`}></div>
              </div>

              {/* 추가 벚꽃 정원 효과 */}
              <div className="absolute top-0 right-0 w-2 h-2 overflow-hidden rounded-tr-2xl">
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-pink-400/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-pulse"></div>
              </div>

              {/* 벚꽃 정원 언더라인 */}
              <div className={`absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-pink-500 to-rose-500 transform origin-left transition-transform duration-300 shadow-sm ${
                activeLink === index ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'
              }`}></div>
            </button>
          ))}
        </div>
      </div>

      {/* 하단 벚꽃 정원 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-pink-400/60 to-transparent shadow-sm"></div>
    </nav>
  );
}