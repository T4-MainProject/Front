import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function DeepOceanSubjectLearning() {
  const navigate = useNavigate();
  const location = useLocation();
  const { subject } = location.state || {};
  
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [completedLessons, setCompletedLessons] = useState(new Set());

  // 심해 효과 상태
  const [abyssalEffect, setAbyssalEffect] = useState(false);
  const [currentEffect, setCurrentEffect] = useState(false);
  const [bubbleEffect, setBubbleEffect] = useState(false);
  const [deepTide, setDeepTide] = useState(false);

  // 뒤로가기
  const handleBackToAnalysis = () => {
    navigate('/learning-analysis');
  };

  // 심해 효과 트리거
  useEffect(() => {
    const abyssalInterval = setInterval(() => {
      setAbyssalEffect(true);
      setTimeout(() => setAbyssalEffect(false), 500);
    }, 8000 + Math.random() * 15000);

    const currentInterval = setInterval(() => {
      setCurrentEffect(true);
      setTimeout(() => setCurrentEffect(false), 3000);
    }, 12000 + Math.random() * 20000);

    const bubbleInterval = setInterval(() => {
      setBubbleEffect(true);
      setTimeout(() => setBubbleEffect(false), 2000);
    }, 6000 + Math.random() * 12000);

    const tideInterval = setInterval(() => {
      setDeepTide(true);
      setTimeout(() => setDeepTide(false), 4000);
    }, 25000 + Math.random() * 35000);

    return () => {
      clearInterval(abyssalInterval);
      clearInterval(currentInterval);
      clearInterval(bubbleInterval);
      clearInterval(tideInterval);
    };
  }, []);

  // 과목별 학습 과정 데이터 - 심해 버전
  const learningData = {
    영어: {
      title: '영어 집중 학습 - English Deep Ocean',
      subtitle: '체계적인 영어 실력 향상을 위한 맞춤형 심해 커리큘럼',
      color: 'from-cyan-600 to-blue-500',
      bgColor: 'from-slate-900 to-indigo-900',
      icon: '🌊',
      courses: [
        {
          id: 'english-grammar',
          title: '어법/문법 심해 마스터',
          description: '영어 문법의 깊은 구조를 체계적으로 학습합니다',
          duration: '4주 심해 과정',
          level: '중급',
          progress: 0,
          lessons: [
            { id: 1, title: '시제의 완벽한 이해', duration: '45분', type: '이론' },
            { id: 2, title: '조동사 활용의 깊이', duration: '35분', type: '이론' },
            { id: 3, title: '가정법 심해 정복하기', duration: '50분', type: '이론' },
            { id: 4, title: '관계대명사/관계부사의 조화', duration: '40분', type: '이론' },
            { id: 5, title: '실전 문제 심해 풀이 1', duration: '60분', type: '실습' },
            { id: 6, title: '실전 문제 심해 풀이 2', duration: '60분', type: '실습' }
          ],
          expectedImprovement: '+8점'
        },
        {
          id: 'english-reading',
          title: '독해 속도 심해 향상',
          description: '빠르고 정확한 영어 독해 능력을 기릅니다',
          duration: '3주 심해 과정',
          level: '고급',
          progress: 25,
          lessons: [
            { id: 1, title: 'Skimming & Scanning 심해 기법', duration: '40분', type: '이론' },
            { id: 2, title: '주제문 찾기 심해 전략', duration: '35분', type: '이론' },
            { id: 3, title: '빈칸추론 심해 해결법', duration: '45분', type: '이론' },
            { id: 4, title: '실전 독해 심해 연습 1', duration: '50분', type: '실습' },
            { id: 5, title: '실전 독해 심해 연습 2', duration: '50분', type: '실습' }
          ],
          expectedImprovement: '+6점'
        },
        {
          id: 'english-vocabulary',
          title: '어휘력 심해 집중 강화',
          description: '수능 빈출 어휘를 체계적으로 암기합니다',
          duration: '2주 심해 과정',
          level: '초급',
          progress: 60,
          lessons: [
            { id: 1, title: '접두사/접미사 심해 활용', duration: '30분', type: '이론' },
            { id: 2, title: '동의어/반의어 심해 정리', duration: '40분', type: '이론' },
            { id: 3, title: '주제별 어휘 심해 학습', duration: '45분', type: '이론' },
            { id: 4, title: '어휘 심해 암기 테스트', duration: '30분', type: '테스트' }
          ],
          expectedImprovement: '+4점'
        }
      ]
    },
    국어: {
      title: '국어 집중 학습 - Korean Deep Ocean',
      subtitle: '언어의 깊이를 탐구하며 실력을 향상시킵니다',
      color: 'from-indigo-600 to-blue-500',
      bgColor: 'from-slate-900 to-blue-900',
      icon: '🐠',
      courses: [
        {
          id: 'korean-literature',
          title: '문학 작품 심해 심화 분석',
          description: '고전문학부터 현대문학까지 작품을 깊이 있게 분석합니다',
          duration: '5주 심해 과정',
          level: '고급',
          progress: 80,
          lessons: [
            { id: 1, title: '고전 시가의 깊은 이해', duration: '50분', type: '이론' },
            { id: 2, title: '현대 소설 심해 분석 기법', duration: '45분', type: '이론' },
            { id: 3, title: '극문학의 심해 특성', duration: '40분', type: '이론' },
            { id: 4, title: '수필과 기행문의 감성', duration: '35분', type: '이론' },
            { id: 5, title: '문학 작품 실전 심해 분석', duration: '60분', type: '실습' },
            { id: 6, title: '문학사 심해 정리', duration: '40분', type: '이론' }
          ],
          expectedImprovement: '+10점'
        },
        {
          id: 'korean-nonfiction',
          title: '비문학 독해 심해 전략',
          description: '다양한 비문학 지문을 효과적으로 분석하는 방법을 배웁니다',
          duration: '3주 심해 과정',
          level: '중급',
          progress: 30,
          lessons: [
            { id: 1, title: '설명문 구조 심해 파악', duration: '40분', type: '이론' },
            { id: 2, title: '논증문 논리 심해 분석', duration: '45분', type: '이론' },
            { id: 3, title: '과학/기술 지문 심해 공략', duration: '50분', type: '이론' },
            { id: 4, title: '인문/예술 지문 심해 이해', duration: '45분', type: '이론' },
            { id: 5, title: '비문학 실전 심해 연습', duration: '60분', type: '실습' }
          ],
          expectedImprovement: '+6점'
        },
        {
          id: 'korean-writing',
          title: '화법과 작문의 심해',
          description: '효과적인 의사소통과 글쓰기 능력을 기릅니다',
          duration: '4주 심해 과정',
          level: '중급',
          progress: 0,
          lessons: [
            { id: 1, title: '화법의 기본 심해 원리', duration: '35분', type: '이론' },
            { id: 2, title: '토론과 토의 심해 전략', duration: '40분', type: '이론' },
            { id: 3, title: '설득적 심해 글쓰기', duration: '45분', type: '이론' },
            { id: 4, title: '정보 전달 심해 글쓰기', duration: '40분', type: '이론' },
            { id: 5, title: '실제 작문 심해 연습', duration: '60분', type: '실습' }
          ],
          expectedImprovement: '+5점'
        }
      ]
    }
  };

  const currentSubjectData = learningData[subject];

  const getLevelColor = (level) => {
    switch(level) {
      case '초급': return 'bg-slate-800/60 text-cyan-300 border border-slate-700/50';
      case '중급': return 'bg-slate-800/60 text-blue-300 border border-slate-700/50';
      case '고급': return 'bg-slate-800/60 text-indigo-300 border border-slate-700/50';
      default: return 'bg-slate-800/60 text-cyan-300 border border-slate-700/50';
    }
  };

  const getTypeIcon = (type) => {
    switch(type) {
      case '이론': return '🐠';
      case '실습': return '🐙';
      case '테스트': return '🌊';
      default: return '🌊';
    }
  };

  const handleStartLesson = (courseId, lessonId) => {
    setCompletedLessons(prev => new Set([...prev, `${courseId}-${lessonId}`]));
    // 실제로는 학습 컨텐츠 페이지로 이동
    alert('🌊 심해 학습이 시작됩니다! (실제로는 학습 컨텐츠로 이동)');
  };

  const calculateCourseProgress = (course) => {
    const completedCount = course.lessons.filter(lesson => 
      completedLessons.has(`${course.id}-${lesson.id}`)
    ).length;
    return Math.round((completedCount / course.lessons.length) * 100);
  };

  if (!subject || !currentSubjectData) {
    navigate('/learning-analysis');
    return null;
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br ${currentSubjectData.bgColor} relative overflow-hidden ${abyssalEffect ? 'animate-pulse' : ''}`}>
      {/* 🌊 심해 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 복잡한 심해와 거품 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-15">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            {/* 심해 패턴 */}
            <path d="M0,0 Q50,20 100,0 L100,15 Q50,35 0,15 Z" fill="url(#abyssalGradient)" />
            <path d="M0,40 Q25,60 50,40 Q75,20 100,40" stroke="#06b6d4" strokeWidth="0.5" fill="none" opacity="0.6"/>
            <path d="M15,0 L15,100 M35,0 L35,100 M55,0 L55,100 M75,0 L75,100" stroke="#3b82f6" strokeWidth="0.3" opacity="0.4"/>
            
            {/* 심해 장식 */}
            <circle cx="20" cy="20" r="8" stroke="#06b6d4" strokeWidth="0.5" fill="none" opacity="0.4"/>
            <circle cx="80" cy="80" r="6" stroke="#3b82f6" strokeWidth="0.5" fill="none" opacity="0.5"/>
            <polygon points="20,15 25,20 20,25 15,20" fill="#06b6d4" opacity="0.3"/>
            <polygon points="80,75 85,80 80,85 75,80" fill="#3b82f6" opacity="0.4"/>
            
            {/* 거품들 */}
            <circle cx="30" cy="30" r="2" fill="#06b6d4" opacity="0.7"/>
            <circle cx="70" cy="70" r="1.5" fill="#3b82f6" opacity="0.6"/>
            <circle cx="15" cy="85" r="1" fill="#6366f1" opacity="0.5"/>
            
            <defs>
              <linearGradient id="abyssalGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.5" />
                <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#6366f1" stopOpacity="0.2" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 🌊 해류 효과 */}
        {currentEffect && (
          <>
            <div className="absolute top-0 left-1/6 w-3 h-40 bg-gradient-to-b from-cyan-400 to-transparent animate-pulse opacity-60"></div>
            <div className="absolute top-0 right-1/5 w-2 h-32 bg-gradient-to-b from-blue-400 to-transparent animate-pulse opacity-50"></div>
            <div className="absolute top-0 left-2/3 w-2.5 h-36 bg-gradient-to-b from-indigo-400 to-transparent animate-bounce opacity-70"></div>
          </>
        )}
        
        {/* 🫧 거품 효과 */}
        {bubbleEffect && (
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 via-white/5 to-blue-500/10 animate-pulse"></div>
        )}
        
        {/* 🌊 심해 조류 효과 */}
        {deepTide && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-cyan-400 opacity-40 text-4xl animate-pulse">
            🌊🐙🐠
          </div>
        )}
        
        {/* 안개 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-slate-900/50 to-transparent"></div>
        
        {/* 움직이는 심해들 */}
        <div className="absolute top-1/4 left-10 w-32 h-32 bg-cyan-400/10 rounded-full blur-3xl opacity-50 animate-pulse"></div>
        <div className="absolute bottom-1/3 right-20 w-40 h-40 bg-blue-400/10 rounded-full blur-3xl opacity-40 animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-2/3 left-1/3 w-24 h-24 bg-indigo-400/10 rounded-full blur-3xl opacity-60 animate-pulse" style={{ animationDelay: '4s' }}></div>
        <div className="absolute top-1/6 right-1/4 w-20 h-20 bg-slate-600/20 rounded-full blur-3xl opacity-50 animate-pulse" style={{ animationDelay: '6s' }}></div>
      </div>

      {/* 🌊 헤더 - 심해 스타일 */}
      <div className="bg-slate-800/60 backdrop-blur-md shadow-2xl shadow-cyan-500/20 border-b border-slate-700/50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToAnalysis}
                className="text-cyan-300 hover:text-cyan-200 mr-4 transition-all duration-300 transform hover:scale-110 bg-slate-800/60 backdrop-blur-sm p-2 rounded-full border border-slate-700/50 shadow-lg"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-black bg-gradient-to-r ${currentSubjectData.color} bg-clip-text text-transparent ${abyssalEffect ? 'animate-bounce' : ''} drop-shadow-lg`}>
                {currentSubjectData.icon} {currentSubjectData.title}
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          
          {/* 🐙 과목 소개 - 심해 스타일 */}
          <div className="bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-cyan-500/20 p-8 mb-8 border border-slate-700/50 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-slate-700/30 to-blue-900/30"></div>
            <div className="text-center relative z-10">
              <div className="text-6xl mb-4 animate-pulse">{currentSubjectData.icon}</div>
              <h2 className="text-3xl font-black bg-gradient-to-r from-cyan-300 to-blue-400 bg-clip-text text-transparent mb-2 drop-shadow-lg">{currentSubjectData.title}</h2>
              <p className="text-cyan-400 text-lg">{currentSubjectData.subtitle}</p>
            </div>
            {/* 🌊 심해 장식 */}
            <div className="absolute top-4 right-4 text-cyan-400 opacity-60 animate-pulse">🌊</div>
            <div className="absolute bottom-4 left-4 text-blue-400 opacity-50 animate-pulse">🐙</div>
            <div className="absolute top-4 left-4 text-cyan-400 opacity-70 animate-pulse">🌊</div>
            <div className="absolute bottom-4 right-4 text-indigo-400 opacity-60 animate-pulse">🐠</div>
          </div>

          {/* 🌊 학습 과정 목록 - 심해 스타일 */}
          <div className="space-y-8">
            {currentSubjectData.courses.map((course) => {
              const courseProgress = calculateCourseProgress(course);
              
              return (
                <div key={course.id} className="bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-cyan-500/20 overflow-hidden border border-slate-700/50 relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 to-blue-900/20"></div>
                  
                  {/* 🌊 코스 헤더 - 심해 스타일 */}
                  <div className={`bg-gradient-to-r ${currentSubjectData.color} p-6 text-white relative z-10`}>
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h3 className="text-2xl font-black mb-2 drop-shadow-lg">🌊 {course.title}</h3>
                        <p className="text-white/90 mb-4 drop-shadow-sm">🌊 {course.description}</p>
                        <div className="flex items-center space-x-6 text-sm">
                          <span className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full border border-white/30">🕰️ {course.duration}</span>
                          <span className={`px-3 py-1 rounded-full backdrop-blur-sm ${getLevelColor(course.level)}`}>
                            ⚡ {course.level}
                          </span>
                          <span className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full border border-white/30">📈 예상 향상: {course.expectedImprovement}</span>
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-black mb-1 drop-shadow-lg">{courseProgress}%</div>
                        <div className="text-white/90 text-sm drop-shadow-sm">완료율</div>
                      </div>
                    </div>
                    
                    {/* 🐙 진행률 바 - 심해 스타일 */}
                    <div className="mt-4 w-full bg-white/20 backdrop-blur-sm rounded-full h-3 border border-white/30">
                      <div 
                        className="bg-gradient-to-r from-white/80 to-white/60 h-3 rounded-full transition-all duration-500 shadow-lg"
                        style={{ 
                          width: `${courseProgress}%`,
                          boxShadow: '0 0 15px rgba(255, 255, 255, 0.8)'
                        }}
                      />
                    </div>
                  </div>

                  {/* 🐠 강의 목록 - 심해 스타일 */}
                  <div className="p-6 relative z-10">
                    <div className="grid gap-4">
                      {course.lessons.map((lesson, index) => {
                        const isCompleted = completedLessons.has(`${course.id}-${lesson.id}`);
                        const isAccessible = index === 0 || completedLessons.has(`${course.id}-${course.lessons[index - 1].id}`);
                        
                        return (
                          <div 
                            key={lesson.id}
                            className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all duration-300 transform hover:scale-105 ${
                              isCompleted 
                                ? 'border-cyan-400 bg-slate-700/60 backdrop-blur-sm shadow-lg shadow-cyan-500/30' 
                                : isAccessible
                                ? 'border-blue-400/50 bg-slate-700/40 backdrop-blur-sm hover:border-blue-400 hover:bg-slate-700/60 hover:shadow-lg hover:shadow-blue-500/30'
                                : 'border-slate-600/50 bg-slate-800/20 backdrop-blur-sm'
                            }`}
                          >
                            <div className="flex items-center space-x-4">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all duration-300 ${
                                isCompleted 
                                  ? 'bg-cyan-500 text-white shadow-lg shadow-cyan-500/50' 
                                  : isAccessible
                                  ? 'bg-slate-700/60 text-blue-300 border-2 border-blue-400/50 backdrop-blur-sm'
                                  : 'bg-slate-800/60 text-slate-400 border-2 border-slate-600/50 backdrop-blur-sm'
                              }`}>
                                {isCompleted ? '✓' : lesson.id}
                              </div>
                              
                              <div className="flex-1">
                                <div className="flex items-center space-x-3 mb-1">
                                  <h4 className={`font-bold ${
                                    isAccessible ? 'text-slate-200' : 'text-slate-400'
                                  }`}>
                                    {getTypeIcon(lesson.type)} {lesson.title}
                                  </h4>
                                  <span className={`text-sm px-2 py-1 rounded-full border backdrop-blur-sm ${
                                    lesson.type === '이론' ? 'bg-slate-700/60 text-cyan-300 border-slate-600/50' :
                                    lesson.type === '실습' ? 'bg-slate-700/60 text-blue-300 border-slate-600/50' :
                                    'bg-slate-700/60 text-indigo-300 border-slate-600/50'
                                  }`}>
                                    {lesson.type}
                                  </span>
                                </div>
                                <p className={`text-sm ${
                                  isAccessible ? 'text-cyan-400' : 'text-slate-500'
                                }`}>
                                  ⏱️ {lesson.duration}
                                </p>
                              </div>
                            </div>
                            
                            <div className="flex items-center space-x-3">
                              {isCompleted ? (
                                <span className="text-cyan-300 font-bold bg-slate-700/60 backdrop-blur-sm px-3 py-1 rounded-full border border-slate-600/50">🌊 완료</span>
                              ) : isAccessible ? (
                                <button
                                  onClick={() => handleStartLesson(course.id, lesson.id)}
                                  className={`px-6 py-2 rounded-2xl font-bold transition-all duration-300 transform hover:scale-105 bg-gradient-to-r ${currentSubjectData.color} text-white hover:shadow-lg shadow-lg border-2 border-slate-700/50 backdrop-blur-sm`}
                                  style={{ boxShadow: `0 0 15px ${currentSubjectData.color.includes('cyan') ? '#06b6d4' : '#3b82f6'}50` }}
                                >
                                  🌊 학습 시작
                                </button>
                              ) : (
                                <span className="text-slate-400 font-medium bg-slate-800/60 backdrop-blur-sm px-3 py-1 rounded-full border border-slate-600/50">🔒 잠금</span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  
                  {/* 🌊 심해 장식 */}
                  <div className="absolute top-4 right-4 text-cyan-400 opacity-50 animate-pulse">
                    {course.id.includes('grammar') ? '🌊' : course.id.includes('reading') ? '🌊' : '🐙'}
                  </div>
                  <div className="absolute bottom-4 left-4 text-blue-400 opacity-40 animate-pulse">🐠</div>
                </div>
              );
            })}
          </div>



          {/* 🌊 학습 동기 부여 섹션 - 심해 스타일 */}
          <div className="mt-12 bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-cyan-500/20 p-8 border border-slate-700/50 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-slate-700/30 to-blue-900/30"></div>
            <div className="text-center relative z-10">
              <h3 className="text-2xl font-black bg-gradient-to-r from-cyan-300 to-blue-400 bg-clip-text text-transparent mb-6 drop-shadow-lg">🌊 심해 학습 동기 - Deep Ocean Motivation</h3>
              
              {completedLessons.size === 0 ? (
                <div className="bg-slate-700/60 backdrop-blur-sm rounded-2xl p-6 border border-slate-600/50 shadow-lg">
                  <div className="text-4xl mb-4 animate-pulse">🌊</div>
                  <h4 className="text-xl font-black text-cyan-300 mb-2 drop-shadow-sm">심해 여정을 시작하세요!</h4>
                  <p className="text-cyan-400 mb-4">
                    첫 번째 강의를 완료하면 깊은 바다의 지혜가 열립니다.
                  </p>
                  <div className="text-sm text-cyan-300 bg-slate-800/60 backdrop-blur-sm px-4 py-2 rounded-full border border-slate-700/50">
                    🐙 총 {currentSubjectData.courses.reduce((sum, course) => sum + course.lessons.length, 0)}개의 심해 강의가 당신을 기다리고 있습니다.
                  </div>
                </div>
              ) : completedLessons.size < 5 ? (
                <div className="bg-slate-700/60 backdrop-blur-sm rounded-2xl p-6 border border-slate-600/50 shadow-lg">
                  <div className="text-4xl mb-4 animate-pulse">🐙</div>
                  <h4 className="text-xl font-black text-cyan-300 mb-2 drop-shadow-sm">심해의 힘이 성장하고 있습니다!</h4>
                  <p className="text-cyan-400 mb-4">
                    {completedLessons.size}개의 강의를 완료했습니다. 계속해서 심해 실력을 키워나가세요!
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div className="bg-slate-800/60 backdrop-blur-sm p-3 rounded-xl border border-slate-700/50">
                      <div className="text-cyan-300 font-bold">🎯 다음 목표</div>
                      <div className="text-cyan-400">10개 강의 완료</div>
                    </div>
                    <div className="bg-slate-800/60 backdrop-blur-sm p-3 rounded-xl border border-slate-700/50">
                      <div className="text-blue-300 font-bold">⚡ 진행률</div>
                      <div className="text-blue-400">
                        {Math.round((completedLessons.size / currentSubjectData.courses.reduce((sum, course) => sum + course.lessons.length, 0)) * 100)}% 완료
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-slate-700/60 backdrop-blur-sm rounded-2xl p-6 border border-slate-600/50 shadow-lg">
                  <div className="text-4xl mb-4 animate-pulse">👑</div>
                  <h4 className="text-xl font-black text-cyan-300 mb-2 drop-shadow-sm">심해 마스터에 근접했습니다!</h4>
                  <p className="text-cyan-400 mb-4">
                    훌륭합니다! {completedLessons.size}개의 강의를 완료하여 상당한 진전을 이루었습니다.
                  </p>
                  <div className="bg-slate-800/60 backdrop-blur-sm p-4 rounded-xl border border-slate-700/50">
                    <div className="text-blue-300 font-bold mb-2">🏆 달성 현황</div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <div className="text-cyan-400">완료 강의</div>
                        <div className="text-cyan-300 font-bold">{completedLessons.size}개</div>
                      </div>
                      <div>
                        <div className="text-cyan-400">전체 진행률</div>
                        <div className="text-cyan-300 font-bold">
                          {Math.round((completedLessons.size / currentSubjectData.courses.reduce((sum, course) => sum + course.lessons.length, 0)) * 100)}%
                        </div>
                      </div>
                      <div>
                        <div className="text-cyan-400">예상 향상</div>
                        <div className="text-cyan-300 font-bold">
                          +{Math.round((completedLessons.size / currentSubjectData.courses.reduce((sum, course) => sum + course.lessons.length, 0)) * 
                            currentSubjectData.courses.reduce((sum, course) => sum + parseInt(course.expectedImprovement.replace('+', '').replace('점', '')), 0))}점
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            {/* 🌊 심해 장식 */}
            <div className="absolute top-4 right-4 text-cyan-400 opacity-60 animate-pulse">🌊</div>
            <div className="absolute bottom-4 left-4 text-blue-400 opacity-50 animate-pulse">⚡</div>
          </div>

          {/* 🌊 추천 학습 경로 - 심해 스타일 */}
          <div className="mt-8 bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-cyan-500/20 p-8 border border-slate-700/50 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-slate-700/30 to-indigo-900/30"></div>
            <div className="relative z-10">
              <h3 className="text-xl font-black bg-gradient-to-r from-cyan-300 to-indigo-400 bg-clip-text text-transparent mb-6 drop-shadow-lg">🗺️ 추천 심해 학습 경로 - Recommended Deep Ocean Path</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {currentSubjectData.courses.map((course, index) => {
                  const courseProgress = calculateCourseProgress(course);
                  const isRecommended = index === 0 || calculateCourseProgress(currentSubjectData.courses[index - 1]) >= 50;
                  
                  return (
                    <div key={course.id} className={`p-4 rounded-2xl border-2 transition-all duration-300 transform hover:scale-105 backdrop-blur-sm ${
                      isRecommended && courseProgress < 100
                        ? 'border-cyan-400 bg-slate-700/60 shadow-lg shadow-cyan-500/30'
                        : courseProgress === 100
                        ? 'border-blue-400 bg-slate-700/60 shadow-lg shadow-blue-500/30'
                        : 'border-slate-600/50 bg-slate-800/30'
                    }`}>
                      <div className="flex items-center justify-between mb-3">
                        <h4 className={`font-bold ${
                          courseProgress === 100 ? 'text-blue-300' :
                          isRecommended ? 'text-cyan-300' : 'text-slate-400'
                        }`}>
                          {course.title}
                        </h4>
                        <span className={`text-xs px-2 py-1 rounded-full backdrop-blur-sm ${
                          courseProgress === 100 ? 'bg-slate-700/60 text-blue-300 border border-slate-600/50' :
                          isRecommended ? 'bg-slate-700/60 text-cyan-300 border border-slate-600/50' : 'bg-slate-800/60 text-slate-400 border border-slate-700/50'
                        }`}>
                          {courseProgress === 100 ? '✅ 완료' :
                           isRecommended ? '🎯 추천' : '🔒 잠금'}
                        </span>
                      </div>
                      
                      <div className="text-sm text-slate-400 mb-3">
                        📊 진행률: {courseProgress}%
                      </div>
                      
                      <div className="w-full bg-slate-700/60 backdrop-blur-sm rounded-full h-2 mb-3 border border-slate-600/50">
                        <div 
                          className={`h-2 rounded-full transition-all duration-500 ${
                            courseProgress === 100 ? 'bg-gradient-to-r from-blue-500 to-indigo-500' :
                            isRecommended ? 'bg-gradient-to-r from-cyan-500 to-blue-500' : 'bg-slate-600/50'
                          }`}
                          style={{ width: `${courseProgress}%` }}
                        />
                      </div>
                      
                      <div className="text-xs text-slate-500">
                        {course.lessons.length}개 강의 • {course.expectedImprovement} 향상 예상
                      </div>
                    </div>
                  );
                })}
              </div>
              
              <div className="mt-6 bg-slate-700/60 backdrop-blur-sm rounded-2xl p-4 border border-slate-600/50 shadow-lg">
                <h4 className="font-bold text-cyan-300 mb-2">💡 심해 학습 팁</h4>
                <div className="text-sm text-cyan-400 space-y-1">
                  <div>🌊 하루에 1-2개 강의씩 꾸준히 학습하세요</div>
                  <div>🐙 이전 강의를 완료해야 다음 강의가 잠금 해제됩니다</div>
                  <div>🐠 실습 강의에서는 직접 문제를 풀어보며 실력을 확인하세요</div>
                </div>
              </div>
            </div>
            
            {/* 🌊 심해 장식 */}
            <div className="absolute top-4 right-4 text-indigo-400 opacity-60 animate-pulse">🗺️</div>
            <div className="absolute bottom-4 left-4 text-cyan-400 opacity-50 animate-pulse">🧭</div>
          </div>
        </div>
      </div>

      {/* 🌊 심해 CSS 애니메이션 */}
      <style jsx>{`
        @keyframes abyssal-pulse {
          0%, 100% { 
            opacity: 0.4;
            transform: scale(1);
          }
          50% { 
            opacity: 0.8;
            transform: scale(1.05);
          }
        }
        
        @keyframes deep-current {
          0% { 
            opacity: 0;
            transform: scale(0.8) rotate(-5deg);
          }
          50% { 
            opacity: 0.6;
            transform: scale(1.1) rotate(3deg);
          }
          100% { 
            opacity: 0;
            transform: scale(0.9) rotate(-2deg);
          }
        }
        
        @keyframes wave-flow {
          0% { 
            transform: translateY(-50%) scaleY(0);
            opacity: 0;
          }
          30% { 
            transform: translateY(0%) scaleY(1);
            opacity: 0.6;
          }
          70% { 
            transform: translateY(200%) scaleY(1);
            opacity: 0.4;
          }
          100% { 
            transform: translateY(300%) scaleY(0);
            opacity: 0;
          }
        }
        
        @keyframes deep-circle {
          0% { 
            transform: rotate(0deg) scale(1);
            opacity: 0.3;
          }
          50% { 
            transform: rotate(180deg) scale(1.05);
            opacity: 0.6;
          }
          100% { 
            transform: rotate(360deg) scale(1);
            opacity: 0.3;
          }
        }
        
        @keyframes floating-abyss {
          0%, 100% { 
            transform: translateY(0px) rotate(0deg);
          }
          33% { 
            transform: translateY(-8px) rotate(120deg);
          }
          66% { 
            transform: translateY(4px) rotate(240deg);
          }
        }
        
        .animate-abyssal-pulse {
          animation: abyssal-pulse 3s ease-in-out infinite;
        }
        
        .animate-deep-current {
          animation: deep-current 5s ease-in-out;
        }
        
        .animate-wave-flow {
          animation: wave-flow 4s ease-in-out;
        }
        
        .animate-deep-circle {
          animation: deep-circle 10s linear infinite;
        }
        
        .animate-floating-abyss {
          animation: floating-abyss 6s ease-in-out infinite;
        }
        
        /* 스크롤바 스타일링 - 심해 테마 */
        ::-webkit-scrollbar {
          width: 12px;
        }
        
        ::-webkit-scrollbar-track {
          background: rgba(15, 23, 42, 0.6);
          border-radius: 6px;
        }
        
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #06b6d4, #3b82f6);
          border-radius: 6px;
          border: 2px solid rgba(15, 23, 42, 0.3);
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #0891b2, #2563eb);
        }
        
        /* 심해 반짝임 효과 */
        .deep-sparkle {
          position: relative;
        }
        
        .deep-sparkle::before,
        .deep-sparkle::after {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: linear-gradient(45deg, transparent, rgba(6, 182, 212, 0.3), transparent);
          animation: deep-sparkle 3s ease-in-out infinite;
        }
        
        .deep-sparkle::after {
          animation-delay: 1.5s;
        }
        
        @keyframes deep-sparkle {
          0%, 100% {
            transform: translateX(-100%);
          }
          50% {
            transform: translateX(100%);
          }
        }
        
        /* 심해 호버 글로우 효과 */
        .deep-glow {
          transition: all 0.3s ease;
        }
        
        .deep-glow:hover {
          filter: drop-shadow(0 0 20px rgba(6, 182, 212, 0.6));
          transform: scale(1.02);
        }
          /* 심해 글로우 효과 */
        .blossom-glow {
          box-shadow: 0 0 20px rgba(71, 42, 235, 0.3);
        }
        
        .blossom-glow:hover {
          box-shadow: 0 0 30px rgba(116, 72, 235, 0.5);
        }
        
        /* 심해 텍스트 효과 */
        .blossom-text {
          background: linear-gradient(45deg, #484becff, #4418beff, #6b48ecff);
          background-size: 200% 200%;
          animation: blossom-gradient 3s ease infinite;
        }
        
        @keyframes blossom-gradient {
          0%, 100% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
      `}</style>
    </div>
  );
}