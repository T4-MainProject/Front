// ============================================
// 🌸 Spring Blossom FeatureList.jsx - 벚꽃 특징 목록
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const features = [
  { 
    icon: '⚡', 
    title: '번개같은 학습 속도', 
    description: '평균 7.77초 내 분석 완료로 즉시 로즈 결과 확인',
    gradient: 'from-pink-500 to-rose-500',
    bgGradient: 'from-pink-100/50 to-white/80'
  },
  { 
    icon: '👁️', 
    title: '벚꽃 정원의 정확도', 
    description: '100% 정확도로 신뢰할 수 있는 벚꽃 학습 결과',
    gradient: 'from-rose-500 to-pink-600',
    bgGradient: 'from-rose-100/60 to-pink-100/70'
  },
  { 
    icon: '🌹', 
    title: '상세한 로즈 분석', 
    description: '문제별 벚꽃 분석과 학습 성장 패턴 리포트 제공',
    gradient: 'from-pink-600 to-rose-600',
    bgGradient: 'from-pink-200/50 to-rose-100/60'
  },
  { 
    icon: '🔒', 
    title: '벚꽃 정원의 보안', 
    description: '학습정보 보호와 데이터 로즈 암호화로 안전한 벚꽃 서비스',
    gradient: 'from-pink-500 to-rose-600',
    bgGradient: 'from-white/80 to-pink-100/60'
  }
];

export default function FeatureList() {
  const sectionRef = useRef(null);
  const cardsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 🌸 카드들 스태거 애니메이션 (벚꽃 느낌으로)
      gsap.fromTo(cardsRef.current, 
        {
          y: 100,
          opacity: 0,
          scale: 0.6,
          rotationY: -45,
          filter: "blur(10px)"
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          rotationY: 0,
          filter: "blur(0px)",
          duration: 1.0,
          stagger: 0.2,
          ease: 'power4.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            end: 'bottom 20%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // 🌺 개별 카드 호버 애니메이션 (벚꽃 정원 효과)
      cardsRef.current.forEach((card) => {
        if (card) {
          card.addEventListener('mouseenter', () => {
            gsap.to(card, {
              y: -16,
              scale: 1.06,
              rotationX: 8,
              duration: 0.5,
              ease: "power3.out"
            });
          });

          card.addEventListener('mouseleave', () => {
            gsap.to(card, {
              y: 0,
              scale: 1,
              rotationX: 0,
              duration: 0.5,
              ease: "power3.out"
            });
          });
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-br from-white via-pink-50 to-rose-100 relative overflow-hidden">
      {/* 🌸 벚꽃 정원 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/80 via-pink-50/60 to-rose-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_75%,rgba(253,125,191,0.18)_0%,rgba(251,207,232,0.12)_50%,rgba(244,114,182,0.18)_80%)]"></div>
      
      {/* 🌺 흩날리는 벚꽃 꽃잎들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-1/4 w-4 h-4 bg-pink-400/50 rounded-full animate-pulse shadow-lg transform rotate-45"></div>
        <div className="absolute top-40 right-1/3 w-3 h-3 bg-rose-400/60 rounded-full animate-pulse delay-700 shadow-lg transform rotate-12"></div>
        <div className="absolute bottom-32 left-1/2 w-3 h-3 bg-pink-300/50 rounded-full animate-pulse delay-1000 shadow-lg transform -rotate-12"></div>
        <div className="absolute top-1/2 right-1/4 w-3 h-3 bg-rose-500/60 rounded-full animate-pulse delay-500 shadow-lg"></div>
        <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-pink-300/50 rounded-full animate-pulse delay-1500 shadow-lg transform rotate-45"></div>
        <div className="absolute top-1/3 left-1/5 w-2 h-2 bg-rose-400/60 rounded-full animate-pulse delay-300 shadow-lg transform -rotate-30"></div>
      </div>

      {/* 🌸 장식 벚꽃 나무들 */}
      <div className="absolute top-16 right-20 opacity-12">
        <svg width="90" height="130" viewBox="0 0 90 130">
          <path d="M45 130 L45 65 M23 65 Q45 45 67 65 M18 60 Q45 40 72 60" stroke="#ec4899" strokeWidth="3" fill="none"/>
          <circle cx="45" cy="55" r="9" fill="#ec4899"/>
          <path d="M36 55 Q25 40 12 45 M54 55 Q65 40 78 45" stroke="#f472b6" strokeWidth="2" fill="none"/>
          {/* 벚꽃 */}
          <circle cx="30" cy="50" r="3" fill="#fce7f3"/>
          <circle cx="60" cy="53" r="3" fill="#fce7f3"/>
          <circle cx="40" cy="45" r="2" fill="#f9a8d4"/>
          <circle cx="50" cy="47" r="2" fill="#f9a8d4"/>
          <circle cx="35" cy="60" r="2" fill="#fce7f3"/>
          <circle cx="55" cy="63" r="2" fill="#fce7f3"/>
        </svg>
      </div>
      <div className="absolute bottom-24 left-16 opacity-15">
        <svg width="70" height="100" viewBox="0 0 70 100">
          <path d="M35 100 L35 50 M18 50 Q35 35 52 50" stroke="#f472b6" strokeWidth="2" fill="none"/>
          <circle cx="35" cy="45" r="7" fill="#f472b6"/>
          <circle cx="25" cy="45" r="2" fill="#fce7f3"/>
          <circle cx="45" cy="48" r="2" fill="#fce7f3"/>
          <circle cx="30" cy="40" r="1" fill="#f9a8d4"/>
          <circle cx="40" cy="42" r="1" fill="#f9a8d4"/>
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* 🌺 헤더 */}
        <div className="text-center mb-16" data-aos="fade-up">
          <div className="inline-flex items-center space-x-3 bg-white/30 backdrop-blur-md border border-white/40 text-pink-700 px-6 py-3 rounded-full text-sm font-bold mb-6 shadow-lg shadow-pink-500/40 hover:shadow-xl hover:shadow-rose-500/60 transition-all duration-300 hover:scale-105">
            <span>🌺</span>
            <span>벚꽃 정원 특징</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-pink-700 mb-6 drop-shadow-2xl">
            왜 
            <span className="bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent"> BlossomCheck</span>을 
            <br className="hidden sm:block" />
            선택해야 할까요?
          </h2>
          <p className="text-xl text-pink-600 max-w-3xl mx-auto leading-relaxed drop-shadow-lg backdrop-blur-sm bg-white/25 rounded-2xl p-6 border border-white/40">
            최고의 로즈 기술력과 벚꽃 정원 사용자 경험을 바탕으로 한 <br className="hidden md:block" />
            차별화된 자동 학습 지원 서비스를 제공합니다
          </p>
        </div>

        {/* 🌸 기능 카드 그리드 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              ref={el => cardsRef.current[index] = el}
              className={`relative group p-8 rounded-3xl bg-gradient-to-br ${feature.bgGradient} backdrop-blur-md border border-white/50 shadow-2xl shadow-pink-500/30 hover:shadow-3xl hover:shadow-rose-500/50 transition-all duration-500 cursor-pointer overflow-hidden`}
            >
              {/* 🌺 배경 글로우 효과 */}
              <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-20 transition-opacity duration-500 rounded-3xl`}></div>
              
              {/* 🌺 추가 로즈 레이어 */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/70 via-pink-50/40 to-rose-100/30 rounded-3xl"></div>
              
              {/* 🌹 로즈 꽃잎들 */}
              <div className="absolute top-4 right-4 w-4 h-4 bg-pink-400/60 rounded-full animate-pulse shadow-lg transform rotate-45"></div>
              <div className="absolute bottom-6 left-6 w-3 h-3 bg-rose-400/70 rounded-full animate-ping shadow-lg transform rotate-12"></div>
              <div className="absolute top-1/2 right-8 w-3 h-3 bg-pink-300/60 rounded-full animate-bounce shadow-lg transform -rotate-12"></div>
              
              {/* 🌸 아이콘 */}
              <div className="relative z-10 mb-6">
                <div className={`inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br ${feature.gradient} rounded-3xl text-white text-3xl shadow-2xl shadow-pink-500/60 group-hover:shadow-3xl group-hover:shadow-rose-500/80 transition-all duration-300 group-hover:scale-110 group-hover:rotate-12 border-2 border-white/40`}>
                  {feature.icon}
                </div>
              </div>
              
              {/* 🌸 콘텐츠 */}
              <div className="relative z-10">
                <h3 className="text-xl font-bold text-pink-700 mb-3 group-hover:text-rose-700 transition-colors duration-300 drop-shadow-lg">
                  {feature.title}
                </h3>
                
                <p className="text-pink-600 text-sm leading-relaxed group-hover:text-rose-600 transition-colors duration-300 drop-shadow-sm">
                  {feature.description}
                </p>
              </div>

              {/* 🌺 호버 시 나타나는 로즈 액센트 */}
              <div className={`absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r ${feature.gradient} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left shadow-lg shadow-pink-500/60`}></div>
              
              {/* 🌺 추가 로즈 효과 */}
              <div className="absolute inset-0 rounded-3xl border border-white/50 group-hover:border-pink-300/70 transition-colors duration-300"></div>
              
              {/* 🌹 중앙 로즈 효과 */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-28 h-28 bg-gradient-radial from-white/20 via-pink-100/15 to-transparent rounded-full blur-3xl opacity-0 group-hover:opacity-60 transition-opacity duration-500"></div>
            </div>
          ))}
        </div>

        {/* 🌸 추가 통계 섹션 */}
        <div className="mt-20 pt-16 border-t border-white/40" data-aos="fade-up" data-aos-delay="400">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-pink-700 mb-4 drop-shadow-lg">
              <span className="bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">실시간</span> 
              벚꽃 정원 현황
            </h3>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: '88.8K+', label: '누적 로즈수', icon: '🌹', color: 'pink' },
              { number: '100%', label: '벚꽃 정원 정확도', icon: '👁️', color: 'rose' },
              { number: '7.77초', label: '평균 분석시간', icon: '⚡', color: 'pink' },
              { number: '999+', label: '활성 벚꽃자', icon: '🌸', color: 'rose' }
            ].map((stat, index) => (
              <div key={index} className="text-center group">
                <div className={`inline-flex items-center justify-center w-16 h-16 bg-white/50 backdrop-blur-md border border-white/40 rounded-2xl mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-pink-500/40 group-hover:shadow-xl group-hover:shadow-rose-500/60`}>
                  <span className="text-3xl drop-shadow-lg">{stat.icon}</span>
                </div>
                <div className={`text-3xl font-black text-pink-700 mb-2 group-hover:scale-110 transition-transform duration-300 drop-shadow-lg`}>
                  {stat.number}
                </div>
                <div className="text-sm text-pink-600 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>

          {/* 🌺 추가 로즈한 장식 */}
          <div className="mt-16 flex justify-center">
            <div className="bg-white/30 backdrop-blur-md px-8 py-6 rounded-3xl border border-white/40 shadow-2xl shadow-pink-500/40 max-w-md">
              <div className="text-center">
                <div className="text-pink-700 font-bold text-lg mb-2 drop-shadow-sm">🌸 벚꽃 정원의 성장</div>
                <div className="text-pink-600 text-sm">매일 새로운 벚꽃자들이 합류하고 있습니다</div>
                <div className="mt-3 flex justify-center space-x-4">
                  <div className="text-center bg-white/40 backdrop-blur-sm rounded-xl p-3 border border-white/40">
                    <div className="text-pink-600 font-bold">+77</div>
                    <div className="text-xs text-pink-500/70">오늘</div>
                  </div>
                  <div className="text-center bg-white/40 backdrop-blur-sm rounded-xl p-3 border border-white/40">
                    <div className="text-pink-600 font-bold">+999</div>
                    <div className="text-xs text-pink-500/70">이번 달</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 🌸 하단 로즈 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white/50 to-transparent pointer-events-none backdrop-blur-sm"></div>
      
      <style jsx>{`
        .bg-gradient-radial {
          background: radial-gradient(circle, var(--tw-gradient-stops));
        }
        
        .shadow-3xl {
          box-shadow: 0 35px 60px -12px rgba(0, 0, 0, 0.25);
        }
      `}</style>
    </section>
  );
}