import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function DeepOceanSimilarProblems() {
  const navigate = useNavigate();
  const location = useLocation();
  const [userAnswers, setUserAnswers] = useState({});
  const [showResults, setShowResults] = useState({});
  const [selectedProblem, setSelectedProblem] = useState(null);

  // 심해 효과 상태
  const [abyssalEffect, setAbyssalEffect] = useState(false);
  const [currentEffect, setCurrentEffect] = useState(false);
  const [bubbleEffect, setBubbleEffect] = useState(false);
  const [deepTide, setDeepTide] = useState(false);

  // URL 파라미터에서 문제 ID 가져오기
  const problemId = location.state?.problemId || 1;
  const originalProblem = location.state?.originalProblem || {};

  // 🌊 뒤로가기
  const handleBackToNote = () => {
    navigate('/wrong-answer-note');
  };

  // 심해 효과 트리거
  useEffect(() => {
    const abyssalInterval = setInterval(() => {
      setAbyssalEffect(true);
      setTimeout(() => setAbyssalEffect(false), 500);
    }, 9000 + Math.random() * 15000);

    const currentInterval = setInterval(() => {
      setCurrentEffect(true);
      setTimeout(() => setCurrentEffect(false), 3000);
    }, 12000 + Math.random() * 20000);

    const bubbleInterval = setInterval(() => {
      setBubbleEffect(true);
      setTimeout(() => setBubbleEffect(false), 2000);
    }, 7000 + Math.random() * 13000);

    const tideInterval = setInterval(() => {
      setDeepTide(true);
      setTimeout(() => setDeepTide(false), 4000);
    }, 20000 + Math.random() * 30000);

    return () => {
      clearInterval(abyssalInterval);
      clearInterval(currentInterval);
      clearInterval(bubbleInterval);
      clearInterval(tideInterval);
    };
  }, []);

  // 유사 기출문제 더미 데이터 (지문 포함) - 심해 버전
  const similarProblems = {
    1: [
      {
        id: 101,
        year: '2023',
        exam: '수능',
        passage: `문화는 인간이 자연 환경에 적응하며 만들어낸 깊은 창조물의 총체이다. 각 지역과 민족은 그들만의 독특한 환경과 역사적 경험을 바탕으로 고유한 문화를 형성해 왔다. 이러한 문화의 다양성은 인류의 소중한 자산이다.

오늘날 세계화의 물결 속에서 서로 다른 문화들이 만나고 있다. 이때 중요한 것은 한 문화가 다른 문화를 일방적으로 흡수하거나 동화시키는 것이 아니라, 서로의 가치를 인정하고 존중하며 조화롭게 공존하는 것이다. 문화의 획일화는 인류의 창조적 잠재력을 약화시킬 수 있기 때문이다.

따라서 우리는 문화의 다양성을 보호하고 증진시키기 위해 노력해야 한다. 이는 곧 인류 문명의 발전을 위한 필수 조건이기도 하다.`,
        question: '다음 글에서 필자가 강조하고자 하는 바는?',
        options: [
          '① 문화의 획일성이 세계화에 미치는 긍정적 영향',
          '② 전통 문화의 보존이 현대 사회에서 갖는 의미',
          '③ 문화의 다양성이 인류 발전에 갖는 중요성',
          '④ 현대 문명의 발전이 문화 변화에 미치는 영향'
        ],
        answer: 3,
        explanation: '글 전체에서 문화의 다양성이 인류의 소중한 자산이며, 인류 문명의 발전을 위한 필수 조건임을 강조하고 있습니다. 특히 마지막 문단에서 이를 명확히 드러내고 있습니다.'
      },
      {
        id: 102,
        year: '2022',
        exam: '6월 모의평가',
        passage: `현대 사회에서 문화 간 교류가 활발해지면서 새로운 형태의 문화 융합 현상이 나타나고 있다. 이는 단순히 서로 다른 문화 요소들이 섞이는 것을 넘어서, 완전히 새로운 문화적 가치와 형태를 창출하는 과정이다.

예를 들어, 한국의 K-pop은 서양의 대중음악과 동양의 전통적 감성이 만나 탄생한 독특한 문화 장르이다. 이처럼 문화 융합은 기존의 문화적 경계를 허물고 새로운 창조적 에너지를 발생시킨다.

중요한 것은 이러한 융합 과정에서 각 문화의 고유성을 잃지 않으면서도 새로운 문화적 가치를 만들어내는 것이다.`,
        question: '글의 화제로 가장 적절한 것은?',
        options: [
          '① 문화 간 충돌과 그 해결 방안',
          '② 현대 사회의 문화 융합 현상',
          '③ 전통 문화의 보존 필요성',
          '④ 세계화가 문화에 미치는 부정적 영향'
        ],
        answer: 2,
        explanation: '글 전체에서 현대 사회에서 나타나는 문화 융합 현상에 대해 설명하고 있으며, K-pop을 구체적인 사례로 제시하면서 이 현상의 특징과 의미를 다루고 있습니다.'
      },
      {
        id: 103,
        year: '2021',
        exam: '9월 모의평가',
        passage: `문화적 정체성은 개인이나 집단이 특정한 문화에 소속감을 느끼며 형성하는 인식이다. 이는 태어나면서부터 자연스럽게 습득되는 것이 아니라, 사회적 상호작용을 통해 점진적으로 구성되는 것이다.

현대의 다문화 사회에서 개인은 여러 문화에 동시에 노출되며, 이로 인해 복합적인 문화적 정체성을 형성하게 된다. 이는 과거의 단일한 문화적 정체성과는 다른 새로운 형태의 정체성이라고 할 수 있다.

이러한 변화는 개인에게 더 풍부하고 유연한 사고를 가능하게 하지만, 동시에 정체성 혼란이라는 과제도 안겨준다. 따라서 현대인은 다양한 문화적 요소들을 조화롭게 통합하여 자신만의 고유한 정체성을 형성해 나가야 한다.`,
        question: '다음 글의 주제문은?',
        options: [
          '① 첫 번째 문단의 첫 번째 문장',
          '② 두 번째 문단의 두 번째 문장',
          '③ 세 번째 문단의 첫 번째 문장',
          '④ 마지막 문단의 마지막 문장'
        ],
        answer: 4,
        explanation: '마지막 문장에서 글 전체의 핵심 메시지인 "현대인이 다양한 문화적 요소들을 조화롭게 통합하여 자신만의 고유한 정체성을 형성해야 한다"는 주제를 요약하여 제시하고 있습니다.'
      }
    ],
    2: [
      {
        id: 201,
        year: '2023',
        exam: '수능',
        passage: `Technology has dramatically changed the way we communicate with others. Social media platforms have made it easier than ever to stay connected with friends and family around the world. However, this convenience comes with certain challenges.

Many people now prefer digital communication over face-to-face interaction. While this may seem efficient, it can lead to a lack of genuine human connection. The nuances of body language and vocal tone are often lost in digital communication.

Furthermore, the constant availability of digital communication can create pressure to respond immediately to messages. This can lead to stress and anxiety, particularly among young people who feel obligated to maintain their online presence constantly.`,
        question: 'The word "however" in the passage can be replaced by:',
        options: [
          '① therefore',
          '② moreover',
          '③ nevertheless',
          '④ consequently'
        ],
        answer: 3,
        explanation: '"However"는 앞의 내용과 대조되는 내용을 이어갈 때 사용하는 역접 접속부사로, "nevertheless"와 같은 의미입니다.'
      },
      {
        id: 202,
        year: '2022',
        exam: '6월 모의평가',
        passage: `Climate change is one of the most pressing issues of our time. The Earth's temperature has been rising steadily due to increased greenhouse gas emissions. This warming trend is causing significant changes to weather patterns around the globe.

Scientists have been studying this phenomenon for decades. They have collected extensive data showing that human activities are the primary cause of recent climate change. The burning of fossil fuels releases carbon dioxide into the atmosphere, which traps heat and causes global warming.

The effects of climate change are already visible. We can see melting ice caps, rising sea levels, and more frequent extreme weather events. If we don't take action soon, these problems will only get worse.`,
        question: 'Which conjunction best fits the blank in "Scientists have been studying this phenomenon for decades, _____ they have strong evidence."?',
        options: [
          '① although',
          '② because',
          '③ and',
          '④ since'
        ],
        answer: 3,
        explanation: '문맥상 과학자들이 수십 년간 연구해왔다는 내용과 강력한 증거를 가지고 있다는 내용을 자연스럽게 연결하는 접속사 "and"가 적절합니다.'
      }
    ],
    3: [
      {
        id: 301,
        year: '2023',
        exam: '수능',
        passage: `이차함수는 y = ax² + bx + c (a ≠ 0) 형태로 나타낼 수 있으며, 그래프는 포물선 모양을 이룬다. 이차함수의 최댓값이나 최솟값은 포물선의 꼭짓점에서 나타난다.

이차함수 f(x) = ax² + bx + c에서 a > 0이면 아래로 볼록한 포물선이 되어 최솟값을 가지고, a < 0이면 위로 볼록한 포물선이 되어 최댓값을 가진다.

꼭짓점의 x좌표는 x = -b/2a로 구할 수 있으며, 이 값을 함수에 대입하면 최댓값 또는 최솟값을 구할 수 있다.`,
        question: 'f(x) = -3x² + 12x - 5의 최댓값은?',
        options: [
          '① 5',
          '② 7',
          '③ 9',
          '④ 11'
        ],
        answer: 2,
        explanation: 'a = -3 < 0이므로 최댓값을 가집니다. 꼭짓점의 x좌표는 x = -12/(2×(-3)) = 2입니다. f(2) = -3(4) + 12(2) - 5 = -12 + 24 - 5 = 7입니다.'
      },
      {
        id: 302,
        year: '2022',
        exam: '6월 모의평가',
        passage: `이차함수의 그래프를 이용하면 이차부등식을 쉽게 해결할 수 있다. 이차함수 y = ax² + bx + c의 그래프와 x축의 교점을 구하면, 이것이 이차방정식 ax² + bx + c = 0의 해가 된다.

판별식 D = b² - 4ac의 값에 따라 교점의 개수가 결정된다. D > 0이면 두 개의 서로 다른 실근을 가지고, D = 0이면 중근을 가지며, D < 0이면 실근이 없다.

이차부등식을 풀 때는 이차함수의 그래프를 그려서 x축보다 위에 있는 부분과 아래에 있는 부분을 구분하여 해를 구한다.`,
        question: '이차함수 y = -x² + 6x - 2의 꼭짓점의 y좌표는?',
        options: [
          '① 5',
          '② 6',
          '③ 7',
          '④ 8'
        ],
        answer: 3,
        explanation: '꼭짓점의 x좌표는 x = -6/(2×(-1)) = 3입니다. y = -(3)² + 6(3) - 2 = -9 + 18 - 2 = 7입니다.'
      }
    ]
  };

  const currentProblems = similarProblems[problemId] || [];

  const handleAnswerSelect = (problemId, optionIndex) => {
    setUserAnswers(prev => ({
      ...prev,
      [problemId]: optionIndex
    }));
  };

  const handleSubmitAnswer = (problemId) => {
    setShowResults(prev => ({
      ...prev,
      [problemId]: true
    }));
  };

  const handleShowProblem = (problemId) => {
    setSelectedProblem(selectedProblem === problemId ? null : problemId);
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-blue-900 relative overflow-hidden ${abyssalEffect ? 'animate-pulse' : ''}`}>
      {/* 🌊 심해 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 복잡한 심해 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-20">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,0 Q50,20 100,0 L100,15 Q50,35 0,15 Z" fill="url(#abyssalGradient)" />
            <path d="M0,40 Q25,60 50,40 Q75,20 100,40" stroke="#06b6d4" strokeWidth="0.5" fill="none" opacity="0.6"/>
            <path d="M15,0 L15,100 M35,0 L35,100 M55,0 L55,100 M75,0 L75,100" stroke="#3b82f6" strokeWidth="0.3" opacity="0.4"/>
            <circle cx="30" cy="30" r="2" fill="#06b6d4" opacity="0.7"/>
            <circle cx="70" cy="70" r="1.5" fill="#3b82f6" opacity="0.6"/>
            <defs>
              <linearGradient id="abyssalGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.5" />
                <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#6366f1" stopOpacity="0.2" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 🌊 해류 효과 */}
        {currentEffect && (
          <>
            <div className="absolute top-0 left-1/5 w-3 h-40 bg-gradient-to-b from-cyan-400 to-transparent animate-pulse opacity-60"></div>
            <div className="absolute top-0 right-1/4 w-2 h-32 bg-gradient-to-b from-blue-400 to-transparent animate-pulse opacity-50"></div>
            <div className="absolute top-0 left-3/4 w-2.5 h-36 bg-gradient-to-b from-indigo-400 to-transparent animate-bounce opacity-70"></div>
          </>
        )}
        
        {/* 🫧 거품 효과 */}
        {bubbleEffect && (
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 via-white/5 to-blue-500/10 animate-pulse"></div>
        )}
        
        {/* 🌊 심해 조류 효과 */}
        {deepTide && (
          <div className="absolute top-1/3 right-10 w-20 h-32 bg-blue-400/20 opacity-50 rounded-full blur-2xl animate-pulse"></div>
        )}
        
        {/* 안개 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-slate-900/40 to-transparent"></div>
        
        {/* 움직이는 심해들 */}
        <div className="absolute top-1/4 left-10 w-32 h-32 bg-cyan-400/10 rounded-full blur-3xl opacity-50 animate-pulse"></div>
        <div className="absolute bottom-1/3 right-20 w-40 h-40 bg-blue-400/10 rounded-full blur-3xl opacity-40 animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-2/3 left-1/3 w-24 h-24 bg-indigo-400/10 rounded-full blur-3xl opacity-60 animate-pulse" style={{ animationDelay: '4s' }}></div>
      </div>

      {/* 🌊 헤더 - 심해 스타일 */}
      <div className="bg-slate-800/60 backdrop-blur-md shadow-2xl shadow-cyan-500/20 border-b border-slate-700/50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToNote}
                className="text-cyan-300 hover:text-cyan-200 mr-4 transition-all duration-300 transform hover:scale-110 bg-slate-800/60 backdrop-blur-sm p-2 rounded-full border border-slate-700/50 shadow-lg"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-black bg-gradient-to-r from-cyan-300 to-blue-400 bg-clip-text text-transparent ${abyssalEffect ? 'animate-bounce' : ''} drop-shadow-lg`}>
                🔍 유사한 역대 기출문제 - Similar Deep Ocean Tests
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          
          {/* 원본 문제 정보 - 심해 스타일 */}
          {originalProblem.question && (
            <div className="bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-cyan-500/20 p-6 mb-8 border border-slate-700/50 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-slate-700/30 to-blue-900/30"></div>
              <h2 className="text-lg font-black text-cyan-300 mb-4 relative z-10 drop-shadow-sm">📝 원본 학습 문제 - Original Deep Ocean Problem</h2>
              <div className="bg-slate-700/60 backdrop-blur-sm border border-slate-600/50 rounded-2xl p-4 relative z-10 shadow-inner">
                <p className="text-slate-200 font-medium">{originalProblem.question}</p>
                <div className="flex items-center justify-between mt-3">
                  <span className="text-cyan-300">🌊 내 답: <strong className="bg-slate-800/60 backdrop-blur-sm px-2 py-1 rounded-full border border-slate-700/50">{originalProblem.userAnswer}</strong></span>
                  <span className="text-blue-300">🌊 정답: <strong className="bg-slate-800/60 backdrop-blur-sm px-2 py-1 rounded-full border border-slate-700/50">{originalProblem.correctAnswer}</strong></span>
                </div>
              </div>
              {/* 🌊 심해 장식 */}
              <div className="absolute top-2 right-2 text-cyan-400 opacity-60 animate-pulse">🌊</div>
              <div className="absolute bottom-2 left-2 text-blue-400 opacity-50 animate-pulse">🐙</div>
            </div>
          )}

          {/* 유사 기출문제 목록 - 심해 스타일 */}
          <div className="space-y-8">
            {currentProblems.map((problem) => (
              <div key={problem.id} className="bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-cyan-500/20 p-8 border border-slate-700/50 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 to-blue-900/20"></div>
                
                {/* 문제 헤더 */}
                <div className="flex items-center justify-between mb-6 relative z-10">
                  <div className="flex items-center space-x-4">
                    <span className="bg-gradient-to-r from-cyan-600 to-blue-500 text-white px-4 py-2 rounded-full font-black shadow-lg shadow-cyan-500/50">
                      🌊 {problem.year}년 {problem.exam}
                    </span>
                    <span className="bg-slate-800/60 text-indigo-300 px-3 py-1 rounded-full text-sm font-medium border border-slate-700/50 backdrop-blur-sm">
                      🔥 기출문제
                    </span>
                  </div>
                  <button
                    onClick={() => handleShowProblem(problem.id)}
                    className={`px-6 py-3 rounded-2xl font-bold transition-all duration-300 transform hover:scale-105 ${
                      selectedProblem === problem.id
                        ? 'bg-gradient-to-r from-cyan-600 to-blue-500 text-white shadow-lg shadow-cyan-500/50'
                        : 'bg-slate-800/60 backdrop-blur-sm text-cyan-300 hover:bg-slate-800/80 border border-slate-700/50 hover:border-cyan-400/50'
                    }`}
                  >
                    {selectedProblem === problem.id ? '🌊 문제 접기' : '🌊 문제 풀어보기'}
                  </button>
                </div>

                {/* 지문 (있는 경우) - 심해 스타일 */}
                {problem.passage && (
                  <div className="mb-6 relative z-10">
                    <h4 className="font-black text-cyan-300 mb-3 drop-shadow-sm">📄 지문 - Deep Ocean Passage</h4>
                    <div className="bg-slate-700/60 backdrop-blur-sm border border-slate-600/50 rounded-2xl p-6 shadow-inner">
                      <p className="text-slate-200 leading-relaxed whitespace-pre-line">
                        {problem.passage}
                      </p>
                    </div>
                  </div>
                )}

                {/* 문제 */}
                <div className="mb-6 relative z-10">
                  <h4 className="font-black text-blue-300 mb-3 drop-shadow-sm">❓ 문제 - The Deep Ocean Question</h4>
                  <p className="text-lg font-bold text-blue-200 mb-4 drop-shadow-sm">{problem.question}</p>
                </div>

                {/* 선택지 및 풀이 - 심해 스타일 */}
                {selectedProblem === problem.id && (
                  <div className="space-y-4 relative z-10">
                    <div className="bg-slate-700/60 backdrop-blur-sm border border-slate-600/50 rounded-2xl p-6 shadow-inner">
                      <h5 className="font-black text-cyan-300 mb-4 drop-shadow-sm">🌊 선택지 - Choose Your Answer</h5>
                      <div className="space-y-3">
                        {problem.options.map((option, optionIndex) => (
                          <label key={optionIndex} className="flex items-center space-x-3 cursor-pointer hover:bg-slate-600/50 hover:backdrop-blur-sm p-3 rounded-xl transition-all duration-300 transform hover:scale-105 border border-transparent hover:border-slate-500/50">
                            <input
                              type="radio"
                              name={`problem-${problem.id}`}
                              value={optionIndex}
                              onChange={() => handleAnswerSelect(problem.id, optionIndex)}
                              className="w-4 h-4 text-cyan-500 bg-slate-800 border-cyan-400 focus:ring-cyan-500"
                            />
                            <span className={`text-lg ${
                              showResults[problem.id] && optionIndex === problem.answer - 1
                                ? 'text-blue-300 font-black'
                                : showResults[problem.id] && userAnswers[problem.id] === optionIndex && optionIndex !== problem.answer - 1
                                ? 'text-cyan-300 font-bold'
                                : 'text-slate-200'
                            }`}>
                              {option}
                            </span>
                          </label>
                        ))}
                      </div>

                      <div className="flex space-x-3 mt-6">
                        <button
                          onClick={() => handleSubmitAnswer(problem.id)}
                          disabled={userAnswers[problem.id] === undefined}
                          className="bg-gradient-to-r from-cyan-600 to-blue-500 text-white px-6 py-3 rounded-2xl font-bold hover:from-cyan-500 hover:to-blue-400 transition-all duration-300 disabled:bg-slate-600/50 disabled:text-slate-400 disabled:cursor-not-allowed transform hover:scale-105 shadow-lg hover:shadow-cyan-500/50 border-2 border-slate-700/50 backdrop-blur-sm"
                        >
                          🌊 정답 확인
                        </button>
                        {showResults[problem.id] && (
                          <div className="flex items-center space-x-2 bg-slate-800/60 backdrop-blur-sm px-4 py-2 rounded-full border border-slate-700/50">
                            <span className="text-blue-300 font-medium">🌊 정답:</span>
                            <span className="font-black text-blue-200">{problem.answer}번</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* 해설 - 심해 스타일 */}
                    {showResults[problem.id] && (
                      <div className="bg-slate-700/60 backdrop-blur-sm border border-slate-600/50 rounded-2xl p-6 shadow-inner">
                        <h6 className="font-black text-blue-300 mb-3 drop-shadow-sm">💡 해설 - The Deep Ocean Truth</h6>
                        <p className="text-slate-200 leading-relaxed">{problem.explanation}</p>
                      </div>
                    )}
                  </div>
                )}
                
                {/* 🌊 심해 장식 */}
                <div className="absolute top-4 right-4 text-cyan-400 opacity-50 animate-pulse">
                  {problem.id % 3 === 0 ? '🌊' : problem.id % 3 === 1 ? '🌊' : '🐙'}
                </div>
                <div className="absolute bottom-4 left-4 text-blue-400 opacity-40 animate-pulse">🐠</div>
              </div>
            ))}
          </div>

          {/* 문제가 없는 경우 */}
          {currentProblems.length === 0 && (
            <div className="bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-cyan-500/20 p-12 border border-slate-700/50 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-slate-700/30 to-blue-900/30"></div>
              <div className="relative z-10">
                <div className="text-6xl mb-4 animate-pulse">🌊</div>
                <h3 className="text-2xl font-black text-cyan-300 mb-4 drop-shadow-sm">유사한 문제를 찾을 수 없습니다</h3>
                <p className="text-cyan-400 mb-8">이 문제 유형에 대한 기출문제가 아직 준비되지 않았습니다.</p>
                <button
                  onClick={() => navigate('/wrong-answer-note')}
                  className="bg-gradient-to-r from-cyan-600 to-blue-500 text-white px-8 py-4 rounded-2xl font-black transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-cyan-500/50 border-2 border-slate-700/50 backdrop-blur-sm"
                >
                  🌊 학습노트로 돌아가기
                </button>
              </div>
            </div>
          )}

          {/* 하단 액션 버튼 - 심해 스타일 */}
          {currentProblems.length > 0 && (
            <div className="mt-12 flex justify-center space-x-4">
              <button
                onClick={() => navigate('/wrong-answer-note')}
                className="bg-gradient-to-r from-cyan-600 to-blue-500 text-white px-8 py-4 rounded-2xl font-black text-lg shadow-2xl shadow-cyan-500/50 hover:shadow-cyan-500/70 transition-all duration-300 transform hover:scale-105 border-2 border-slate-700/50 backdrop-blur-sm"
              >
                📚 학습노트로 돌아가기
              </button>
              <button
                onClick={() => navigate('/upload')}
                className="bg-gradient-to-r from-indigo-600 to-blue-500 text-white px-8 py-4 rounded-2xl font-black text-lg shadow-2xl shadow-indigo-500/50 hover:shadow-indigo-500/70 transition-all duration-300 transform hover:scale-105 border-2 border-slate-700/50 backdrop-blur-sm"
              >
                📝 새로운 시험지 풀기
              </button>
            </div>
          )}

          {/* 통계 정보 (문제를 푼 경우) */}
          {Object.keys(showResults).length > 0 && (
            <div className="mt-12 bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-cyan-500/20 p-8 border border-slate-700/50 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-slate-700/30 to-blue-900/30"></div>
              <div className="text-center relative z-10">
                <h3 className="text-2xl font-black bg-gradient-to-r from-cyan-300 to-blue-400 bg-clip-text text-transparent mb-6 drop-shadow-lg">📊 학습 현황 - Learning Progress of Deep Ocean</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-slate-700/60 backdrop-blur-sm rounded-2xl p-6 border border-slate-600/50 shadow-lg">
                    <div className="text-3xl mb-2">🎯</div>
                    <div className="text-2xl font-black text-cyan-300 mb-1 drop-shadow-sm">
                      {Object.keys(showResults).filter(key => 
                        userAnswers[key] === currentProblems.find(p => p.id == key)?.answer - 1
                      ).length}
                    </div>
                    <div className="text-sm text-cyan-400 font-medium">정답 문제</div>
                  </div>
                  
                  <div className="bg-slate-700/60 backdrop-blur-sm rounded-2xl p-6 border border-slate-600/50 shadow-lg">
                    <div className="text-3xl mb-2">📊</div>
                    <div className="text-2xl font-black text-blue-300 mb-1 drop-shadow-sm">
                      {Object.keys(showResults).length > 0 ? 
                        Math.round((Object.keys(showResults).filter(key => 
                          userAnswers[key] === currentProblems.find(p => p.id == key)?.answer - 1
                        ).length / Object.keys(showResults).length) * 100) : 0}%
                    </div>
                    <div className="text-sm text-blue-400 font-medium">정답률</div>
                  </div>
                  
                  <div className="bg-slate-700/60 backdrop-blur-sm rounded-2xl p-6 border border-slate-600/50 shadow-lg">
                    <div className="text-3xl mb-2">📚</div>
                    <div className="text-2xl font-black text-indigo-300 mb-1 drop-shadow-sm">
                      {Object.keys(showResults).length}/{currentProblems.length}
                    </div>
                    <div className="text-sm text-indigo-400 font-medium">완료 문제</div>
                  </div>
                </div>
                
                {/* 개별 문제 결과 */}
                <div className="mt-8 bg-slate-700/60 backdrop-blur-sm rounded-2xl p-6 border border-slate-600/50 shadow-lg">
                  <h4 className="font-black text-cyan-300 mb-4 drop-shadow-sm">🔍 문제별 결과</h4>
                  <div className="space-y-3">
                    {currentProblems.map(problem => {
                      const isAnswered = showResults[problem.id];
                      const isCorrect = userAnswers[problem.id] === problem.answer - 1;
                      
                      if (!isAnswered) return null;
                      
                      return (
                        <div key={problem.id} className="flex items-center justify-between p-3 bg-slate-800/60 backdrop-blur-sm rounded-xl border border-slate-700/50 shadow-sm">
                          <span className="text-cyan-300 font-medium">
                            🌊 {problem.year}년 {problem.exam}
                          </span>
                          <span className={`font-bold ${isCorrect ? 'text-blue-300' : 'text-cyan-300'}`}>
                            {isCorrect ? '✅ 정답' : '❌ 오답'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
              
              {/* 🌊 심해 장식 */}
              <div className="absolute top-4 right-4 text-cyan-400 opacity-60 animate-pulse">📈</div>
              <div className="absolute bottom-4 left-4 text-blue-400 opacity-50 animate-pulse">🏆</div>
            </div>
          )}

          {/* 추천 학습법 (일부 문제를 푼 경우) */}
          {Object.keys(showResults).length > 0 && Object.keys(showResults).length < currentProblems.length && (
            <div className="mt-8 bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-cyan-500/20 p-8 border border-slate-700/50 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/30 to-blue-900/30"></div>
              <div className="relative z-10">
                <h3 className="text-xl font-black bg-gradient-to-r from-indigo-300 to-blue-400 bg-clip-text text-transparent mb-4 drop-shadow-lg">💡 추천 학습법 - Recommended Deep Ocean Learning</h3>
                <div className="bg-slate-700/60 backdrop-blur-sm rounded-2xl p-6 border border-slate-600/50 shadow-lg">
                  <div className="space-y-3 text-slate-200">
                    <div>🔥 남은 문제들도 풀어보세요! 더 많은 연습이 실력 향상에 도움됩니다.</div>
                    <div>🌊 틀린 문제는 해설을 꼼꼼히 읽어보세요.</div>
                    <div>🌊 비슷한 유형의 문제를 더 찾아서 연습해보세요.</div>
                  </div>
                </div>
              </div>
              
              {/* 🌊 심해 장식 */}
              <div className="absolute top-4 right-4 text-indigo-400 opacity-60 animate-pulse">💡</div>
              <div className="absolute bottom-4 left-4 text-blue-400 opacity-50 animate-pulse">📖</div>
            </div>
          )}
        </div>
      </div>

      {/* 🌊 심해 CSS 애니메이션 */}
      <style jsx>{`
        @keyframes abyssal-pulse {
          0%, 100% { 
            opacity: 0.6;
            transform: scale(1);
          }
          50% { 
            opacity: 1;
            transform: scale(1.05);
          }
        }
        
        @keyframes deep-appear {
          0% { 
            opacity: 0;
            transform: translateY(10px) scale(0.9);
          }
          50% { 
            opacity: 0.8;
            transform: translateY(0px) scale(1);
          }
          100% { 
            opacity: 0;
            transform: translateY(-10px) scale(1.1);
          }
        }
        
        @keyframes current-flow {
          0% { 
            transform: translateY(-50%) scaleY(0);
            opacity: 0;
          }
          30% { 
            transform: translateY(0%) scaleY(1);
            opacity: 0.8;
          }
          70% { 
            transform: translateY(200%) scaleY(1);
            opacity: 0.6;
          }
          100% { 
            transform: translateY(300%) scaleY(0);
            opacity: 0;
          }
        }
        
        @keyframes abyssal-shimmer {
          0%, 100% { 
            opacity: 0.2;
          }
          50% { 
            opacity: 0.6;
          }
        }
        
        .animate-abyssal-pulse {
          animation: abyssal-pulse 2s ease-in-out infinite;
        }
        
        .animate-deep-appear {
          animation: deep-appear 4s ease-in-out;
        }
        
        .animate-current-flow {
          animation: current-flow 3s ease-in-out;
        }
        
        .animate-abyssal-shimmer {
          animation: abyssal-shimmer 4s ease-in-out infinite;
        }
        
        /* 스크롤바 스타일링 */
        ::-webkit-scrollbar {
          width: 12px;
        }
        
        ::-webkit-scrollbar-track {
          background: rgba(30, 41, 59, 0.6);
          border-radius: 6px;
        }
        
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #06b6d4, #3b82f6);
          border-radius: 6px;
          border: 2px solid rgba(30, 41, 59, 0.6);
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #0891b2, #2563eb);
        }
        
        /* 반짝임 효과 */
        .sparkle-text {
          position: relative;
        }
        
        .sparkle-text::before,
        .sparkle-text::after {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: linear-gradient(45deg, transparent, rgba(6, 182, 212, 0.3), transparent);
          animation: sparkle 2s ease-in-out infinite;
        }
        
        .sparkle-text::after {
          animation-delay: 1s;
        }
        
        @keyframes sparkle {
          0%, 100% {
            transform: translateX(-100%);
          }
          50% {
            transform: translateX(100%);
          }
        }
        
        /* 호버 글로우 효과 */
        .hover-glow {
          transition: all 0.3s ease;
        }
        
        .hover-glow:hover {
          filter: drop-shadow(0 0 20px rgba(6, 182, 212, 0.6));
          transform: scale(1.02);
        }
      `}</style>
    </div>
  );
}