// ============================================
// 🌸 Spring Blossom Hero.jsx - 벚꽃 히어로 섹션
// ============================================
import React, { useLayoutEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function Hero({ onNext }) {
  const heroRef = useRef(null);
  const titleRef = useRef(null);
  const subtitleRef = useRef(null);
  const buttonsRef = useRef(null);
  const bgRef = useRef(null);
  const particlesRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 벚꽃 정원 패럴랙스 효과
      gsap.to(bgRef.current, {
        yPercent: 50,
        ease: "none",
        scrollTrigger: {
          trigger: heroRef.current,
          start: "top bottom",
          end: "bottom top",
          scrub: true
        }
      });

      // 벚꽃 정원 텍스트 애니메이션
      const tl = gsap.timeline();
      
      tl.fromTo(titleRef.current, 
        { 
          y: 150, 
          opacity: 0, 
          scale: 0.6,
          rotationX: -120,
          filter: "blur(20px)"
        },
        { 
          y: 0, 
          opacity: 1, 
          scale: 1,
          rotationX: 0,
          filter: "blur(0px)",
          duration: 1.8, 
          ease: "power4.out" 
        }
      )
      .fromTo(subtitleRef.current,
        { y: 80, opacity: 0, filter: "blur(10px)" },
        { y: 0, opacity: 1, filter: "blur(0px)", duration: 1.2, ease: "power3.out" },
        "-=0.8"
      )
      .fromTo(buttonsRef.current,
        { y: 60, opacity: 0, scale: 0.8, rotationY: 90 },
        { y: 0, opacity: 1, scale: 1, rotationY: 0, duration: 1.0, ease: "back.out(2)" },
        "-=0.6"
      );

      // 로즈 꽃잎 애니메이션
      particlesRef.current.forEach((particle, index) => {
        if (particle) {
          gsap.to(particle, {
            y: "random(-40, 40)",
            x: "random(-40, 40)",
            rotation: "random(-360, 360)",
            scale: "random(0.5, 1.5)",
            duration: "random(3, 6)",
            repeat: -1,
            yoyo: true,
            ease: "sine.inOut",
            delay: index * 0.2
          });
        }
      });

    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={heroRef}
      className="relative min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-pink-100 overflow-hidden flex items-center"
    >
      {/* 벚꽃 정원 배경 요소들 */}
      <div ref={bgRef} className="absolute inset-0 overflow-hidden">
        {/* 벚꽃 정원 그라데이션 블러 */}
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-br from-pink-400/40 to-rose-300/60 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-br from-rose-400/40 to-pink-300/50 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-br from-rose-300/25 to-white/50 rounded-full blur-3xl animate-pulse delay-500"></div>
        
        {/* 벚꽃 정원 추가 레이어 */}
        <div className="absolute inset-0 bg-white/40"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(253,125,191,0.15)_0%,rgba(251,207,232,0.08)_50%,rgba(244,114,182,0.15)_100%)]"></div>
        
        {/* 흩날리는 로즈 꽃잎들 */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            ref={el => particlesRef.current[i] = el}
            className={`absolute w-6 h-6 bg-gradient-to-br from-pink-400 to-rose-500 rounded-full opacity-40 blur-sm shadow-lg shadow-pink-500/60`}
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              transform: `rotate(${Math.random() * 360}deg)`
            }}
          ></div>
        ))}

        {/* 추가 벚꽃 정원 효과들 */}
        {[...Array(6)].map((_, i) => (
          <div
            key={`sparkle-${i}`}
            className={`absolute w-8 h-8 bg-white/50 rounded-full blur-lg animate-pulse`}
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.5}s`
            }}
          ></div>
        ))}
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center min-h-screen py-20">
          {/* 벚꽃 정원 텍스트 콘텐츠 */}
          <div className="flex-1 lg:pr-12 text-center lg:text-left">
            {/* 벚꽃 정원 배지 */}
            <div 
              data-aos="fade-down" 
              data-aos-delay="100"
              className="inline-flex items-center space-x-3 bg-white/50 backdrop-blur-md border border-white/60 text-pink-700 px-6 py-3 rounded-full text-sm font-semibold mb-8 shadow-lg shadow-pink-500/40 hover:shadow-xl hover:shadow-pink-500/60 transition-all duration-300 hover:scale-105"
            >
              <div className="relative">
                <div className="w-2 h-2 bg-pink-500 rounded-full"></div>
                <div className="absolute inset-0 w-2 h-2 bg-pink-500 rounded-full animate-ping opacity-75"></div>
              </div>
              <span>🌸 AI 벚꽃 정원 채점 시스템</span>
              <span className="bg-gradient-to-r from-pink-500 to-rose-500 text-white px-2 py-1 rounded-full text-xs font-bold animate-pulse border border-pink-400">
                BLOSSOM
              </span>
            </div>
            
            {/* 벚꽃 정원 메인 타이틀 */}
            <h1 
              ref={titleRef}
              className="text-5xl md:text-6xl lg:text-7xl font-black leading-tight mb-6 drop-shadow-2xl"
            >
              <span className="bg-gradient-to-r from-pink-600 via-pink-500 to-pink-700 bg-clip-text text-transparent drop-shadow-2xl">
                AI 로즈의
              </span>
              <br />
              <span className="text-pink-700 drop-shadow-lg">
                정확한 채점,
              </span>
              <br />
              <span className="bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent">
                벚꽃 정원 같은 편리함
              </span>
            </h1>
            
            {/* 벚꽃 정원 서브타이틀 */}
            <p 
              ref={subtitleRef}
              className="text-xl md:text-2xl text-pink-600 mb-10 leading-relaxed max-w-3xl mx-auto lg:mx-0 drop-shadow-lg"
            >
              <span className="font-semibold text-pink-600">YOLO8 로즈 비전</span>, 
              <span className="font-semibold text-rose-600"> OCR 텍스트 인식</span>, 
              <span className="font-semibold text-pink-700"> GPT 상세 해설</span>이 
              결합된 차세대 벚꽃 정원 채점 솔루션
            </p>

            {/* 벚꽃 정원 버튼들 */}
            <div 
              ref={buttonsRef}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12"
            >
              <button 
                onClick={onNext}
                className="group bg-gradient-to-r from-pink-500 to-rose-500 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-xl shadow-pink-500/60 hover:shadow-2xl hover:shadow-pink-500/80 transition-all duration-300 hover:scale-105 hover:from-pink-400 hover:to-rose-400 relative overflow-hidden border-2 border-white/40 backdrop-blur-sm"
              >
                <span className="relative z-10 flex items-center justify-center">
                  🌸 벚꽃 정원 시작하기
                  <svg className="ml-2 w-6 h-6 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
              </button>
            </div>

            {/* 벚꽃 정원 통계 */}
            <div 
              data-aos="fade-up" 
              data-aos-delay="400"
              className="grid grid-cols-3 gap-8 pt-8 border-t border-pink-300/60"
            >
              <div className="text-center group bg-white/50 backdrop-blur-sm p-4 rounded-lg border border-white/60">
                <div className="text-3xl font-black bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                  99.8%
                </div>
                <div className="text-sm text-pink-600 font-medium">로즈 정확도</div>
              </div>
              <div className="text-center group bg-white/50 backdrop-blur-sm p-4 rounded-lg border border-white/60">
                <div className="text-3xl font-black bg-gradient-to-r from-rose-600 to-pink-700 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                  3.5초
                </div>
                <div className="text-sm text-pink-600 font-medium">벚꽃 처리시간</div>
              </div>
              <div className="text-center group bg-white/50 backdrop-blur-sm p-4 rounded-lg border border-white/60">
                <div className="text-3xl font-black bg-gradient-to-r from-pink-700 to-rose-600 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                  1000+
                </div>
                <div className="text-sm text-pink-600 font-medium">완료된 시험지</div>
              </div>
            </div>
          </div>

          {/* 벚꽃 정원 오른쪽 일러스트레이션 */}
          <div className="flex-1 lg:pl-12 mt-12 lg:mt-0">
            <div 
              data-aos="fade-left" 
              data-aos-delay="200"
              className="relative"
            >
              {/* 벚꽃 정원 메인 카드 */}
              <div className="bg-white/40 backdrop-blur-md p-8 rounded-3xl shadow-2xl shadow-pink-500/40 transform rotate-3 hover:rotate-0 transition-all duration-700 hover:scale-105 border border-white/60 relative overflow-hidden">
                {/* 카드 내부 벚꽃 정원 글로우 */}
                <div className="absolute inset-0 bg-gradient-to-br from-pink-100/50 via-white/70 to-rose-100/50 rounded-3xl"></div>
                
                <div className="relative z-10">
                  {/* 벚꽃 정원 브라우저 헤더 */}
                  <div className="flex items-center space-x-2 mb-6">
                    <div className="w-3 h-3 bg-pink-500 rounded-full animate-pulse"></div>
                    <div className="w-3 h-3 bg-rose-400 rounded-full animate-pulse delay-100"></div>
                    <div className="w-3 h-3 bg-pink-600 rounded-full animate-pulse delay-200"></div>
                    <div className="flex-1 bg-white/60 h-6 rounded-full ml-4 border border-pink-300/60"></div>
                  </div>
                  
                  {/* 벚꽃 정원 콘텐츠 */}
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="h-4 bg-gradient-to-r from-pink-400 to-pink-500 rounded-lg w-3/4 animate-pulse shadow-lg"></div>
                      <div className="h-4 bg-gradient-to-r from-rose-400 to-rose-500 rounded-lg w-1/2 animate-pulse shadow-lg delay-100"></div>
                      <div className="h-4 bg-gradient-to-r from-pink-500 to-rose-400 rounded-lg w-2/3 animate-pulse shadow-lg delay-200"></div>
                    </div>
                    
                    {/* 벚꽃 정원 결과 카드 */}
                    <div className="bg-pink-100/70 backdrop-blur-sm p-6 rounded-2xl shadow-lg shadow-pink-500/40 border border-pink-300/60">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-sm font-bold text-pink-700 flex items-center">
                          <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          채점 완료
                        </span>
                        <span className="text-xs text-pink-600">3.5초</span>
                      </div>
                      <div className="text-4xl font-black bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent drop-shadow-lg">
                        87점
                      </div>
                      <div className="text-sm text-pink-700 mt-2">
                        20문제 중 17문제 정답 🌸
                      </div>
                      <div className="text-xs text-pink-600 mt-1">
                        "훌륭한 성과입니다!"
                      </div>
                    </div>
                  </div>
                </div>

                {/* 벚꽃 정원 추가 효과 */}
                <div className="absolute inset-0 bg-gradient-to-t from-pink-100/25 to-transparent rounded-3xl"></div>
              </div>

              {/* 떠다니는 벚꽃 정원 요소들 */}
              <div className="absolute -top-6 -right-6 w-16 h-16 bg-gradient-to-br from-pink-500 to-rose-500 rounded-2xl flex items-center justify-center shadow-xl shadow-pink-500/60 animate-bounce border-2 border-white/60">
                <span className="text-white text-2xl">🌺</span>
              </div>
              
              <div className="absolute -bottom-6 -left-6 w-16 h-16 bg-gradient-to-br from-rose-400 to-pink-600 rounded-2xl flex items-center justify-center shadow-xl shadow-rose-500/60 animate-pulse border-2 border-white/60">
                <span className="text-white text-2xl">🌸</span>
              </div>

              {/* 추가 벚꽃 정원 장식 */}
              <div className="absolute top-1/2 -left-8 w-12 h-12 bg-gradient-to-br from-pink-400 to-pink-500 rounded-full flex items-center justify-center shadow-lg shadow-pink-500/50 animate-pulse delay-300">
                <span className="text-white text-lg">✨</span>
              </div>

              <div className="absolute top-1/4 -right-8 w-12 h-12 bg-gradient-to-br from-rose-400 to-pink-600 rounded-full flex items-center justify-center shadow-lg shadow-rose-500/50 animate-pulse delay-700">
                <span className="text-white text-lg">🌹</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 벚꽃 정원 그라데이션 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white/30 to-transparent"></div>
    </section>
  );
}