// ============================================
// ✨ Angelic Light ContentLeft.jsx - 희망의 소식
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const updates = [
  {
    type: 'update',
    title: 'AI 천사 성능 대폭 향상',
    date: '2025.01.20',
    content: 'YOLO8 천국 버전 적용으로 희망 인식 정확도가 13.3% 향상되었습니다. 특히 축복받은 글씨 해독 능력이 크게 개선되었습니다.',
    icon: '👼',
    color: 'blue',
    badge: '축복'
  },
  {
    type: 'feature',
    title: '대량 축복 기능 천국 출시',
    date: '2025.01.15',
    content: '여러 과제를 한 번에 업로드하여 일괄 축복할 수 있는 대량 처리 기능이 추가되었습니다. 최대 999장까지 동시 처리 가능합니다.',
    icon: '✨',
    color: 'light',
    badge: '천사'
  },
  {
    type: 'notice',
    title: '새로운 축복 템플릿 추가',
    date: '2025.01.10',
    content: '수학, 과학, 언어 과목별 맞춤형 축복 템플릿이 추가되어 더욱 정확하고 따뜻한 피드백을 제공합니다.',
    icon: '📜',
    color: 'purple',
    badge: null
  },
  {
    type: 'maintenance',
    title: '천국 서버 최적화 완료',
    date: '2025.01.05',
    content: '빛의 안정성 향상을 위한 천국 서버 최적화 작업이 완료되어 처리 속도가 평균 77.7% 향상되었습니다.',
    icon: '⚡',
    color: 'gray',
    badge: null
  }
];

const quickLinks = [
  { title: '천사 사용 가이드', icon: '📚', desc: '천국의 사용법 익히기' },
  { title: '희망 튜토리얼', icon: '🎥', desc: '기적으로 배우기' },
  { title: '축복받은 질문들', icon: '❓', desc: '천국 FAQ 확인하기' },
  { title: '빛의 지원', icon: '🛠️', desc: '천사의 도움받기' }
];

export default function ContentLeft() {
  const sectionRef = useRef(null);
  const cardsRef = useRef([]);
  const linksRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 빛의 업데이트 카드들 순차 애니메이션
      gsap.fromTo(cardsRef.current,
        {
          x: -80,
          opacity: 0,
          scale: 0.8,
          rotationY: -30
        },
        {
          x: 0,
          opacity: 1,
          scale: 1,
          rotationY: 0,
          duration: 0.8,
          stagger: 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // 빛의 퀵링크 애니메이션
      gsap.fromTo(linksRef.current,
        {
          y: 50,
          opacity: 0,
          scale: 0.9
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          duration: 0.6,
          stagger: 0.12,
          ease: "back.out(1.7)",
          delay: 0.4,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const getColorClasses = (color) => {
    const colors = {
      blue: {
        bg: 'bg-gradient-to-r from-blue-100/30 to-white/50',
        border: 'border-l-blue-500',
        text: 'text-blue-600',
        badge: 'bg-blue-500'
      },
      light: {
        bg: 'bg-gradient-to-r from-sky-100/50 to-blue-100/30',
        border: 'border-l-sky-500',
        text: 'text-sky-700',
        badge: 'bg-sky-600'
      },
      purple: {
        bg: 'bg-gradient-to-r from-indigo-100/30 to-white/50',
        border: 'border-l-indigo-500',
        text: 'text-indigo-600',
        badge: 'bg-indigo-500'
      },
      gray: {
        bg: 'bg-gradient-to-r from-slate-100/50 to-gray-100/50',
        border: 'border-l-slate-400',
        text: 'text-slate-600',
        badge: 'bg-slate-500'
      }
    };
    return colors[color];
  };

  return (
    <section ref={sectionRef} className="flex-1">
      <div className="bg-gradient-to-br from-white via-sky-50 to-blue-100 rounded-3xl shadow-2xl shadow-blue-500/20 border border-blue-300/50 overflow-hidden h-full relative">
        {/* 천국의 배경 효과 */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/80 via-sky-50/60 to-blue-100/40"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,rgba(255,255,255,0.8)_100%)]"></div>
        
        {/* 움직이는 빛의 파티클들 */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-4 left-8 w-1 h-1 bg-blue-400/40 rounded-full animate-pulse"></div>
          <div className="absolute top-12 right-12 w-1 h-1 bg-sky-400/30 rounded-full animate-pulse delay-700"></div>
          <div className="absolute bottom-16 left-16 w-1 h-1 bg-indigo-400/40 rounded-full animate-pulse delay-1000"></div>
        </div>

        {/* 천사의 헤더 */}
        <div className="bg-gradient-to-r from-blue-100/50 to-white/70 p-6 border-b border-blue-300/50 relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-white rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/50 border border-blue-300/50">
                <span className="text-blue-600 text-2xl drop-shadow-lg">✨</span>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-blue-700 drop-shadow-lg">
                  희망의 소식 & 축복 업데이트
                </h2>
                <p className="text-blue-600/80 text-sm drop-shadow-sm">
                  천국의 개선사항과 새로운 축복을 확인하세요
                </p>
              </div>
            </div>
            <button className="bg-white/60 hover:bg-blue-100/60 border border-blue-300/50 hover:border-blue-400 text-blue-600 hover:text-blue-700 px-4 py-2 rounded-xl font-medium transition-all duration-200 hover:scale-105 shadow-sm shadow-blue-500/30 hover:shadow-md hover:shadow-blue-500/50">
              ✨ 모든 축복 보기
            </button>
          </div>
        </div>

        {/* 빛의 업데이트 목록 */}
        <div className="p-6 space-y-4 max-h-96 overflow-y-auto relative z-10">
          {updates.map((update, index) => {
            const colors = getColorClasses(update.color);
            return (
              <div 
                key={index}
                ref={el => cardsRef.current[index] = el}
                className={`
                  ${colors.bg} ${colors.border}
                  p-5 rounded-2xl border-l-4 hover:shadow-lg hover:shadow-blue-500/30 transition-all duration-300 
                  cursor-pointer group relative overflow-hidden backdrop-blur-sm
                `}
              >
                {/* 빛의 배경 호버 효과 */}
                <div className="absolute inset-0 bg-gradient-to-r from-blue-100/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                <div className="flex items-start space-x-4 relative z-10">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-white/60 rounded-xl shadow-md shadow-blue-500/30 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 border border-blue-300/50">
                      <span className="text-2xl drop-shadow-lg">{update.icon}</span>
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <h3 className="font-bold text-blue-700 group-hover:text-blue-800 transition-colors duration-200 drop-shadow-sm">
                          {update.title}
                        </h3>
                        {update.badge && (
                          <span className={`${colors.badge} text-white px-2 py-1 rounded-full text-xs font-bold animate-pulse border border-blue-300/50`}>
                            {update.badge}
                          </span>
                        )}
                      </div>
                      <span className="text-sm text-blue-600/80 flex-shrink-0">
                        {update.date}
                      </span>
                    </div>
                    <p className="text-blue-600/90 text-sm leading-relaxed group-hover:text-blue-700 transition-colors duration-200 drop-shadow-sm">
                      {update.content}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* 빛의 퀵 액세스 링크 */}
        <div className="p-6 bg-gradient-to-b from-white/60 to-blue-100/40 border-t border-blue-300/50 relative z-10">
          <h3 className="font-bold text-blue-700 mb-4 flex items-center drop-shadow-sm">
            <span className="text-lg mr-2">🔗</span>
            빛의 바로가기
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {quickLinks.map((link, index) => (
              <button
                key={index}
                ref={el => linksRef.current[index] = el}
                className="flex items-center space-x-3 p-4 bg-white/40 hover:bg-gradient-to-r hover:from-blue-100/40 hover:to-white/60 rounded-xl transition-all duration-300 group border border-blue-300/50 hover:border-blue-400 hover:shadow-md hover:shadow-blue-500/30"
              >
                <span className="text-2xl group-hover:scale-110 transition-transform duration-200 drop-shadow-sm">
                  {link.icon}
                </span>
                <div className="text-left">
                  <div className="font-medium text-blue-700 group-hover:text-blue-800 transition-colors duration-200 text-sm drop-shadow-sm">
                    {link.title}
                  </div>
                  <div className="text-xs text-blue-600/80 group-hover:text-blue-700 transition-colors duration-200">
                    {link.desc}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* 추가 빛 효과 */}
        <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-white to-transparent pointer-events-none"></div>
      </div>
    </section>
  );
}