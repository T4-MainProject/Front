// ============================================
// 🏝️ Tropical Paradise SimpleFooter.jsx - 열대 간소 푸터
// ============================================
import React from 'react';

export default function SimpleFooter() {
  return (
    <footer className="bg-gradient-to-br from-emerald-100 via-cyan-50 to-sky-100 text-emerald-700 py-12 relative overflow-hidden border-t border-white/40">
      {/* 🏖️ 열대 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-t from-white/80 via-emerald-50/60 to-cyan-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_60%_40%,rgba(16,185,129,0.15)_0%,rgba(6,182,212,0.1)_50%,rgba(14,165,233,0.15)_80%)]"></div>
      
      {/* 🌺 떠다니는 열대 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-4 left-1/4 w-3 h-3 bg-emerald-400/40 rounded-full animate-pulse shadow-lg"></div>
        <div className="absolute top-8 right-1/3 w-2 h-2 bg-cyan-400/50 rounded-full animate-pulse delay-700 shadow-lg"></div>
        <div className="absolute bottom-6 left-1/2 w-2 h-2 bg-sky-400/40 rounded-full animate-pulse delay-1000 shadow-lg"></div>
        <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-teal-500/50 rounded-full animate-pulse delay-500 shadow-lg"></div>
        <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-emerald-300/40 rounded-full animate-pulse delay-1500 shadow-lg"></div>
      </div>

      {/* 🌴 미니 야자수 장식 */}
      <div className="absolute top-6 right-12 opacity-15">
        <svg width="30" height="40" viewBox="0 0 30 40">
          <path d="M15 40 L15 20 M8 20 Q15 15 22 20" stroke="#059669" strokeWidth="1.5" fill="none"/>
          <circle cx="15" cy="18" r="3" fill="#059669"/>
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between">
          {/* 🏝️ 파라다이스 로고 */}
          <div className="flex items-center space-x-3 mb-6 md:mb-0">
            <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-cyan-500 rounded-2xl flex items-center justify-center shadow-xl shadow-emerald-500/50 border-2 border-white/30 backdrop-blur-sm">
              <span className="text-white font-bold text-xl drop-shadow-lg">🏝️</span>
            </div>
            <div>
              <h3 className="text-xl font-bold text-emerald-700 drop-shadow-lg">ParadiseCheck</h3>
              <p className="text-emerald-600 text-sm drop-shadow-sm">🌺 AI 열대 크리스탈 시스템</p>
            </div>
          </div>
          
          {/* 🌊 간단한 정보 */}
          <div className="text-center md:text-right">
            <p className="text-emerald-600 text-sm mb-2 drop-shadow-sm backdrop-blur-sm bg-white/20 rounded-xl px-4 py-2 border border-white/30">
              © 2025 ParadiseCheck. All crystals reserved.
            </p>
            <div className="flex items-center justify-center md:justify-end space-x-4 text-xs text-emerald-500/80">
              <span className="bg-white/20 backdrop-blur-sm rounded-lg px-3 py-1 border border-white/30">파라다이스 문의</span>
              <span>•</span>
              <span className="bg-white/20 backdrop-blur-sm rounded-lg px-3 py-1 border border-white/30">paradise@skycheck.co.kr</span>
            </div>
          </div>
        </div>
                
        {/* 🏖️ 크리스탈 기술 스택 */}
        <div className="mt-8 pt-8 border-t border-white/30 text-center">
          <div className="bg-white/25 backdrop-blur-md rounded-2xl p-6 border border-white/30 shadow-lg shadow-emerald-500/20">
            <p className="text-emerald-600 text-sm drop-shadow-sm mb-4">
              Powered by <span className="text-emerald-700 font-semibold">👁️ YOLO8 파라다이스의 눈</span> •
              <span className="text-cyan-700 font-semibold"> 🔮 OCR 열대 추출</span> •
              <span className="text-emerald-700 font-semibold"> 🌺 GPT 크리스탈</span>
            </p>
          </div>
        </div>

        {/* 🌺 추가 크리스탈한 장식 */}
        <div className="mt-6 text-center">
          <div className="inline-flex items-center space-x-3 bg-white/25 backdrop-blur-md px-6 py-3 rounded-full border border-white/30 shadow-lg shadow-emerald-500/30">
            <span className="text-emerald-600 text-xs">⚡ 파라다이스 서버 상태:</span>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-sm"></div>
              <span className="text-emerald-700 text-xs font-semibold">운영중</span>
            </div>
          </div>
        </div>

        {/* 🏝️ 파라다이스 축복 메시지 */}
        <div className="mt-6 text-center">
          <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4 border border-white/30 shadow-lg max-w-2xl mx-auto">
            <p className="text-emerald-600/80 text-xs italic drop-shadow-sm">
              "크리스탈 속에서 태어나 파라다이스를 품는 자들을 위한 열대 시스템"
            </p>
          </div>
        </div>
      </div>

      {/* 🌈 하단 크리스탈 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-10 bg-gradient-to-t from-white/40 to-transparent pointer-events-none backdrop-blur-sm"></div>
      
      {/* 💎 크리스탈 테두리 */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-emerald-400/60 to-transparent shadow-sm"></div>
    </footer>
  );
}