// ============================================
// src/App.jsx - 메인 앱 컴포넌트 (React Router 기반 라우팅)
// ============================================
// 🔄 URL 라우팅:
// - "/" : Home 페이지 (메인 랜딩 페이지)
// - "/upload" : ExamUpload 페이지 (시험지 업로드)
// ============================================

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import ExamUpload from './pages/ExamUpload';

export default function App() {
  return (
    <Router>
      <Routes>
        {/* 🏠 메인 홈 페이지 (/) */}
        <Route path="/" element={<Home />} />
        
        {/* 📤 시험지 업로드 페이지 (/upload) */}
        <Route path="/upload" element={<ExamUpload />} />
      </Routes>
    </Router>
  );
}


