// ============================================
// src/data/dummyUsers.js - 더미 사용자 데이터
// ============================================
// 🧪 테스트용 계정들 (실제 서비스에서는 보안상 제거 필요)
// ============================================

export const dummyUsers = [
  {
    id: 1,
    email: '1234@email.com',
    password: 'abcd1234',
    name: '관리자',
    phone: '010-1234-5678',
    birthDate: '1990-01-01',
    address: '서울시 강남구',
    school: '서울대학교',
    securityQuestion: '가장 좋아하는 음식은 무엇입니까?',
    securityAnswer: '피자',
    role: 'admin',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=admin',
    joinDate: '2024-01-01',
    loginCount: 127,
    points: 9999,
    tier: 'admin',
    profileCompletionRewardReceived: true,
    dailyUploadsUsed: 0,
    dailyUploadsReset: new Date().toDateString(),
    examHistory: {
      totalExams: 150,
      averageScore: 95,
      recentScores: [98, 96, 97, 94, 99],
      subjectScores: {
        korean: { total: 50, average: 96 },
        english: { total: 50, average: 94 },
        math: { total: 50, average: 95 }
      },
      detailedScores: [
        { exam: '1회', date: '2023-06', examName: '2023년 6월 모의고사', examDate: '2023.06.15', total: 92, korean: 94, english: 90, math: 93 },
        { exam: '2회', date: '2023-08', examName: '2023년 8월 모의고사', examDate: '2023.08.17', total: 95, korean: 93, english: 96, math: 96 },
        { exam: '3회', date: '2023-10', examName: '2023년 10월 모의고사', examDate: '2023.10.12', total: 98, korean: 99, english: 98, math: 97 },
        { exam: '4회', date: '2023-12', examName: '2023년 12월 모의고사', examDate: '2023.12.07', total: 96, korean: 97, english: 94, math: 97 },
        { exam: '5회', date: '2024-02', examName: '2024년 2월 모의고사', examDate: '2024.02.22', total: 97, korean: 98, english: 97, math: 96 },
        { exam: '6회', date: '2024-04', examName: '2024년 4월 모의고사', examDate: '2024.04.11', total: 94, korean: 96, english: 93, math: 93 },
        { exam: '7회', date: '2024-06', examName: '2024년 6월 모의고사', examDate: '2024.06.13', total: 99, korean: 99, english: 99, math: 99 }
      ]
    }
  },
  {
    id: 2,
    email: 'teacher@langcheck.com',
    password: 'teacher123',
    name: '김선생',
    phone: '010-2345-6789',
    birthDate: '1985-05-15',
    address: '서울시 서초구',
    school: '서울중학교',
    securityQuestion: '첫 번째 반려동물의 이름은 무엇입니까?',
    securityAnswer: '뽀삐',
    role: 'teacher',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=teacher',
    joinDate: '2024-02-15',
    loginCount: 89,
    points: 450,
    tier: 'proplus',
    profileCompletionRewardReceived: true,
    dailyUploadsUsed: 2,
    dailyUploadsReset: new Date().toDateString(),
    examHistory: {
      totalExams: 89,
      averageScore: 88,
      recentScores: [85, 90, 87, 91, 86],
      subjectScores: {
        korean: { total: 30, average: 89 },
        english: { total: 30, average: 87 },
        math: { total: 29, average: 88 }
      },
      detailedScores: [
        { exam: '1회', date: '2023-06', examName: '2023년 6월 모의고사', examDate: '2023.06.15', total: 80, korean: 82, english: 78, math: 80 },
        { exam: '2회', date: '2023-08', examName: '2023년 8월 모의고사', examDate: '2023.08.17', total: 85, korean: 87, english: 83, math: 85 },
        { exam: '3회', date: '2023-10', examName: '2023년 10월 모의고사', examDate: '2023.10.12', total: 90, korean: 92, english: 88, math: 90 },
        { exam: '4회', date: '2023-12', examName: '2023년 12월 모의고사', examDate: '2023.12.07', total: 87, korean: 89, english: 85, math: 87 },
        { exam: '5회', date: '2024-02', examName: '2024년 2월 모의고사', examDate: '2024.02.22', total: 91, korean: 93, english: 89, math: 91 },
        { exam: '6회', date: '2024-04', examName: '2024년 4월 모의고사', examDate: '2024.04.11', total: 86, korean: 88, english: 84, math: 86 },
        { exam: '7회', date: '2024-06', examName: '2024년 6월 모의고사', examDate: '2024.06.13', total: 92, korean: 94, english: 90, math: 92 }
      ]
    }
  },
  {
    id: 3,
    email: 'abcd@email.com',
    password: 'abcd1234',
    name: '이학생',
    phone: '',
    birthDate: '2008-12-25',
    address: '',
    school: '',
    securityQuestion: '가장 좋아하는 영화는 무엇입니까?',
    securityAnswer: '어벤져스',
    role: 'student',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=student',
    joinDate: '2024-03-10',
    loginCount: 45,
    points: 30,
    tier: 'individual',
    profileCompletionRewardReceived: false,
    dailyUploadsUsed: 1,
    dailyUploadsReset: new Date().toDateString(),
    examHistory: {
      totalExams: 45,
      averageScore: 82,
      recentScores: [78, 85, 80, 84, 83],
      subjectScores: {
        korean: { total: 15, average: 83 },
        english: { total: 15, average: 80 },
        math: { total: 15, average: 84 }
      },
      detailedScores: [
        { exam: '1회', date: '2023-06', examName: '2023년 6월 모의고사', examDate: '2023.06.15', total: 65, korean: 62, english: 68, math: 65 },
        { exam: '2회', date: '2023-08', examName: '2023년 8월 모의고사', examDate: '2023.08.17', total: 68, korean: 65, english: 70, math: 69 },
        { exam: '3회', date: '2023-10', examName: '2023년 10월 모의고사', examDate: '2023.10.12', total: 71, korean: 67, english: 73, math: 73 },
        { exam: '4회', date: '2023-12', examName: '2023년 12월 모의고사', examDate: '2023.12.07', total: 74, korean: 70, english: 76, math: 76 },
        { exam: '5회', date: '2024-02', examName: '2024년 2월 모의고사', examDate: '2024.02.22', total: 78, korean: 75, english: 80, math: 79 },
        { exam: '6회', date: '2024-04', examName: '2024년 4월 모의고사', examDate: '2024.04.11', total: 83, korean: 85, english: 82, math: 82 },
        { exam: '7회', date: '2024-06', examName: '2024년 6월 모의고사', examDate: '2024.06.13', total: 89, korean: 92, english: 87, math: 88 }
      ]
    }
  },
  {
    id: 4,
    email: 'parent@langcheck.com',
    password: 'parent123',
    name: '박학부모',
    phone: '010-4567-8901',
    birthDate: '1978-08-30',
    address: '서울시 마포구',
    school: '마포중학교',
    securityQuestion: '어머니의 성함은 무엇입니까?',
    securityAnswer: '김영희',
    role: 'parent',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=parent',
    joinDate: '2024-01-20',
    loginCount: 72,
    points: 720,
    tier: 'ultra',
    profileCompletionRewardReceived: true,
    dailyUploadsUsed: 0,
    dailyUploadsReset: new Date().toDateString(),
    examHistory: {
      totalExams: 72,
      averageScore: 78,
      recentScores: [75, 80, 76, 82, 79],
      subjectScores: {
        korean: { total: 24, average: 79 },
        english: { total: 24, average: 77 },
        math: { total: 24, average: 78 }
      },
      detailedScores: [
        { exam: '1회', date: '2023-06', examName: '2023년 6월 모의고사', examDate: '2023.06.15', total: 70, korean: 72, english: 68, math: 70 },
        { exam: '2회', date: '2023-08', examName: '2023년 8월 모의고사', examDate: '2023.08.17', total: 75, korean: 77, english: 73, math: 75 },
        { exam: '3회', date: '2023-10', examName: '2023년 10월 모의고사', examDate: '2023.10.12', total: 80, korean: 82, english: 78, math: 80 },
        { exam: '4회', date: '2023-12', examName: '2023년 12월 모의고사', examDate: '2023.12.07', total: 76, korean: 78, english: 74, math: 76 },
        { exam: '5회', date: '2024-02', examName: '2024년 2월 모의고사', examDate: '2024.02.22', total: 82, korean: 84, english: 80, math: 82 },
        { exam: '6회', date: '2024-04', examName: '2024년 4월 모의고사', examDate: '2024.04.11', total: 79, korean: 81, english: 77, math: 79 },
        { exam: '7회', date: '2024-06', examName: '2024년 6월 모의고사', examDate: '2024.06.13', total: 83, korean: 85, english: 81, math: 83 }
      ]
    }
  },
  {
    id: 5,
    email: 'test@test.com',
    password: 'test123',
    name: '테스트',
    phone: '010-1234-5678',
    birthDate: '2000-01-01',
    address: '서울시 강남구 테헤란로 123',
    school: '테스트고등학교',
    securityQuestion: '태어난 병원의 이름은 무엇입니까?',
    securityAnswer: '서울병원',
    role: 'student',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=test',
    joinDate: '2024-04-01',
    loginCount: 12,
    points: 30,
    tier: 'individual',
    profileCompletionRewardReceived: false,
    dailyUploadsUsed: 0,
    dailyUploadsReset: new Date().toDateString(),
    examHistory: {
      totalExams: 12,
      averageScore: 75,
      recentScores: [70, 78, 73, 77, 76],
      subjectScores: {
        korean: { total: 4, average: 76 },
        english: { total: 4, average: 74 },
        math: { total: 4, average: 75 }
      },
      detailedScores: [
        { exam: '1회', date: '2023-06', examName: '2023년 6월 모의고사', examDate: '2023.06.15', total: 60, korean: 58, english: 62, math: 60 },
        { exam: '2회', date: '2023-08', examName: '2023년 8월 모의고사', examDate: '2023.08.17', total: 65, korean: 63, english: 67, math: 65 },
        { exam: '3회', date: '2023-10', examName: '2023년 10월 모의고사', examDate: '2023.10.12', total: 70, korean: 68, english: 72, math: 70 },
        { exam: '4회', date: '2023-12', examName: '2023년 12월 모의고사', examDate: '2023.12.07', total: 73, korean: 71, english: 75, math: 73 },
        { exam: '5회', date: '2024-02', examName: '2024년 2월 모의고사', examDate: '2024.02.22', total: 78, korean: 76, english: 80, math: 78 },
        { exam: '6회', date: '2024-04', examName: '2024년 4월 모의고사', examDate: '2024.04.11', total: 76, korean: 74, english: 78, math: 76 },
        { exam: '7회', date: '2024-06', examName: '2024년 6월 모의고사', examDate: '2024.06.13', total: 82, korean: 80, english: 84, math: 82 }
      ]
    }
  }
];

// 🔐 로그인 검증 함수
export const validateLogin = (email, password) => {
  const user = dummyUsers.find(u => u.email === email && u.password === password);
  if (user) {
    // 로그인 카운트 증가 (실제로는 서버에서 처리)
    user.loginCount += 1;
    user.lastLogin = new Date().toISOString();
    
    // 민감한 정보 제거 후 반환
    const { password: _, securityAnswer: __, ...safeUser } = user;
    return {
      success: true,
      user: safeUser,
      message: '로그인 성공!'
    };
  }
  
  return {
    success: false,
    user: null,
    message: '이메일 또는 비밀번호가 올바르지 않습니다.'
  };
};

// 📧 이메일 중복 확인 함수
export const checkEmailExists = (email) => {
  return dummyUsers.some(user => user.email === email);
};

// 👥 회원가입 함수 (더미)
export const registerUser = (userData) => {
  // 이메일 중복 확인
  if (checkEmailExists(userData.email)) {
    return {
      success: false,
      message: '이미 존재하는 이메일입니다.'
    };
  }

  // 새 사용자 ID 생성
  const newId = Math.max(...dummyUsers.map(u => u.id)) + 1;
  
  // 새 사용자 생성
  const newUser = {
    id: newId,
    email: userData.email,
    password: userData.password,
    name: userData.name,
    phone: userData.phone || '',
    birthDate: userData.birthDate || '',
    address: userData.address || '',
    school: userData.school || '',
    securityQuestion: userData.securityQuestion || '',
    securityAnswer: userData.securityAnswer || '',
    role: userData.role || 'student',
    avatar: userData.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${userData.name}`,
    joinDate: new Date().toISOString(),
    loginCount: 0,
    points: 30, // 회원가입 보너스 포인트
    tier: 'individual', // 기본 등급
    profileCompletionRewardReceived: false, // 개인정보 완료 보상 미수령
    dailyUploadsUsed: 0,
    dailyUploadsReset: new Date().toDateString(),
    examHistory: {
      totalExams: 0,
      averageScore: 0,
      recentScores: [],
      subjectScores: {
        korean: { total: 0, average: 0 },
        english: { total: 0, average: 0 },
        math: { total: 0, average: 0 }
      },
      detailedScores: []
    }
  };

  // 더미 데이터에 추가 (실제로는 서버 API 호출)
  dummyUsers.push(newUser);

  // 민감한 정보 제거 후 반환
  const { password: _, securityAnswer: __, ...safeUser } = newUser;
  
  return {
    success: true,
    user: safeUser,
    message: '회원가입이 완료되었습니다!'
  };
};

// 🎭 역할별 권한 정의
export const userRoles = {
  admin: {
    name: '관리자',
    permissions: ['all'],
    color: 'red'
  },
  teacher: {
    name: '선생님',
    permissions: ['grade', 'view_results', 'manage_students'],
    color: 'blue'
  },
  student: {
    name: '학생',
    permissions: ['submit_exam', 'view_own_results'],
    color: 'green'
  },
  parent: {
    name: '학부모',
    permissions: ['view_child_results'],
    color: 'purple'
  }
};

// 🏆 회원등급 시스템 (5단계)
export const memberTiers = {
  individual: {
    name: 'Individual',
    icon: '🥉',
    color: 'amber',
    bgColor: 'bg-amber-100',
    textColor: 'text-amber-700',
    borderColor: 'border-amber-300',
    dailyUploads: 3,
    pointsRequired: 0,
    features: [
      '일일 시험지 채점 3회',
      '기본 채점 서비스',
      '제한된 기능 사용'
    ]
  },
  pro: {
    name: 'PRO',
    icon: '🥈',
    color: 'gray',
    bgColor: 'bg-gray-100',
    textColor: 'text-gray-700',
    borderColor: 'border-gray-300',
    dailyUploads: 5,
    pointsRequired: 100,
    features: [
      '일일 시험지 채점 5회',
      '상세 채점 서비스',
      '오답노트 기능',
      '기타 기능 제한'
    ]
  },
  proplus: {
    name: 'PRO+',
    icon: '🥇',
    color: 'yellow',
    bgColor: 'bg-yellow-100',
    textColor: 'text-yellow-700',
    borderColor: 'border-yellow-300',
    dailyUploads: 10,
    pointsRequired: 300,
    features: [
      '일일 시험지 채점 10회',
      '프리미엄 채점 서비스',
      '오답노트 기능',
      '학습 분석 기능',
      '기타 기능 제한'
    ]
  },
  ultra: {
    name: 'ULTRA',
    icon: '💎',
    color: 'blue',
    bgColor: 'bg-blue-100',
    textColor: 'text-blue-700',
    borderColor: 'border-blue-300',
    dailyUploads: Infinity,
    pointsRequired: 600,
    features: [
      '무제한 시험지 채점',
      'AI 맞춤 분석',
      '오답노트 기능',
      '학습 분석 기능',
      '모든 기능 사용 가능'
    ]
  },
  admin: {
    name: 'Administrator',
    icon: '👑',
    color: 'red',
    bgColor: 'bg-red-100',
    textColor: 'text-red-700',
    borderColor: 'border-red-300',
    dailyUploads: Infinity,
    pointsRequired: 0,
    features: [
      '무제한 사용',
      '모든 기능 접근',
      '관리자 권한',
      '시스템 관리'
    ]
  }
};

// 💰 포인트 시스템
export const pointsSystem = {
  uploadCost: 1, // 시험지 업로드당 포인트 소모
  dailyBonus: 5, // 일일 로그인 보너스
  examComplete: 2, // 시험 완료시 포인트 획득
  wrongAnswerReview: 1, // 오답 복습시 포인트 획득
  profileComplete: 80, // 개인정보 완료시 포인트 획득 (Individual→PRO 업그레이드용)
  achievements: {
    firstUpload: 10,
    week_streak: 20,
    month_streak: 50
  }
};

// 🎁 개인정보 완료 체크 함수
export const checkProfileCompletion = (user) => {
  // 필수 정보: 이메일, 이름, 비밀번호는 회원가입 시 필수
  // 선택 정보: 전화번호, 주소, 학교
  const requiredOptionalFields = ['phone', 'address', 'school'];
  
  const completedFields = requiredOptionalFields.filter(field => 
    user[field] && user[field].trim() !== ''
  );
  
  return {
    isComplete: completedFields.length === requiredOptionalFields.length,
    completedFields,
    totalFields: requiredOptionalFields.length
  };
};

// 🏆 개인정보 완료 보상 지급 함수
export const grantProfileCompletionReward = (userId) => {
  const userIndex = dummyUsers.findIndex(user => user.id === userId);
  
  if (userIndex === -1) {
    return {
      success: false,
      message: '사용자를 찾을 수 없습니다.'
    };
  }

  const user = dummyUsers[userIndex];
  
  // 이미 보상을 받았는지 확인
  if (user.profileCompletionRewardReceived) {
    return {
      success: false,
      message: '이미 보상을 받으셨습니다.'
    };
  }

  // 개인정보 완료 상태 확인
  const profileStatus = checkProfileCompletion(user);
  
  if (!profileStatus.isComplete) {
    return {
      success: false,
      message: '개인정보를 모두 입력해주세요.'
    };
  }

  // 포인트 지급 및 보상 플래그 설정
  const previousPoints = user.points || 0;
  const newPoints = previousPoints + pointsSystem.profileComplete;
  const previousTier = calculateUserTier(previousPoints);
  const newTier = calculateUserTier(newPoints);
  
  dummyUsers[userIndex].points = newPoints;
  dummyUsers[userIndex].tier = newTier;
  dummyUsers[userIndex].profileCompletionRewardReceived = true;
  
  // 로컬 스토리지 업데이트
  const storedUser = getUserFromStorage();
  if (storedUser && storedUser.id === userId) {
    storedUser.points = newPoints;
    storedUser.tier = newTier;
    storedUser.profileCompletionRewardReceived = true;
    saveUserToStorage(storedUser);
  }

  return {
    success: true,
    message: '개인정보 완료 보상이 지급되었습니다!',
    pointsAwarded: pointsSystem.profileComplete,
    newPoints,
    tierUpgraded: previousTier !== newTier,
    previousTier,
    newTier
  };
};

// 🚀 사용자 등급 계산 함수
export const calculateUserTier = (points) => {
  if (points >= 600) return 'ultra';
  if (points >= 300) return 'proplus';
  if (points >= 100) return 'pro';
  return 'individual';
};

// 🔧 로컬 스토리지 관리 함수들
export const saveUserToStorage = (user) => {
  localStorage.setItem('langcheck_user', JSON.stringify(user));
};

export const getUserFromStorage = () => {
  const stored = localStorage.getItem('langcheck_user');
  return stored ? JSON.parse(stored) : null;
};

export const removeUserFromStorage = () => {
  localStorage.removeItem('langcheck_user');
};

// 🔑 비밀번호 업데이트 함수
export const updateUserPassword = (email, newPassword) => {
  const userIndex = dummyUsers.findIndex(user => user.email === email);
  
  if (userIndex === -1) {
    return {
      success: false,
      message: '사용자를 찾을 수 없습니다.'
    };
  }

  // 비밀번호 업데이트
  dummyUsers[userIndex].password = newPassword;
  
  // 로컬 스토리지에 저장된 사용자 정보도 업데이트
  const storedUser = getUserFromStorage();
  if (storedUser && storedUser.email === email) {
    storedUser.password = newPassword;
    saveUserToStorage(storedUser);
  }

  return {
    success: true,
    message: '비밀번호가 성공적으로 업데이트되었습니다.'
  };
}; 