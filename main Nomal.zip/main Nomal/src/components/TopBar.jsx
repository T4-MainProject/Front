import React, { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';

export default function TopBar() {
  const topBarRef = useRef(null);
  const [selectedButton, setSelectedButton] = useState(null); // 선택된 버튼 상태

  useEffect(() => {
    gsap.fromTo(topBarRef.current,
      { y: -50, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.6, ease: "power2.out" }
    );
  }, []);

  return (
    <div 
      ref={topBarRef}
      className="bg-gradient-to-r from-slate-50 via-blue-50 to-indigo-50 border-b border-blue-100/50 overflow-hidden relative"
    >
      {/* 배경 애니메이션 */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 animate-pulse"></div>
      
      <div className="container mx-auto flex justify-between items-center py-3 px-4 text-sm relative z-10">
        <div className="hidden sm:flex items-center space-x-3 text-blue-700">
          <span className="text-lg animate-bounce">🎉</span>
          <span className="font-semibold">신규 가입 시 첫 50장 무료!</span>
          <span className="bg-red-500 text-white px-2 py-0.5 rounded-full text-xs font-bold animate-pulse">
            HOT
          </span>
        </div>
        
        <div className="flex items-center space-x-4 ml-auto">
          {/* 회원가입 버튼 */}
          <button 
            onClick={() => setSelectedButton(selectedButton === 'signup' ? null : 'signup')}
            className={`relative px-6 py-2 font-medium rounded-lg transition-all duration-300 hover:scale-105 ${
              selectedButton === 'signup' 
                ? 'text-white shadow-lg' 
                : 'text-gray-600 hover:text-gray-800 bg-transparent'
            }`}
            style={selectedButton === 'signup' ? {
              background: 'linear-gradient(45deg, #3b82f6, #4f46e5, #6366f1, #8b5cf6, #a855f7, #6366f1, #4f46e5)',
              backgroundSize: '300% 300%',
              animation: 'aurora 3s ease-in-out infinite'
            } : {}}
          >
            <span className="relative z-10">회원가입</span>
            {selectedButton === 'signup' && (
              <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-500"></div>
            )}
          </button>
          
          {/* 로그인 버튼 */}
          <button 
            onClick={() => setSelectedButton(selectedButton === 'login' ? null : 'login')}
            className={`relative px-6 py-2 font-medium rounded-lg transition-all duration-300 hover:scale-105 ${
              selectedButton === 'login' 
                ? 'text-white shadow-lg' 
                : 'text-gray-600 hover:text-gray-800 bg-transparent'
            }`}
            style={selectedButton === 'login' ? {
              background: 'linear-gradient(45deg, #1d4ed8, #3b82f6, #4f46e5, #6366f1, #8b5cf6, #4f46e5, #3b82f6)',
              backgroundSize: '300% 300%',
              animation: 'aurora 4s ease-in-out infinite reverse'
            } : {}}
          >
            <span className="relative z-10">로그인</span>
            {selectedButton === 'login' && (
              <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-500"></div>
            )}
          </button>
        </div>
      </div>
      
      {/* 오로라 애니메이션을 위한 CSS */}
      <style jsx>{`
        @keyframes aurora {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }
      `}</style>
    </div>
  );
}