// ============================================
// src/components/MyPageModal.jsx - 마이페이지 모달
// ============================================
// 📱 주요 기능:
// - 사용자 정보 표시
// - 프로필 편집
// - 통계 정보 표시
// - 반응형 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { userRoles, saveUserToStorage } from '../data/dummyUsers';

export default function MyPageModal({ isOpen, onClose, currentUser, onUserUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    school: ''
  });

  // 모달이 열릴 때 사용자 정보로 초기화
  useEffect(() => {
    if (currentUser) {
      setFormData({
        name: currentUser.name || '',
        phone: currentUser.phone || '',
        address: currentUser.address || '',
        school: currentUser.school || ''
      });
    }
  }, [currentUser]);

  // 모달이 열릴 때 body 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.keyCode === 27) onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    // 원래 데이터로 복원
    setFormData({
      name: currentUser.name || '',
      phone: currentUser.phone || '',
      address: currentUser.address || '',
      school: currentUser.school || ''
    });
  };

  const handleSave = () => {
    const updatedUser = {
      ...currentUser,
      ...formData
    };
    
    // 로컬 스토리지 업데이트
    saveUserToStorage(updatedUser);
    
    // 부모 컴포넌트에 업데이트 알림
    onUserUpdate(updatedUser);
    
    setIsEditing(false);
    alert('정보가 성공적으로 업데이트되었습니다!');
  };

  if (!isOpen || !currentUser) return null;

  const roleInfo = userRoles[currentUser.role] || userRoles.student;
  const joinDate = new Date(currentUser.joinDate).toLocaleDateString('ko-KR');

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* 배경 오버레이 */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 transition-opacity duration-300"
        onClick={onClose}
      />
      
      {/* 모달 컨테이너 */}
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl transform transition-all duration-300 modal-enter">
          {/* 닫기 버튼 */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors duration-200 z-10"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          {/* 헤더 */}
          <div className="px-8 pt-8 pb-6 text-center">
            <div className="w-20 h-20 rounded-full overflow-hidden mx-auto mb-4 shadow-lg ring-4 ring-blue-100">
              <img 
                src={currentUser.avatar} 
                alt={currentUser.name}
                className="w-full h-full object-cover"
              />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">{currentUser.name}</h2>
            <div className="flex items-center justify-center space-x-2">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                roleInfo.color === 'red' ? 'bg-red-100 text-red-600' :
                roleInfo.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                roleInfo.color === 'green' ? 'bg-green-100 text-green-600' :
                'bg-purple-100 text-purple-600'
              }`}>
                {roleInfo.name}
              </span>
              <span className="text-gray-500 text-sm">가입일: {joinDate}</span>
            </div>
          </div>

          {/* 통계 정보 */}
          <div className="px-8 pb-6">
            <div className="grid grid-cols-3 gap-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{currentUser.loginCount || 0}</div>
                <div className="text-sm text-gray-600">로그인 횟수</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {Math.floor(Math.random() * 50) + 1}
                </div>
                <div className="text-sm text-gray-600">채점 완료</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {Math.floor(Math.random() * 20) + 80}%
                </div>
                <div className="text-sm text-gray-600">평균 점수</div>
              </div>
            </div>
          </div>

          {/* 사용자 정보 */}
          <div className="px-8 pb-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">개인정보</h3>
              {!isEditing ? (
                <button
                  onClick={handleEdit}
                  className="text-blue-600 hover:text-blue-800 font-medium text-sm flex items-center"
                >
                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                  편집
                </button>
              ) : (
                <div className="flex space-x-2">
                  <button
                    onClick={handleCancel}
                    className="text-gray-600 hover:text-gray-800 font-medium text-sm px-3 py-1 rounded border"
                  >
                    취소
                  </button>
                  <button
                    onClick={handleSave}
                    className="bg-blue-600 text-white font-medium text-sm px-3 py-1 rounded hover:bg-blue-700"
                  >
                    저장
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 이메일 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  이메일
                </label>
                <input
                  type="email"
                  value={currentUser.email}
                  disabled
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-500"
                />
              </div>

              {/* 이름 */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  이름
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 ${
                    isEditing 
                      ? 'border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
                />
              </div>

              {/* 전화번호 */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  전화번호
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 ${
                    isEditing 
                      ? 'border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
                />
              </div>

              {/* 학교 */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  학교
                </label>
                <input
                  type="text"
                  name="school"
                  value={formData.school}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 ${
                    isEditing 
                      ? 'border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
                />
              </div>

              {/* 주소 */}
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  주소
                </label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 ${
                    isEditing 
                      ? 'border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
                />
              </div>

              {/* 생년월일 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  생년월일
                </label>
                <input
                  type="date"
                  value={currentUser.birthDate}
                  disabled
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-500"
                />
              </div>

              {/* 역할 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  역할
                </label>
                <input
                  type="text"
                  value={roleInfo.name}
                  disabled
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-500"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
} 