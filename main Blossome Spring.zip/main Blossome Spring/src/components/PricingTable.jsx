// 🌸 Spring Blossom PricingTable.jsx - 로즈 멤버십
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const plans = [
  { 
    name: '로즈 입문', 
    price: '무료', 
    period: '/월',
    originalPrice: null,
    features: [
      '일일 채점 3회',
      '기본 벚꽃 정원 서비스',
      '이메일 지원',
      '제한된 기능 사용'
    ],
    popular: false,
    color: 'pink',
    description: '벚꽃 정원에 입문하는 로즈를 위한 기본 플랜',
    icon: '🌺'
  },
  { 
    name: '블로섬 PRO', 
    price: '19,900원', 
    period: '/월',
    originalPrice: '29,900원',
    features: [
      '일일 채점 20회',
      '상세 분석 서비스',
      '벚꽃 정원 오답노트',
      '우선 지원',
      '기타 기능 제한'
    ],
    popular: false,
    color: 'rose',
    description: '학생과 학부모를 위한 블로섬 프로 플랜',
    icon: '🌷'
  },
  { 
    name: '벚꽃 정원 PRO+', 
    price: '39,900원', 
    period: '/월',
    originalPrice: '59,900원',
    features: [
      '일일 채점 50회',
      '프리미엄 분석 서비스',
      '벚꽃 정원 오답노트',
      '학습 분석 기능',
      '고급 리포트',
      '기타 기능 제한'
    ],
    popular: true,
    color: 'pink',
    description: '교사와 소규모 학원을 위한 벚꽃 정원 플러스',
    icon: '🌸'
  },
  { 
    name: '로즈 ULTRA', 
    price: '99,900원', 
    period: '/월',
    originalPrice: '149,900원',
    features: [
      '무제한 채점',
      'AI 맞춤 분석',
      '벚꽃 정원 오답노트',
      '학습 분석 기능',
      '모든 기능 사용',
      '24/7 지원',
      '전담 매니저'
    ],
    popular: false,
    color: 'rose',
    description: '대규모 교육기관을 위한 궁극의 로즈',
    icon: '🌹'
  }
];

export default function PricingTable() {
  const sectionRef = useRef(null);
  const cardsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      cardsRef.current.forEach((card, index) => {
        if (!card) return;

        // 벚꽃 정원 스크롤 트리거 애니메이션 (부드럽고 우아하게)
        gsap.fromTo(card,
          { y: 120, opacity: 0, scale: 0.7, rotationY: -30, filter: "blur(10px)" },
          {
            y: 0,
            opacity: 1,
            scale: 1,
            rotationY: 0,
            filter: "blur(0px)",
            duration: 1.2,
            ease: 'power4.out',
            delay: index * 0.25,
            scrollTrigger: {
              trigger: card,
              start: 'top 90%',
              toggleActions: 'play none none reverse',
            },
          }
        );

        // 벚꽃 정원 호버 애니메이션 (부드럽고 세련되게)
        card.addEventListener('mouseenter', () => {
          gsap.to(card, {
            y: -15,
            scale: 1.05,
            rotationX: 5,
            duration: 0.4,
            ease: 'power3.out',
          });
        });
        card.addEventListener('mouseleave', () => {
          gsap.to(card, {
            y: 0,
            scale: 1,
            rotationX: 0,
            duration: 0.4,
            ease: 'power3.out',
          });
        });
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const getCardStyle = (plan) => {
    if (plan.popular) {
      return 'bg-white/40 backdrop-blur-md border-2 border-pink-400/80 shadow-2xl shadow-pink-500/60 transform scale-105';
    }
    return 'bg-white/30 backdrop-blur-md border border-white/60 shadow-xl shadow-pink-500/40';
  };

  const getIconStyle = (plan) => {
    if (plan.popular) {
      return 'text-4xl animate-pulse drop-shadow-lg';
    }
    return 'text-3xl drop-shadow-md';
  };

  return (
    <section ref={sectionRef} className="py-16 bg-gradient-to-b from-pink-50 via-rose-50 to-pink-100 relative overflow-hidden">
      {/* 벚꽃 정원 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-b from-pink-100/50 via-white/70 to-rose-100/50"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(253,125,191,0.15)_0%,rgba(251,207,232,0.08)_50%,rgba(244,114,182,0.15)_100%)]"></div>
      
      {/* 흩날리는 벚꽃 꽃잎 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-3 h-3 bg-pink-400/50 rounded-full animate-pulse shadow-sm transform rotate-45"></div>
        <div className="absolute top-32 right-1/3 w-2 h-2 bg-rose-400/40 rounded-full animate-pulse delay-700 shadow-sm transform rotate-12"></div>
        <div className="absolute bottom-24 left-1/2 w-2 h-2 bg-pink-300/40 rounded-full animate-pulse delay-1000 shadow-sm transform -rotate-12"></div>
        <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-rose-500/50 rounded-full animate-pulse delay-500 shadow-sm"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-pink-300/40 rounded-full animate-pulse delay-1500 shadow-sm transform rotate-45"></div>
      </div>

      <div className="container mx-auto px-4 text-center mb-8 relative z-10">
        <h2 className="text-3xl font-bold text-pink-700 mb-4 drop-shadow-2xl">🌸 로즈 멤버십 요금제</h2>
        <p className="text-pink-600/80 mt-2 drop-shadow-lg">당신의 벚꽃 정원에 맞는 플랜을 선택하세요</p>
      </div>
      
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
        {plans.map((plan, i) => (
          <div
            key={i}
            ref={el => (cardsRef.current[i] = el)}
            className={`${getCardStyle(plan)} p-6 rounded-2xl flex flex-col relative overflow-hidden transition-all duration-300`}
          >
            {/* 벚꽃 정원 배경 레이어 */}
            <div className="absolute inset-0 bg-gradient-to-br from-white/40 via-pink-50/30 to-rose-100/30 rounded-2xl"></div>
            
            {/* 흩날리는 벚꽃 꽃잎 (카드 내부) */}
            <div className="absolute inset-0 overflow-hidden rounded-2xl pointer-events-none">
              <div className="absolute top-4 right-4 w-2 h-2 bg-pink-400/50 rounded-full animate-pulse shadow-sm transform rotate-45"></div>
              <div className="absolute bottom-6 left-6 w-1 h-1 bg-rose-400/40 rounded-full animate-pulse delay-700 shadow-sm transform rotate-12"></div>
            </div>

            <div className="relative z-10">
              {plan.popular && (
                <div className="text-center mb-4">
                  <div className="inline-flex items-center space-x-2 bg-pink-500/80 text-white px-3 py-1 rounded-full text-sm font-bold border border-pink-400/60 shadow-lg">
                    <span>🌟</span>
                    <span>30일 무료 체험</span>
                  </div>
                </div>
              )}

              {/* 아이콘 */}
              <div className="text-center mb-4">
                <span className={getIconStyle(plan)}>{plan.icon}</span>
              </div>

              <h3 className="text-xl font-semibold mb-2 text-pink-700 text-center drop-shadow-lg">{plan.name}</h3>
              
              <div className="text-center mb-4">
                <p className="text-3xl font-bold text-pink-600 drop-shadow-lg">
                  {plan.price}
                  <span className="text-base font-normal text-pink-500/80">{plan.period}</span>
                </p>
                {plan.originalPrice && (
                  <p className="text-sm text-pink-500/70 line-through mt-1">
                    {plan.originalPrice}
                  </p>
                )}
              </div>

              <p className="text-pink-600/80 mb-6 text-center text-sm leading-relaxed drop-shadow-sm">{plan.description}</p>
              
              <ul className="mb-6 space-y-3 flex-1">
                {plan.features.map((feat, j) => (
                  <li key={j} className="flex items-start space-x-3">
                    <span className="text-pink-500 mt-1 drop-shadow-sm">✨</span>
                    <span className="text-pink-700/90 text-sm drop-shadow-sm">{feat}</span>
                  </li>
                ))}
              </ul>
              
              <button className={`mt-auto w-full py-3 rounded-xl font-semibold transition-all duration-300 ${
                plan.popular 
                  ? 'bg-gradient-to-r from-pink-500 to-rose-500 text-white hover:from-pink-400 hover:to-rose-400 shadow-lg shadow-pink-500/60 hover:shadow-xl hover:shadow-pink-500/80 hover:scale-105 border-2 border-white/40'
                  : 'bg-white/50 backdrop-blur-sm text-pink-700 hover:bg-white/70 border border-white/60 hover:border-pink-400 hover:shadow-lg hover:shadow-pink-500/50'
              }`}>
                {plan.popular ? '🌟 벚꽃 정원 시작하기' : '🌸 로즈 선택하기'}
              </button>
            </div>

            {/* 인기 플랜 글로우 효과 */}
            {plan.popular && (
              <div className="absolute inset-0 bg-gradient-to-br from-pink-400/25 to-transparent rounded-2xl animate-pulse pointer-events-none"></div>
            )}

            {/* 벚꽃 정원 테두리 효과 */}
            <div className="absolute inset-0 rounded-2xl border border-pink-300/40 pointer-events-none"></div>
          </div>
        ))}
      </div>

      {/* 추가 벚꽃 정원 정보 */}
      <div className="container mx-auto px-4 mt-12 text-center relative z-10">
        <div className="bg-white/30 backdrop-blur-md rounded-2xl p-8 border border-white/40 shadow-lg shadow-pink-500/40">
          <h3 className="text-xl font-bold text-pink-700 mb-4 drop-shadow-lg">🌹 모든 로즈 멤버십에 포함된 벚꽃 정원 혜택</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
            <div className="flex items-center justify-center space-x-2">
              <span className="text-pink-500 text-lg">🌺</span>
              <span className="text-pink-700/90">무료 학습 상담</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <span className="text-rose-500 text-lg">🌷</span>
              <span className="text-pink-700/90">24/7 벚꽃 정원 지원</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <span className="text-pink-600 text-lg">🛡️</span>
              <span className="text-pink-700/90">로즈 보안 보장</span>
            </div>
          </div>
          
          <div className="mt-6 pt-6 border-t border-pink-300/60">
            <p className="text-pink-600/80 text-xs italic">
              "모든 멤버십은 벚꽃 정원 이용약관에 따라 제공되며, 로즈 보안 시스템으로 보호됩니다"
            </p>
          </div>
        </div>
      </div>

      {/* 하단 벚꽃 정원 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white/30 to-transparent pointer-events-none"></div>
    </section>
  );
}