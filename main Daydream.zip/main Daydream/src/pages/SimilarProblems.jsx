// ============================================
// ✨ Angelic Light SimilarProblems.jsx - 유사 문제 축복 페이지
// ============================================
// 📚 주요 기능:
// - 축복받은 유사 문제 추천 시스템
// - 천사의 실시간 문제 풀이
// - 빛의 정답 해설 및 피드백
// - 희망 학습 진도 추적
// - 반응형 빛 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function SimilarProblems() {
  const navigate = useNavigate();
  const location = useLocation();
  const [userAnswers, setUserAnswers] = useState({});
  const [showResults, setShowResults] = useState({});
  const [selectedProblem, setSelectedProblem] = useState(null);

  // 축복 효과 상태
  const [blessingEffect, setBlessingEffect] = useState(false);
  const [lightShine, setLightShine] = useState(false);
  const [angelFlicker, setAngelFlicker] = useState(false);
  const [holyAppear, setHolyAppear] = useState(false);

  // URL 파라미터에서 문제 ID 가져오기
  const problemId = location.state?.problemId || 1;
  const originalProblem = location.state?.originalProblem || {};

  // 🏠 뒤로가기
  const handleBackToNote = () => {
    navigate('/wrong-answer-note');
  };

  // 축복 효과 트리거
  useEffect(() => {
    const blessingInterval = setInterval(() => {
      setBlessingEffect(true);
      setTimeout(() => setBlessingEffect(false), 200);
    }, 9000 + Math.random() * 15000);

    const lightInterval = setInterval(() => {
      setLightShine(true);
      setTimeout(() => setLightShine(false), 4000);
    }, 12000 + Math.random() * 20000);

    const angelInterval = setInterval(() => {
      setAngelFlicker(true);
      setTimeout(() => setAngelFlicker(false), 600);
    }, 7000 + Math.random() * 13000);

    const holyInterval = setInterval(() => {
      setHolyAppear(true);
      setTimeout(() => setHolyAppear(false), 2000);
    }, 20000 + Math.random() * 30000);

    return () => {
      clearInterval(blessingInterval);
      clearInterval(lightInterval);
      clearInterval(angelInterval);
      clearInterval(holyInterval);
    };
  }, []);

  // 축복받은 유사 문제 데이터
  const similarProblems = [
    {
      id: 1,
      subject: '✨ 희망의 국어',
      topic: '문학 작품의 빛',
      difficulty: '중급',
      question: '다음 시에서 화자의 정서를 가장 잘 나타낸 것은?',
      passage: `
하늘과 바람과 별과 시

죽는 날까지 하늘을 우러러
한 점 부끄럼이 없기를,
잎새에 이는 바람에도
나는 괴로워했다.
별을 노래하는 마음으로
모든 죽어가는 것을 사랑해야지
그리고 나한테 주어진
길을 걸어가야겠다.

오늘 밤에도 별이 바람에 스치운다.
      `,
      options: [
        '절망과 좌절감',
        '의지와 다짐',
        '그리움과 회상',
        '분노와 원망',
        '환상과 도피'
      ],
      correctAnswer: 1,
      explanation: '이 시는 윤동주의 「서시」로, 화자는 부끄럽지 않은 삶을 살겠다는 의지와 다짐을 보여주고 있습니다. 특히 "한 점 부끄럼이 없기를", "모든 죽어가는 것을 사랑해야지", "길을 걸어가야겠다"와 같은 표현에서 강한 의지를 느낄 수 있습니다.',
      relatedTopics: ['현대시 화자의 정서', '의지적 어조', '상징과 은유']
    },
    {
      id: 2,
      subject: '🌟 빛의 영어',
      topic: '문법의 축복',
      difficulty: '고급',
      question: 'Choose the best answer to complete the sentence.',
      passage: 'The research team _____ the project for six months when they finally made a breakthrough.',
      options: [
        'has been working on',
        'had been working on',
        'was working on',
        'will have been working on',
        'would work on'
      ],
      correctAnswer: 1,
      explanation: '과거완료진행형(had been working)을 사용해야 합니다. "when they finally made a breakthrough"가 과거 시점이므로, 그 이전부터 계속 진행되어온 행위를 나타내는 과거완료진행형이 적절합니다.',
      relatedTopics: ['과거완료진행형', '시제 일치', '완료 시제']
    },
    {
      id: 3,
      subject: '💫 천사의 수학',
      topic: '함수의 신비',
      difficulty: '고급',
      question: '함수 f(x) = x³ - 3x² + 2에 대하여 f\'(x) = 0인 x의 값은?',
      passage: null,
      options: [
        'x = 0, 2',
        'x = 1, 2', 
        'x = 0, 1',
        'x = -1, 2',
        'x = 1, 3'
      ],
      correctAnswer: 0,
      explanation: 'f(x) = x³ - 3x² + 2를 미분하면 f\'(x) = 3x² - 6x = 3x(x - 2)입니다. f\'(x) = 0이 되려면 3x(x - 2) = 0이어야 하므로, x = 0 또는 x = 2입니다.',
      relatedTopics: ['도함수', '함수의 극값', '방정식 풀이']
    },
    {
      id: 4,
      subject: '✨ 희망의 국어',
      topic: '독서의 빛',
      difficulty: '중급',
      question: '다음 글의 핵심 논지로 가장 적절한 것은?',
      passage: `
인공지능이 발달하면서 많은 사람들이 인간의 일자리가 사라질 것을 우려하고 있다. 하지만 역사를 돌아보면, 기술 발전은 항상 새로운 형태의 일자리를 창출해왔다. 산업혁명 때도 많은 수공업자들이 일자리를 잃었지만, 동시에 공장 노동자라는 새로운 직업이 생겨났다. 

중요한 것은 변화에 능동적으로 대응하는 것이다. 인공지능이 대체할 수 없는 인간만의 고유한 능력을 개발하고, 새로운 기술을 활용할 수 있는 역량을 기르는 것이 필요하다. 창의성, 공감 능력, 윤리적 판단력과 같은 인간의 고유한 특성을 더욱 발전시켜야 한다.
      `,
      options: [
        '인공지능 발전을 막아야 한다',
        '기술 변화에 능동적으로 대응해야 한다',
        '새로운 일자리는 창출되지 않는다',
        '인공지능이 모든 일을 대체할 것이다',
        '과거와 현재는 완전히 다르다'
      ],
      correctAnswer: 1,
      explanation: '이 글은 인공지능 발전으로 인한 일자리 변화를 인정하면서도, 역사적 경험을 바탕으로 기술 변화에 능동적으로 대응하여 인간 고유의 능력을 개발해야 한다는 논지를 펼치고 있습니다.',
      relatedTopics: ['논설문 구조', '핵심 논지 파악', '근거와 주장']
    },
    {
      id: 5,
      subject: '🌟 빛의 영어',
      topic: '독해의 축복',
      difficulty: '중급',
      question: 'What is the main idea of the following passage?',
      passage: `
Climate change is one of the most pressing issues of our time. While governments and large corporations play crucial roles in addressing this challenge, individual actions are equally important. Simple changes in daily habits can collectively make a significant impact.

For instance, reducing energy consumption at home, using public transportation, and choosing sustainable products can contribute to environmental protection. Moreover, educating others about climate change and supporting eco-friendly policies can amplify individual efforts.

The key is consistency and persistence. Small actions, when performed by millions of people, can create a powerful force for positive change.
      `,
      options: [
        'Only governments can solve climate change',
        'Individual actions are meaningless',
        'Personal efforts can collectively impact climate change',
        'Climate change is not a serious problem',
        'Technology alone will solve environmental issues'
      ],
      correctAnswer: 2,
      explanation: '이 글의 주요 내용은 기후 변화가 심각한 문제이지만, 개인의 작은 행동들이 모여서 큰 변화를 만들 수 있다는 것입니다. 정부와 기업의 역할도 중요하지만, 개인의 일관된 노력이 집단적으로 큰 힘을 발휘할 수 있다고 강조하고 있습니다.',
      relatedTopics: ['Main idea', 'Reading comprehension', 'Environmental topics']
    }
  ];

  const currentProblems = similarProblems.filter(p => p.id === problemId);

  const handleAnswerSelect = (problemId, optionIndex) => {
    setUserAnswers(prev => ({
      ...prev,
      [problemId]: optionIndex
    }));
  };

  const handleSubmitAnswer = (problemId) => {
    setShowResults(prev => ({
      ...prev,
      [problemId]: true
    }));
  };

  const handleShowProblem = (problemId) => {
    setSelectedProblem(selectedProblem === problemId ? null : problemId);
  };

  const getSubjectColor = (subject) => {
    if (subject.includes('국어')) return 'text-blue-600 bg-blue-100';
    if (subject.includes('영어')) return 'text-sky-600 bg-sky-100';
    if (subject.includes('수학')) return 'text-indigo-600 bg-indigo-100';
    return 'text-blue-600 bg-blue-100';
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case '초급': return 'text-green-600 bg-green-100';
      case '중급': return 'text-yellow-600 bg-yellow-100';
      case '고급': return 'text-red-600 bg-red-100';
      default: return 'text-blue-600 bg-blue-100';
    }
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-white via-sky-50 to-blue-100 relative overflow-hidden ${blessingEffect ? 'animate-pulse' : ''}`}>
      {/* 천사 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 천사 날개 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,0 Q50,30 100,0 L100,20 Q50,50 0,20 Z" fill="url(#angelGradient)" />
            <defs>
              <linearGradient id="angelGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#60a5fa" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 빛 효과 */}
        {lightShine && (
          <div className="absolute top-0 left-1/4 w-2 h-32 bg-gradient-to-b from-blue-400 to-transparent animate-ping opacity-70"></div>
        )}
        
        {/* 천사 출현 효과 */}
        {holyAppear && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-6xl animate-bounce opacity-50">👼</div>
        )}
        
        {/* 구름 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-white/30 to-transparent"></div>
      </div>

      {/* 헤더 */}
      <div className="bg-white bg-opacity-90 shadow-2xl border-b border-blue-200 backdrop-blur-sm relative z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToNote}
                className="text-blue-600 hover:text-blue-500 mr-4 transition-all duration-300 transform hover:scale-110"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-bold bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent ${blessingEffect ? 'animate-bounce' : ''}`}>
                ✨ 유사 문제 축복 - Similar Problems Blessing
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-6xl mx-auto space-y-8">
          
          {/* 소개 카드 */}
          <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-blue-200 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-100/30 to-white/60"></div>
            <div className="text-center relative z-10">
              <div className="text-4xl mb-4 animate-pulse">🎯</div>
              <h2 className="text-2xl font-bold text-blue-600 mb-2">
                문제 #{problemId} 유사 문제 축복
              </h2>
              <p className="text-blue-500">
                AI 천사가 선별한 유사 문제들로 실력을 향상시켜보세요!
              </p>
            </div>
            {/* 천사 장식 */}
            <div className="absolute top-4 right-4 text-blue-400 opacity-30 animate-pulse">✨</div>
            <div className="absolute bottom-4 left-4 text-blue-400 opacity-30 animate-pulse">🪽</div>
          </div>

          {/* 유사 문제 목록 */}
          <div className="space-y-6">
            {currentProblems.map((problem) => (
              <div 
                key={problem.id} 
                className="bg-white bg-opacity-90 rounded-3xl shadow-2xl border-2 border-blue-200 overflow-hidden relative"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 to-white/80"></div>
                
                {/* 문제 헤더 */}
                <div className="p-6 border-b border-blue-200 relative z-10">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${getSubjectColor(problem.subject)}`}>
                        {problem.subject}
                      </span>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${getDifficultyColor(problem.difficulty)}`}>
                        {problem.difficulty}
                      </span>
                      <span className="text-blue-600 text-sm font-medium">
                        {problem.topic}
                      </span>
                    </div>
                    
                    <button
                      onClick={() => handleShowProblem(problem.id)}
                      className={`px-4 py-2 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 ${
                        selectedProblem === problem.id
                          ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/50'
                          : 'bg-blue-100 text-blue-600 hover:bg-blue-200'
                      }`}
                    >
                      {selectedProblem === problem.id ? '문제 접기' : '문제 풀기'}
                    </button>
                  </div>
                </div>

                {/* 문제 내용 */}
                {selectedProblem === problem.id && (
                  <div className="p-6 relative z-10">
                    <div className="space-y-6">
                      {/* 문제 */}
                      <div>
                        <h3 className="text-lg font-bold text-blue-600 mb-4">
                          📝 문제 {problem.id}
                        </h3>
                        <p className="text-blue-700 mb-4 leading-relaxed">
                          {problem.question}
                        </p>
                        
                        {/* 지문 */}
                        {problem.passage && (
                          <div className="bg-blue-50 bg-opacity-50 p-4 rounded-xl border border-blue-200 mb-4">
                            <pre className="whitespace-pre-wrap text-blue-700 font-sans leading-relaxed">
                              {problem.passage}
                            </pre>
                          </div>
                        )}
                      </div>

                      {/* 선택지 */}
                      <div>
                        <h4 className="font-semibold text-blue-600 mb-3">선택지:</h4>
                        <div className="space-y-2">
                          {problem.options.map((option, index) => (
                            <label
                              key={index}
                              className={`block p-3 rounded-xl border-2 cursor-pointer transition-all duration-300 hover:scale-105 ${
                                userAnswers[problem.id] === index
                                  ? 'border-blue-500 bg-blue-100 text-blue-700'
                                  : 'border-blue-200 bg-white hover:border-blue-300 hover:bg-blue-50'
                              }`}
                            >
                              <input
                                type="radio"
                                name={`problem-${problem.id}`}
                                value={index}
                                checked={userAnswers[problem.id] === index}
                                onChange={() => handleAnswerSelect(problem.id, index)}
                                className="sr-only"
                              />
                              <div className="flex items-center">
                                <span className="w-6 h-6 bg-blue-200 rounded-full flex items-center justify-center text-blue-600 font-medium text-sm mr-3">
                                  {index + 1}
                                </span>
                                <span>{option}</span>
                              </div>
                            </label>
                          ))}
                        </div>
                      </div>

                      {/* 제출 버튼 */}
                      <div className="text-center">
                        <button
                          onClick={() => handleSubmitAnswer(problem.id)}
                          disabled={userAnswers[problem.id] === undefined}
                          className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 ${
                            userAnswers[problem.id] !== undefined
                              ? 'bg-gradient-to-r from-blue-600 to-sky-500 text-white hover:from-blue-500 hover:to-sky-400 shadow-lg hover:shadow-blue-500/50'
                              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                          }`}
                        >
                          ✨ 답안 제출
                        </button>
                      </div>

                      {/* 결과 및 해설 */}
                      {showResults[problem.id] && (
                        <div className="mt-6 space-y-4">
                          <div className={`p-4 rounded-xl border-2 ${
                            userAnswers[problem.id] === problem.correctAnswer
                              ? 'border-green-500 bg-green-100'
                              : 'border-red-500 bg-red-100'
                          }`}>
                            <div className="flex items-center space-x-3 mb-3">
                              <span className="text-2xl">
                                {userAnswers[problem.id] === problem.correctAnswer ? '🎉' : '💫'}
                              </span>
                              <span className={`font-bold text-lg ${
                                userAnswers[problem.id] === problem.correctAnswer
                                  ? 'text-green-600'
                                  : 'text-red-600'
                              }`}>
                                {userAnswers[problem.id] === problem.correctAnswer ? '정답입니다!' : '틀렸습니다'}
                              </span>
                            </div>
                            
                            <div className="text-sm space-y-2">
                              <div>
                                <span className="font-medium text-blue-600">정답: </span>
                                <span className="text-blue-700">{problem.correctAnswer + 1}번</span>
                              </div>
                              <div>
                                <span className="font-medium text-blue-600">내 답: </span>
                                <span className="text-blue-700">{userAnswers[problem.id] + 1}번</span>
                              </div>
                            </div>
                          </div>

                          {/* 해설 */}
                          <div className="bg-blue-50 bg-opacity-50 p-4 rounded-xl border border-blue-200">
                            <h5 className="font-bold text-blue-600 mb-3 flex items-center">
                              <span className="text-xl mr-2">💡</span>
                              해설
                            </h5>
                            <p className="text-blue-700 leading-relaxed mb-4">
                              {problem.explanation}
                            </p>
                            
                            {/* 관련 주제 */}
                            <div>
                              <h6 className="font-semibold text-blue-600 mb-2">🔗 관련 주제:</h6>
                              <div className="flex flex-wrap gap-2">
                                {problem.relatedTopics.map((topic, index) => (
                                  <span
                                    key={index}
                                    className="px-3 py-1 bg-blue-100 text-blue-600 text-sm rounded-full border border-blue-200"
                                  >
                                    {topic}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* 학습 진행 상황 */}
          <div className="bg-gradient-to-r from-blue-500 to-sky-400 rounded-3xl shadow-2xl p-8 text-white border-2 border-blue-300 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/30 to-sky-400/30"></div>
            <div className="text-center relative z-10">
              <div className="text-4xl mb-4 animate-bounce">🏆</div>
              <h3 className="text-2xl font-bold mb-2">
                천사의 학습 진행 상황
              </h3>
              <p className="text-blue-100 mb-6">
                축복받은 문제들을 통해 실력을 꾸준히 향상시키고 있습니다!
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white/20 rounded-xl p-4 backdrop-blur-sm">
                  <div className="text-2xl font-bold">
                    {Object.keys(showResults).length}
                  </div>
                  <div className="text-blue-100 text-sm">완료한 문제</div>
                </div>
                
                <div className="bg-white/20 rounded-xl p-4 backdrop-blur-sm">
                  <div className="text-2xl font-bold">
                    {Object.entries(showResults).filter(([id, shown]) => 
                      shown && userAnswers[id] === similarProblems.find(p => p.id === parseInt(id))?.correctAnswer
                    ).length}
                  </div>
                  <div className="text-blue-100 text-sm">정답 개수</div>
                </div>
                
                <div className="bg-white/20 rounded-xl p-4 backdrop-blur-sm">
                  <div className="text-2xl font-bold">
                    {Object.keys(showResults).length > 0 
                      ? Math.round((Object.entries(showResults).filter(([id, shown]) => 
                          shown && userAnswers[id] === similarProblems.find(p => p.id === parseInt(id))?.correctAnswer
                        ).length / Object.keys(showResults).length) * 100)
                      : 0}%
                  </div>
                  <div className="text-blue-100 text-sm">정답률</div>
                </div>
              </div>
            </div>
            {/* 천사 장식 */}
            <div className="absolute top-4 right-4 text-white opacity-50 animate-pulse">✨</div>
            <div className="absolute bottom-4 left-4 text-white opacity-30 animate-pulse">🌟</div>
          </div>
        </div>
      </div>
    </div>
  );
}