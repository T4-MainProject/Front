// ============================================
// 수정된 Home.jsx - 기존 컴포넌트들 활용 + React Router 네비게이션
// ============================================
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AOS from 'aos';
import 'aos/dist/aos.css';

// 기존 컴포넌트들 활용
import TopBar from '../components/TopBar';
import AppHeader from '../components/AppHeader';
import Hero from '../components/Hero';
import FeatureExplanation from '../components/FeatureExplanation'; // 기존 컴포넌트 사용
import Footer from '../components/Footer';

export default function Home() {
  // 🧭 React Router 네비게이션 훅
  const navigate = useNavigate();

  // 📤 업로드 페이지로 이동 함수
  const handleNavigateToUpload = () => {
    navigate('/upload');
  };

  useEffect(() => {
    // AOS 초기화
    AOS.init({
      duration: 600,
      easing: 'ease-out-cubic',
      once: true,
      offset: 50
    });

    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      {/* 최상단 바 */}
      <TopBar />
      
      {/* 헤더 */}
      <AppHeader />

      {/* 메인 콘텐츠 */}
      <main>
        {/* 히어로 섹션 */}
        <Hero onNext={handleNavigateToUpload} />

        {/* 기능 설명 섹션 (기존 컴포넌트 재사용) */}
        <FeatureExplanation />

        {/* 체험 CTA */}
        <section className="py-20 bg-gradient-to-br from-blue-600 to-purple-600 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              🚀 지금 바로 체험해보세요
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              실제 시험지를 업로드하여 AI 자동 채점의 
              <br className="hidden md:block" />
              놀라운 정확성을 직접 확인해보세요
            </p>
            
            <button 
              onClick={handleNavigateToUpload}
              className="bg-white text-purple-600 px-10 py-4 rounded-2xl font-bold text-lg shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 group"
            >
              <span className="flex items-center justify-center">
                채점 시작하기
                <svg className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </span>
            </button>

            {/* 성능 지표 */}
            <div className="mt-12 grid grid-cols-2 md:grid-cols-3 gap-8 max-w-2xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold mb-2">99.8%</div>
                <div className="text-blue-200 text-sm">정확도</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold mb-2">2.3초</div>
                <div className="text-blue-200 text-sm">처리시간</div>
              </div>
              <div className="text-center col-span-2 md:col-span-1">
                <div className="text-3xl font-bold mb-2">10K+</div>
                <div className="text-blue-200 text-sm">월 처리량</div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* 기존 푸터 사용 */}
      <Footer />
    </div>
  );
}