// ============================================
// 🌸 Spring Blossom AnotherPage.jsx - 벚꽃 정원 준비 중 페이지
// ============================================
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

export default function AnotherPage({ onBack }) {
  const containerRef = useRef(null);
  const iconRef = useRef(null);
  const titleRef = useRef(null);
  const descRef = useRef(null);
  const buttonsRef = useRef(null);

  useEffect(() => {
    const tl = gsap.timeline();

    // 벚꽃 정원 페이지 진입 애니메이션 (더 부드럽고 우아하게)
    tl.fromTo(containerRef.current,
      { opacity: 0, filter: "blur(10px)" },
      { opacity: 1, filter: "blur(0px)", duration: 0.8 }
    )
    .fromTo(iconRef.current,
      { 
        scale: 0,
        rotation: -360,
        opacity: 0,
        y: -100
      },
      { 
        scale: 1,
        rotation: 0,
        opacity: 1,
        y: 0,
        duration: 1.2,
        ease: "back.out(2)"
      }
    )
    .fromTo(titleRef.current,
      { 
        y: 80,
        opacity: 0,
        scale: 0.8
      },
      { 
        y: 0,
        opacity: 1,
        scale: 1,
        duration: 0.8,
        ease: "power3.out"
      },
      "-=0.4"
    )
    .fromTo(descRef.current,
      { 
        y: 50,
        opacity: 0,
        scale: 0.9
      },
      { 
        y: 0,
        opacity: 1,
        scale: 1,
        duration: 0.8,
        ease: "power3.out"
      },
      "-=0.3"
    )
    .fromTo(buttonsRef.current,
      { 
        y: 40,
        opacity: 0,
        scale: 0.9
      },
      { 
        y: 0,
        opacity: 1,
        scale: 1,
        duration: 0.7,
        ease: "power3.out"
      },
      "-=0.2"
    );

    // 아이콘 무한 애니메이션 (부드럽고 우아하게)
    gsap.to(iconRef.current, {
      y: -15,
      duration: 3,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut"
    });

    // 회전 애니메이션 추가 (벚꽃 정원 느낌)
    gsap.to(iconRef.current, {
      rotation: 5,
      duration: 4,
      repeat: -1,
      yoyo: true,
      ease: "power1.inOut"
    });

  }, []);

  return (
    <div 
      ref={containerRef}
      className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-pink-100 flex items-center justify-center p-4 relative overflow-hidden"
    >
      {/* 벚꽃 정원 배경 장식 */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-pink-400/25 to-rose-500/15 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-rose-400/20 to-pink-300/25 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/4 w-32 h-32 bg-gradient-to-br from-rose-400/35 to-pink-300/25 rounded-full blur-2xl animate-pulse delay-500"></div>
        <div className="absolute bottom-1/4 right-1/4 w-24 h-24 bg-gradient-to-br from-pink-300/30 to-rose-400/20 rounded-full blur-xl animate-pulse delay-1500"></div>
      </div>

      {/* 추가 벚꽃 정원 레이어 */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/40 via-pink-50/50 to-rose-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_50%,rgba(253,125,191,0.15)_80%)]"></div>

      {/* 흩날리는 벚꽃 꽃잎들 */}
      {[...Array(12)].map((_, i) => (
        <div
          key={i}
          className="absolute w-3 h-3 bg-gradient-to-br from-pink-400 to-rose-500 rounded-full opacity-50 animate-pulse shadow-sm"
          style={{
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 3}s`,
            animationDuration: `${3 + Math.random() * 3}s`,
            transform: `rotate(${Math.random() * 360}deg)`
          }}
        ></div>
      ))}

      <div className="text-center max-w-2xl relative z-10">
        {/* 벚꽃 정원 아이콘 */}
        <div 
          ref={iconRef}
          className="relative inline-block mb-8"
        >
          <div className="w-32 h-32 bg-gradient-to-br from-pink-500 via-rose-400 to-pink-600 rounded-3xl flex items-center justify-center mx-auto shadow-2xl shadow-pink-500/60 relative overflow-hidden group border-2 border-white/40 backdrop-blur-sm">
            <span className="text-white text-6xl relative z-10 drop-shadow-2xl">🌸</span>
            
            {/* 벚꽃 정원 글로우 효과 */}
            <div className="absolute inset-0 bg-gradient-to-br from-pink-400/50 via-rose-300/30 to-pink-400/50 rounded-3xl blur-xl opacity-70 group-hover:opacity-90 transition-opacity duration-300"></div>
            
            {/* 벚꽃 정원 반짝이는 효과 */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent transform -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
          </div>
          
          {/* 벚꽃 정원 주변 장식 */}
          <div className="absolute -top-4 -right-4 w-8 h-8 bg-pink-500 rounded-full animate-bounce shadow-lg shadow-pink-500/60 border-2 border-white/60">
            <span className="flex items-center justify-center w-full h-full text-white text-sm">🌺</span>
          </div>
          <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-rose-500 rounded-full animate-ping shadow-lg shadow-rose-500/60 border border-white/60">
            <span className="flex items-center justify-center w-full h-full text-white text-xs">🌹</span>
          </div>
        </div>
        
        {/* 벚꽃 정원 제목 */}
        <h1 
          ref={titleRef}
          className="text-4xl md:text-5xl font-black text-pink-700 mb-6 drop-shadow-2xl"
        >
          <span className="bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">
            벚꽃 정원에서
          </span>
          <br />
          <span className="text-pink-600">준비 중입니다</span>
        </h1>
        
        {/* 벚꽃 정원 설명 */}
        <div ref={descRef}>
          <p className="text-xl text-pink-600/80 mb-4 leading-relaxed drop-shadow-lg">
            더 나은 벚꽃 정원 경험을 위해 
            <span className="font-semibold text-pink-700"> 로즈 팀이 개발</span> 중입니다.
          </p>
          <p className="text-lg text-pink-500/70 mb-8 drop-shadow-sm">
            곧 벚꽃 정원에서 만나뵐 수 있도록 최선을 다하겠습니다! 🌸
          </p>
        </div>
        
        {/* 벚꽃 정원 버튼들 */}
        <div ref={buttonsRef} className="space-y-4">
          <button 
            onClick={onBack}
            className="w-full sm:w-auto bg-gradient-to-r from-pink-500 to-rose-500 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-xl shadow-pink-500/60 hover:shadow-2xl hover:shadow-pink-500/80 transition-all duration-300 hover:scale-105 group mb-4 border-2 border-white/40 backdrop-blur-sm"
          >
            <span className="flex items-center justify-center">
              <svg className="mr-2 w-5 h-5 group-hover:-translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              🌷 벚꽃 정원으로 돌아가기
            </span>
          </button>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white/40 backdrop-blur-md border-2 border-white/60 text-pink-700 px-6 py-3 rounded-xl font-semibold hover:border-pink-400 hover:text-pink-600 transition-all duration-300 hover:scale-105 group hover:bg-white/60">
              <span className="flex items-center justify-center">
                <span className="mr-2 text-lg">📧</span>
                벚꽃 정원 업데이트 알림
                <svg className="ml-1 w-4 h-4 group-hover:scale-110 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </span>
            </button>
            
            <button className="bg-white/40 backdrop-blur-md border-2 border-white/60 text-pink-700 px-6 py-3 rounded-xl font-semibold hover:border-pink-400 hover:text-pink-600 transition-all duration-300 hover:scale-105 group hover:bg-white/60">
              <span className="flex items-center justify-center">
                <span className="mr-2 text-lg">💬</span>
                벚꽃 정원 문의하기
                <svg className="ml-1 w-4 h-4 group-hover:scale-110 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-3.582 8-8 8a8.012 8.012 0 01-2.282-.323l-4.367 1.46 1.46-4.367A8.012 8.012 0 013 12c0-4.418 3.582-8 8-8s8 3.582 8 8z" />
                </svg>
              </span>
            </button>
          </div>
        </div>

        {/* 벚꽃 정원 진행률 표시 */}
        <div className="mt-12 p-6 bg-white/30 backdrop-blur-md rounded-2xl border border-white/40 shadow-lg shadow-pink-500/40">
          <h3 className="text-lg font-bold text-pink-700 mb-4 drop-shadow-sm">🌸 벚꽃 정원 개발 진행률</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-pink-600/80">로즈 UI/UX 디자인</span>
              <span className="text-sm font-bold text-pink-700">100%</span>
            </div>
            <div className="w-full bg-pink-100/50 rounded-full h-2 border border-pink-300/60">
              <div className="bg-gradient-to-r from-pink-500 to-rose-500 h-2 rounded-full shadow-sm" style={{width: '100%'}}></div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm text-pink-600/80">벚꽃 정원 백엔드 개발</span>
              <span className="text-sm font-bold text-pink-700">75%</span>
            </div>
            <div className="w-full bg-pink-100/50 rounded-full h-2 border border-pink-300/60">
              <div className="bg-gradient-to-r from-pink-500 to-rose-500 h-2 rounded-full shadow-sm" style={{width: '75%'}}></div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm text-pink-600/80">로즈 테스트 & 최적화</span>
              <span className="text-sm font-bold text-pink-700">50%</span>
            </div>
            <div className="w-full bg-pink-100/50 rounded-full h-2 border border-pink-300/60">
              <div className="bg-gradient-to-r from-pink-500 to-rose-500 h-2 rounded-full shadow-sm" style={{width: '50%'}}></div>
            </div>
          </div>
          
          <p className="text-sm text-pink-600/70 mt-4 text-center drop-shadow-sm">
            예상 완료일: <span className="font-semibold text-pink-700">2025년 로즈 시즌</span>
          </p>
        </div>

        {/* 추가 벚꽃 정원 안내 */}
        <div className="mt-8 p-4 bg-pink-100/50 border border-pink-300/60 rounded-xl backdrop-blur-sm">
          <div className="flex items-center justify-center space-x-2 text-sm text-pink-600/80">
            <span>🛡️</span>
            <span>이 페이지는 벚꽃 정원에서 개발 중입니다</span>
            <span>🛡️</span>
          </div>
        </div>
      </div>
    </div>
  );
}