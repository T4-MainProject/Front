// ============================================
// src/data/dummyUsers.js - 더미 사용자 데이터
// ============================================
// 🧪 테스트용 계정들 (실제 서비스에서는 보안상 제거 필요)
// ============================================

export const dummyUsers = [
  {
    id: 1,
    email: '1234@email.com',
    password: 'abcd1234',
    name: '관리자',
    phone: '010-1234-5678',
    birthDate: '1990-01-01',
    address: '서울시 강남구',
    school: '서울대학교',
    securityQuestion: '가장 좋아하는 음식은 무엇입니까?',
    securityAnswer: '피자',
    role: 'admin',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=admin',
    joinDate: '2024-01-01',
    loginCount: 127,
    points: 9999,
    tier: 'admin',
    dailyUploadsUsed: 0,
    dailyUploadsReset: new Date().toDateString(),
    examHistory: {
      totalExams: 150,
      averageScore: 95,
      recentScores: [98, 96, 97, 94, 99],
      subjectScores: {
        korean: { total: 50, average: 96 },
        english: { total: 50, average: 94 },
        math: { total: 50, average: 95 }
      }
    }
  },
  {
    id: 2,
    email: 'teacher@langcheck.com',
    password: 'teacher123',
    name: '김선생',
    phone: '010-2345-6789',
    birthDate: '1985-05-15',
    address: '서울시 서초구',
    school: '서울중학교',
    securityQuestion: '첫 번째 반려동물의 이름은 무엇입니까?',
    securityAnswer: '뽀삐',
    role: 'teacher',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=teacher',
    joinDate: '2024-02-15',
    loginCount: 89,
    points: 450,
    tier: 'gold',
    dailyUploadsUsed: 2,
    dailyUploadsReset: new Date().toDateString(),
    examHistory: {
      totalExams: 89,
      averageScore: 88,
      recentScores: [85, 90, 87, 91, 86],
      subjectScores: {
        korean: { total: 30, average: 89 },
        english: { total: 30, average: 87 },
        math: { total: 29, average: 88 }
      }
    }
  },
  {
    id: 3,
    email: 'abcd@email.com',
    password: 'abcd1234',
    name: '이학생',
    phone: '010-3456-7890',
    birthDate: '2008-12-25',
    address: '서울시 종로구',
    school: '종로중학교',
    securityQuestion: '가장 좋아하는 영화는 무엇입니까?',
    securityAnswer: '어벤져스',
    role: 'student',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=student',
    joinDate: '2024-03-10',
    loginCount: 45,
    points: 180,
    tier: 'silver',
    dailyUploadsUsed: 1,
    dailyUploadsReset: new Date().toDateString(),
    examHistory: {
      totalExams: 45,
      averageScore: 82,
      recentScores: [78, 85, 80, 84, 83],
      subjectScores: {
        korean: { total: 15, average: 83 },
        english: { total: 15, average: 80 },
        math: { total: 15, average: 84 }
      }
    }
  },
  {
    id: 4,
    email: 'parent@langcheck.com',
    password: 'parent123',
    name: '박학부모',
    phone: '010-4567-8901',
    birthDate: '1978-08-30',
    address: '서울시 마포구',
    school: '마포중학교',
    securityQuestion: '어머니의 성함은 무엇입니까?',
    securityAnswer: '김영희',
    role: 'parent',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=parent',
    joinDate: '2024-01-20',
    loginCount: 72,
    points: 720,
    tier: 'platinum',
    dailyUploadsUsed: 0,
    dailyUploadsReset: new Date().toDateString(),
    examHistory: {
      totalExams: 72,
      averageScore: 78,
      recentScores: [75, 80, 76, 82, 79],
      subjectScores: {
        korean: { total: 24, average: 79 },
        english: { total: 24, average: 77 },
        math: { total: 24, average: 78 }
      }
    }
  },
  {
    id: 5,
    email: 'test@test.com',
    password: 'test123',
    name: '테스트',
    phone: '010-0000-0000',
    birthDate: '2000-01-01',
    address: '서울시 강서구',
    school: '테스트중학교',
    securityQuestion: '태어난 병원의 이름은 무엇입니까?',
    securityAnswer: '서울병원',
    role: 'student',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=test',
    joinDate: '2024-04-01',
    loginCount: 12,
    points: 50,
    tier: 'bronze',
    dailyUploadsUsed: 0,
    dailyUploadsReset: new Date().toDateString(),
    examHistory: {
      totalExams: 12,
      averageScore: 75,
      recentScores: [70, 78, 73, 77, 76],
      subjectScores: {
        korean: { total: 4, average: 76 },
        english: { total: 4, average: 74 },
        math: { total: 4, average: 75 }
      }
    }
  }
];

// 🔐 로그인 검증 함수
export const validateLogin = (email, password) => {
  const user = dummyUsers.find(u => u.email === email && u.password === password);
  if (user) {
    // 로그인 카운트 증가 (실제로는 서버에서 처리)
    user.loginCount += 1;
    user.lastLogin = new Date().toISOString();
    
    // 민감한 정보 제거 후 반환
    const { password: _, securityAnswer: __, ...safeUser } = user;
    return {
      success: true,
      user: safeUser,
      message: '로그인 성공!'
    };
  }
  
  return {
    success: false,
    user: null,
    message: '이메일 또는 비밀번호가 올바르지 않습니다.'
  };
};

// 📧 이메일 중복 확인 함수
export const checkEmailExists = (email) => {
  return dummyUsers.some(user => user.email === email);
};

// 👥 회원가입 함수 (더미)
export const registerUser = (userData) => {
  // 이메일 중복 확인
  if (checkEmailExists(userData.email)) {
    return {
      success: false,
      message: '이미 존재하는 이메일입니다.'
    };
  }

  // 새 사용자 ID 생성
  const newId = Math.max(...dummyUsers.map(u => u.id)) + 1;
  
  // 새 사용자 객체 생성
  const newUser = {
    id: newId,
    ...userData,
    role: 'student', // 기본 역할
    avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${userData.email}`,
    joinDate: new Date().toISOString(),
    loginCount: 0,
    points: 30, // 회원가입 보너스 포인트
    tier: 'bronze', // 기본 등급
    dailyUploadsUsed: 0,
    dailyUploadsReset: new Date().toDateString(),
    examHistory: {
      totalExams: 0,
      averageScore: 0,
      recentScores: [],
      subjectScores: {
        korean: { total: 0, average: 0 },
        english: { total: 0, average: 0 },
        math: { total: 0, average: 0 }
      }
    }
  };

  // 더미 데이터에 추가 (실제로는 서버 API 호출)
  dummyUsers.push(newUser);

  // 민감한 정보 제거 후 반환
  const { password: _, securityAnswer: __, ...safeUser } = newUser;
  
  return {
    success: true,
    user: safeUser,
    message: '회원가입이 완료되었습니다!'
  };
};

// 🎭 역할별 권한 정의
export const userRoles = {
  admin: {
    name: '관리자',
    permissions: ['all'],
    color: 'red'
  },
  teacher: {
    name: '선생님',
    permissions: ['grade', 'view_results', 'manage_students'],
    color: 'blue'
  },
  student: {
    name: '학생',
    permissions: ['submit_exam', 'view_own_results'],
    color: 'green'
  },
  parent: {
    name: '학부모',
    permissions: ['view_child_results'],
    color: 'purple'
  }
};

// 🏆 회원등급 시스템 (5단계)
export const memberTiers = {
  bronze: {
    name: 'Bronze',
    icon: '🥉',
    color: 'amber',
    bgColor: 'bg-amber-100',
    textColor: 'text-amber-700',
    borderColor: 'border-amber-300',
    dailyUploads: 3,
    pointsRequired: 0,
    features: [
      '일일 시험지 업로드 3회',
      '기본 채점 서비스',
      '간단한 학습 분석'
    ]
  },
  silver: {
    name: 'Silver',
    icon: '🥈',
    color: 'gray',
    bgColor: 'bg-gray-100',
    textColor: 'text-gray-700',
    borderColor: 'border-gray-300',
    dailyUploads: 5,
    pointsRequired: 100,
    features: [
      '일일 시험지 업로드 5회',
      '상세 채점 서비스',
      '학습 분석 리포트',
      '오답노트 기능'
    ]
  },
  gold: {
    name: 'Gold',
    icon: '🥇',
    color: 'yellow',
    bgColor: 'bg-yellow-100',
    textColor: 'text-yellow-700',
    borderColor: 'border-yellow-300',
    dailyUploads: 10,
    pointsRequired: 300,
    features: [
      '일일 시험지 업로드 10회',
      '프리미엄 채점 서비스',
      '심화 학습 분석',
      '유사 문제 추천',
      '학습 통계 대시보드'
    ]
  },
  platinum: {
    name: 'Platinum',
    icon: '💎',
    color: 'blue',
    bgColor: 'bg-blue-100',
    textColor: 'text-blue-700',
    borderColor: 'border-blue-300',
    dailyUploads: 20,
    pointsRequired: 600,
    features: [
      '일일 시험지 업로드 20회',
      'AI 맞춤 분석',
      '개인별 학습 로드맵',
      '전국 단위 성적 비교',
      '우선 고객지원'
    ]
  },
  admin: {
    name: 'Administrator',
    icon: '👑',
    color: 'red',
    bgColor: 'bg-red-100',
    textColor: 'text-red-700',
    borderColor: 'border-red-300',
    dailyUploads: Infinity,
    pointsRequired: 0,
    features: [
      '무제한 사용',
      '모든 기능 접근',
      '관리자 권한',
      '시스템 관리'
    ]
  }
};

// 💰 포인트 시스템
export const pointsSystem = {
  uploadCost: 1, // 시험지 업로드당 포인트 소모
  dailyBonus: 5, // 일일 로그인 보너스
  examComplete: 2, // 시험 완료시 포인트 획득
  wrongAnswerReview: 1, // 오답 복습시 포인트 획득
  achievements: {
    firstUpload: 10,
    week_streak: 20,
    month_streak: 50
  }
};

// 🚀 사용자 등급 계산 함수
export const calculateUserTier = (points) => {
  if (points >= 600) return 'platinum';
  if (points >= 300) return 'gold';
  if (points >= 100) return 'silver';
  return 'bronze';
};

// 🔧 로컬 스토리지 관리 함수들
export const saveUserToStorage = (user) => {
  localStorage.setItem('langcheck_user', JSON.stringify(user));
};

export const getUserFromStorage = () => {
  const stored = localStorage.getItem('langcheck_user');
  return stored ? JSON.parse(stored) : null;
};

export const removeUserFromStorage = () => {
  localStorage.removeItem('langcheck_user');
}; 