// ============================================
// 🌊 Deep Ocean AnotherPage.jsx - 심해 준비 중 페이지
// ============================================
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

export default function AnotherPage({ onBack }) {
  const containerRef = useRef(null);
  const iconRef = useRef(null);
  const titleRef = useRef(null);
  const descRef = useRef(null);
  const buttonsRef = useRef(null);

  useEffect(() => {
    const tl = gsap.timeline();

    // 심해 페이지 진입 애니메이션 (더 부드럽고 우아하게)
    tl.fromTo(containerRef.current,
      { opacity: 0, filter: "blur(10px)" },
      { opacity: 1, filter: "blur(0px)", duration: 0.8 }
    )
    .fromTo(iconRef.current,
      { 
        scale: 0,
        rotation: -360,
        opacity: 0,
        y: -100
      },
      { 
        scale: 1,
        rotation: 0,
        opacity: 1,
        y: 0,
        duration: 1.2,
        ease: "back.out(2)"
      }
    )
    .fromTo(titleRef.current,
      { 
        y: 80,
        opacity: 0,
        scale: 0.8
      },
      { 
        y: 0,
        opacity: 1,
        scale: 1,
        duration: 0.8,
        ease: "power3.out"
      },
      "-=0.4"
    )
    .fromTo(descRef.current,
      { 
        y: 50,
        opacity: 0,
        scale: 0.9
      },
      { 
        y: 0,
        opacity: 1,
        scale: 1,
        duration: 0.8,
        ease: "power3.out"
      },
      "-=0.3"
    )
    .fromTo(buttonsRef.current,
      { 
        y: 40,
        opacity: 0,
        scale: 0.9
      },
      { 
        y: 0,
        opacity: 1,
        scale: 1,
        duration: 0.7,
        ease: "power3.out"
      },
      "-=0.2"
    );

    // 아이콘 무한 애니메이션 (부드럽고 우아하게)
    gsap.to(iconRef.current, {
      y: -15,
      duration: 3,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut"
    });

    // 회전 애니메이션 추가 (심해 느낌)
    gsap.to(iconRef.current, {
      rotation: 5,
      duration: 4,
      repeat: -1,
      yoyo: true,
      ease: "power1.inOut"
    });

  }, []);

  return (
    <div 
      ref={containerRef}
      className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-blue-950 flex items-center justify-center p-4 relative overflow-hidden"
    >
      {/* 심해 배경 장식 */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-indigo-600/20 to-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-cyan-600/15 to-indigo-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/4 w-32 h-32 bg-gradient-to-br from-blue-600/30 to-cyan-500/20 rounded-full blur-2xl animate-pulse delay-500"></div>
        <div className="absolute bottom-1/4 right-1/4 w-24 h-24 bg-gradient-to-br from-indigo-500/25 to-teal-600/15 rounded-full blur-xl animate-pulse delay-1500"></div>
      </div>

      {/* 추가 심해 레이어 */}
      <div className="absolute inset-0 bg-gradient-to-b from-slate-900/30 via-indigo-900/40 to-blue-900/30"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_50%,rgba(30,64,175,0.1)_80%)]"></div>

      {/* 떠다니는 심해 파티클들 */}
      {[...Array(12)].map((_, i) => (
        <div
          key={i}
          className="absolute w-2 h-2 bg-gradient-to-br from-blue-400 to-cyan-500 rounded-full opacity-40 animate-pulse shadow-lg shadow-blue-500/50"
          style={{
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 3}s`,
            animationDuration: `${3 + Math.random() * 3}s`
          }}
        ></div>
      ))}

      <div className="text-center max-w-2xl relative z-10">
        {/* 심해 아이콘 */}
        <div 
          ref={iconRef}
          className="relative inline-block mb-8"
        >
          <div className="w-32 h-32 bg-gradient-to-br from-indigo-600 via-blue-500 to-cyan-500 rounded-3xl flex items-center justify-center mx-auto shadow-2xl shadow-indigo-500/50 relative overflow-hidden group border-2 border-slate-700/50 backdrop-blur-sm">
            <span className="text-white text-6xl relative z-10 drop-shadow-2xl">🌊</span>
            
            {/* 심해 글로우 효과 */}
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/40 via-blue-500/20 to-cyan-500/40 rounded-3xl blur-xl opacity-60 group-hover:opacity-80 transition-opacity duration-300"></div>
            
            {/* 심해 반짝이는 효과 */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
          </div>
          
          {/* 심해 주변 장식 */}
          <div className="absolute -top-4 -right-4 w-8 h-8 bg-blue-500 rounded-full animate-bounce shadow-lg shadow-blue-500/50 border-2 border-slate-700/50">
            <span className="flex items-center justify-center w-full h-full text-white text-sm">🐠</span>
          </div>
          <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-cyan-500 rounded-full animate-ping shadow-lg shadow-cyan-500/50 border border-slate-700/50">
            <span className="flex items-center justify-center w-full h-full text-white text-xs">🌊</span>
          </div>
        </div>
        
        {/* 심해 제목 */}
        <h1 
          ref={titleRef}
          className="text-4xl md:text-5xl font-black text-cyan-300 mb-6 drop-shadow-2xl"
        >
          <span className="bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
            깊은 바다에서
          </span>
          <br />
          <span className="text-cyan-300">준비 중입니다</span>
        </h1>
        
        {/* 심해 설명 */}
        <div ref={descRef}>
          <p className="text-xl text-cyan-300/80 mb-4 leading-relaxed drop-shadow-lg">
            더 나은 심해 경험을 위해 
            <span className="font-semibold text-cyan-200"> 바다 팀이 개발</span> 중입니다.
          </p>
          <p className="text-lg text-cyan-400/70 mb-8 drop-shadow-sm">
            곧 깊은 바다에서 만나뵐 수 있도록 최선을 다하겠습니다! 🌊
          </p>
        </div>
        
        {/* 심해 버튼들 */}
        <div ref={buttonsRef} className="space-y-4">
          <button 
            onClick={onBack}
            className="w-full sm:w-auto bg-gradient-to-r from-indigo-600 to-cyan-600 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-xl shadow-indigo-500/50 hover:shadow-2xl hover:shadow-indigo-500/70 transition-all duration-300 hover:scale-105 group mb-4 border-2 border-slate-700/50 backdrop-blur-sm"
          >
            <span className="flex items-center justify-center">
              <svg className="mr-2 w-5 h-5 group-hover:-translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              🌊 깊은 바다로 돌아가기
            </span>
          </button>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-slate-800/60 backdrop-blur-md border-2 border-slate-700/50 text-cyan-300 px-6 py-3 rounded-xl font-semibold hover:border-cyan-500 hover:text-cyan-200 transition-all duration-300 hover:scale-105 group hover:bg-slate-800/80">
              <span className="flex items-center justify-center">
                <span className="mr-2 text-lg">📧</span>
                바다 업데이트 알림
                <svg className="ml-1 w-4 h-4 group-hover:scale-110 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </span>
            </button>
            
            <button className="bg-slate-800/60 backdrop-blur-md border-2 border-slate-700/50 text-cyan-300 px-6 py-3 rounded-xl font-semibold hover:border-cyan-500 hover:text-cyan-200 transition-all duration-300 hover:scale-105 group hover:bg-slate-800/80">
              <span className="flex items-center justify-center">
                <span className="mr-2 text-lg">💬</span>
                심해 문의하기
                <svg className="ml-1 w-4 h-4 group-hover:scale-110 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-3.582 8-8 8a8.012 8.012 0 01-2.282-.323l-4.367 1.46 1.46-4.367A8.012 8.012 0 013 12c0-4.418 3.582-8 8-8s8 3.582 8 8z" />
                </svg>
              </span>
            </button>
          </div>
        </div>

        {/* 심해 진행률 표시 */}
        <div className="mt-12 p-6 bg-slate-800/60 backdrop-blur-md rounded-2xl border border-slate-700/50 shadow-lg shadow-indigo-500/30">
          <h3 className="text-lg font-bold text-cyan-300 mb-4 drop-shadow-sm">🌊 심해 개발 진행률</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-cyan-400/80">바다 UI/UX 디자인</span>
              <span className="text-sm font-bold text-cyan-300">100%</span>
            </div>
            <div className="w-full bg-slate-700/40 rounded-full h-2 border border-slate-600/50">
              <div className="bg-gradient-to-r from-indigo-500 to-cyan-500 h-2 rounded-full shadow-sm" style={{width: '100%'}}></div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm text-cyan-400/80">심해 백엔드 개발</span>
              <span className="text-sm font-bold text-cyan-300">75%</span>
            </div>
            <div className="w-full bg-slate-700/40 rounded-full h-2 border border-slate-600/50">
              <div className="bg-gradient-to-r from-indigo-500 to-cyan-500 h-2 rounded-full shadow-sm" style={{width: '75%'}}></div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm text-cyan-400/80">바다 테스트 & 최적화</span>
              <span className="text-sm font-bold text-cyan-300">50%</span>
            </div>
            <div className="w-full bg-slate-700/40 rounded-full h-2 border border-slate-600/50">
              <div className="bg-gradient-to-r from-indigo-500 to-cyan-500 h-2 rounded-full shadow-sm" style={{width: '50%'}}></div>
            </div>
          </div>
          
          <p className="text-sm text-cyan-400/70 mt-4 text-center drop-shadow-sm">
            예상 완료일: <span className="font-semibold text-cyan-300">2025년 바다 시즌</span>
          </p>
        </div>

        {/* 추가 심해 안내 */}
        <div className="mt-8 p-4 bg-slate-800/40 border border-slate-700/50 rounded-xl backdrop-blur-sm">
          <div className="flex items-center justify-center space-x-2 text-sm text-cyan-400/80">
            <span>🛡️</span>
            <span>이 페이지는 깊은 바다에서 개발 중입니다</span>
            <span>🛡️</span>
          </div>
        </div>
      </div>
    </div>
  );
}