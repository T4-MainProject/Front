import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const features = [
  { 
    icon: '⚡', 
    title: '번개같은 학습 속도', 
    description: '평균 7.77초 내 분석 완료로 즉시 희망 결과 확인',
    gradient: 'from-blue-500 to-sky-500',
    bgGradient: 'from-blue-100/30 to-white/60'
  },
  { 
    icon: '👁️', 
    title: '천사의 정확도', 
    description: '100% 정확도로 신뢰할 수 있는 따뜻한 학습 결과',
    gradient: 'from-sky-500 to-blue-600',
    bgGradient: 'from-sky-100/40 to-blue-100/50'
  },
  { 
    icon: '✨', 
    title: '상세한 축복 분석', 
    description: '문제별 천사 분석과 학습 성장 패턴 리포트 제공',
    gradient: 'from-blue-600 to-indigo-600',
    bgGradient: 'from-blue-200/40 to-indigo-100/50'
  },
  { 
    icon: '🔒', 
    title: '천국의 보안', 
    description: '학습정보 보호와 데이터 축복 암호화로 안전한 빛 서비스',
    gradient: 'from-indigo-500 to-blue-600',
    bgGradient: 'from-white/70 to-blue-100/40'
  }
];

export default function FeatureList() {
  const sectionRef = useRef(null);
  const cardsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 빛의 카드들 스태거 애니메이션 (더 우아하게)
      gsap.fromTo(cardsRef.current, 
        {
          y: 100,
          opacity: 0,
          scale: 0.6,
          rotationY: -45,
          filter: "blur(10px)"
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          rotationY: 0,
          filter: "blur(0px)",
          duration: 1.0,
          stagger: 0.2,
          ease: 'power4.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            end: 'bottom 20%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // 빛의 개별 카드 호버 애니메이션 (더 부드럽게)
      cardsRef.current.forEach((card) => {
        if (card) {
          card.addEventListener('mouseenter', () => {
            gsap.to(card, {
              y: -12,
              scale: 1.05,
              rotationX: 5,
              duration: 0.4,
              ease: "power3.out"
            });
          });

          card.addEventListener('mouseleave', () => {
            gsap.to(card, {
              y: 0,
              scale: 1,
              rotationX: 0,
              duration: 0.4,
              ease: "power3.out"
            });
          });
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-b from-white via-sky-50 to-blue-100 relative overflow-hidden">
      {/* 천국의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/80 via-sky-50/60 to-blue-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_40%,rgba(255,255,255,0.8)_80%)]"></div>
      
      {/* 움직이는 빛의 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-1/4 w-2 h-2 bg-blue-400/30 rounded-full animate-pulse"></div>
        <div className="absolute top-40 right-1/3 w-1 h-1 bg-sky-400/40 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-32 left-1/2 w-1 h-1 bg-indigo-400/30 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-blue-500/40 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-sky-300/30 rounded-full animate-pulse delay-1500"></div>
        <div className="absolute top-1/3 left-1/5 w-1 h-1 bg-blue-400/40 rounded-full animate-pulse delay-300"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* 천사의 헤더 */}
        <div className="text-center mb-16" data-aos="fade-up">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-100/60 to-white/80 text-blue-600 px-6 py-3 rounded-full text-sm font-bold mb-6 shadow-lg shadow-blue-500/30 border border-blue-300/50">
            <span>✨</span>
            <span>희망의 특징</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-blue-700 mb-6 drop-shadow-2xl">
            왜 
            <span className="bg-gradient-to-r from-blue-500 to-blue-700 bg-clip-text text-transparent"> AngelCheck</span>을 
            <br className="hidden sm:block" />
            선택해야 할까요?
          </h2>
          <p className="text-xl text-blue-600/80 max-w-3xl mx-auto leading-relaxed drop-shadow-lg">
            최고의 천사 기술력과 천국 사용자 경험을 바탕으로 한 <br className="hidden md:block" />
            차별화된 자동 학습 지원 서비스를 제공합니다
          </p>
        </div>

        {/* 빛의 기능 카드 그리드 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              ref={el => cardsRef.current[index] = el}
              className={`relative group p-8 rounded-3xl bg-gradient-to-br ${feature.bgGradient} border border-blue-300/50 shadow-2xl shadow-blue-500/20 hover:shadow-2xl hover:shadow-blue-500/40 transition-all duration-500 cursor-pointer overflow-hidden backdrop-blur-sm`}
            >
              {/* 빛의 배경 글로우 효과 */}
              <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-15 transition-opacity duration-500 rounded-3xl`}></div>
              
              {/* 추가 빛 레이어 */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/60 via-sky-50/30 to-blue-100/20 rounded-3xl"></div>
              
              {/* 빛의 파티클들 */}
              <div className="absolute top-4 right-4 w-2 h-2 bg-blue-400/40 rounded-full animate-pulse"></div>
              <div className="absolute bottom-6 left-6 w-1 h-1 bg-sky-400/60 rounded-full animate-ping"></div>
              <div className="absolute top-1/2 right-8 w-1.5 h-1.5 bg-indigo-400/50 rounded-full animate-bounce"></div>
              
              {/* 천사의 아이콘 */}
              <div className="relative z-10 mb-6">
                <div className={`inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br ${feature.gradient} rounded-2xl text-white text-2xl shadow-lg shadow-blue-500/50 group-hover:shadow-xl group-hover:shadow-blue-500/70 transition-all duration-300 group-hover:scale-110 group-hover:rotate-12 border border-blue-300/50`}>
                  {feature.icon}
                </div>
              </div>
              
              {/* 빛의 콘텐츠 */}
              <div className="relative z-10">
                <h3 className="text-xl font-bold text-blue-700 mb-3 group-hover:text-blue-800 transition-colors duration-300 drop-shadow-lg">
                  {feature.title}
                </h3>
                
                <p className="text-blue-600/90 text-sm leading-relaxed group-hover:text-blue-700 transition-colors duration-300 drop-shadow-sm">
                  {feature.description}
                </p>
              </div>

              {/* 호버 시 나타나는 빛의 액센트 */}
              <div className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${feature.gradient} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left shadow-lg shadow-blue-500/50`}></div>
              
              {/* 추가 빛 효과 */}
              <div className="absolute inset-0 rounded-3xl border border-blue-300/30 group-hover:border-blue-400/50 transition-colors duration-300"></div>
              
              {/* 중앙 빛 효과 */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-24 h-24 bg-white/10 rounded-full blur-2xl opacity-0 group-hover:opacity-40 transition-opacity duration-500"></div>
            </div>
          ))}
        </div>

        {/* 빛의 추가 통계 섹션 */}
        <div className="mt-20 pt-16 border-t border-blue-300/50" data-aos="fade-up" data-aos-delay="400">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-blue-700 mb-4 drop-shadow-lg">
              <span className="bg-gradient-to-r from-blue-500 to-blue-700 bg-clip-text text-transparent">실시간</span> 
              천국 현황
            </h3>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: '88.8K+', label: '누적 축복수', icon: '✨', color: 'blue' },
              { number: '100%', label: '천사 정확도', icon: '👁️', color: 'sky' },
              { number: '7.77초', label: '평균 분석시간', icon: '⚡', color: 'blue' },
              { number: '999+', label: '활성 학습자', icon: '👼', color: 'blue' }
            ].map((stat, index) => (
              <div key={index} className="text-center group">
                <div className={`inline-flex items-center justify-center w-12 h-12 bg-blue-100/50 border border-blue-300/50 rounded-xl mb-4 group-hover:scale-110 transition-transform duration-300 shadow-md shadow-blue-500/30 group-hover:shadow-lg group-hover:shadow-blue-500/50`}>
                  <span className="text-2xl drop-shadow-lg">{stat.icon}</span>
                </div>
                <div className={`text-3xl font-black text-blue-600 mb-2 group-hover:scale-110 transition-transform duration-300 drop-shadow-lg`}>
                  {stat.number}
                </div>
                <div className="text-sm text-blue-600/80 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>

          {/* 추가 빛의 장식 */}
          <div className="mt-16 flex justify-center">
            <div className="bg-gradient-to-r from-blue-100/40 to-white/60 px-8 py-6 rounded-2xl border border-blue-300/50 shadow-lg shadow-blue-500/30 max-w-md">
              <div className="text-center">
                <div className="text-blue-700 font-bold text-lg mb-2 drop-shadow-sm">✨ 희망의 성장</div>
                <div className="text-blue-600/80 text-sm">매일 새로운 학습자들이 합류하고 있습니다</div>
                <div className="mt-3 flex justify-center space-x-4">
                  <div className="text-center">
                    <div className="text-blue-600 font-bold">+77</div>
                    <div className="text-xs text-blue-500/70">오늘</div>
                  </div>
                  <div className="text-center">
                    <div className="text-blue-600 font-bold">+999</div>
                    <div className="text-xs text-blue-500/70">이번 달</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 하단 빛 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent pointer-events-none"></div>
    </section>
  );
}