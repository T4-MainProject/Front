// ============================================
// src/components/AppHeader.jsx - 로그인/회원가입 버튼 추가
// ============================================
import React, { useState } from 'react';

export default function AppHeader({ currentUser, onOpenLogin, onOpenSignup, onLogout, onOpenMyPage }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogin = () => {
    // 로그인 모달 열기
    onOpenLogin();
  };

  const handleSignup = () => {
    // 회원가입 모달 열기
    onOpenSignup();
  };

  const handleLogout = () => {
    // 로그아웃 확인 후 처리
    if (window.confirm('정말 로그아웃 하시겠습니까?')) {
      onLogout();
    }
  };

  const handleMyPage = () => {
    // 마이페이지 열기
    if (onOpenMyPage) {
      onOpenMyPage();
    }
  };

  return (
    <header className="bg-white/95 backdrop-blur-md shadow-sm border-b border-gray-100 sticky top-0 z-50">
      <div className="container mx-auto flex items-center justify-between py-4 px-4 lg:px-6">
        {/* 로고 영역 */}
        <div className="flex items-center space-x-4">
          <div className="relative group">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-105">
              <span className="text-white font-bold text-xl">L</span>
            </div>
            <div className="absolute inset-0 bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 rounded-xl blur opacity-20 group-hover:opacity-40 transition-opacity duration-300"></div>
          </div>
          
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              LangCheck
            </h1>
            <p className="text-xs text-gray-500 font-medium tracking-wide">
              AI 자동 채점 시스템
            </p>
          </div>
        </div>

        {/* 중앙 상태 표시기 - 데스크탑 */}
        <div className="hidden lg:flex items-center space-x-6">
          <div className="flex items-center space-x-2 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 px-4 py-2 rounded-full">
            <div className="relative">
              <div className="w-3 h-3 bg-green-400 rounded-full"></div>
              <div className="absolute inset-0 w-3 h-3 bg-green-400 rounded-full animate-ping opacity-20"></div>
            </div>
            <span className="text-sm font-medium text-green-700">서비스 운영중</span>
          </div>
          
          <div className="text-sm text-gray-600 bg-gray-50 px-3 py-1 rounded-full">
            <span className="font-medium">정확도</span>
            <span className="ml-2 text-blue-600 font-bold">99.8%</span>
          </div>
        </div>

        {/* 우측 버튼들 */}
        <div className="flex items-center space-x-4">
          {/* 데스크탑 버튼들 */}
          <div className="hidden md:flex items-center space-x-3">
            {currentUser ? (
              // 로그인된 상태
              <>
                {/* 사용자 정보 */}
                <div className="flex items-center space-x-3 text-sm">
                  <div className="w-8 h-8 rounded-full overflow-hidden">
                    <img 
                      src={currentUser.avatar} 
                      alt={currentUser.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="text-gray-700">
                    <span className="font-medium">{currentUser.name}</span>
                    <span className="ml-2 text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded-full">
                      {currentUser.role === 'admin' ? '관리자' : 
                       currentUser.role === 'teacher' ? '선생님' : 
                       currentUser.role === 'student' ? '학생' : '학부모'}
                    </span>
                  </div>
                </div>

                {/* 마이페이지 버튼 */}
                <button
                  onClick={handleMyPage}
                  className="text-gray-600 hover:text-purple-600 font-medium px-4 py-2 rounded-lg hover:bg-purple-50 transition-all duration-200 relative group"
                >
                  마이페이지
                  <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-purple-600 group-hover:w-full transition-all duration-300"></span>
                </button>
                
                {/* 로그아웃 버튼 */}
                <button
                  onClick={handleLogout}
                  className="bg-gradient-to-r from-gray-600 to-gray-700 text-white font-medium px-6 py-2 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 relative overflow-hidden group"
                >
                  <span className="relative z-10">로그아웃</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-500"></div>
                </button>
              </>
            ) : (
              // 로그인되지 않은 상태
              <>
                <button
                  onClick={handleLogin}
                  className="text-gray-600 hover:text-blue-600 font-medium px-4 py-2 rounded-lg hover:bg-blue-50 transition-all duration-200 relative group"
                >
                  로그인
                  <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-blue-600 group-hover:w-full transition-all duration-300"></span>
                </button>
                
                <button
                  onClick={handleSignup}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 text-white font-medium px-6 py-2 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 relative overflow-hidden group"
                >
                  <span className="relative z-10">회원가입</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-500"></div>
                </button>
              </>
            )}
          </div>

          {/* 모바일 메뉴 버튼 */}
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors duration-200"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* 모바일 메뉴 */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 py-4 px-4 shadow-lg">
          {/* 모바일 상태 표시 */}
          <div className="flex items-center space-x-2 bg-green-50 px-3 py-2 rounded-lg mb-4">
            <div className="w-2 h-2 bg-green-400 rounded-full"></div>
            <span className="text-sm text-green-700 font-medium">서비스 운영중</span>
            <span className="text-xs text-gray-500 ml-auto">정확도 99.8%</span>
          </div>
          
          {currentUser ? (
            // 로그인된 상태 - 모바일
            <div className="space-y-4">
              {/* 사용자 정보 */}
              <div className="flex items-center space-x-3 bg-gray-50 px-4 py-3 rounded-lg">
                <div className="w-10 h-10 rounded-full overflow-hidden">
                  <img 
                    src={currentUser.avatar} 
                    alt={currentUser.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <div className="font-medium text-gray-900">{currentUser.name}</div>
                  <div className="text-sm text-gray-500">
                    {currentUser.role === 'admin' ? '관리자' : 
                     currentUser.role === 'teacher' ? '선생님' : 
                     currentUser.role === 'student' ? '학생' : '학부모'}
                  </div>
                </div>
              </div>

              {/* 모바일 버튼들 */}
              <div className="space-y-3">
                <button
                  onClick={handleMyPage}
                  className="w-full text-left text-gray-700 hover:text-purple-600 font-medium py-3 px-4 rounded-lg hover:bg-purple-50 transition-all duration-200"
                >
                  마이페이지
                </button>
                
                <button
                  onClick={handleLogout}
                  className="w-full bg-gradient-to-r from-gray-600 to-gray-700 text-white font-medium py-3 px-4 rounded-lg shadow-md hover:shadow-lg transition-all duration-300"
                >
                  로그아웃
                </button>
              </div>
            </div>
          ) : (
            // 로그인되지 않은 상태 - 모바일
            <div className="space-y-3">
              <button
                onClick={handleLogin}
                className="w-full text-left text-gray-700 hover:text-blue-600 font-medium py-3 px-4 rounded-lg hover:bg-blue-50 transition-all duration-200"
              >
                로그인
              </button>
              
              <button
                onClick={handleSignup}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-medium py-3 px-4 rounded-lg shadow-md hover:shadow-lg transition-all duration-300"
              >
                회원가입
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
}