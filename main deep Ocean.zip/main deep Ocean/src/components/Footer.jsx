// ============================================
// 🌊 Deep Ocean SimpleFooter.jsx - 심해 간소 푸터
// ============================================
import React from 'react';

export default function SimpleFooter() {
  return (
    <footer className="bg-gradient-to-br from-slate-900 via-indigo-900 to-blue-950 text-cyan-300 py-12 relative overflow-hidden border-t border-slate-700/50">
      {/* 🌊 심해 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-indigo-900/70 to-blue-900/80"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_60%_40%,rgba(30,64,175,0.2)_0%,rgba(15,23,42,0.8)_50%,rgba(30,58,138,0.15)_80%)]"></div>
      
      {/* 🐠 떠다니는 심해 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-4 left-1/4 w-3 h-3 bg-blue-400/40 rounded-full animate-pulse shadow-lg shadow-blue-500/50"></div>
        <div className="absolute top-8 right-1/3 w-2 h-2 bg-cyan-400/50 rounded-full animate-pulse delay-700 shadow-lg shadow-cyan-500/50"></div>
        <div className="absolute bottom-6 left-1/2 w-2 h-2 bg-indigo-400/40 rounded-full animate-pulse delay-1000 shadow-lg shadow-indigo-500/50"></div>
        <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-teal-500/50 rounded-full animate-pulse delay-500 shadow-lg shadow-teal-500/50"></div>
        <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-blue-300/40 rounded-full animate-pulse delay-1500 shadow-lg shadow-blue-400/50"></div>
      </div>

      {/* 🐙 미니 산고 장식 */}
      <div className="absolute top-6 right-12 opacity-25">
        <svg width="30" height="40" viewBox="0 0 30 40">
          <path d="M15 40 L15 20 M8 20 Q15 15 22 20" stroke="#3B82F6" strokeWidth="1.5" fill="none"/>
          <circle cx="15" cy="18" r="3" fill="#1E40AF"/>
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between">
          {/* 🌊 심해 로고 */}
          <div className="flex items-center space-x-3 mb-6 md:mb-0">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-cyan-600 rounded-2xl flex items-center justify-center shadow-xl shadow-indigo-500/50 border-2 border-slate-700/50 backdrop-blur-sm">
              <span className="text-cyan-100 font-bold text-xl drop-shadow-lg">🌊</span>
            </div>
            <div>
              <h3 className="text-xl font-bold text-cyan-300 drop-shadow-lg">OceanCheck</h3>
              <p className="text-cyan-200 text-sm drop-shadow-sm">🌊 AI 심해 바다 시스템</p>
            </div>
          </div>
          
          {/* 🌊 간단한 정보 */}
          <div className="text-center md:text-right">
            <p className="text-cyan-200 text-sm mb-2 drop-shadow-sm backdrop-blur-sm bg-slate-800/30 rounded-xl px-4 py-2 border border-slate-700/50">
              © 2025 OceanCheck. All waters reserved.
            </p>
            <div className="flex items-center justify-center md:justify-end space-x-4 text-xs text-cyan-300/80">
              <span className="bg-slate-800/30 backdrop-blur-sm rounded-lg px-3 py-1 border border-slate-700/50">심해 문의</span>
              <span>•</span>
              <span className="bg-slate-800/30 backdrop-blur-sm rounded-lg px-3 py-1 border border-slate-700/50">ocean@deepcheck.co.kr</span>
            </div>
          </div>
        </div>
                
        {/* 🌊 바다 기술 스택 */}
        <div className="mt-8 pt-8 border-t border-slate-700/50 text-center">
          <div className="bg-slate-800/30 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50 shadow-lg shadow-indigo-500/20">
            <p className="text-cyan-200 text-sm drop-shadow-sm mb-4">
              Powered by <span className="text-cyan-300 font-semibold">👁️ YOLO8 심해의 눈</span> •
              <span className="text-blue-300 font-semibold"> 🔮 OCR 바다 추출</span> •
              <span className="text-cyan-300 font-semibold"> 🌊 GPT 바다</span>
            </p>
          </div>
        </div>

        {/* 🌊 추가 바다한 장식 */}
        <div className="mt-6 text-center">
          <div className="inline-flex items-center space-x-3 bg-slate-800/30 backdrop-blur-md px-6 py-3 rounded-full border border-slate-700/50 shadow-lg shadow-indigo-500/30">
            <span className="text-cyan-200 text-xs">⚡ 심해 서버 상태:</span>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse shadow-sm"></div>
              <span className="text-cyan-300 text-xs font-semibold">운영중</span>
            </div>
          </div>
        </div>

        {/* 🌊 심해 축복 메시지 */}
        <div className="mt-6 text-center">
          <div className="bg-slate-800/25 backdrop-blur-sm rounded-2xl p-4 border border-slate-700/50 shadow-lg max-w-2xl mx-auto">
            <p className="text-cyan-200/80 text-xs italic drop-shadow-sm">
              "바다 속에서 태어나 심해를 품는 자들을 위한 바다 시스템"
            </p>
          </div>
        </div>
      </div>

      {/* 🌊 하단 심해 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-10 bg-gradient-to-t from-slate-900/60 to-transparent pointer-events-none backdrop-blur-sm"></div>
      
      {/* 🐠 바다 테두리 */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-400/60 to-transparent shadow-sm"></div>
    </footer>
  );
}