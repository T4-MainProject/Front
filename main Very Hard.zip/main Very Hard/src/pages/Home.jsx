// ============================================
// 수정된 Home.jsx - 기존 컴포넌트들 활용 + React Router 네비게이션 + 모달 상태 관리
// ============================================
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AOS from 'aos';
import 'aos/dist/aos.css';

// 기존 컴포넌트들 활용
import TopBar from '../components/TopBar';
import AppHeader from '../components/AppHeader';
import NavBar from '../components/NavBar';
import Hero from '../components/Hero';
import FeatureExplanation from '../components/FeatureExplanation'; // 기존 컴포넌트 사용
import FeatureList from '../components/FeatureList';
import CustomerCarousel from '../components/CustomerCarousel';
import PricingTable from '../components/PricingTable';
import ContentLeft from '../components/ContentLeft';
import Sidebar from '../components/Sidebar';
import Footer from '../components/Footer';

// 모달 컴포넌트들
import LoginModal from '../components/LoginModal';
import SignupModal from '../components/SignupModal';
import MyPageModal from '../components/MyPageModal';

// 더미 데이터 및 유틸리티
import { getUserFromStorage, removeUserFromStorage } from '../data/dummyUsers';

export default function Home() {
  // 🧭 React Router 네비게이션 훅
  const navigate = useNavigate();
  
  // 🔐 모달 상태 관리
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isSignupModalOpen, setIsSignupModalOpen] = useState(false);
  const [isMyPageModalOpen, setIsMyPageModalOpen] = useState(false);
  
  // 👤 로그인 상태 관리
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // 🎨 버튼 클릭 상태 관리
  const [clickedButtons, setClickedButtons] = useState({
    login: false,
    signup: false,
    mypage: false,
    upload: false,
    demo: false
  });

  // 📤 업로드 페이지로 이동 함수
  const handleNavigateToUpload = () => {
    // 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, upload: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, upload: false }));
    }, 200);
    
    navigate('/upload');
  };

  // 업로드 페이지로 이동하는 함수 (별칭)
  const handleStartUpload = () => {
    // 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, upload: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, upload: false }));
    }, 200);
    
    navigate('/upload');
  };

  // 🔐 로그인 모달 관리 함수들
  const handleOpenLogin = () => {
    // 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, login: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, login: false }));
    }, 200);
    
    setIsLoginModalOpen(true);
  };

  const handleCloseLogin = () => {
    setIsLoginModalOpen(false);
  };

  const handleOpenSignup = () => {
    // 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, signup: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, signup: false }));
    }, 200);
    
    setIsSignupModalOpen(true);
  };

  const handleCloseSignup = () => {
    setIsSignupModalOpen(false);
  };

  // 모달 간 전환 함수들
  const handleSwitchToSignup = () => {
    setIsLoginModalOpen(false);
    setIsSignupModalOpen(true);
  };

  const handleSwitchToLogin = () => {
    setIsSignupModalOpen(false);
    setIsLoginModalOpen(true);
  };

  // 👤 로그인 성공 핸들러
  const handleLoginSuccess = (user) => {
    setCurrentUser(user);
    setIsLoginModalOpen(false);
  };

  // 👥 회원가입 성공 핸들러
  const handleSignupSuccess = (user) => {
    setCurrentUser(user);
    setIsSignupModalOpen(false);
  };

  // 🚪 로그아웃 핸들러
  const handleLogout = () => {
    setCurrentUser(null);
    removeUserFromStorage();
  };

  // 📄 마이페이지 핸들러
  const handleOpenMyPage = () => {
    // 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, mypage: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, mypage: false }));
    }, 200);
    
    setIsMyPageModalOpen(true);
  };

  const handleCloseMyPage = () => {
    setIsMyPageModalOpen(false);
  };

  // 👤 사용자 정보 업데이트 핸들러
  const handleUserUpdate = (updatedUser) => {
    setCurrentUser(updatedUser);
  };

  // 🎬 데모 영상 핸들러
  const handleDemoClick = () => {
    // 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, demo: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, demo: false }));
    }, 200);
    
    // 여기에 데모 영상 로직 추가 가능
    console.log('데모 영상 클릭됨');
  };

  useEffect(() => {
    // AOS 초기화
    AOS.init({
      duration: 800,
      easing: 'ease-out-cubic',
      once: true,
      offset: 100,
      delay: 100
    });

    // 스크롤 시 AOS 새로고침
    const handleScroll = () => {
      AOS.refresh();
    };

    window.addEventListener('scroll', handleScroll);

    // 로컬 스토리지에서 사용자 정보 확인
    const storedUser = getUserFromStorage();
    if (storedUser) {
      setCurrentUser(storedUser);
    }
    setIsLoading(false);

    // 페이지 로드 완료 후 스크롤 위치 조정
    window.scrollTo(0, 0);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      {/* 최상단 바 */}
      <TopBar />
      
      {/* 헤더 */}
      <AppHeader 
        currentUser={currentUser}
        onOpenLogin={handleOpenLogin}
        onOpenSignup={handleOpenSignup}
        onLogout={handleLogout}
        onOpenMyPage={handleOpenMyPage}
      />

      {/* 네비게이션 */}
      <NavBar />

      {/* 메인 콘텐츠 */}
      <main>
        {/* 히어로 섹션 */}
        <Hero onNext={handleNavigateToUpload} />

        {/* 기능 설명 섹션 (기존 컴포넌트 재사용) */}
        <FeatureExplanation />

        {/* 주요 특징 섹션 */}
        <FeatureList />

        {/* 고객사 캐러셀 */}
        <CustomerCarousel />

        {/* 요금제 섹션 */}
        <PricingTable />

        {/* 콘텐츠 + 사이드바 섹션 */}
        <section className="py-16 bg-gradient-to-b from-gray-50 to-white">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row gap-8 max-w-7xl mx-auto">
              {/* 왼쪽 콘텐츠 */}
              <ContentLeft />
              
              {/* 오른쪽 사이드바 */}
              <Sidebar onNext={handleStartUpload} />
            </div>
          </div>
        </section>

        {/* 체험 CTA */}
        <section className="py-20 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 relative overflow-hidden">
          {/* 배경 장식 */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute -top-24 -right-24 w-48 h-48 bg-white/10 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-white/10 rounded-full blur-3xl"></div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-white/5 rounded-full blur-3xl"></div>
          </div>

          <div className="container mx-auto px-4 text-center relative z-10" data-aos="fade-up">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
                🚀 지금 바로 체험해보세요
              </h2>
              <p className="text-xl text-blue-100 mb-8 leading-relaxed max-w-2xl mx-auto">
                실제 시험지를 업로드하여 AI 자동 채점의 
                <br className="hidden md:block" />
                놀라운 정확성을 직접 확인해보세요
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
                <button 
                  onClick={handleNavigateToUpload}
                  className={`px-10 py-4 rounded-2xl font-bold text-lg shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 group ${
                    clickedButtons.upload 
                      ? 'bg-purple-200 text-purple-800 transform scale-95' 
                      : 'bg-white text-purple-600'
                  }`}
                >
                  <span className="flex items-center justify-center">
                    채점 시작하기
                    <svg className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </span>
                </button>
                
                <button 
                  onClick={handleDemoClick}
                  className={`px-8 py-4 rounded-2xl font-bold text-lg transition-all duration-300 hover:scale-105 border-2 ${
                    clickedButtons.demo
                      ? 'bg-white/20 border-white/60 text-white/80 transform scale-95'
                      : 'bg-transparent border-white text-white hover:bg-white hover:text-purple-600'
                  }`}
                >
                  데모 영상 보기
                </button>
              </div>

              {/* 성능 지표 */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-white/90">
                <div className="text-center">
                  <div className="text-3xl font-bold mb-2">1,247+</div>
                  <div className="text-sm">파트너 기관</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold mb-2">2.5M+</div>
                  <div className="text-sm">처리된 시험지</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold mb-2">99.8%</div>
                  <div className="text-sm">정확도</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold mb-2">2.3초</div>
                  <div className="text-sm">평균 처리시간</div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* 기존 푸터 사용 */}
      <Footer />

      {/* 스크롤 투 탑 버튼 */}
      <ScrollToTopButton />

      {/* 모달 컴포넌트들 */}
      <LoginModal 
        isOpen={isLoginModalOpen}
        onClose={handleCloseLogin}
        onSwitchToSignup={handleSwitchToSignup}
        onLoginSuccess={handleLoginSuccess}
      />
      
      <SignupModal 
        isOpen={isSignupModalOpen}
        onClose={handleCloseSignup}
        onSwitchToLogin={handleSwitchToLogin}
        onSignupSuccess={handleSignupSuccess}
      />

      <MyPageModal 
        isOpen={isMyPageModalOpen}
        onClose={handleCloseMyPage}
        currentUser={currentUser}
        onUserUpdate={handleUserUpdate}
      />
    </div>
  );
}

// 스크롤 투 탑 버튼 컴포넌트
function ScrollToTopButton() {
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  if (!isVisible) return null;

  return (
    <button
      onClick={scrollToTop}
      className="fixed bottom-8 right-8 w-14 h-14 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 z-50 group"
      aria-label="맨 위로 스크롤"
    >
      <svg className="w-6 h-6 mx-auto group-hover:-translate-y-1 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
      </svg>
    </button>
  );
}