// ============================================
// 🏝️ Tropical Paradise FeatureExplanation.jsx - 파라다이스 기능 설명
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const features = [
  { 
    icon: '👁️', 
    title: 'YOLO8 파라다이스의 눈', 
    description: '시험지에서 학습/성장란 영역 자동 탐지로 정확한 크리스탈 분석', 
    accent: 'from-emerald-500 to-cyan-500',
    bgColor: 'from-emerald-100/40 to-white/70'
  },
  { 
    icon: '🔮', 
    title: 'OCR 열대 추출', 
    description: 'Vision OCR로 학습자의 답안 정확히 추출하여 파라다이스 디지털화', 
    accent: 'from-cyan-500 to-sky-600',
    bgColor: 'from-cyan-100/50 to-emerald-100/60'
  },
  { 
    icon: '🌺', 
    title: 'GPT 크리스탈 생성', 
    description: '오답 단계별 크리스탈 및 개인 맞춤형 열대 피드백 자동 제공', 
    accent: 'from-sky-600 to-emerald-600',
    bgColor: 'from-sky-200/40 to-cyan-100/50'
  },
];

export default function FeatureExplanation() {
  const sectionRef = useRef(null);
  const cardsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 🌊 카드들 순차 애니메이션 (열대 느낌으로)
      cardsRef.current.forEach((card, index) => {
        if (card) {
          gsap.fromTo(card, 
            { 
              y: 150, 
              opacity: 0, 
              scale: 0.6,
              rotationY: -60,
              rotationX: 30,
              filter: "blur(15px)"
            },
            {
              y: 0,
              opacity: 1,
              scale: 1,
              rotationY: 0,
              rotationX: 0,
              filter: "blur(0px)",
              duration: 1.2,
              ease: "power4.out",
              scrollTrigger: {
                trigger: card,
                start: "top 80%",
                end: "bottom 20%",
                toggleActions: "play none none reverse"
              },
              delay: index * 0.3
            }
          );

          // 🏖️ 호버 애니메이션 (파라다이스 효과)
          card.addEventListener('mouseenter', () => {
            gsap.to(card, {
              y: -20,
              scale: 1.08,
              rotationX: 10,
              duration: 0.5,
              ease: "power3.out"
            });
          });

          card.addEventListener('mouseleave', () => {
            gsap.to(card, {
              y: 0,
              scale: 1,
              rotationX: 0,
              duration: 0.5,
              ease: "power3.out"
            });
          });
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-br from-emerald-50 via-cyan-50 to-sky-100 overflow-hidden relative">
      {/* 🏝️ 열대 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/80 via-emerald-50/60 to-cyan-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(16,185,129,0.15)_0%,rgba(6,182,212,0.1)_50%,rgba(14,165,233,0.15)_80%)]"></div>
      
      {/* 🌺 떠다니는 열대 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-3 h-3 bg-emerald-400/40 rounded-full animate-pulse shadow-lg"></div>
        <div className="absolute top-32 right-1/3 w-2 h-2 bg-cyan-400/50 rounded-full animate-pulse delay-700 shadow-lg"></div>
        <div className="absolute bottom-24 left-1/2 w-2 h-2 bg-sky-400/40 rounded-full animate-pulse delay-1000 shadow-lg"></div>
        <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-teal-500/50 rounded-full animate-pulse delay-500 shadow-lg"></div>
        <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-emerald-300/40 rounded-full animate-pulse delay-1500 shadow-lg"></div>
      </div>

      {/* 🌴 장식 야자수 */}
      <div className="absolute top-24 right-12 opacity-10">
        <svg width="60" height="90" viewBox="0 0 60 90">
          <path d="M30 90 L30 45 M15 45 Q30 30 45 45 M10 40 Q30 25 50 40" stroke="#059669" strokeWidth="2" fill="none"/>
          <circle cx="30" cy="35" r="6" fill="#059669"/>
          <path d="M24 35 Q15 25 5 30 M36 35 Q45 25 55 30" stroke="#16a34a" strokeWidth="2" fill="none"/>
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* 🏖️ 헤더 */}
        <div className="text-center mb-16" data-aos="fade-up">
          <div className="inline-flex items-center space-x-3 bg-white/25 backdrop-blur-md border border-white/30 text-emerald-700 px-6 py-3 rounded-full text-sm font-bold mb-6 shadow-lg shadow-emerald-500/30 hover:shadow-xl hover:shadow-cyan-500/50 transition-all duration-300 hover:scale-105">
            <span>🏝️</span>
            <span>파라다이스 기술</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-emerald-700 mb-6 drop-shadow-2xl">
            파라다이스 기술의 
            <span className="bg-gradient-to-r from-emerald-600 to-cyan-600 bg-clip-text text-transparent"> 완벽한 조화</span>
          </h2>
          <p className="text-xl text-emerald-600 max-w-3xl mx-auto leading-relaxed drop-shadow-lg backdrop-blur-sm bg-white/20 rounded-2xl p-6 border border-white/30">
            최첨단 열대 기술들이 크리스탈처럼 결합되어 <br className="hidden md:block" />
            정확하고 빠른 자동 학습 지원 서비스를 제공합니다
          </p>
        </div>

        {/* 🌊 기능 카드들 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {features.map((feature, index) => (
            <div 
              key={index}
              ref={el => cardsRef.current[index] = el}
              data-aos="fade-up" 
              data-aos-delay={index * 200}
              className={`relative group p-8 rounded-3xl bg-gradient-to-br ${feature.bgColor} backdrop-blur-md border border-white/40 shadow-2xl shadow-emerald-500/20 hover:shadow-3xl hover:shadow-cyan-500/40 transition-all duration-500 cursor-pointer overflow-hidden`}
            >
              {/* 🌺 배경 글로우 */}
              <div className={`absolute inset-0 bg-gradient-to-br ${feature.accent} opacity-0 group-hover:opacity-25 transition-opacity duration-500 rounded-3xl`}></div>
              
              {/* 🏖️ 추가 크리스탈 레이어 */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/60 via-emerald-50/30 to-cyan-100/20 rounded-3xl"></div>
              
              {/* 💎 크리스탈 파티클들 */}
              <div className="absolute top-4 right-4 w-3 h-3 bg-emerald-400/50 rounded-full animate-pulse shadow-lg"></div>
              <div className="absolute bottom-6 left-6 w-2 h-2 bg-cyan-400/60 rounded-full animate-ping shadow-lg"></div>
              <div className="absolute top-1/2 right-8 w-2 h-2 bg-sky-400/50 rounded-full animate-bounce shadow-lg"></div>
              
              {/* 🏝️ 아이콘 */}
              <div className="relative z-10 text-center mb-6">
                <div className="inline-flex items-center justify-center w-24 h-24 bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-emerald-500/50 group-hover:shadow-3xl group-hover:shadow-cyan-500/70 transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 border border-white/40">
                  <span className="text-5xl drop-shadow-2xl">{feature.icon}</span>
                </div>
              </div>
              
              {/* 🌊 콘텐츠 */}
              <div className="relative z-10 text-center">
                <h3 className="text-2xl font-bold text-emerald-700 mb-4 group-hover:text-cyan-700 transition-colors duration-300 drop-shadow-lg">
                  {feature.title}
                </h3>
                <p className="text-emerald-600 leading-relaxed group-hover:text-cyan-600 transition-colors duration-300 drop-shadow-sm">
                  {feature.description}
                </p>
              </div>

              {/* 🌺 하단 크리스탈 액센트 */}
              <div className={`absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r ${feature.accent} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 shadow-lg shadow-emerald-500/50`}></div>
              
              {/* 🏖️ 추가 크리스탈 효과 */}
              <div className="absolute inset-0 rounded-3xl border border-white/40 group-hover:border-emerald-300/60 transition-colors duration-300"></div>
              
              {/* 💎 중앙 글로우 */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-gradient-radial from-white/20 via-emerald-100/10 to-transparent rounded-full blur-3xl opacity-0 group-hover:opacity-60 transition-opacity duration-700"></div>
            </div>
          ))}
        </div>

        {/* 🏝️ 프로세스 플로우 */}
        <div className="mt-20 pt-16 border-t border-white/30" data-aos="fade-up" data-aos-delay="600">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-emerald-700 mb-4 drop-shadow-lg">
              <span className="bg-gradient-to-r from-emerald-600 to-cyan-600 bg-clip-text text-transparent">3단계</span> 
              파라다이스 과정
            </h3>
            <p className="text-emerald-600 text-lg drop-shadow-sm backdrop-blur-sm bg-white/20 rounded-xl p-4 border border-white/30 inline-block">간단하고 빠른 자동 학습 지원 프로세스</p>
          </div>
          
          <div className="flex flex-col md:flex-row items-center justify-center space-y-8 md:space-y-0 md:space-x-12">
            {[
              { step: 1, title: '학습 업로드', desc: '시험지 크리스탈 촬영', icon: '📤', color: 'emerald' },
              { step: 2, title: 'AI 파라다이스 분석', desc: '자동 인식 및 크리스탈화', icon: '🏝️', color: 'cyan' },
              { step: 3, title: '크리스탈 결과 제공', desc: '점수 및 열대 해설', icon: '💎', color: 'emerald' }
            ].map((process, index) => (
              <div key={index} className="flex flex-col items-center relative">
                <div className={`w-20 h-20 bg-gradient-to-br from-emerald-500 to-cyan-500 rounded-3xl flex items-center justify-center text-white font-bold text-2xl mb-4 shadow-2xl shadow-emerald-500/50 hover:shadow-3xl hover:shadow-cyan-500/70 transition-all duration-300 hover:scale-110 border-2 border-white/30 backdrop-blur-sm`}>
                  {process.step}
                </div>
                
                <div className="text-center mb-4 bg-white/20 backdrop-blur-sm rounded-2xl p-4 border border-white/30">
                  <div className="text-4xl mb-3 drop-shadow-lg">{process.icon}</div>
                  <h4 className="font-bold text-emerald-700 text-lg drop-shadow-sm">{process.title}</h4>
                  <p className="text-emerald-600 text-sm">{process.desc}</p>
                </div>

                {/* 🌊 크리스탈 화살표 (마지막 제외) */}
                {index < 2 && (
                  <div className="hidden md:block absolute top-10 left-full text-emerald-500/60 transform translate-x-6 drop-shadow-sm">
                    <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* 🌺 추가 파라다이스 장식 */}
          <div className="mt-16 text-center">
            <div className="inline-flex items-center space-x-4 bg-white/25 backdrop-blur-md px-8 py-6 rounded-3xl border border-white/30 shadow-2xl shadow-emerald-500/30">
              <span className="text-3xl">⚡</span>
              <div className="text-left">
                <div className="text-emerald-700 font-bold text-lg drop-shadow-sm">평균 처리 시간</div>
                <div className="text-emerald-600 text-sm">7.77초 내 완료</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 🌈 하단 크리스탈 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white/40 to-transparent pointer-events-none backdrop-blur-sm"></div>
      
      <style jsx>{`
        .bg-gradient-radial {
          background: radial-gradient(circle, var(--tw-gradient-stops));
        }
        
        .shadow-3xl {
          box-shadow: 0 35px 60px -12px rgba(0, 0, 0, 0.25);
        }
      `}</style>
    </section>
  );
}