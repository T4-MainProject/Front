// ============================================
// 💀 Dark Horror LoginModal.jsx - 지옥문 로그인 모달
// ============================================
// 📝 주요 기능:
// - 모달 형태의 지옥문 로그인 폼
// - 영혼/비밀번호 입력
// - 지옥문 열기, 영혼 계약, 어둠의 비밀번호 복원 버튼
// - 반응형 디자인 및 어둠의 애니메이션
// ============================================

import React, { useState, useEffect } from 'react';
import { validateLogin, saveUserToStorage } from '../data/dummyUsers';
import ForgotPasswordModal from './ForgotPasswordModal';

export default function LoginModal({ isOpen, onClose, onSwitchToSignup, onLoginSuccess }) {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);

  // 모달이 열릴 때 body 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.keyCode === 27) onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  // 지옥문 로그인 모달이 닫힐 때 비밀번호 찾기 모달도 닫기
  useEffect(() => {
    if (!isOpen) {
      setShowForgotPassword(false);
    }
  }, [isOpen]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // 에러 메시지 클리어
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    // 영혼 이메일 검증
    if (!formData.email) {
      newErrors.email = '영혼의 이메일을 입력해주세요.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = '올바른 악마 이메일 형식이 아닙니다.';
    }

    // 어둠의 비밀번호 검증
    if (!formData.password) {
      newErrors.password = '어둠의 비밀번호를 입력해주세요.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);
    
    try {
      // 시뮬레이션된 로딩 (실제 지옥 API 호출 시뮬레이션)
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // 더미 데이터로 영혼 인증 검증
      const result = validateLogin(formData.email, formData.password);
      
      if (result.success) {
        // 지옥 스토리지에 영혼 정보 저장
        saveUserToStorage(result.user);
        
        // 부모 컴포넌트에 지옥문 입장 성공 알림
        onLoginSuccess(result.user);
        
        // 성공 메시지 표시
        alert(`${result.message}\n어둠에 오신 것을 환영합니다, ${result.user.name}님!`);
      } else {
        // 지옥문 입장 실패 에러 표시
        setErrors({ general: result.message });
      }
    } catch (error) {
      console.error('지옥문 입장 오류:', error);
      setErrors({ general: '지옥문 입장 처리 중 어둠의 오류가 발생했습니다.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = () => {
    setShowForgotPassword(true);
  };

  const handleForgotPasswordClose = () => {
    setShowForgotPassword(false);
  };

  const handleForgotPasswordSuccess = () => {
    setShowForgotPassword(false);
    // 어둠의 비밀번호 재설정 성공 후 지옥문 로그인 모달로 돌아가기
    alert('어둠의 비밀번호가 성공적으로 변경되었습니다. 새로운 저주로 지옥문에 입장해주세요.');
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 overflow-y-auto">
        {/* 어둠의 배경 오버레이 */}
        <div 
          className="fixed inset-0 bg-black bg-opacity-80 transition-opacity duration-300"
          onClick={onClose}
        />
        
        {/* 어둠의 모달 컨테이너 */}
        <div className="flex min-h-full items-center justify-center p-4">
          <div className="relative bg-gradient-to-br from-gray-900 via-black to-red-900 rounded-2xl shadow-2xl shadow-red-500/50 w-full max-w-md transform transition-all duration-300 modal-enter border border-red-800/50">
            {/* 어둠의 배경 효과 */}
            <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-gray-900/40 to-red-900/30 rounded-2xl"></div>
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,black_40%)] rounded-2xl"></div>
            
            {/* 움직이는 어둠 파티클 */}
            <div className="absolute inset-0 overflow-hidden rounded-2xl pointer-events-none">
              <div className="absolute top-4 left-8 w-1 h-1 bg-red-500/40 rounded-full animate-pulse"></div>
              <div className="absolute top-12 right-12 w-1 h-1 bg-red-400/30 rounded-full animate-pulse delay-700"></div>
              <div className="absolute bottom-8 left-12 w-1 h-1 bg-gray-500/40 rounded-full animate-pulse delay-1000"></div>
              <div className="absolute top-1/2 right-8 w-1 h-1 bg-red-600/30 rounded-full animate-pulse delay-500"></div>
            </div>

            {/* 어둠의 닫기 버튼 */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-red-400 hover:text-red-300 transition-colors duration-200 z-10"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            {/* 어둠의 헤더 */}
            <div className="px-8 pt-8 pb-6 text-center relative z-10">
              <div className="w-16 h-16 bg-gradient-to-br from-red-600 to-black rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-red-500/50 border border-red-700/50">
                <svg className="w-8 h-8 text-red-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-red-300 mb-2 drop-shadow-lg">🔥 지옥문 입장</h2>
              <p className="text-red-400/80 drop-shadow-sm">DarkCheck 어둠의 세계에 오신 것을 환영합니다</p>
            </div>

            {/* 어둠의 폼 */}
            <form onSubmit={handleSubmit} className="px-8 pb-8 relative z-10">
              {/* 전체 에러 메시지 */}
              {errors.general && (
                <div className="mb-4 p-3 bg-red-900/50 border border-red-700/50 text-red-400 rounded-lg text-sm backdrop-blur-sm">
                  {errors.general}
                </div>
              )}

              {/* 영혼 이메일 입력 */}
              <div className="mb-4">
                <label className="block text-sm font-semibold text-red-300 mb-2 drop-shadow-sm">
                  영혼의 이메일
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="soul@darkcheck.co.kr"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:border-transparent transition-all duration-200 bg-black/60 text-red-300 placeholder-red-600/50 backdrop-blur-sm ${
                    errors.email 
                      ? 'border-red-500 focus:ring-red-500' 
                      : 'border-red-800/50 focus:ring-red-600'
                  }`}
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-400">{errors.email}</p>
                )}
              </div>

              {/* 어둠의 비밀번호 입력 */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-red-300 mb-2 drop-shadow-sm">
                  어둠의 비밀번호
                </label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  placeholder="어둠의 비밀번호를 입력하세요"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:border-transparent transition-all duration-200 bg-black/60 text-red-300 placeholder-red-600/50 backdrop-blur-sm ${
                    errors.password 
                      ? 'border-red-500 focus:ring-red-500' 
                      : 'border-red-800/50 focus:ring-red-600'
                  }`}
                />
                {errors.password && (
                  <p className="mt-1 text-sm text-red-400">{errors.password}</p>
                )}
              </div>

              {/* 지옥문 입장 버튼 */}
              <button
                type="submit"
                disabled={isLoading}
                className={`w-full py-3 px-4 rounded-xl font-semibold text-red-300 transition-all duration-300 mb-4 border ${
                  isLoading
                    ? 'bg-gray-800/60 cursor-not-allowed border-gray-700'
                    : 'bg-gradient-to-r from-red-800 to-black hover:shadow-lg hover:shadow-red-500/50 hover:scale-105 border-red-700/50'
                }`}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center">
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    지옥문 입장 중...
                  </div>
                ) : (
                  '🔥 지옥문 입장'
                )}
              </button>

              {/* 어둠의 비밀번호 복원 */}
              <button
                type="button"
                onClick={handleForgotPassword}
                className="w-full text-center text-sm text-red-400 hover:text-red-300 transition-colors duration-200 mb-4"
              >
                💀 어둠의 비밀번호를 잊으셨나요?
              </button>

              {/* 어둠의 구분선 */}
              <div className="relative mb-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-red-800/50" />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-4 bg-gradient-to-r from-black to-red-900 text-red-500/80">또는</span>
                </div>
              </div>

              {/* 영혼 계약 버튼 */}
              <button
                type="button"
                onClick={onSwitchToSignup}
                className="w-full py-3 px-4 border border-red-800/50 rounded-xl font-semibold text-red-400 hover:bg-red-900/30 hover:border-red-700 transition-all duration-200 bg-black/40 backdrop-blur-sm"
              >
                영혼이 없으신가요? 👹 영혼 계약하기
              </button>
            </form>

            {/* 추가 어둠 장식 */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
              <div className="flex items-center space-x-1 text-xs text-red-600/60">
                <span>⚡</span>
                <span>지옥 서버 연결됨</span>
                <div className="w-1 h-1 bg-red-500 rounded-full animate-pulse"></div>
              </div>
            </div>

            {/* 어둠의 테두리 효과 */}
            <div className="absolute inset-0 rounded-2xl border border-red-700/30 pointer-events-none"></div>
          </div>
        </div>
      </div>

      {/* 어둠의 비밀번호 복원 모달 */}
      <ForgotPasswordModal
        isOpen={showForgotPassword}
        onClose={handleForgotPasswordClose}
        onSuccess={handleForgotPasswordSuccess}
      />
    </>
  );
}