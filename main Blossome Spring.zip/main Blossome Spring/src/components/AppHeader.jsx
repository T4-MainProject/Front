// ============================================
// 🌸 Spring Blossom AppHeader.jsx - 벚꽃 헤더
// ============================================
import React, { useState, useEffect } from 'react';

export default function AppHeader({ currentUser, onOpenLogin, onOpenSignup, onLogout, onOpenMyPage }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // 🌸 활성 버튼 상태 관리 (어떤 벚꽃 정원 문이 열려있는지)
  const [activeButton, setActiveButton] = useState(null); // 'login' | 'signup' | null
  
  // 🌺 버튼 클릭 상태 관리 (벚꽃 클릭 애니메이션용)
  const [clickedButtons, setClickedButtons] = useState({
    login: false,
    signup: false,
    mypage: false
  });

  const handleLogin = () => {
    // 벚꽃 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, login: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, login: false }));
    }, 200);
    
    // 벚꽃 정원 활성 버튼 설정
    setActiveButton('login');
    
    // 벚꽃 정원 문 열기
    if (onOpenLogin) {
      onOpenLogin();
    }
  };

  const handleSignup = () => {
    // 벚꽃 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, signup: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, signup: false }));
    }, 200);
    
    // 벚꽃 정원 활성 버튼 설정
    setActiveButton('signup');
    
    // 로즈 멤버십 가입 문서 열기
    if (onOpenSignup) {
      onOpenSignup();
    }
  };

  const handleLogout = () => {
    // 벚꽃 정원 로그아웃 확인
    if (window.confirm('🌸 정말 벚꽃 정원에서 로그아웃하시겠습니까?')) {
      setActiveButton(null); // 벚꽃 정원 활성 상태 초기화
      if (onLogout) {
        onLogout();
      }
    }
  };

  const handleMyPage = () => {
    // 벚꽃 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, mypage: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, mypage: false }));
    }, 200);
    
    // 로즈 가든 열기
    if (onOpenMyPage) {
      onOpenMyPage();
    }
  };

  // 벚꽃 정원 문이 닫힐 때 활성 상태 해제
  useEffect(() => {
    // 사용자 상태가 변경되면 벚꽃 정원 활성 버튼 초기화
    if (currentUser) {
      setActiveButton(null);
    }
  }, [currentUser]);

  // 로즈 아바타 이미지 처리
  const getAvatarSrc = (avatar) => {
    if (!avatar) {
      return "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiNGRDdEQkYiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iI0ZGRkZGRiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iI0ZGRkZGRiIvPgo8L3N2Zz4K";
    }
    return avatar;
  };

  // 벚꽃 정원 역할 텍스트 변환
  const getRoleText = (role) => {
    switch(role) {
      case 'admin': return '🌸 벚꽃 정원지기';
      case 'teacher': return '🌺 교육 전문가';
      case 'student': return '🌷 로즈 학습자';
      case 'parent': return '💐 보호자';
      default: return '🌹 벚꽃 정원 멤버';
    }
  };

  return (
    <header className="bg-white/20 backdrop-blur-md shadow-2xl shadow-pink-500/20 border-b border-white/30 sticky top-0 z-50 relative overflow-hidden">
      {/* 벚꽃 정원 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-r from-pink-50/60 via-white/70 to-rose-50/60"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(253,125,191,0.15)_0%,rgba(251,207,232,0.1)_50%,rgba(244,114,182,0.15)_100%)]"></div>
      
      {/* 흩날리는 벚꽃 꽃잎들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-3 h-3 bg-pink-400/50 rounded-full animate-pulse shadow-md transform rotate-45"></div>
        <div className="absolute top-2 right-1/3 w-2 h-2 bg-rose-400/40 rounded-full animate-pulse delay-500 shadow-sm transform rotate-12"></div>
        <div className="absolute bottom-1 left-1/2 w-2 h-2 bg-pink-300/40 rounded-full animate-pulse delay-1000 shadow-sm transform -rotate-12"></div>
        <div className="absolute top-1/2 left-1/6 w-1 h-1 bg-rose-300/30 rounded-full animate-pulse delay-700 shadow-sm"></div>
        <div className="absolute bottom-3 right-1/4 w-2 h-2 bg-pink-400/30 rounded-full animate-pulse delay-300 shadow-sm transform rotate-45"></div>
      </div>

      <div className="container mx-auto flex items-center justify-between py-4 px-4 lg:px-6 relative z-10">
        {/* 벚꽃 정원 로고 영역 */}
        <div className="flex items-center space-x-4">
          <div className="relative group">
            <div className="w-12 h-12 bg-gradient-to-br from-pink-500 via-rose-400 to-pink-600 rounded-xl flex items-center justify-center shadow-lg shadow-pink-500/60 group-hover:shadow-xl group-hover:shadow-pink-500/80 transition-all duration-300 group-hover:scale-105 border-2 border-white/40">
              <span className="text-white font-bold text-xl drop-shadow-lg">🌸</span>
            </div>
            <div className="absolute inset-0 bg-gradient-to-br from-pink-400/50 via-rose-300/30 to-pink-400/50 rounded-xl blur opacity-70 group-hover:opacity-90 transition-opacity duration-300"></div>
          </div>
          
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-600 via-rose-500 to-pink-700 bg-clip-text text-transparent drop-shadow-lg">
              BlossomCheck
            </h1>
            <p className="text-xs text-pink-600/80 font-medium tracking-wide drop-shadow-sm">
              🌺 AI 벚꽃 정원 채점 시스템
            </p>
          </div>
        </div>

        {/* 벚꽃 정원 우측 상태 표시기 - 데스크탑 */}
        <div className="hidden lg:flex items-center space-x-6 flex-1 justify-end mr-8">
          <div className="flex items-center space-x-2 bg-white/50 backdrop-blur-sm border border-white/60 px-4 py-2 rounded-full">
            <div className="relative">
              <div className="w-3 h-3 bg-pink-500 rounded-full animate-pulse"></div>
              <div className="absolute inset-0 w-3 h-3 bg-pink-500 rounded-full animate-ping opacity-50"></div>
            </div>
            <span className="text-sm font-medium text-pink-700">🌸 벚꽃 만개중</span>
          </div>
          
          <div className="text-sm text-pink-700 bg-white/50 backdrop-blur-sm px-3 py-1 rounded-full border border-white/60">
            <span className="font-medium">로즈 정확도</span>
            <span className="ml-2 text-pink-600 font-bold">99.8%</span>
          </div>
        </div>

        {/* 벚꽃 정원 우측 버튼들 */}
        <div className="flex items-center space-x-4">
          {/* 벚꽃 정원 데스크탑 버튼들 */}
          <div className="hidden md:flex items-center space-x-3">
            {currentUser ? (
              // 사용자가 로그인된 상태
              <>
                {/* 사용자 정보 */}
                <div className="flex items-center space-x-3 text-sm">
                  <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-pink-400/80 shadow-lg shadow-pink-500/60">
                    <img 
                      src={getAvatarSrc(currentUser.avatar)} 
                      alt={currentUser.name || '벚꽃 정원 멤버'}
                      className="w-full h-full object-cover brightness-110 saturate-150"
                      onError={(e) => {
                        e.target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiNGRDdEQkYiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iI0ZGRkZGRiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iI0ZGRkZGRiIvPgo8L3N2Zz4K";
                      }}
                    />
                  </div>
                  <div className="text-pink-700">
                    <span className="font-medium drop-shadow-sm">{currentUser.name || '벚꽃 정원 멤버'}</span>
                    <span className="ml-2 text-xs bg-pink-100/80 text-pink-700 px-2 py-1 rounded-full border border-pink-300/60">
                      {getRoleText(currentUser.role)}
                    </span>
                  </div>
                </div>

                {/* 로즈 가든 버튼 */}
                <button
                  onClick={handleMyPage}
                  className={`font-medium px-4 py-2 rounded-lg transition-all duration-200 relative group border border-white/60 ${
                    clickedButtons.mypage 
                      ? 'text-pink-700 bg-white/70 transform scale-95 shadow-lg shadow-pink-500/60' 
                      : 'text-pink-600 hover:text-pink-700 hover:bg-white/60 hover:shadow-lg hover:shadow-pink-500/50'
                  }`}
                >
                  🌹 마이 가든
                  <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-pink-500 group-hover:w-full transition-all duration-300"></span>
                </button>
                
                {/* 로그아웃 버튼 */}
                <button
                  onClick={handleLogout}
                  className="bg-gradient-to-r from-pink-500 to-rose-500 text-white font-medium px-6 py-2 rounded-lg shadow-md shadow-pink-500/60 hover:shadow-lg hover:shadow-pink-500/80 transition-all duration-300 hover:scale-105 relative overflow-hidden group border-2 border-white/40"
                >
                  <span className="relative z-10">🌸 로그아웃</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-500"></div>
                </button>
              </>
            ) : (
              // 사용자가 로그인되지 않은 상태
              <>
                <button
                  onClick={handleLogin}
                  className={`font-medium px-6 py-3 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                    activeButton === 'login'
                      ? 'bg-gradient-to-r from-pink-500 via-rose-400 to-pink-600 border-white/60 text-white shadow-lg shadow-pink-500/60'
                      : clickedButtons.login 
                      ? 'bg-gradient-to-r from-pink-500 via-rose-400 to-pink-600 border-white/60 text-white transform scale-95 shadow-lg shadow-pink-500/60'
                      : 'bg-white/50 backdrop-blur-sm border-white/60 text-pink-700 hover:bg-gradient-to-r hover:from-pink-500 hover:via-rose-400 hover:to-pink-600 hover:border-white/60 hover:text-white hover:scale-105 hover:shadow-lg hover:shadow-pink-500/60'
                  }`}
                >
                  {(activeButton === 'login' || clickedButtons.login) && (
                    <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-white/10 to-white/20 animate-pulse"></div>
                  )}
                  <span className="relative z-10">🌸 벚꽃 정원 입장</span>
                </button>
                
                <button
                  onClick={handleSignup}
                  className={`font-medium px-6 py-3 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                    activeButton === 'signup'
                      ? 'bg-gradient-to-r from-pink-500 via-rose-400 to-pink-600 border-white/60 text-white shadow-lg shadow-pink-500/60'
                      : clickedButtons.signup 
                      ? 'bg-gradient-to-r from-pink-500 via-rose-400 to-pink-600 border-white/60 text-white transform scale-95 shadow-lg shadow-pink-500/60'
                      : 'bg-white/50 backdrop-blur-sm border-white/60 text-pink-700 hover:bg-gradient-to-r hover:from-pink-500 hover:via-rose-400 hover:to-pink-600 hover:border-white/60 hover:text-white hover:scale-105 hover:shadow-lg hover:shadow-pink-500/60'
                  }`}
                >
                  {(activeButton === 'signup' || clickedButtons.signup) && (
                    <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-white/10 to-white/20 animate-pulse"></div>
                  )}
                  <span className="relative z-10">🌺 로즈 멤버십</span>
                </button>
              </>
            )}
          </div>

          {/* 벚꽃 정원 모바일 메뉴 버튼 */}
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-white/60 transition-colors duration-200 text-pink-600 border border-white/60 bg-white/40 backdrop-blur-sm"
            aria-label="벚꽃 정원 메뉴 토글"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* 벚꽃 정원 모바일 메뉴 */}
      {isMenuOpen && (
        <div className="md:hidden bg-white/40 backdrop-blur-md border-t border-white/40 py-4 px-4 shadow-lg shadow-pink-500/40">
          {/* 벚꽃 정원 모바일 상태 표시 */}
          <div className="flex items-center space-x-2 bg-pink-100/70 px-3 py-2 rounded-lg mb-4 border border-pink-300/60">
            <div className="relative">
              <div className="w-2 h-2 bg-pink-500 rounded-full animate-pulse"></div>
              <div className="absolute inset-0 w-2 h-2 bg-pink-500 rounded-full animate-ping opacity-40"></div>
            </div>
            <span className="text-sm text-pink-700 font-medium">🌸 벚꽃 만개중</span>
            <span className="text-xs text-pink-600 ml-auto">로즈 정확도 99.8%</span>
          </div>
          
          {currentUser ? (
            // 사용자가 로그인된 상태 - 모바일
            <div className="space-y-4">
              {/* 사용자 정보 */}
              <div className="flex items-center space-x-3 bg-white/50 backdrop-blur-sm px-4 py-3 rounded-lg border border-white/60">
                <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-pink-400/80 shadow-lg shadow-pink-500/60">
                  <img 
                    src={getAvatarSrc(currentUser.avatar)} 
                    alt={currentUser.name || '벚꽃 정원 멤버'}
                    className="w-full h-full object-cover brightness-110 saturate-150"
                    onError={(e) => {
                      e.target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiNGRDdEQkYiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iI0ZGRkZGRiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iI0ZGRkZGRiIvPgo8L3N2Zz4K";
                    }}
                  />
                </div>
                <div>
                  <div className="font-medium text-pink-700">{currentUser.name || '벚꽃 정원 멤버'}</div>
                  <div className="text-sm text-pink-600">
                    {getRoleText(currentUser.role)}
                  </div>
                </div>
              </div>

              {/* 벚꽃 정원 모바일 버튼들 */}
              <div className="space-y-3">
                <button
                  onClick={handleMyPage}
                  className={`w-full text-left font-medium py-3 px-4 rounded-lg transition-all duration-200 border border-white/60 ${
                    clickedButtons.mypage 
                      ? 'text-pink-700 bg-white/70 transform scale-95 shadow-lg shadow-pink-500/60' 
                      : 'text-pink-600 hover:text-pink-700 hover:bg-white/60 hover:shadow-lg hover:shadow-pink-500/50'
                  }`}
                >
                  🌹 마이 가든
                </button>
                
                <button
                  onClick={handleLogout}
                  className="w-full bg-gradient-to-r from-pink-500 to-rose-500 text-white font-medium py-3 px-4 rounded-lg shadow-md shadow-pink-500/60 hover:shadow-lg hover:shadow-pink-500/80 transition-all duration-300 border-2 border-white/40"
                >
                  🌸 로그아웃
                </button>
              </div>
            </div>
          ) : (
            // 사용자가 로그인되지 않은 상태 - 모바일
            <div className="space-y-3">
              <button
                onClick={handleLogin}
                className={`w-full font-medium py-3 px-4 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                  activeButton === 'login'
                    ? 'bg-gradient-to-r from-pink-500 via-rose-400 to-pink-600 border-white/60 text-white shadow-lg shadow-pink-500/60'
                    : clickedButtons.login 
                    ? 'bg-gradient-to-r from-pink-500 via-rose-400 to-pink-600 border-white/60 text-white transform scale-95 shadow-lg shadow-pink-500/60'
                    : 'bg-white/50 backdrop-blur-sm border-white/60 text-pink-700 hover:bg-gradient-to-r hover:from-pink-500 hover:via-rose-400 hover:to-pink-600 hover:border-white/60 hover:text-white hover:shadow-lg hover:shadow-pink-500/60'
                }`}
              >
                {(activeButton === 'login' || clickedButtons.login) && (
                  <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-white/10 to-white/20 animate-pulse"></div>
                )}
                <span className="relative z-10">🌸 벚꽃 정원 입장</span>
              </button>
              
              <button
                onClick={handleSignup}
                className={`w-full font-medium py-3 px-4 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                  activeButton === 'signup'
                    ? 'bg-gradient-to-r from-pink-500 via-rose-400 to-pink-600 border-white/60 text-white shadow-lg shadow-pink-500/60'
                    : clickedButtons.signup 
                    ? 'bg-gradient-to-r from-pink-500 via-rose-400 to-pink-600 border-white/60 text-white transform scale-95 shadow-lg shadow-pink-500/60'
                    : 'bg-white/50 backdrop-blur-sm border-white/60 text-pink-700 hover:bg-gradient-to-r hover:from-pink-500 hover:via-rose-400 hover:to-pink-600 hover:border-white/60 hover:text-white hover:shadow-lg hover:shadow-pink-500/60'
                }`}
              >
                {(activeButton === 'signup' || clickedButtons.signup) && (
                  <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-white/10 to-white/20 animate-pulse"></div>
                )}
                <span className="relative z-10">🌺 로즈 멤버십</span>
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
}