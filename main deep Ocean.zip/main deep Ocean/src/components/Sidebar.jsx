// ============================================
// 🌊 Deep Ocean Footer.jsx - 심해 푸터
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const footerSections = [
  {
    title: '심해 서비스',
    links: [
      { name: 'AI 자동 채점', href: '#' },
      { name: '대량 채점 처리', href: '#' },
      { name: '심해 API 서비스', href: '#' },
      { name: '교육기관 솔루션', href: '#' }
    ]
  },
  {
    title: '바다 지원',
    links: [
      { name: '사용자 가이드', href: '#' },
      { name: '자주 묻는 질문', href: '#' },
      { name: '기술 지원', href: '#' },
      { name: '문의하기', href: '#' }
    ]
  },
  {
    title: '심해 회사',
    links: [
      { name: '회사 소개', href: '#' },
      { name: '채용 정보', href: '#' },
      { name: '보도자료', href: '#' },
      { name: '파트너십', href: '#' }
    ]
  }
];

const socialLinks = [
  { name: 'Ocean Twitter', icon: '🐦', href: '#', color: 'hover:bg-indigo-600' },
  { name: 'Deep Book', icon: '📖', href: '#', color: 'hover:bg-blue-600' },
  { name: 'Ocean Gram', icon: '📸', href: '#', color: 'hover:bg-cyan-600' },
  { name: 'Deep In', icon: '💼', href: '#', color: 'hover:bg-indigo-500' },
  { name: 'Ocean Tube', icon: '📺', href: '#', color: 'hover:bg-teal-600' }
];

export default function Footer() {
  const footerRef = useRef(null);
  const sectionsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 심해 푸터 섹션들 애니메이션 (부드럽고 우아하게)
      gsap.fromTo(sectionsRef.current,
        {
          y: 80,
          opacity: 0,
          scale: 0.9,
          filter: "blur(5px)"
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          filter: "blur(0px)",
          duration: 1.0,
          stagger: 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: footerRef.current,
            start: "top 90%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, footerRef);

    return () => ctx.revert();
  }, []);

  return (
    <footer ref={footerRef} className="bg-gradient-to-br from-slate-900 via-indigo-900 to-blue-950 text-cyan-300 relative overflow-hidden">
      {/* 심해 배경 장식 */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-gradient-to-br from-indigo-600/20 to-cyan-600/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-gradient-to-br from-blue-600/15 to-indigo-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-br from-cyan-600/10 to-blue-500/15 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* 추가 심해 레이어 */}
      <div className="absolute inset-0 bg-gradient-to-b from-slate-900/50 via-indigo-900/60 to-blue-900/70"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(30,64,175,0.15)_0%,rgba(15,23,42,0.8)_50%,rgba(30,58,138,0.1)_100%)]"></div>

      {/* 움직이는 바다 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-2 h-2 bg-blue-400/40 rounded-full animate-pulse shadow-sm shadow-blue-500/50"></div>
        <div className="absolute top-32 right-1/3 w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse delay-700 shadow-sm shadow-cyan-500/50"></div>
        <div className="absolute bottom-24 left-1/2 w-1 h-1 bg-indigo-400/30 rounded-full animate-pulse delay-1000 shadow-sm shadow-indigo-500/50"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-teal-500/40 rounded-full animate-pulse delay-500 shadow-sm shadow-teal-500/50"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-blue-300/30 rounded-full animate-pulse delay-1500 shadow-sm shadow-blue-400/50"></div>
        <div className="absolute top-1/3 left-1/5 w-1 h-1 bg-cyan-500/40 rounded-full animate-pulse delay-300 shadow-sm shadow-cyan-500/50"></div>
      </div>

      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
          {/* 심해 회사 정보 */}
          <div 
            ref={el => sectionsRef.current[0] = el}
            className="lg:col-span-2"
          >
            <div className="flex items-center space-x-4 mb-6">
              <div className="relative group">
                <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 via-blue-500 to-cyan-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-indigo-500/50 group-hover:scale-110 transition-transform duration-300 border-2 border-slate-700/50">
                  <span className="text-cyan-100 font-bold text-2xl drop-shadow-lg">🌊</span>
                </div>
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/40 via-blue-500/20 to-cyan-600/40 rounded-2xl blur opacity-50 group-hover:opacity-70 transition-opacity duration-300"></div>
              </div>
              <div>
                <h3 className="text-2xl font-bold bg-gradient-to-r from-cyan-300 to-blue-300 bg-clip-text text-transparent drop-shadow-lg">
                  OceanCheck
                </h3>
                <p className="text-cyan-200/80 text-sm font-medium tracking-wide">
                  🌊 AI POWERED OCEAN SYSTEM
                </p>
              </div>
            </div>
            
            <p className="text-cyan-200/80 mb-6 leading-relaxed max-w-md drop-shadow-sm">
              첨단 바다 기술로 심해의 미래를 만들어가는 OceanCheck. 
              정확하고 빠른 자동 채점으로 더 나은 학습 경험을 제공합니다.
            </p>
            
            {/* 심해 소셜 미디어 */}
            <div className="flex space-x-3 mb-8">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className={`w-12 h-12 bg-slate-800/60 backdrop-blur-sm ${social.color} rounded-xl flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-lg hover:shadow-indigo-500/30 group border border-slate-700/50 hover:border-cyan-400`}
                  title={social.name}
                >
                  <span className="text-xl group-hover:scale-110 transition-transform duration-200 drop-shadow-sm">
                    {social.icon}
                  </span>
                </a>
              ))}
            </div>

            {/* 심해 연락처 정보 */}
            <div className="space-y-3 text-sm text-cyan-200/80">
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-slate-800/80 rounded-lg flex items-center justify-center group-hover:bg-slate-700 transition-colors duration-200 border border-slate-600/50">
                  <span>📧</span>
                </div>
                <div>
                  <p className="text-cyan-300 font-medium">support@oceancheck.co.kr</p>
                  <p className="text-xs text-cyan-200/70">고객 지원 이메일</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-slate-800/80 rounded-lg flex items-center justify-center group-hover:bg-slate-700 transition-colors duration-200 border border-slate-600/50">
                  <span>📞</span>
                </div>
                <div>
                  <p className="text-cyan-300 font-medium">02-1234-5678</p>
                  <p className="text-xs text-cyan-200/70">평일 09:00 - 18:00</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-slate-800/80 rounded-lg flex items-center justify-center group-hover:bg-slate-700 transition-colors duration-200 border border-slate-600/50">
                  <span>📍</span>
                </div>
                <div>
                  <p className="text-cyan-300 font-medium">서울특별시 강남구 테헤란로 123</p>
                  <p className="text-xs text-cyan-200/70">OceanCheck 본사</p>
                </div>
              </div>
            </div>
          </div>

          {/* 심해 링크 섹션들 */}
          {footerSections.map((section, index) => (
            <div 
              key={index}
              ref={el => sectionsRef.current[index + 1] = el}
              className="lg:col-span-1"
            >
              <h4 className="text-lg font-bold mb-6 text-cyan-300 relative drop-shadow-sm">
                {section.title}
                <div className="absolute bottom-0 left-0 w-8 h-0.5 bg-gradient-to-r from-indigo-600 to-cyan-600 rounded-full"></div>
              </h4>
              <ul className="space-y-4">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a 
                      href={link.href}
                      className="text-cyan-200/80 hover:text-cyan-100 transition-all duration-200 hover:translate-x-2 transform inline-block relative group py-1"
                    >
                      <span className="relative z-10 drop-shadow-sm">{link.name}</span>
                      <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-indigo-600 to-cyan-600 group-hover:w-full transition-all duration-300"></span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* 심해 구분선 */}
        <div className="my-12">
          <div className="h-px bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent"></div>
        </div>
        
        {/* 심해 하단 정보 */}
        <div 
          ref={el => sectionsRef.current[4] = el}
          className="flex flex-col lg:flex-row justify-between items-center text-sm text-cyan-200/80"
        >
          <div className="space-y-2 lg:space-y-0 text-center lg:text-left mb-6 lg:mb-0">
            <p className="font-medium drop-shadow-sm">© 2025 OceanCheck Co., Ltd. All rights reserved.</p>
            <p className="text-xs">
              사업자등록번호: 123-45-67890 | 대표: 🌊 김오션체크 | 통신판매업신고: 2024-서울강남구-1234
            </p>
          </div>
          
          <div className="flex flex-wrap justify-center lg:justify-end gap-6">
            <a href="#" className="hover:text-cyan-100 transition-colors duration-200 relative group">
              <span>이용약관</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-indigo-600 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-cyan-100 transition-colors duration-200 relative group font-semibold">
              <span>개인정보처리방침</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-cyan-600 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-cyan-100 transition-colors duration-200 relative group">
              <span>쿠키정책</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-blue-600 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-cyan-100 transition-colors duration-200 relative group">
              <span>사이트맵</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-teal-600 group-hover:w-full transition-all duration-300"></span>
            </a>
          </div>
        </div>

        {/* 심해 인증 마크들 */}
        <div 
          ref={el => sectionsRef.current[5] = el}
          className="mt-12 pt-8 border-t border-cyan-400/50 flex flex-wrap justify-center lg:justify-start items-center gap-4 text-xs text-cyan-200/80"
        >
          <div className="flex items-center space-x-2 bg-slate-800/60 backdrop-blur-sm px-4 py-2 rounded-xl border border-slate-600/50 hover:border-cyan-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🔒</span>
            <span className="text-cyan-300">보안 인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-slate-800/60 backdrop-blur-sm px-4 py-2 rounded-xl border border-slate-600/50 hover:border-cyan-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">✅</span>
            <span className="text-cyan-300">개인정보보호 인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-slate-800/60 backdrop-blur-sm px-4 py-2 rounded-xl border border-slate-600/50 hover:border-cyan-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🏆</span>
            <span className="text-cyan-300">ISO 27001 인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-slate-800/60 backdrop-blur-sm px-4 py-2 rounded-xl border border-slate-600/50 hover:border-cyan-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🛡️</span>
            <span className="text-cyan-300">GDPR 준수</span>
          </div>
        </div>

        {/* 심해 추가 정보 */}
        <div 
          ref={el => sectionsRef.current[6] = el}
          className="mt-8 text-center"
        >
          <p className="text-xs text-cyan-200/70 leading-relaxed max-w-2xl mx-auto drop-shadow-sm">
            OceanCheck는 바다 기술 혁신을 통해 더 나은 교육 환경을 만들어가고 있습니다. 
            우리의 AI 기술이 전 세계 교육자와 학습자들에게 도움이 되기를 바랍니다.
          </p>
          
          <div className="mt-6 flex justify-center items-center space-x-2 text-xs text-cyan-200/80">
            <span>Made with</span>
            <span className="text-cyan-400 animate-pulse">💙</span>
            <span>in Seoul, Korea</span>
          </div>
        </div>

        {/* 추가 심해 안내 */}
        <div 
          ref={el => sectionsRef.current[7] = el}
          className="mt-8 text-center"
        >
          <div className="inline-flex items-center space-x-2 bg-slate-800/80 text-cyan-300 px-4 py-2 rounded-full text-xs border border-slate-600/50">
            <span>🌟</span>
            <span>이 사이트는 심해 보안 시스템으로 보호됩니다</span>
          </div>
        </div>
      </div>

      {/* 하단 심해 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-slate-900/40 to-transparent pointer-events-none"></div>
    </footer>
  );
}