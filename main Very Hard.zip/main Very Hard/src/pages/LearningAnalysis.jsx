import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function LearningAnalysis() {
  const navigate = useNavigate();
  const [selectedPeriod, setSelectedPeriod] = useState('최근 6개월');
  const [selectedChartSubject, setSelectedChartSubject] = useState('과목 전체');

  // 🏠 뒤로가기
  const handleBackToResult = () => {
    navigate('/grading-result');
  };

  // 더미 성적 데이터
  const scoreData = {
    '최근 6개월': [
      { exam: '1회', date: '2024-01', total: 72, korean: 68, english: 75, math: 73 },
      { exam: '2회', date: '2024-02', total: 76, korean: 72, english: 78, math: 78 },
      { exam: '3회', date: '2024-03', total: 82, korean: 85, english: 80, math: 81 },
      { exam: '4회', date: '2024-04', total: 78, korean: 82, english: 75, math: 77 },
      { exam: '5회', date: '2024-05', total: 86, korean: 88, english: 85, math: 85 },
      { exam: '6회', date: '2024-06', total: 89, korean: 92, english: 87, math: 88 }
    ],
    '최근 1년': [
      { exam: '1회', date: '2023-06', total: 65, korean: 62, english: 68, math: 65 },
      { exam: '2회', date: '2023-08', total: 68, korean: 65, english: 70, math: 69 },
      { exam: '3회', date: '2023-10', total: 71, korean: 67, english: 73, math: 73 },
      { exam: '4회', date: '2023-12', total: 74, korean: 70, english: 76, math: 76 },
      { exam: '5회', date: '2024-02', total: 78, korean: 75, english: 80, math: 79 },
      { exam: '6회', date: '2024-04', total: 83, korean: 85, english: 82, math: 82 },
      { exam: '7회', date: '2024-06', total: 89, korean: 92, english: 87, math: 88 }
    ]
  };

  const currentData = scoreData[selectedPeriod];
  const maxScore = Math.max(...currentData.map(d => Math.max(d.total, d.korean, d.english, d.math)));
  const minScore = Math.min(...currentData.map(d => Math.min(d.total, d.korean, d.english, d.math)));

  // 학습 분석 데이터
  const analysisData = {
    totalImprovement: 17,
    bestSubject: '국어',
    weakestSubject: '영어',
    consistencyScore: 85,
    strengths: [
      '문학 작품 분석 능력이 뛰어남',
      '수학 기초 연산 실력이 탄탄함',
      '영어 독해 속도가 향상되고 있음'
    ],
    improvements: [
      '영어 어법/문법 영역 집중 학습 필요',
      '수학 응용 문제 해결 능력 강화',
      '국어 비문학 지문 분석 연습'
    ],
    recommendations: [
      {
        title: '영어 어법 집중 코스',
        description: '취약점으로 분석된 어법 영역을 체계적으로 학습',
        duration: '4주',
        expectedImprovement: '+8점'
      },
      {
        title: '수학 응용 문제 마스터',
        description: '기초는 탄탄하니 응용 문제 해결 능력 향상',
        duration: '6주',
        expectedImprovement: '+12점'
      },
      {
        title: '국어 비문학 독해 강화',
        description: '문학은 우수하므로 비문학 지문 분석 능력 향상',
        duration: '3주',
        expectedImprovement: '+6점'
      }
    ]
  };



  const renderLineChart = () => {
    const totalData = currentData.map(d => d.total);
    const koreanData = currentData.map(d => d.korean);
    const englishData = currentData.map(d => d.english);
    const mathData = currentData.map(d => d.math);
    
    const maxValue = 100;
    const minValue = 60;
    const range = maxValue - minValue;
    
    // SVG 크기 설정
    const width = 500;
    const height = 350;
    const padding = 50;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    
    // 좌표 계산 함수
    const getX = (index) => padding + (index / (currentData.length - 1)) * chartWidth;
    const getY = (value) => padding + ((maxValue - value) / range) * chartHeight;
    
    // 선 경로 생성 함수
    const createPath = (data) => {
      return data.map((value, index) => 
        `${index === 0 ? 'M' : 'L'} ${getX(index)} ${getY(value)}`
      ).join(' ');
    };
    
    // 선택된 과목에 따른 표시 여부 결정
    const shouldShowKorean = selectedChartSubject === '과목 전체' || selectedChartSubject === '국어';
    const shouldShowEnglish = selectedChartSubject === '과목 전체' || selectedChartSubject === '영어';
    const shouldShowMath = selectedChartSubject === '과목 전체' || selectedChartSubject === '수학';
    
    return (
      <div className="relative bg-white rounded-2xl">
        <h4 className="text-center font-bold text-gray-800 mb-4">📈 성적 변화 추이</h4>
        <svg width={width} height={height} className="h-auto">
          {/* 그리드 라인 */}
          {[60, 70, 80, 90, 100].map((value) => (
            <g key={value}>
              <line
                x1={padding}
                y1={getY(value)}
                x2={width - padding}
                y2={getY(value)}
                stroke="#f1f5f9"
                strokeWidth="1"
              />
              <text
                x={padding - 15}
                y={getY(value) + 4}
                textAnchor="end"
                fontSize="12"
                fill="#64748b"
              >
                {value}
              </text>
            </g>
          ))}
          
          {/* X축 라벨 */}
          {currentData.map((item, index) => (
            <text
              key={index}
              x={getX(index)}
              y={height - 15}
              textAnchor="middle"
              fontSize="12"
              fill="#64748b"
            >
              {item.exam}
            </text>
          ))}
          
          {/* 선 그래프 */}
          {/* 국어 */}
          {shouldShowKorean && (
            <path
              d={createPath(koreanData)}
              fill="none"
              stroke="#3b82f6"
              strokeWidth="5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}
          
          {/* 영어 */}
          {shouldShowEnglish && (
            <path
              d={createPath(englishData)}
              fill="none"
              stroke="#10b981"
              strokeWidth="5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}
          
          {/* 수학 */}
          {shouldShowMath && (
            <path
              d={createPath(mathData)}
              fill="none"
              stroke="#8b5cf6"
              strokeWidth="5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}
          
          {/* 데이터 포인트 - 국어 */}
          {shouldShowKorean && koreanData.map((value, index) => (
            <circle
              key={`korean-${index}`}
              cx={getX(index)}
              cy={getY(value)}
              r="6"
              fill="#3b82f6"
              stroke="#ffffff"
              strokeWidth="3"
            />
          ))}
          
          {/* 데이터 포인트 - 영어 */}
          {shouldShowEnglish && englishData.map((value, index) => (
            <circle
              key={`english-${index}`}
              cx={getX(index)}
              cy={getY(value)}
              r="6"
              fill="#10b981"
              stroke="#ffffff"
              strokeWidth="3"
            />
          ))}
          
          {/* 데이터 포인트 - 수학 */}
          {shouldShowMath && mathData.map((value, index) => (
            <circle
              key={`math-${index}`}
              cx={getX(index)}
              cy={getY(value)}
              r="6"
              fill="#8b5cf6"
              stroke="#ffffff"
              strokeWidth="3"
            />
          ))}
          
          {/* 점수 표시 */}
          {currentData.map((item, index) => (
            <g key={index}>
              {shouldShowKorean && (
                <text
                  x={getX(index)}
                  y={getY(item.korean) - 12}
                  textAnchor="middle"
                  fontSize="12"
                  fill="#3b82f6"
                  fontWeight="600"
                >
                  {item.korean}
                </text>
              )}
              {shouldShowEnglish && (
                <text
                  x={getX(index)}
                  y={getY(item.english) - 12}
                  textAnchor="middle"
                  fontSize="12"
                  fill="#10b981"
                  fontWeight="600"
                >
                  {item.english}
                </text>
              )}
              {shouldShowMath && (
                <text
                  x={getX(index)}
                  y={getY(item.math) + 20}
                  textAnchor="middle"
                  fontSize="12"
                  fill="#8b5cf6"
                  fontWeight="600"
                >
                  {item.math}
                </text>
              )}
            </g>
          ))}
        </svg>
        
        {/* 범례 */}
        <div className="flex justify-center space-x-6 mt-4 text-sm">
          {shouldShowKorean && (
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
              <span className="text-gray-700">국어</span>
            </div>
          )}
          {shouldShowEnglish && (
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-green-500 rounded-full"></div>
              <span className="text-gray-700">영어</span>
            </div>
          )}
          {shouldShowMath && (
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-purple-500 rounded-full"></div>
              <span className="text-gray-700">수학</span>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderStackedBarChart = () => {
    // 최근 5회차 데이터로 제한
    const recentData = currentData.slice(-5);
    
    // 과목별 데이터 추출
    const getSubjectData = () => {
      switch(selectedChartSubject) {
        case '국어':
          return recentData.map(d => d.korean);
        case '영어':
          return recentData.map(d => d.english);
        case '수학':
          return recentData.map(d => d.math);
        default: // '과목 전체'
          return {
            korean: recentData.map(d => d.korean),
            english: recentData.map(d => d.english),
            math: recentData.map(d => d.math)
          };
      }
    };

    const calculateStats = (data) => {
      if (!data || data.length === 0) return { min: 0, max: 0, avg: 0 };
      const min = Math.min(...data);
      const max = Math.max(...data);
      const avg = Math.round(data.reduce((sum, val) => sum + val, 0) / data.length);
      return { min, max, avg };
    };

    const subjectData = getSubjectData();
    
    // SVG 크기 설정
    const width = 300;
    const height = 350;
    const padding = 50;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    
    const maxValue = 100;
    const minValue = 60;
    const range = maxValue - minValue;
    
    // 과목 전체인 경우와 개별 과목인 경우 처리
    if (selectedChartSubject === '과목 전체') {
      const koreanStats = calculateStats(subjectData.korean);
      const englishStats = calculateStats(subjectData.english);
      const mathStats = calculateStats(subjectData.math);
      
      const subjects = [
        { name: '국어', stats: koreanStats, color: '#3b82f6' },
        { name: '영어', stats: englishStats, color: '#10b981' },
        { name: '수학', stats: mathStats, color: '#8b5cf6' }
      ];
      
      const barWidth = chartWidth / 3 - 20;
      
      return (
        <div className="bg-white rounded-2xl">
          <h4 className="text-center font-bold text-gray-800 mb-4">📊 성적 통계 (최근 5회)</h4>
          <svg width={width} height={height} className="h-auto">
            {/* Y축 눈금 */}
            {[60, 70, 80, 90, 100].map((value) => (
              <g key={value}>
                <line
                  x1={padding}
                  y1={padding + ((maxValue - value) / range) * chartHeight}
                  x2={width - padding}
                  y2={padding + ((maxValue - value) / range) * chartHeight}
                  stroke="#f1f5f9"
                  strokeWidth="1"
                />
                <text
                  x={padding - 15}
                  y={padding + ((maxValue - value) / range) * chartHeight + 4}
                  textAnchor="end"
                  fontSize="10"
                  fill="#64748b"
                >
                  {value}
                </text>
              </g>
            ))}
            
                         {/* 누적 바 차트 */}
             {subjects.map((subject, index) => {
               const x = padding + index * (barWidth + 20);
               
               // 누적 바를 위한 높이 계산 (바닥부터 시작)
               const minBarHeight = ((subject.stats.min - minValue) / range) * chartHeight;
               const avgBarHeight = ((subject.stats.avg - minValue) / range) * chartHeight;
               const maxBarHeight = ((subject.stats.max - minValue) / range) * chartHeight;
               
               // 각 섹션의 높이 (누적)
               const minSectionHeight = minBarHeight;
               const avgSectionHeight = avgBarHeight - minBarHeight;
               const maxSectionHeight = maxBarHeight - avgBarHeight;
               
               return (
                 <g key={subject.name}>
                   {/* 최저점수 바 (맨 아래) */}
                   <rect
                     x={x}
                     y={height - padding - minBarHeight}
                     width={barWidth}
                     height={minSectionHeight}
                     fill={subject.color}
                     opacity="0.4"
                   />
                   
                   {/* 평균점수 바 (가운데) */}
                   <rect
                     x={x}
                     y={height - padding - avgBarHeight}
                     width={barWidth}
                     height={avgSectionHeight}
                     fill={subject.color}
                     opacity="0.7"
                   />
                   
                   {/* 최고점수 바 (맨 위) */}
                   <rect
                     x={x}
                     y={height - padding - maxBarHeight}
                     width={barWidth}
                     height={maxSectionHeight}
                     fill={subject.color}
                     opacity="1"
                   />
                  
                  {/* 과목명 */}
                  <text
                    x={x + barWidth / 2}
                    y={height - 15}
                    textAnchor="middle"
                    fontSize="12"
                    fill="#64748b"
                    fontWeight="600"
                  >
                    {subject.name}
                  </text>
                  
                                     {/* 점수 표시 */}
                   <text
                     x={x + barWidth / 2}
                     y={height - padding - maxBarHeight - 5}
                     textAnchor="middle"
                     fontSize="10"
                     fill={subject.color}
                     fontWeight="600"
                   >
                     {subject.stats.max}
                   </text>
                   {maxSectionHeight > 15 && (
                     <text
                       x={x + barWidth / 2}
                       y={height - padding - maxBarHeight + maxSectionHeight / 2 + 4}
                       textAnchor="middle"
                       fontSize="10"
                       fill="#ffffff"
                       fontWeight="600"
                     >
                       {subject.stats.max}
                     </text>
                   )}
                   {avgSectionHeight > 15 && (
                     <text
                       x={x + barWidth / 2}
                       y={height - padding - avgBarHeight + avgSectionHeight / 2 + 4}
                       textAnchor="middle"
                       fontSize="10"
                       fill="#ffffff"
                       fontWeight="600"
                     >
                       {subject.stats.avg}
                     </text>
                   )}
                   {minSectionHeight > 15 && (
                     <text
                       x={x + barWidth / 2}
                       y={height - padding - minBarHeight + minSectionHeight / 2 + 4}
                       textAnchor="middle"
                       fontSize="10"
                       fill="#ffffff"
                       fontWeight="600"
                     >
                       {subject.stats.min}
                     </text>
                   )}
                </g>
              );
            })}
          </svg>
          
          {/* 범례 */}
          <div className="flex justify-center space-x-4 mt-4 text-xs">
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-gray-400 rounded opacity-40"></div>
              <span>최저</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-gray-400 rounded opacity-70"></div>
              <span>평균</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-gray-400 rounded"></div>
              <span>최고</span>
            </div>
          </div>
        </div>
      );
    } else {
      // 개별 과목 선택시
      const stats = calculateStats(subjectData);
      const subjectColor = selectedChartSubject === '국어' ? '#3b82f6' : 
                          selectedChartSubject === '영어' ? '#10b981' : '#8b5cf6';
      
             const barWidth = chartWidth / 2;
       const x = padding + chartWidth / 4;
       
       // 누적 바를 위한 높이 계산
       const minBarHeight = ((stats.min - minValue) / range) * chartHeight;
       const avgBarHeight = ((stats.avg - minValue) / range) * chartHeight;
       const maxBarHeight = ((stats.max - minValue) / range) * chartHeight;
       
       // 각 섹션의 높이 (누적)
       const minSectionHeight = minBarHeight;
       const avgSectionHeight = avgBarHeight - minBarHeight;
       const maxSectionHeight = maxBarHeight - avgBarHeight;
      
      return (
        <div className="bg-white rounded-2xl">
          <h4 className="text-center font-bold text-gray-800 mb-4">📊 {selectedChartSubject} 성적 통계 (최근 5회)</h4>
          <svg width={width} height={height} className="h-auto">
            {/* Y축 눈금 */}
            {[60, 70, 80, 90, 100].map((value) => (
              <g key={value}>
                <line
                  x1={padding}
                  y1={padding + ((maxValue - value) / range) * chartHeight}
                  x2={width - padding}
                  y2={padding + ((maxValue - value) / range) * chartHeight}
                  stroke="#f1f5f9"
                  strokeWidth="1"
                />
                <text
                  x={padding - 15}
                  y={padding + ((maxValue - value) / range) * chartHeight + 4}
                  textAnchor="end"
                  fontSize="10"
                  fill="#64748b"
                >
                  {value}
                </text>
              </g>
            ))}
            
                         {/* 누적 바 */}
             <g>
               {/* 최저점수 바 (맨 아래) */}
               <rect
                 x={x}
                 y={height - padding - minBarHeight}
                 width={barWidth}
                 height={minSectionHeight}
                 fill={subjectColor}
                 opacity="0.4"
               />
               
               {/* 평균점수 바 (가운데) */}
               <rect
                 x={x}
                 y={height - padding - avgBarHeight}
                 width={barWidth}
                 height={avgSectionHeight}
                 fill={subjectColor}
                 opacity="0.7"
               />
               
               {/* 최고점수 바 (맨 위) */}
               <rect
                 x={x}
                 y={height - padding - maxBarHeight}
                 width={barWidth}
                 height={maxSectionHeight}
                 fill={subjectColor}
                 opacity="1"
               />
              
                             {/* 점수 표시 */}
               <text
                 x={x + barWidth / 2}
                 y={height - padding - maxBarHeight - 5}
                 textAnchor="middle"
                 fontSize="12"
                 fill={subjectColor}
                 fontWeight="600"
               >
                 최고: {stats.max}점
               </text>
               {maxSectionHeight > 20 && (
                 <text
                   x={x + barWidth / 2}
                   y={height - padding - maxBarHeight + maxSectionHeight / 2 + 4}
                   textAnchor="middle"
                   fontSize="11"
                   fill="#ffffff"
                   fontWeight="600"
                 >
                   {stats.max}
                 </text>
               )}
               {avgSectionHeight > 20 && (
                 <text
                   x={x + barWidth / 2}
                   y={height - padding - avgBarHeight + avgSectionHeight / 2 + 4}
                   textAnchor="middle"
                   fontSize="11"
                   fill="#ffffff"
                   fontWeight="600"
                 >
                   {stats.avg}
                 </text>
               )}
               {minSectionHeight > 20 && (
                 <text
                   x={x + barWidth / 2}
                   y={height - padding - minBarHeight + minSectionHeight / 2 + 4}
                   textAnchor="middle"
                   fontSize="11"
                   fill="#ffffff"
                   fontWeight="600"
                 >
                   {stats.min}
                 </text>
               )}
            </g>
          </svg>
          
          {/* 범례 */}
          <div className="flex justify-center space-x-4 mt-4 text-xs">
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 rounded opacity-40" style={{backgroundColor: subjectColor}}></div>
              <span>최저점수</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 rounded opacity-70" style={{backgroundColor: subjectColor}}></div>
              <span>평균점수</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 rounded" style={{backgroundColor: subjectColor}}></div>
              <span>최고점수</span>
            </div>
          </div>
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* 헤더 */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToResult}
                className="text-gray-600 hover:text-gray-800 mr-4 transition-colors duration-200"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                📊 학습 분석
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto space-y-8">
          
          {/* 기간 선택 */}
          <div className="bg-white rounded-3xl shadow-xl p-6">
            <div className="flex flex-wrap gap-4">
              {['최근 6개월', '최근 1년'].map((period) => (
                <button
                  key={period}
                  onClick={() => setSelectedPeriod(period)}
                  className={`px-6 py-3 rounded-2xl font-medium transition-all duration-300 ${
                    selectedPeriod === period
                      ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {period}
                </button>
              ))}
            </div>
          </div>

          {/* 종합 통계 */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="bg-white rounded-3xl shadow-xl p-6 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-6 h-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-gray-800 mb-1">+{analysisData.totalImprovement}점</div>
              <div className="text-sm text-gray-600">총 향상도</div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-6 text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-gray-800 mb-1">{analysisData.bestSubject}</div>
              <div className="text-sm text-gray-600">최우수 과목</div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-6 text-center">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.864-.833-2.5 0L5.268 16.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-gray-800 mb-1">{analysisData.weakestSubject}</div>
              <div className="text-sm text-gray-600">집중 필요 과목</div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-6 text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-6 h-6 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v10a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-gray-800 mb-1">{analysisData.consistencyScore}%</div>
              <div className="text-sm text-gray-600">일관성 지수</div>
            </div>
          </div>

          {/* 성적 변화 그래프 */}
          <div className="bg-white rounded-3xl shadow-xl p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-800">📈 성적 변화 추이 & 통계</h3>
              <select
                value={selectedChartSubject}
                onChange={(e) => setSelectedChartSubject(e.target.value)}
                className="px-4 py-2 rounded-xl border border-gray-300 text-sm"
              >
                <option value="과목 전체">과목 전체</option>
                <option value="국어">국어</option>
                <option value="영어">영어</option>
                <option value="수학">수학</option>
              </select>
            </div>
            
            {/* 그래프와 누적 바 차트를 나란히 배치 */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* 왼쪽: 기존 선 그래프 */}
              <div className="flex justify-center">
                {renderLineChart()}
              </div>
              
              {/* 오른쪽: 누적 바 차트 */}
              <div className="flex justify-center">
                {renderStackedBarChart()}
              </div>
            </div>
          </div>

          {/* 강점과 개선점 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* 강점 */}
            <div className="bg-white rounded-3xl shadow-xl p-8">
              <h3 className="text-xl font-bold text-gray-800 mb-6">💪 나의 강점</h3>
              <div className="space-y-4">
                {analysisData.strengths.map((strength, index) => (
                  <div key={index} className="flex items-start space-x-3 p-4 bg-green-50 rounded-2xl">
                    <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <span className="text-gray-700">{strength}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 개선점 */}
            <div className="bg-white rounded-3xl shadow-xl p-8">
              <h3 className="text-xl font-bold text-gray-800 mb-6">🎯 개선이 필요한 영역</h3>
              <div className="space-y-4">
                {analysisData.improvements.map((improvement, index) => (
                  <div key={index} className="flex items-start space-x-3 p-4 bg-orange-50 rounded-2xl">
                    <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.864-.833-2.5 0L5.268 16.5c-.77.833.192 2.5 1.732 2.5z" />
                      </svg>
                    </div>
                    <span className="text-gray-700">{improvement}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* AI 맞춤 학습 추천 */}
          <div className="bg-white rounded-3xl shadow-xl p-8">
            <h3 className="text-xl font-bold text-gray-800 mb-6">🤖 AI 맞춤 학습 추천</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {analysisData.recommendations.map((rec, index) => (
                <div key={index} className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-2xl p-6 border border-purple-100">
                  <h4 className="font-bold text-gray-800 mb-3">{rec.title}</h4>
                  <p className="text-gray-600 text-sm mb-4">{rec.description}</p>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">예상 기간:</span>
                      <span className="font-medium text-gray-700">{rec.duration}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">예상 향상:</span>
                      <span className="font-bold text-green-600">{rec.expectedImprovement}</span>
                    </div>
                  </div>
                  
                  <button className="w-full bg-gradient-to-r from-purple-500 to-blue-500 text-white py-3 rounded-xl font-medium hover:from-purple-600 hover:to-blue-600 transition-all duration-300">
                    학습 시작하기
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* 학습 목표 설정 */}
          <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-3xl shadow-xl p-8 text-white">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-2">🎯 다음 목표</h3>
                <p className="text-indigo-100 mb-4">
                  현재 추세로 학습하면 <span className="font-bold">3개월 후 95점</span> 달성 가능합니다!
                </p>
                <div className="flex space-x-4">
                  <button 
                    onClick={() => navigate('/upload')}
                    className="bg-white text-indigo-600 px-6 py-3 rounded-xl font-bold hover:bg-indigo-50 transition-colors duration-200"
                  >
                    다음 시험지 풀기
                  </button>
                  <button 
                    onClick={() => navigate('/wrong-answer-note')}
                    className="bg-white/20 text-white border border-white/30 px-6 py-3 rounded-xl font-bold hover:bg-white/30 transition-colors duration-200"
                  >
                    오답 복습하기
                  </button>
                </div>
              </div>
              <div className="ml-8 text-6xl">
                📚
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
} 