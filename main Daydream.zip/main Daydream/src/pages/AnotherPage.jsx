// ============================================
// ✨ Angelic Light AnotherPage.jsx - 빛의 준비 중 페이지
// ============================================
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

export default function AnotherPage({ onBack }) {
  const containerRef = useRef(null);
  const iconRef = useRef(null);
  const titleRef = useRef(null);
  const descRef = useRef(null);
  const buttonsRef = useRef(null);

  useEffect(() => {
    const tl = gsap.timeline();

    // 빛의 페이지 진입 애니메이션 (더 은은하고 아름답게)
    tl.fromTo(containerRef.current,
      { opacity: 0, filter: "blur(10px)" },
      { opacity: 1, filter: "blur(0px)", duration: 0.8 }
    )
    .fromTo(iconRef.current,
      { 
        scale: 0,
        rotation: 360,
        opacity: 0,
        y: -100
      },
      { 
        scale: 1,
        rotation: 0,
        opacity: 1,
        y: 0,
        duration: 1.2,
        ease: "back.out(1.7)"
      }
    )
    .fromTo(titleRef.current,
      { 
        y: 80,
        opacity: 0,
        scale: 0.8
      },
      { 
        y: 0,
        opacity: 1,
        scale: 1,
        duration: 0.8,
        ease: "power3.out"
      },
      "-=0.6"
    )
    .fromTo(descRef.current,
      { 
        y: 50,
        opacity: 0
      },
      { 
        y: 0,
        opacity: 1,
        duration: 0.6,
        ease: "power2.out"
      },
      "-=0.4"
    )
    .fromTo(buttonsRef.current,
      { 
        y: 30,
        opacity: 0,
        scale: 0.9
      },
      { 
        y: 0,
        opacity: 1,
        scale: 1,
        duration: 0.7,
        ease: "back.out(1.2)"
      },
      "-=0.3"
    );

    // 천사 아이콘 부드러운 호버 애니메이션
    const icon = iconRef.current;
    
    const handleMouseEnter = () => {
      gsap.to(icon, {
        scale: 1.1,
        rotation: 15,
        duration: 0.3,
        ease: "power2.out"
      });
    };

    const handleMouseLeave = () => {
      gsap.to(icon, {
        scale: 1,
        rotation: 0,
        duration: 0.3,
        ease: "power2.out"
      });
    };

    icon.addEventListener('mouseenter', handleMouseEnter);
    icon.addEventListener('mouseleave', handleMouseLeave);

    // 천사 빛 반짝임 효과
    gsap.to(icon, {
      filter: "brightness(1.2) drop-shadow(0 0 20px rgba(59, 130, 246, 0.5))",
      duration: 2,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut"
    });

    return () => {
      icon.removeEventListener('mouseenter', handleMouseEnter);
      icon.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-sky-50 to-blue-100 flex items-center justify-center relative overflow-hidden">
      {/* 천사 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 천사 날개 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,0 Q50,30 100,0 L100,20 Q50,50 0,20 Z" fill="url(#angelGradient)" />
            <defs>
              <linearGradient id="angelGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#60a5fa" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 부드러운 빛 파티클 효과 */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="absolute bg-blue-400 rounded-full opacity-20 animate-pulse"
              style={{
                width: `${Math.random() * 4 + 2}px`,
                height: `${Math.random() * 4 + 2}px`,
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${Math.random() * 2 + 2}s`
              }}
            />
          ))}
        </div>

        {/* 구름 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-white/30 to-transparent"></div>
      </div>

      <div ref={containerRef} className="relative z-10 max-w-2xl mx-auto px-6">
        <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-12 text-center border-2 border-blue-200 relative overflow-hidden backdrop-blur-sm">
          {/* 천사 배경 효과 */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 via-white/80 to-sky-100/40 rounded-3xl"></div>
          
          {/* 천사 아이콘 */}
          <div ref={iconRef} className="relative z-10 mb-8">
            <div className="w-32 h-32 bg-gradient-to-br from-blue-400 to-sky-500 rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-blue-500/50 border-4 border-blue-300">
              <span className="text-6xl text-white drop-shadow-lg">👼</span>
            </div>
          </div>

          {/* 제목 */}
          <div ref={titleRef} className="relative z-10 mb-6">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent mb-4 drop-shadow-lg">
              ✨ 빛의 기능 준비 중
            </h1>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-sky-400 mx-auto rounded-full"></div>
          </div>

          {/* 설명 */}
          <div ref={descRef} className="relative z-10 mb-10">
            <p className="text-lg text-blue-600 leading-relaxed mb-4">
              천사들이 정성스럽게 새로운 축복 기능을 준비하고 있습니다.
            </p>
            <p className="text-blue-500">
              곧 더욱 빛나는 서비스로 찾아뵙겠습니다! ✨
            </p>
          </div>

          {/* 특징 카드들 */}
          <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
            <div className="bg-blue-100 bg-opacity-50 rounded-2xl p-6 border border-blue-200">
              <div className="text-3xl mb-3">🌟</div>
              <h3 className="font-bold text-blue-600 mb-2">더 나은 성능</h3>
              <p className="text-blue-500 text-sm">천사의 힘으로 더욱 빠르고 정확한 서비스</p>
            </div>
            
            <div className="bg-sky-100 bg-opacity-50 rounded-2xl p-6 border border-sky-200">
              <div className="text-3xl mb-3">💫</div>
              <h3 className="font-bold text-sky-600 mb-2">새로운 기능</h3>
              <p className="text-sky-500 text-sm">혁신적인 축복 기능들이 추가됩니다</p>
            </div>
            
            <div className="bg-indigo-100 bg-opacity-50 rounded-2xl p-6 border border-indigo-200">
              <div className="text-3xl mb-3">🪽</div>
              <h3 className="font-bold text-indigo-600 mb-2">향상된 UI</h3>
              <p className="text-indigo-500 text-sm">더욱 아름답고 직관적인 인터페이스</p>
            </div>
            
            <div className="bg-purple-100 bg-opacity-50 rounded-2xl p-6 border border-purple-200">
              <div className="text-3xl mb-3">🎯</div>
              <h3 className="font-bold text-purple-600 mb-2">맞춤 서비스</h3>
              <p className="text-purple-500 text-sm">개인화된 천사 학습 경험</p>
            </div>
          </div>

          {/* 버튼들 */}
          <div ref={buttonsRef} className="relative z-10 space-y-4">
            <button
              onClick={onBack}
              className="bg-gradient-to-r from-blue-600 to-sky-500 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:from-blue-500 hover:to-sky-400 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-blue-500/50 w-full md:w-auto"
            >
              🏠 천국 홈으로 돌아가기
            </button>
            
            <div className="text-blue-500 text-sm">
              또는 잠시 후 다시 시도해주세요
            </div>
          </div>

          {/* 천사 장식 */}
          <div className="absolute top-6 right-6 text-blue-400 opacity-30 animate-pulse">✨</div>
          <div className="absolute bottom-6 left-6 text-blue-400 opacity-20 animate-pulse">🌟</div>
          <div className="absolute top-1/2 left-6 text-sky-400 opacity-25 animate-pulse" style={{ animationDelay: '1s' }}>💫</div>
          <div className="absolute top-1/4 right-6 text-indigo-400 opacity-30 animate-pulse" style={{ animationDelay: '2s' }}>🪽</div>
        </div>

        {/* 로딩 인디케이터 */}
        <div className="mt-8 flex justify-center">
          <div className="flex space-x-2">
            {[...Array(3)].map((_, i) => (
              <div
                key={i}
                className="w-3 h-3 bg-blue-400 rounded-full animate-bounce"
                style={{ animationDelay: `${i * 0.2}s` }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* 추가 천사 장식 (화면 전체) */}
      <div className="absolute top-10 left-10 text-blue-300 opacity-20 animate-pulse" style={{ animationDelay: '3s' }}>
        <span className="text-4xl">👼</span>
      </div>
      <div className="absolute bottom-20 right-20 text-sky-300 opacity-25 animate-pulse" style={{ animationDelay: '4s' }}>
        <span className="text-3xl">✨</span>
      </div>
      <div className="absolute top-1/3 left-1/4 text-indigo-300 opacity-15 animate-pulse" style={{ animationDelay: '5s' }}>
        <span className="text-2xl">🌟</span>
      </div>
    </div>
  );
}