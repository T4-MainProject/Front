import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';


export default function DarkHorrorWrongAnswerNote() {
  const [selectedSubject, setSelectedSubject] = useState('전체');
  const [glitchEffect, setGlitchEffect] = useState(false);
  const navigate = useNavigate();

  // 글리치 효과
  useEffect(() => {
    const interval = setInterval(() => {
      setGlitchEffect(true);
      setTimeout(() => setGlitchEffect(false), 200);
    }, 3000 + Math.random() * 5000);
    
    return () => clearInterval(interval);
  }, []);

  // 저주받은 오답 데이터
  const cursedWrongAnswers = [
    // 국어 (4개)
    {
      id: 1,
      subject: '국어',
      question: '다음 글의 중심 내용으로 가장 적절한 것은?',
      userAnswer: '②',
      correctAnswer: '④',
      explanation: '이 문제는 글의 전체적인 맥락을 파악하는 문제입니다. 지문에서 강조하는 핵심은 "문화의 다양성"이며, 이는 4번 선택지에서 명확히 드러납니다.',
      difficulty: '중',
      category: '독해',
      points: 3,
      deathCount: 1247
    },
    {
      id: 2,
      subject: '국어',
      question: '다음 시에서 화자의 정서로 가장 적절한 것은?',
      userAnswer: '①',
      correctAnswer: '③',
      explanation: '시상 전개 과정에서 화자의 감정 변화를 주의 깊게 살펴봐야 합니다. 초반의 그리움에서 후반부의 체념적 수용으로 이어지는 정서적 흐름이 핵심입니다.',
      difficulty: '상',
      category: '문학',
      points: 4,
      deathCount: 2156
    },
    {
      id: 3,
      subject: '국어',
      question: '다음 문장에서 높임법이 잘못 사용된 것은?',
      userAnswer: '④',
      correctAnswer: '②',
      explanation: '높임법은 주체높임, 객체높임, 상대높임으로 구분됩니다. 이 문제에서는 주체와 객체의 관계를 정확히 파악하여 적절한 높임 표현을 사용해야 합니다.',
      difficulty: '하',
      category: '문법',
      points: 2,
      deathCount: 892
    },
    {
      id: 4,
      subject: '국어',
      question: '다음 발표에서 청중과의 소통 방법으로 가장 적절한 것은?',
      userAnswer: '③',
      correctAnswer: '⑤',
      explanation: '화법에서는 청중의 반응을 살피고 상호작용을 유도하는 것이 중요합니다. 단순한 정보 전달이 아닌 청중 참여형 발표 기법을 활용해야 합니다.',
      difficulty: '중',
      category: '화법과 작문',
      points: 3,
      deathCount: 1456
    },

    // 영어 (4개)
    {
      id: 5,
      subject: '영어',
      question: 'Choose the most appropriate word to fill in the blank.',
      userAnswer: 'though',
      correctAnswer: 'because',
      explanation: '문맥상 인과관계를 나타내는 접속사가 필요합니다. "though"는 양보의 의미이지만, 여기서는 "because"가 적절합니다.',
      difficulty: '하',
      category: '어법',
      points: 2,
      deathCount: 743
    },
    {
      id: 6,
      subject: '영어',
      question: 'What is the main idea of the passage?',
      userAnswer: '①',
      correctAnswer: '④',
      explanation: '지문의 주제를 파악할 때는 각 단락의 핵심 내용과 전체적인 흐름을 종합적으로 고려해야 합니다. 세부 사항이 아닌 전체를 아우르는 내용을 찾는 것이 중요합니다.',
      difficulty: '중',
      category: '독해',
      points: 3,
      deathCount: 1889
    },
    {
      id: 7,
      subject: '영어',
      question: 'Choose the best word to fill in the blank considering the context.',
      userAnswer: 'However',
      correctAnswer: 'Therefore',
      explanation: '빈칸 앞뒤 문맥을 보면 결과나 결론을 나타내는 표현이 필요합니다. "However"는 대조의 의미이지만, 여기서는 "Therefore"가 논리적 흐름에 맞습니다.',
      difficulty: '상',
      category: '빈칸추론',
      points: 4,
      deathCount: 2987
    },
    {
      id: 8,
      subject: '영어',
      question: 'Choose the most logical order of the given sentences.',
      userAnswer: '②',
      correctAnswer: '⑤',
      explanation: '문장의 순서를 배열할 때는 시간적 순서, 논리적 연결, 대명사나 지시어의 지시 대상 등을 종합적으로 고려해야 합니다.',
      difficulty: '상',
      category: '순서배열',
      points: 4,
      deathCount: 3124
    },

    // 수학 (4개)
    {
      id: 9,
      subject: '수학',
      question: '다음 이차함수의 최댓값을 구하시오. f(x) = -2x² + 8x - 3',
      userAnswer: '7',
      correctAnswer: '5',
      explanation: '이차함수 f(x) = -2x² + 8x - 3에서 x = -b/2a = -8/(-4) = 2일 때 최댓값을 가집니다. f(2) = -2(4) + 8(2) - 3 = -8 + 16 - 3 = 5',
      difficulty: '상',
      category: '함수',
      points: 4,
      deathCount: 4567
    },
    {
      id: 10,
      subject: '수학',
      question: '원의 중심이 (2, 3)이고 반지름이 5인 원의 방정식을 구하시오.',
      userAnswer: '(x-2)² + (y-3)² = 10',
      correctAnswer: '(x-2)² + (y-3)² = 25',
      explanation: '원의 표준형은 (x-a)² + (y-b)² = r²입니다. 여기서 중심이 (2,3), 반지름이 5이므로 (x-2)² + (y-3)² = 5² = 25가 됩니다.',
      difficulty: '하',
      category: '기하',
      points: 2,
      deathCount: 1234
    },
    {
      id: 11,
      subject: '수학',
      question: '주사위를 두 번 던져서 나온 눈의 합이 7이 될 확률을 구하시오.',
      userAnswer: '1/5',
      correctAnswer: '1/6',
      explanation: '두 주사위의 합이 7이 되는 경우는 (1,6), (2,5), (3,4), (4,3), (5,2), (6,1)로 총 6가지입니다. 전체 경우의 수는 6×6=36이므로 확률은 6/36 = 1/6입니다.',
      difficulty: '중',
      category: '확률과 통계',
      points: 3,
      deathCount: 2345
    },
    {
      id: 12,
      subject: '수학',
      question: 'f(x) = 2x³ - 6x² + 6x - 1일 때, f\'(x)를 구하시오.',
      userAnswer: '6x² - 6x + 6',
      correctAnswer: '6x² - 12x + 6',
      explanation: '미분 공식을 사용하면 f\'(x) = 6x² - 12x + 6입니다. 각 항을 차수를 1씩 낮추고 원래 차수를 계수에 곱하면 됩니다. -6x² 항의 미분에서 실수가 있었습니다.',
      difficulty: '중',
      category: '미적분',
      points: 3,
      deathCount: 1876
    }
  ];

  const subjects = ['전체', '국어', '영어', '수학'];
  const filteredProblems = selectedSubject === '전체' 
    ? cursedWrongAnswers 
    : cursedWrongAnswers.filter(problem => problem.subject === selectedSubject);

  const getDifficultyColor = (difficulty) => {
    switch(difficulty) {
      case '하': return 'bg-green-900 text-green-300 border-green-700';
      case '중': return 'bg-yellow-900 text-yellow-300 border-yellow-700';
      case '상': return 'bg-red-900 text-red-300 border-red-700';
      default: return 'bg-gray-900 text-gray-300 border-gray-700';
    }
  };

  const getSubjectEmoji = (subject) => {
    switch(subject) {
      case '국어': return '💀';
      case '영어': return '👻';
      case '수학': return '🖤';
      default: return '⚰️';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-red-900 relative overflow-hidden">
      {/* 무서운 배경 효과 */}
      <div className="absolute inset-0 opacity-10">
        <div className="w-full h-full bg-gradient-to-b from-transparent via-red-950 to-transparent animate-pulse"></div>
      </div>
      
      {/* 번개 효과 */}
      {glitchEffect && (
        <div className="absolute inset-0 bg-white opacity-20 animate-pulse pointer-events-none z-10"></div>
      )}

      {/* 피의 헤더 */}
      <div className="bg-black shadow-2xl border-b border-red-800 relative z-20">
        <div className="absolute inset-0 bg-gradient-to-r from-red-900/20 to-black/20"></div>
        <div className="container mx-auto px-4 py-4 relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                className="text-red-400 hover:text-red-300 mr-4 transition-colors duration-300 hover:scale-110"
                onClick={() => navigate(-1)}
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
            <h1 
              className={`text-2xl font-bold text-red-400 ${glitchEffect ? 'animate-pulse' : ''} cursor-pointer hover:text-red-300 transition-colors duration-300`}
              onClick={() => navigate('/')}  // 여기에 넣으세요
            >
              ⚰️ 오답의 무덤
            </h1>
            </div>
            <div className="text-red-500 text-sm opacity-70">
              "틀린 답은 영원히 너를 따라다닌다..."
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-20">
        <div className="max-w-6xl mx-auto">
          
          {/* 저주받은 과목 필터 */}
          <div className="bg-gray-900 rounded-3xl shadow-2xl p-6 mb-8 border border-red-800">
            <div className="flex flex-wrap gap-4">
              {subjects.map((subject) => (
                <button
                  key={subject}
                  onClick={() => setSelectedSubject(subject)}
                  className={`px-6 py-3 rounded-2xl font-medium transition-all duration-300 border-2 ${
                    selectedSubject === subject
                      ? 'bg-gradient-to-r from-red-700 to-red-900 text-white shadow-lg border-red-600 shadow-red-900/50'
                      : 'bg-gray-800 text-gray-300 hover:bg-gray-700 border-gray-600 hover:border-red-700'
                  }`}
                >
                  {getSubjectEmoji(subject)} {subject}
                </button>
              ))}
            </div>
          </div>

          {/* 저주받은 오답 목록 */}
          <div className="space-y-8">
            {filteredProblems.map((problem) => (
              <div key={problem.id} className="bg-gray-900 rounded-3xl shadow-2xl p-8 border border-red-800 hover:border-red-600 transition-all duration-300 group">
                
                {/* 문제 헤더 */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-4">
                    <span className="bg-gradient-to-r from-red-700 to-red-900 text-white px-4 py-2 rounded-full font-bold shadow-lg">
                      {getSubjectEmoji(problem.subject)} {problem.subject}
                    </span>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getDifficultyColor(problem.difficulty)}`}>
                      난이도: {problem.difficulty}
                    </span>
                    <span className="bg-purple-900 text-purple-300 px-3 py-1 rounded-full text-sm font-medium border border-purple-700">
                      {problem.category}
                    </span>
                    <span className="text-gray-400 text-sm">
                      {problem.points}점
                    </span>
                  </div>
                  <div className="text-red-500 text-sm opacity-70">
                    💀 {problem.deathCount.toLocaleString()}명이 틀렸습니다
                  </div>
                </div>

                {/* 문제 내용 */}
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-200 mb-4 group-hover:text-red-300 transition-colors">
                    {problem.question}
                  </h3>
                  
                  <div className="bg-red-950 border border-red-800 rounded-2xl p-4 mb-4 shadow-inner">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-red-400 font-medium">내가 선택한 답: </span>
                        <span className="font-bold text-red-300 bg-red-900 px-2 py-1 rounded">
                          {problem.userAnswer}
                        </span>
                      </div>
                      <div>
                        <span className="text-green-400 font-medium">정답: </span>
                        <span className="font-bold text-green-300 bg-green-900 px-2 py-1 rounded">
                          {problem.correctAnswer}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-800 border border-gray-700 rounded-2xl p-4">
                    <h4 className="font-semibold text-purple-400 mb-2">🧠 해설의 속삭임</h4>
                    <p className="text-gray-300 leading-relaxed">{problem.explanation}</p>
                  </div>
                </div>

                {/* 유사 기출문제 버튼 */}
                <div className="border-t border-gray-700 pt-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-lg font-bold text-gray-200">🔍 유사한 저주받은 문제들</h4>
                    <button
                                      onClick={() => navigate('/similar-problems', { 
                        state: { 
                          problemId: problem.id, 
                          originalProblem: problem 
                        } 
                      })}
                      className="bg-gradient-to-r from-purple-500 to-blue-500 text-white px-6 py-3 rounded-2xl font-medium hover:from-purple-600 hover:to-blue-600 transition-all duration-300 shadow-lg hover:shadow-xl"
                    >
                      어둠 속으로 들어가기 →
                    </button>
                  </div>
                  <div className="bg-purple-950 border border-purple-800 rounded-2xl p-4">
                    <p className="text-purple-300 text-sm">
                      이 문제와 유사한 저주받은 문제들이 당신을 기다리고 있습니다. 
                      더 깊은 어둠 속에서 당신의 지식을 시험해보세요... 🌙
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* 하단 액션 버튼 */}
          <div className="mt-12 text-center">
            <button
              onClick={() => alert('새로운 저주받은 시험지를 불러옵니다...')}
              className="bg-gradient-to-r from-red-700 to-red-900 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-2xl hover:shadow-red-900/50 transition-all duration-300 hover:scale-105 border border-red-600"
            >
              📜 새로운 저주받은 시험지로 도전하기
            </button>
            <p className="text-gray-500 text-sm mt-3 opacity-70">
              "더 많은 고통을 원한다면..."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}