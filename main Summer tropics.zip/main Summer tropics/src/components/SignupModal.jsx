import React, { useState, useEffect } from 'react';
import { registerUser, checkEmailExists, saveUserToStorage } from '../data/dummyUsers';

export default function SignupModal({ isOpen, onClose, onSwitchToLogin, onSignupSuccess }) {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    passwordConfirm: '',
    name: '',
    phone: '',
    birthDate: '',
    address: '',
    school: ''
  });

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  // 모달이 열릴 때 body 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.keyCode === 27) onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // 에러 메시지 클리어
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    // 크리스탈 이메일 검증 (필수)
    if (!formData.email) {
      newErrors.email = '파라다이스 이메일을 입력해주세요.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = '올바른 이메일 형식이 아닙니다.';
    }

    // 파라다이스 비밀번호 검증 (필수, 크리스탈 조합)
    if (!formData.password) {
      newErrors.password = '파라다이스 비밀번호를 입력해주세요.';
    } else if (!/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*#?&]{8,}$/.test(formData.password)) {
      newErrors.password = '비밀번호는 8자 이상 영문, 숫자 조합이어야 합니다.';
    }

    // 파라다이스 비밀번호 확인 검증 (필수)
    if (!formData.passwordConfirm) {
      newErrors.passwordConfirm = '비밀번호 확인을 입력해주세요.';
    } else if (formData.password !== formData.passwordConfirm) {
      newErrors.passwordConfirm = '비밀번호가 일치하지 않습니다.';
    }

    // 크리스탈 이름 검증 (필수)
    if (!formData.name) {
      newErrors.name = '이름을 입력해주세요.';
    }

    // 파라다이스 전화번호 검증 (필수)
    if (!formData.phone) {
      newErrors.phone = '전화번호를 입력해주세요.';
    } else if (!/^01[0-9]-?[0-9]{4}-?[0-9]{4}$/.test(formData.phone.replace(/-/g, ''))) {
      newErrors.phone = '올바른 전화번호 형식이 아닙니다.';
    }

    // 생년월일, 학교, 주소는 이제 선택사항

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);
    
    try {
      // 시뮬레이션된 로딩 (실제 파라다이스 API 호출 시뮬레이션)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // 더미 데이터로 크리스탈 가입 처리
      const result = registerUser(formData);
      
      if (result.success) {
        // 파라다이스 스토리지에 크리스탈 정보 저장
        saveUserToStorage(result.user);
        
        // 부모 컴포넌트에 크리스탈 가입 성공 알림
        onSignupSuccess(result.user);
        
        // 성공 메시지 표시
        alert(`${result.message}\n파라다이스에 오신 것을 환영합니다, ${result.user.name}님!`);
      } else {
        // 크리스탈 가입 실패 에러 표시
        setErrors({ general: result.message });
      }
    } catch (error) {
      console.error('크리스탈 가입 오류:', error);
      setErrors({ general: '가입 처리 중 오류가 발생했습니다.' });
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* 파라다이스 배경 오버레이 */}
      <div 
        className="fixed inset-0 bg-emerald-500/20 backdrop-blur-sm transition-opacity duration-300"
        onClick={onClose}
      />
      
      {/* 파라다이스 모달 컨테이너 */}
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="relative bg-white/25 backdrop-blur-md rounded-2xl shadow-2xl shadow-emerald-500/50 w-full max-w-2xl transform transition-all duration-300 modal-enter border border-white/30">
          {/* 파라다이스 배경 효과 */}
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-100/40 via-white/60 to-cyan-100/40 rounded-2xl"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.1)_0%,rgba(6,182,212,0.05)_50%,rgba(14,165,233,0.1)_100%)] rounded-2xl"></div>
          
          {/* 움직이는 크리스탈 파티클 */}
          <div className="absolute inset-0 overflow-hidden rounded-2xl pointer-events-none">
            <div className="absolute top-8 left-12 w-1 h-1 bg-emerald-400/40 rounded-full animate-pulse shadow-sm"></div>
            <div className="absolute top-16 right-16 w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse delay-700 shadow-sm"></div>
            <div className="absolute bottom-12 left-16 w-1 h-1 bg-sky-400/30 rounded-full animate-pulse delay-1000 shadow-sm"></div>
            <div className="absolute top-1/2 right-12 w-1 h-1 bg-teal-500/40 rounded-full animate-pulse delay-500 shadow-sm"></div>
            <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-emerald-300/30 rounded-full animate-pulse delay-1500 shadow-sm"></div>
          </div>

          {/* 파라다이스 닫기 버튼 */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-emerald-600 hover:text-emerald-500 transition-colors duration-200 z-10 bg-white/30 rounded-full p-2 backdrop-blur-sm border border-white/30"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          {/* 파라다이스 헤더 */}
          <div className="px-8 pt-8 pb-6 text-center relative z-10">
            <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-500/50 border-2 border-white/30">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-emerald-700 mb-2 drop-shadow-lg">🏝️ 크리스탈 멤버십</h2>
            <p className="text-emerald-600/80 drop-shadow-sm">ParadiseCheck과 함께 파라다이스 여정을 시작하세요</p>
          </div>

          {/* 파라다이스 폼 */}
          <form onSubmit={handleSubmit} className="px-8 pb-8 max-h-96 overflow-y-auto relative z-10">
            {/* 전체 에러 메시지 */}
            {errors.general && (
              <div className="mb-4 p-3 bg-red-100/60 border border-red-300/50 text-red-600 rounded-lg text-sm backdrop-blur-sm">
                {errors.general}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 파라다이스 이메일 */}
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-emerald-700 mb-2 drop-shadow-sm">
                  파라다이스 이메일 <span className="text-emerald-600">*</span>
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="crystal@paradise.co.kr"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:border-transparent transition-all duration-200 bg-white/60 text-emerald-800 placeholder-emerald-600/50 backdrop-blur-sm ${
                    errors.email 
                      ? 'border-red-400 focus:ring-red-400' 
                      : 'border-white/50 focus:ring-emerald-500'
                  }`}
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-500">{errors.email}</p>
                )}
              </div>

              {/* 파라다이스 비밀번호 */}
              <div>
                <label className="block text-sm font-semibold text-emerald-700 mb-2 drop-shadow-sm">
                  파라다이스 비밀번호 <span className="text-emerald-600">*</span>
                </label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  placeholder="영문, 숫자 조합 8자 이상"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:border-transparent transition-all duration-200 bg-white/60 text-emerald-800 placeholder-emerald-600/50 backdrop-blur-sm ${
                    errors.password 
                      ? 'border-red-400 focus:ring-red-400' 
                      : 'border-white/50 focus:ring-emerald-500'
                  }`}
                />
                {errors.password && (
                  <p className="mt-1 text-sm text-red-500">{errors.password}</p>
                )}
              </div>

              {/* 파라다이스 비밀번호 확인 */}
              <div>
                <label className="block text-sm font-semibold text-emerald-700 mb-2 drop-shadow-sm">
                  비밀번호 확인 <span className="text-emerald-600">*</span>
                </label>
                <input
                  type="password"
                  name="passwordConfirm"
                  value={formData.passwordConfirm}
                  onChange={handleInputChange}
                  placeholder="비밀번호를 다시 입력하세요"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:border-transparent transition-all duration-200 bg-white/60 text-emerald-800 placeholder-emerald-600/50 backdrop-blur-sm ${
                    errors.passwordConfirm 
                      ? 'border-red-400 focus:ring-red-400' 
                      : formData.passwordConfirm && formData.password === formData.passwordConfirm
                        ? 'border-emerald-400 focus:ring-emerald-400'
                        : 'border-white/50 focus:ring-emerald-500'
                  }`}
                />
                {errors.passwordConfirm && (
                  <p className="mt-1 text-sm text-red-500">{errors.passwordConfirm}</p>
                )}
                {formData.passwordConfirm && formData.password === formData.passwordConfirm && (
                  <p className="mt-1 text-sm text-emerald-600">비밀번호가 일치합니다</p>
                )}
              </div>

              {/* 크리스탈 이름 */}
              <div>
                <label className="block text-sm font-semibold text-emerald-700 mb-2 drop-shadow-sm">
                  이름 <span className="text-emerald-600">*</span>
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="실제 이름을 입력하세요"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:border-transparent transition-all duration-200 bg-white/60 text-emerald-800 placeholder-emerald-600/50 backdrop-blur-sm ${
                    errors.name 
                      ? 'border-red-400 focus:ring-red-400' 
                      : 'border-white/50 focus:ring-emerald-500'
                  }`}
                />
                {errors.name && (
                  <p className="mt-1 text-sm text-red-500">{errors.name}</p>
                )}
              </div>

              {/* 파라다이스 전화번호 */}
              <div>
                <label className="block text-sm font-semibold text-emerald-700 mb-2 drop-shadow-sm">
                  전화번호 <span className="text-emerald-600">*</span>
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  placeholder="010-1234-5678"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:border-transparent transition-all duration-200 bg-white/60 text-emerald-800 placeholder-emerald-600/50 backdrop-blur-sm ${
                    errors.phone 
                      ? 'border-red-400 focus:ring-red-400' 
                      : 'border-white/50 focus:ring-emerald-500'
                  }`}
                />
                {errors.phone && (
                  <p className="mt-1 text-sm text-red-500">{errors.phone}</p>
                )}
              </div>

              {/* 생년월일 */}
              <div>
                <label className="block text-sm font-semibold text-emerald-700 mb-2 drop-shadow-sm">
                  생년월일 (선택사항)
                </label>
                <input
                  type="date"
                  name="birthDate"
                  value={formData.birthDate}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-white/50 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all duration-200 bg-white/60 text-emerald-800 backdrop-blur-sm"
                />
              </div>

              {/* 파라다이스 학교 */}
              <div>
                <label className="block text-sm font-semibold text-emerald-700 mb-2 drop-shadow-sm">
                  학교 (선택사항)
                </label>
                <input
                  type="text"
                  name="school"
                  value={formData.school}
                  onChange={handleInputChange}
                  placeholder="예: 파라다이스 중학교"
                  className="w-full px-4 py-3 border border-white/50 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all duration-200 bg-white/60 text-emerald-800 placeholder-emerald-600/50 backdrop-blur-sm"
                />
              </div>

              {/* 파라다이스 주소 (선택사항) */}
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-emerald-700 mb-2 drop-shadow-sm">
                  주소 (선택사항)
                </label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  placeholder="시/구/동까지 입력"
                  className="w-full px-4 py-3 border border-white/50 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all duration-200 bg-white/60 text-emerald-800 placeholder-emerald-600/50 backdrop-blur-sm"
                />
              </div>

              {/* 파라다이스 비밀번호 복원 안내 */}
              <div className="md:col-span-2">
                <div className="bg-emerald-100/60 border border-emerald-300/50 rounded-xl p-4 backdrop-blur-sm">
                  <div className="flex items-center space-x-2">
                    <svg className="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-sm font-medium text-emerald-700">🔐 비밀번호 복원</span>
                  </div>
                  <p className="text-sm text-emerald-600/80 mt-2">
                    비밀번호를 잊어버린 경우, 등록하신 이메일을 통해 비밀번호를 재설정할 수 있습니다.
                  </p>
                </div>
              </div>
            </div>

            {/* 크리스탈 가입 버튼 */}
            <button
              type="submit"
              disabled={isLoading}
              className={`w-full mt-6 py-3 px-4 rounded-xl font-semibold text-white transition-all duration-300 mb-4 border-2 ${
                isLoading
                  ? 'bg-gray-100/60 cursor-not-allowed border-gray-300 text-emerald-600/50'
                  : 'bg-gradient-to-r from-emerald-500 to-cyan-500 hover:shadow-lg hover:shadow-emerald-500/50 hover:scale-105 border-white/30 backdrop-blur-sm'
              }`}
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-emerald-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  크리스탈 가입 중...
                </div>
              ) : (
                '🏝️ 크리스탈 멤버십 가입하기'
              )}
            </button>

            {/* 파라다이스 구분선 */}
            <div className="relative mb-4">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-emerald-300/50" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-4 bg-gradient-to-r from-white/60 to-emerald-100/60 text-emerald-600/80 rounded-full backdrop-blur-sm">또는</span>
              </div>
            </div>

            {/* 파라다이스 입장 버튼 */}
            <button
              type="button"
              onClick={onSwitchToLogin}
              className="w-full py-3 px-4 border border-white/50 rounded-xl font-semibold text-emerald-700 hover:bg-white/50 hover:border-emerald-400 transition-all duration-200 bg-white/30 backdrop-blur-sm"
            >
              이미 멤버이신가요? 🏖️ 파라다이스 입장
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}