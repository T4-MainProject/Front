import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function SubjectLearning() {
  const navigate = useNavigate();
  const location = useLocation();
  const { subject } = location.state || {};
  
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [completedLessons, setCompletedLessons] = useState(new Set());

  // 축복 효과 상태
  const [blessingEffect, setBlessingEffect] = useState(false);
  const [lightShine, setLightShine] = useState(false);
  const [angelicGlow, setAngelicGlow] = useState(false);
  const [holyWhisper, setHolyWhisper] = useState(false);

  // 뒤로가기
  const handleBackToAnalysis = () => {
    navigate('/learning-analysis');
  };

  // 축복 효과 트리거
  useEffect(() => {
    const blessingInterval = setInterval(() => {
      setBlessingEffect(true);
      setTimeout(() => setBlessingEffect(false), 250);
    }, 8000 + Math.random() * 15000);

    const lightInterval = setInterval(() => {
      setLightShine(true);
      setTimeout(() => setLightShine(false), 4000);
    }, 12000 + Math.random() * 20000);

    const glowInterval = setInterval(() => {
      setAngelicGlow(true);
      setTimeout(() => setAngelicGlow(false), 500);
    }, 6000 + Math.random() * 12000);

    const whisperInterval = setInterval(() => {
      setHolyWhisper(true);
      setTimeout(() => setHolyWhisper(false), 3000);
    }, 25000 + Math.random() * 35000);

    return () => {
      clearInterval(blessingInterval);
      clearInterval(lightInterval);
      clearInterval(glowInterval);
      clearInterval(whisperInterval);
    };
  }, []);

  // 과목별 학습 과정 데이터 - 천사 버전
  const learningData = {
    영어: {
      title: '영어 집중 학습 - English Angelic Arts',
      subtitle: '체계적인 영어 축복 향상을 위한 맞춤형 빛의 커리큘럼',
      color: 'from-blue-500 to-blue-700',
      bgColor: 'from-blue-100 to-white',
      icon: '👼',
      courses: [
        {
          id: 'english-grammar',
          title: '어법/문법 천사 마스터',
          description: '영어 문법의 축복을 체계적으로 학습합니다',
          duration: '4주 빛의 과정',
          level: '중급',
          progress: 0,
          lessons: [
            { id: 1, title: '시제의 완벽한 희망', duration: '45분', type: '축복' },
            { id: 2, title: '조동사 천사 활용법', duration: '35분', type: '축복' },
            { id: 3, title: '가정법 빛으로 정복하기', duration: '50분', type: '축복' },
            { id: 4, title: '관계대명사/관계부사의 빛', duration: '40분', type: '축복' },
            { id: 5, title: '실전 문제 천사 풀이 1', duration: '60분', type: '실습' },
            { id: 6, title: '실전 문제 천사 풀이 2', duration: '60분', type: '실습' }
          ],
          expectedImprovement: '+8점'
        },
        {
          id: 'english-reading',
          title: '독해 속도 축복 향상',
          description: '빠르고 정확한 영어 독해 축복 능력을 기릅니다',
          duration: '3주 천사 과정',
          level: '고급',
          progress: 25,
          lessons: [
            { id: 1, title: 'Skimming & Scanning 천사 기법', duration: '40분', type: '축복' },
            { id: 2, title: '주제문 찾기 빛의 전략', duration: '35분', type: '축복' },
            { id: 3, title: '빈칸추론 천국 해결법', duration: '45분', type: '축복' },
            { id: 4, title: '실전 독해 천사 연습 1', duration: '50분', type: '실습' },
            { id: 5, title: '실전 독해 천사 연습 2', duration: '50분', type: '실습' }
          ],
          expectedImprovement: '+6점'
        },
        {
          id: 'english-vocabulary',
          title: '어휘력 축복 집중 강화',
          description: '수능 빈출 축복 어휘를 체계적으로 암기합니다',
          duration: '2주 천사 과정',
          level: '초급',
          progress: 60,
          lessons: [
            { id: 1, title: '접두사/접미사 천사 활용', duration: '30분', type: '축복' },
            { id: 2, title: '동의어/반의어 빛으로 정리', duration: '40분', type: '축복' },
            { id: 3, title: '주제별 축복 어휘 학습', duration: '45분', type: '축복' },
            { id: 4, title: '어휘 천사 암기 테스트', duration: '30분', type: '테스트' }
          ],
          expectedImprovement: '+4점'
        }
      ]
    },
    국어: {
      title: '국어 집중 학습 - Korean Blessed Literature',
      subtitle: '언어의 빛을 탐구하며 축복받은 실력을 향상시킵니다',
      color: 'from-sky-500 to-sky-700',
      bgColor: 'from-sky-100 to-white',
      icon: '✨',
      courses: [
        {
          id: 'korean-literature',
          title: '문학 작품 빛의 심화 분석',
          description: '고전문학부터 현대문학까지 축복받은 작품을 깊이 있게 분석합니다',
          duration: '5주 빛의 과정',
          level: '고급',
          progress: 80,
          lessons: [
            { id: 1, title: '고전 시가의 희망적 이해', duration: '50분', type: '축복' },
            { id: 2, title: '현대 소설 천사 분석 기법', duration: '45분', type: '축복' },
            { id: 3, title: '극문학의 빛나는 특성', duration: '40분', type: '축복' },
            { id: 4, title: '수필과 기행문의 희망', duration: '35분', type: '축복' },
            { id: 5, title: '문학 작품 실전 천사 분석', duration: '60분', type: '실습' },
            { id: 6, title: '문학사 빛으로 정리', duration: '40분', type: '축복' }
          ],
          expectedImprovement: '+10점'
        },
        {
          id: 'korean-nonfiction',
          title: '비문학 독해 빛의 전략',
          description: '다양한 비문학 지문을 효과적으로 분석하는 축복받은 방법을 배웁니다',
          duration: '3주 천사 과정',
          level: '중급',
          progress: 30,
          lessons: [
            { id: 1, title: '설명문 구조 천사 파악', duration: '40분', type: '축복' },
            { id: 2, title: '논증문 논리 빛으로 분석', duration: '45분', type: '축복' },
            { id: 3, title: '과학/기술 지문 천사 공략', duration: '50분', type: '축복' },
            { id: 4, title: '인문/예술 지문 빛의 이해', duration: '45분', type: '축복' },
            { id: 5, title: '비문학 실전 천사 연습', duration: '60분', type: '실습' }
          ],
          expectedImprovement: '+6점'
        },
        {
          id: 'korean-writing',
          title: '화법과 작문의 축복',
          description: '효과적인 천사적 의사소통과 글쓰기 능력을 기릅니다',
          duration: '4주 빛의 과정',
          level: '중급',
          progress: 0,
          lessons: [
            { id: 1, title: '화법의 기본 천사 원리', duration: '35분', type: '축복' },
            { id: 2, title: '토론과 토의 빛의 전략', duration: '40분', type: '축복' },
            { id: 3, title: '설득적 천사 글쓰기', duration: '45분', type: '축복' },
            { id: 4, title: '정보 전달 빛의 글쓰기', duration: '40분', type: '축복' },
            { id: 5, title: '실제 작문 천사 연습', duration: '60분', type: '실습' }
          ],
          expectedImprovement: '+5점'
        }
      ]
    }
  };

  const currentSubjectData = learningData[subject];

  const getLevelColor = (level) => {
    switch(level) {
      case '초급': return 'bg-blue-100 bg-opacity-50 text-blue-600 border border-blue-200';
      case '중급': return 'bg-sky-100 bg-opacity-50 text-sky-600 border border-sky-200';
      case '고급': return 'bg-indigo-100 bg-opacity-50 text-indigo-600 border border-indigo-200';
      default: return 'bg-gray-100 bg-opacity-50 text-gray-400 border border-gray-200';
    }
  };

  const getTypeIcon = (type) => {
    switch(type) {
      case '축복': return '✨';
      case '실습': return '🪽';
      case '테스트': return '👼';
      default: return '🌟';
    }
  };

  const handleStartLesson = (courseId, lessonId) => {
    setCompletedLessons(prev => new Set([...prev, `${courseId}-${lessonId}`]));
    // 실제로는 학습 컨텐츠 페이지로 이동
    alert('✨ 축복의 학습이 시작됩니다! (실제로는 축복받은 학습 컨텐츠로 이동)');
  };

  const calculateCourseProgress = (course) => {
    const completedCount = course.lessons.filter(lesson => 
      completedLessons.has(`${course.id}-${lesson.id}`)
    ).length;
    return Math.round((completedCount / course.lessons.length) * 100);
  };

  if (!subject || !currentSubjectData) {
    navigate('/learning-analysis');
    return null;
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br from-white via-sky-50 to-blue-100 relative overflow-hidden ${blessingEffect ? 'animate-pulse' : ''}`}>
      {/* 천사 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 빛의 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            {/* 빛의 패턴 */}
            <path d="M0,0 Q50,30 100,0 L100,20 Q50,50 0,20 Z" fill="url(#angelGradient)" />
            <path d="M0,50 Q25,80 50,50 Q75,20 100,50" stroke="#38bdf8" strokeWidth="0.5" fill="none" opacity="0.2"/>
            <path d="M20,0 L20,100 M40,0 L40,100 M60,0 L60,100 M80,0 L80,100" stroke="#0ea5e9" strokeWidth="0.3" opacity="0.2"/>
            {/* 천사 마법진 */}
            <circle cx="20" cy="20" r="8" stroke="#7dd3fc" strokeWidth="0.5" fill="none" opacity="0.2"/>
            <circle cx="80" cy="80" r="6" stroke="#bae6fd" strokeWidth="0.5" fill="none" opacity="0.2"/>
            <polygon points="20,15 25,20 20,25 15,20" fill="#e0f2fe" opacity="0.1"/>
            <polygon points="80,75 85,80 80,85 75,80" fill="#7dd3fc" opacity="0.1"/>
            {/* 천사 파티클 */}
            <circle cx="30" cy="30" r="2" fill="#38bdf8" opacity="0.2"/>
            <circle cx="70" cy="70" r="1.5" fill="#0ea5e9" opacity="0.2"/>
            <circle cx="15" cy="85" r="1" fill="#7dd3fc" opacity="0.2"/>
            <defs>
              <linearGradient id="angelGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#bae6fd" stopOpacity="0.3" />
                <stop offset="50%" stopColor="#7dd3fc" stopOpacity="0.15" />
                <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>

      {/* 헤더 - 천사 스타일 */}
      <div className="bg-white bg-opacity-90 shadow-2xl border-b-2 border-blue-200 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToAnalysis}
                className="text-blue-400 hover:text-blue-600 mr-4 transition-all duration-300 transform hover:scale-110"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-bold bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent ${blessingEffect ? 'animate-bounce' : ''}`}>
                {currentSubjectData.icon} {currentSubjectData.title}
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          
          {/* 과목 소개 섹션 - 천사 스타일 */}
          <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-8 mb-8 border-2 border-blue-200 relative overflow-hidden">
            <div className={`absolute inset-0 bg-gradient-to-r ${currentSubjectData.bgColor} opacity-30`}></div>
            <div className="relative z-10">
              <div className="text-center mb-6">
                <span className="text-6xl mb-4 block animate-pulse">{currentSubjectData.icon}</span>
                <h2 className="text-3xl font-bold text-blue-600 mb-2">{currentSubjectData.title}</h2>
                <p className="text-blue-500 text-lg">{currentSubjectData.subtitle}</p>
              </div>
              
              {/* 전체 진행률 */}
              <div className="bg-white bg-opacity-80 rounded-2xl p-6 border border-blue-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-blue-600">✨ 전체 학습 진행률</h3>
                  <span className="text-2xl font-bold text-blue-600">
                    {Math.round(currentSubjectData.courses.reduce((acc, course) => acc + calculateCourseProgress(course), 0) / currentSubjectData.courses.length)}%
                  </span>
                </div>
                <div className="w-full bg-blue-100 bg-opacity-50 rounded-full h-4 border border-blue-200">
                  <div 
                    className={`bg-gradient-to-r ${currentSubjectData.color} h-4 rounded-full transition-all duration-1000 relative overflow-hidden shadow-lg`}
                    style={{ 
                      width: `${Math.round(currentSubjectData.courses.reduce((acc, course) => acc + calculateCourseProgress(course), 0) / currentSubjectData.courses.length)}%`,
                      boxShadow: '0 0 15px rgba(59, 130, 246, 0.5)'
                    }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent transform -skew-x-12 animate-pulse"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 학습 과정 목록 - 천사 스타일 */}
          <div className="space-y-6">
            {currentSubjectData.courses.map((course, index) => {
              const courseProgress = calculateCourseProgress(course);
              
              return (
                <div 
                  key={course.id}
                  className="bg-white bg-opacity-90 rounded-3xl shadow-2xl border-2 border-blue-200 overflow-hidden transform hover:scale-105 transition-all duration-300"
                >
                  {/* 과정 헤더 */}
                  <div className={`bg-gradient-to-r ${currentSubjectData.color} p-6 text-white relative overflow-hidden`}>
                    <div className="absolute inset-0 bg-white/10"></div>
                    <div className="relative z-10">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <h3 className="text-2xl font-bold mb-2">{course.title}</h3>
                          <p className="text-blue-100 mb-4">{course.description}</p>
                          <div className="flex items-center space-x-4 text-sm">
                            <span className="bg-white/20 px-3 py-1 rounded-full border border-blue-200">⏱️ {course.duration}</span>
                            <span className={`px-3 py-1 rounded-full ${getLevelColor(course.level)} bg-white/20 border border-blue-200`}>
                              📊 {course.level}
                            </span>
                            <span className="bg-white/20 px-3 py-1 rounded-full border border-blue-200">📈 {course.expectedImprovement}</span>
                          </div>
                        </div>
                        <div className="text-right ml-6">
                          <div className="text-3xl font-bold mb-1">{courseProgress}%</div>
                          <div className="text-blue-100 text-sm">완료율</div>
                        </div>
                      </div>
                      
                      {/* 진행률 바 */}
                      <div className="w-full bg-white/20 rounded-full h-3 border border-blue-200">
                        <div 
                          className="bg-white h-3 rounded-full transition-all duration-1000 shadow-lg"
                          style={{ width: `${courseProgress}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>

                  {/* 강의 목록 */}
                  <div className="p-6">
                    <div className="space-y-4">
                      {course.lessons.map((lesson, lessonIndex) => {
                        const isCompleted = completedLessons.has(`${course.id}-${lesson.id}`);
                        
                        return (
                          <div 
                            key={lesson.id}
                            className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all duration-300 transform hover:scale-105 ${
                              isCompleted 
                                ? 'bg-green-100 bg-opacity-50 border-green-200 shadow-lg shadow-green-400/20' 
                                : 'bg-blue-50 bg-opacity-50 border-blue-200 hover:bg-blue-100 hover:bg-opacity-60 shadow-lg hover:shadow-blue-400/20'
                            }`}
                          >
                            <div className="flex items-center space-x-4">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white border-2 ${
                                isCompleted 
                                  ? 'bg-green-500 border-green-400' 
                                  : 'bg-blue-500 border-blue-400'
                              }`}>
                                {isCompleted ? '✓' : lessonIndex + 1}
                              </div>
                              
                              <div className="flex-1">
                                <div className="flex items-center space-x-2 mb-1">
                                  <span className="text-lg font-semibold text-blue-600">
                                    {getTypeIcon(lesson.type)} {lesson.title}
                                  </span>
                                  {isCompleted && (
                                    <span className="bg-green-100 bg-opacity-50 text-green-600 px-2 py-1 rounded-full text-xs font-medium border border-green-200">
                                      완료됨
                                    </span>
                                  )}
                                </div>
                                <div className="flex items-center space-x-4 text-sm text-blue-400">
                                  <span>⏰ {lesson.duration}</span>
                                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                    lesson.type === '축복' ? 'bg-blue-100 bg-opacity-50 text-blue-600 border border-blue-200' :
                                    lesson.type === '실습' ? 'bg-sky-100 bg-opacity-50 text-sky-600 border border-sky-200' :
                                    'bg-indigo-100 bg-opacity-50 text-indigo-600 border border-indigo-200'
                                  }`}>
                                    {getTypeIcon(lesson.type)} {lesson.type}
                                  </span>
                                </div>
                              </div>
                            </div>
                            
                            <button
                              onClick={() => handleStartLesson(course.id, lesson.id)}
                              disabled={isCompleted}
                              className={`px-6 py-2 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 ${
                                isCompleted
                                  ? 'bg-gray-100 bg-opacity-50 text-gray-400 cursor-not-allowed border border-gray-200'
                                  : 'bg-gradient-to-r from-blue-600 to-blue-500 text-white hover:from-blue-500 hover:to-blue-400 shadow-lg hover:shadow-blue-500/50 border border-blue-400'
                              }`}
                            >
                              {isCompleted ? '완료' : '학습하기'}
                            </button>
                          </div>
                        );
                      })}
                    </div>

                    {/* 과정 완료 상태 */}
                    {courseProgress === 100 && (
                      <div className="mt-6 p-4 bg-gradient-to-r from-green-500 to-emerald-400 text-white rounded-2xl text-center border-2 border-green-400">
                        <div className="text-2xl font-bold mb-2">🎉 축하합니다!</div>
                        <div>'{course.title}' 과정을 완료하셨습니다. 천사의 축복이 함께합니다!</div>
                        <div className="text-green-100 text-sm mt-1">예상 점수 향상: {course.expectedImprovement}</div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* 학습 통계 및 추천 - 천사 스타일 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
            
            {/* 학습 통계 */}
            <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-blue-200">
              <h3 className="text-xl font-bold text-blue-600 mb-6">📊 학습 통계 - Blessed Learning Stats</h3>
              
              <div className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-blue-50 bg-opacity-50 rounded-2xl border border-blue-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold border-2 border-blue-400">📚</div>
                    <div>
                      <div className="font-semibold text-blue-600">총 학습 시간</div>
                      <div className="text-blue-400 text-sm">누적 축복받은 시간</div>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-blue-600">24시간</div>
                </div>

                <div className="flex items-center justify-between p-4 bg-sky-50 bg-opacity-50 rounded-2xl border border-sky-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-sky-500 rounded-full flex items-center justify-center text-white font-bold border-2 border-sky-400">✨</div>
                    <div>
                      <div className="font-semibold text-sky-600">완료한 수업</div>
                      <div className="text-sky-400 text-sm">축복받은 강의 수</div>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-sky-600">{completedLessons.size}개</div>
                </div>

                <div className="flex items-center justify-between p-4 bg-indigo-50 bg-opacity-50 rounded-2xl border border-indigo-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-indigo-500 rounded-full flex items-center justify-center text-white font-bold border-2 border-indigo-400">🏆</div>
                    <div>
                      <div className="font-semibold text-indigo-600">학습 스트릭</div>
                      <div className="text-indigo-400 text-sm">연속 학습 일수</div>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-indigo-600">7일</div>
                </div>
              </div>
            </div>

            {/* 학습 추천 */}
            <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-sky-200">
              <div className="flex items-center space-x-2 mb-6">
                <span className="text-xl font-bold text-sky-600">🤖 AI 학습 추천 - Angel Learning Recommendations</span>
              </div>
              
              <div className="space-y-4">
                <div className="p-4 bg-gradient-to-r from-blue-100/50 to-sky-100/50 rounded-2xl border border-blue-200">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="font-semibold text-blue-600 mb-1">✨ 우선 학습 추천</div>
                      <div className="text-sm text-blue-500 mb-2">현재 진행률이 낮은 과정을 우선적으로 학습하세요</div>
                      <div className="flex flex-wrap gap-2">
                        {currentSubjectData.courses
                          .filter(course => calculateCourseProgress(course) < 50)
                          .slice(0, 2)
                          .map(course => (
                            <span key={course.id} className="bg-blue-100 bg-opacity-50 text-blue-600 px-3 py-1 rounded-full text-xs font-medium border border-blue-200">
                              {course.title}
                            </span>
                          ))
                        }
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-gradient-to-r from-sky-100/50 to-indigo-100/50 rounded-2xl border border-sky-200">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="font-semibold text-sky-600 mb-1">🎯 맞춤형 학습 계획</div>
                      <div className="text-sm text-blue-500 mb-2">주 3회, 1회당 2시간 학습으로 4주 내 완료 가능</div>
                      <div className="bg-sky-100 bg-opacity-50 text-sky-600 px-3 py-1 rounded-full text-xs font-medium inline-block border border-sky-200">
                        예상 점수 향상: +18점
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-gradient-to-r from-indigo-100/50 to-purple-100/50 rounded-2xl border border-indigo-200">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="font-semibold text-indigo-600 mb-1">🌟 보상 시스템</div>
                      <div className="text-sm text-blue-500 mb-2">모든 과정 완료 시 특별 인증서와 추가 모의고사 제공</div>
                      <div className="bg-indigo-100 bg-opacity-50 text-indigo-600 px-3 py-1 rounded-full text-xs font-medium inline-block border border-indigo-200">
                        천사의 축복 인증서
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 하단 액션 버튼 - 천사 스타일 */}
          <div className="mt-8 text-center">
            <div className="bg-white bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-blue-200">
              <h3 className="text-xl font-bold text-blue-600 mb-4">🚀 학습을 계속하시겠습니까?</h3>
              <p className="text-blue-500 mb-6">천사의 축복과 함께 목표 달성까지 함께 나아가요!</p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button 
                  onClick={() => {
                    const nextLesson = currentSubjectData.courses
                      .flatMap(course => course.lessons.map(lesson => ({ ...lesson, courseId: course.id })))
                      .find(lesson => !completedLessons.has(`${lesson.courseId}-${lesson.id}`));
                    
                    if (nextLesson) {
                      handleStartLesson(nextLesson.courseId, nextLesson.id);
                    } else {
                      alert('✨ 모든 수업을 완료하셨습니다! 천사의 축복이 함께합니다!');
                    }
                  }}
                  className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-8 py-4 rounded-2xl font-semibold hover:from-blue-500 hover:to-blue-400 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-blue-500/50 border border-blue-400"
                >
                  ✨ 다음 수업 계속하기
                </button>
                
                <button 
                  onClick={handleBackToAnalysis}
                  className="bg-blue-50 bg-opacity-80 hover:bg-blue-100 hover:bg-opacity-80 text-blue-600 px-8 py-4 rounded-2xl font-semibold transition-all duration-300 transform hover:scale-105 border border-blue-200"
                >
                  📊 분석 페이지로 돌아가기
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}