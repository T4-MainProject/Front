// ============================================
// pages/ExamUpload.jsx
// ============================================
import React, { useState, useRef } from 'react';

// Layout Components
import TopBar from '../components/TopBar';
import AppHeader from '../components/AppHeader';
import NavBar from '../components/NavBar';
import Footer from '../components/Footer';

export default function ExamUpload() {
  const [formData, setFormData] = useState({
    uploadTitle: '',
    subject: '',
    grade: '',
    examType: '',
    examDate: '',
    schoolName: ''
  });
  
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef(null);

  // 폼 데이터 업데이트 함수
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // 파일 선택 처리
  const handleFiles = (files) => {
    const validFiles = Array.from(files).filter(file => {
      const fileType = file.type.toLowerCase();
      return fileType === 'image/jpeg' || fileType === 'image/jpg' || fileType === 'image/png';
    });

    if (validFiles.length !== files.length) {
      alert('JPG, PNG 형식의 이미지 파일만 업로드 가능합니다.');
    }

    setSelectedFiles(prev => [...prev, ...validFiles]);
  };

  // 파일 선택 버튼 클릭
  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  // 파일 입력 변경
  const handleFileInputChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(e.target.files);
    }
  };

  // 드래그 앤 드롭 처리
  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  };

  // 파일 제거
  const removeFile = (index) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  // 파일 크기 포맷팅
  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // 폼 제출
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // 필수 항목 검증
    if (!formData.subject) {
      alert('과목을 선택해주세요.');
      return;
    }
    if (!formData.grade) {
      alert('학년을 선택해주세요.');
      return;
    }
    if (selectedFiles.length === 0) {
      alert('최소 1개 이상의 시험지 이미지를 업로드해주세요.');
      return;
    }

    // 여기서 실제 업로드 로직 구현
    console.log('업로드 데이터:', {
      formData,
      files: selectedFiles
    });
    
    alert('시험지 업로드가 완료되었습니다!');
  };

  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      {/* 최상단 바 */}
      <TopBar />
      
      {/* 헤더 */}
      <AppHeader />
      
      {/* 네비게이션 */}
      <NavBar />

      {/* 메인 콘텐츠 */}
      <main className="py-20 bg-gradient-to-b from-gray-50 to-white min-h-screen">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {/* 페이지 제목 */}
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-black text-gray-800 mb-4">
                📝 시험지 업로드
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                AI가 자동으로 채점하고 상세한 해설을 제공해드립니다
              </p>
            </div>

            {/* 업로드 폼 */}
            <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12">
              <form onSubmit={handleSubmit} className="space-y-8">
                
                {/* 시험지 제목 */}
                <div>
                  <label className="block text-lg font-semibold text-gray-700 mb-3">
                    시험지 제목 (선택사항)
                  </label>
                  <input
                    type="text"
                    name="uploadTitle"
                    value={formData.uploadTitle}
                    onChange={handleInputChange}
                    placeholder="예: 2024년 1학기 중간고사"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors text-lg"
                  />
                </div>

                {/* 과목 선택 */}
                <div>
                  <label className="block text-lg font-semibold text-gray-700 mb-4">
                    과목 선택 <span className="text-red-500">*</span>
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {['국어', '영어', '과학', '사회', '한국사', '기타'].map((subject) => (
                      <label key={subject} className="flex items-center p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-blue-300 transition-colors">
                        <input
                          type="radio"
                          name="subject"
                          value={subject}
                          checked={formData.subject === subject}
                          onChange={handleInputChange}
                          className="w-5 h-5 text-blue-600 mr-3"
                        />
                        <span className="text-lg font-medium">{subject}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* 학년 선택 */}
                <div>
                  <label className="block text-lg font-semibold text-gray-700 mb-4">
                    학년 선택 <span className="text-red-500">*</span>
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {['1학년', '2학년', '3학년', '기타'].map((grade) => (
                      <label key={grade} className="flex items-center p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-blue-300 transition-colors">
                        <input
                          type="radio"
                          name="grade"
                          value={grade}
                          checked={formData.grade === grade}
                          onChange={handleInputChange}
                          className="w-5 h-5 text-blue-600 mr-3"
                        />
                        <span className="text-lg font-medium">{grade}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* 시험 정보 */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-lg font-semibold text-gray-700 mb-3">
                      시험 유형
                    </label>
                    <select
                      name="examType"
                      value={formData.examType}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors text-lg"
                    >
                      <option value="">선택해주세요</option>
                      <option value="중간고사">중간고사</option>
                      <option value="기말고사">기말고사</option>
                      <option value="모의고사">모의고사</option>
                      <option value="수능">수능</option>
                      <option value="단원평가">단원평가</option>
                      <option value="기타">기타</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-lg font-semibold text-gray-700 mb-3">
                      시험 날짜
                    </label>
                    <input
                      type="date"
                      name="examDate"
                      value={formData.examDate}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors text-lg"
                    />
                  </div>
                </div>

                {/* 학교명 */}
                <div>
                  <label className="block text-lg font-semibold text-gray-700 mb-3">
                    학교명 (선택사항)
                  </label>
                  <input
                    type="text"
                    name="schoolName"
                    value={formData.schoolName}
                    onChange={handleInputChange}
                    placeholder="예: 서울고등학교"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors text-lg"
                  />
                </div>

                {/* 파일 업로드 영역 */}
                <div>
                  <label className="block text-lg font-semibold text-gray-700 mb-4">
                    시험지 이미지 업로드 <span className="text-red-500">*</span>
                  </label>
                  <p className="text-sm text-gray-500 mb-4">
                    JPG, PNG 형식만 지원됩니다. 여러 장의 시험지를 한 번에 업로드할 수 있습니다.
                  </p>
                  
                  {/* 드래그 앤 드롭 영역 */}
                  <div
                    className={`border-3 border-dashed rounded-2xl p-12 text-center transition-all ${
                      dragActive 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                  >
                    <div className="text-6xl mb-4">📁</div>
                    <h3 className="text-xl font-semibold text-gray-700 mb-2">
                      시험지 이미지를 드래그하여 업로드하거나
                    </h3>
                    <button
                      type="button"
                      onClick={handleFileSelect}
                      className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:shadow-lg transition-all hover:scale-105"
                    >
                      파일 선택하기
                    </button>
                    <p className="text-gray-500 mt-4">
                      최대 파일 크기: 10MB per file
                    </p>
                  </div>

                  {/* 숨겨진 파일 입력 */}
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    accept=".jpg,.jpeg,.png"
                    onChange={handleFileInputChange}
                    className="hidden"
                  />
                </div>

                {/* 선택된 파일 목록 */}
                {selectedFiles.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-700 mb-4">
                      선택된 파일 ({selectedFiles.length}개)
                    </h3>
                    <div className="space-y-3">
                      {selectedFiles.map((file, index) => (
                        <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                          <div className="flex items-center space-x-3">
                            <div className="text-2xl">🖼️</div>
                            <div>
                              <p className="font-medium text-gray-700">{file.name}</p>
                              <p className="text-sm text-gray-500">{formatFileSize(file.size)}</p>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => removeFile(index)}
                            className="text-red-500 hover:text-red-700 p-2 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 제출 버튼 */}
                <div className="pt-8">
                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white px-8 py-4 rounded-2xl font-bold text-xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
                  >
                    🚀 시험지 업로드 및 AI 채점 시작
                  </button>
                  <p className="text-center text-gray-500 mt-4">
                    업로드 후 AI가 자동으로 채점을 시작합니다. 처리 시간은 시험지 장수에 따라 달라집니다.
                  </p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </main>

      {/* 푸터 */}
      <Footer />
    </div>
  );
}