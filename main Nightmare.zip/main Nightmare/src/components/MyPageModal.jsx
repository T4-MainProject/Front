// ============================================
// 💀 Dark Horror MyPageModal.jsx - 영혼의 방 모달
// ============================================
// 📱 주요 기능:
// - 영혼 정보 표시
// - 어둠의 프로필 편집
// - 지옥 통계 정보 표시
// - 반응형 어둠 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { userRoles, memberTiers, pointsSystem, calculateUserTier, saveUserToStorage } from '../data/dummyUsers';

export default function MyPageModal({ isOpen, onClose, currentUser, onUserUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    school: ''
  });

  // 모달이 열릴 때 영혼 정보로 초기화
  useEffect(() => {
    if (currentUser) {
      setFormData({
        name: currentUser.name || '',
        phone: currentUser.phone || '',
        address: currentUser.address || '',
        school: currentUser.school || ''
      });
    }
  }, [currentUser]);

  // 모달이 열릴 때 body 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.keyCode === 27) onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    // 원래 어둠의 데이터로 복원
    setFormData({
      name: currentUser.name || '',
      phone: currentUser.phone || '',
      address: currentUser.address || '',
      school: currentUser.school || ''
    });
  };

  const handleSave = () => {
    const updatedUser = {
      ...currentUser,
      ...formData
    };
    
    // 지옥 스토리지 업데이트
    saveUserToStorage(updatedUser);
    
    // 부모 컴포넌트에 어둠의 업데이트 알림
    onUserUpdate(updatedUser);
    
    setIsEditing(false);
    alert('영혼의 정보가 성공적으로 저주되었습니다!');
  };

  if (!isOpen || !currentUser) return null;

  const roleInfo = userRoles[currentUser.role] || userRoles.student;
  const joinDate = new Date(currentUser.joinDate).toLocaleDateString('ko-KR');
  
  // 어둠의 회원등급 정보
  const currentTier = currentUser.role === 'admin' ? 'admin' : (currentUser.tier || calculateUserTier(currentUser.points || 0));
  const tierInfo = memberTiers[currentTier];
  const nextTier = currentTier === 'individual' ? 'pro' : 
                   currentTier === 'pro' ? 'proplus' : 
                   currentTier === 'proplus' ? 'ultra' : null;
  const nextTierInfo = nextTier ? memberTiers[nextTier] : null;
  
  // 어둠의 포인트 및 등급 진행도
  const currentPoints = currentUser.points || 0;
  const pointsToNext = nextTierInfo ? nextTierInfo.pointsRequired - currentPoints : 0;
  const progressPercentage = nextTierInfo ? 
    ((currentPoints - tierInfo.pointsRequired) / (nextTierInfo.pointsRequired - tierInfo.pointsRequired)) * 100 : 100;

  // 일일 저주 업로드 사용량 체크
  const today = new Date().toDateString();
  const hasResetToday = currentUser.dailyUploadsReset === today;
  const dailyUploadsUsed = hasResetToday ? (currentUser.dailyUploadsUsed || 0) : 0;
  const dailyUploadsRemaining = Math.max(0, tierInfo.dailyUploads - dailyUploadsUsed);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* 어둠의 배경 오버레이 */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-85 transition-opacity duration-300"
        onClick={onClose}
      />
      
      {/* 어둠의 모달 컨테이너 */}
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="relative bg-gradient-to-br from-gray-900 via-black to-red-900 rounded-2xl shadow-2xl shadow-red-500/50 w-full max-w-2xl transform transition-all duration-300 modal-enter border border-red-800/50">
          {/* 어둠의 배경 효과 */}
          <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-gray-900/40 to-red-900/30 rounded-2xl"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,black_40%)] rounded-2xl"></div>
          
          {/* 움직이는 어둠 파티클 */}
          <div className="absolute inset-0 overflow-hidden rounded-2xl pointer-events-none">
            <div className="absolute top-8 left-12 w-1 h-1 bg-red-500/40 rounded-full animate-pulse"></div>
            <div className="absolute top-16 right-16 w-1 h-1 bg-red-400/30 rounded-full animate-pulse delay-700"></div>
            <div className="absolute bottom-12 left-16 w-1 h-1 bg-gray-500/40 rounded-full animate-pulse delay-1000"></div>
            <div className="absolute top-1/2 right-12 w-1 h-1 bg-red-600/30 rounded-full animate-pulse delay-500"></div>
          </div>

          {/* 어둠의 닫기 버튼 */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-red-400 hover:text-red-300 transition-colors duration-200 z-10"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          {/* 어둠의 헤더 */}
          <div className="px-8 pt-8 pb-6 relative z-10">
            <div className="text-center mb-6">
              <div className="w-20 h-20 rounded-full overflow-hidden mx-auto mb-4 shadow-lg shadow-red-500/50 ring-4 ring-red-800/50">
                <img 
                  src={currentUser.avatar} 
                  alt={currentUser.name}
                  className="w-full h-full object-cover filter grayscale contrast-150"
                />
              </div>
              <h2 className="text-2xl font-bold text-red-300 mb-2 drop-shadow-lg">{currentUser.name}</h2>
              <div className="flex items-center justify-center space-x-2 mb-4">
                <span className={`px-3 py-1 rounded-full text-sm font-medium border ${
                  roleInfo.color === 'red' ? 'bg-red-900/50 text-red-400 border-red-700/50' :
                  roleInfo.color === 'blue' ? 'bg-red-900/50 text-red-400 border-red-700/50' :
                  roleInfo.color === 'green' ? 'bg-red-900/50 text-red-400 border-red-700/50' :
                  'bg-red-900/50 text-red-400 border-red-700/50'
                }`}>
                  {roleInfo.name === '관리자' ? '👹 어둠의 지배자' :
                   roleInfo.name === '선생님' ? '🔮 어둠의 전달자' :
                   roleInfo.name === '학생' ? '👻 영혼 학습자' :
                   roleInfo.name === '학부모' ? '💀 보호령' : '🌑 어둠의 존재'}
                </span>
                <span className="text-red-500/80 text-sm">지옥 계약일: {joinDate}</span>
              </div>
            </div>

            {/* 어둠의 회원등급 및 포인트 정보 */}
            <div className="bg-gradient-to-br from-red-900/30 to-black/60 border-2 border-red-800/50 rounded-2xl p-6 mb-6 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <span className="text-3xl drop-shadow-lg">{tierInfo.icon}</span>
                  <div>
                    <h3 className="text-xl font-bold text-red-300 drop-shadow-sm">{tierInfo.name}</h3>
                    <p className="text-sm text-red-500/80">어둠의 등급</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-red-400 drop-shadow-sm">{currentPoints.toLocaleString()}</div>
                  <div className="text-sm text-red-500/80">저주 포인트</div>
                </div>
              </div>

              {/* 어둠의 등급 진행도 */}
              {nextTierInfo && (
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-red-400/80">다음 어둠 등급까지</span>
                    <span className="font-medium text-red-400">{pointsToNext.toLocaleString()}P 남음</span>
                  </div>
                  <div className="w-full bg-red-900/40 rounded-full h-2 border border-red-800/50">
                    <div 
                      className="bg-gradient-to-r from-red-600 to-red-800 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(100, Math.max(0, progressPercentage))}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-xs mt-1 text-red-500/70">
                    <span>{tierInfo.name}</span>
                    <span>{nextTierInfo.name} {nextTierInfo.icon}</span>
                  </div>
                </div>
              )}

              {/* 일일 저주 업로드 제한 */}
              <div className="flex items-center justify-between text-sm">
                <span className="text-red-400/80">일일 저주 업로드</span>
                <span className={`font-medium ${dailyUploadsRemaining > 0 ? 'text-red-400' : 'text-red-600'}`}>
                  {dailyUploadsRemaining > 999 ? '무한 저주' : `${dailyUploadsRemaining}회 남음`}
                </span>
              </div>
            </div>
          </div>

          {/* 어둠의 학습 통계 대시보드 */}
          <div className="px-8 pb-6 relative z-10">
            <h3 className="text-lg font-semibold text-red-300 mb-4 drop-shadow-sm">💀 지옥 통계</h3>
            
            {/* 주요 악마 지표 */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-gradient-to-br from-red-900/40 to-black/60 rounded-xl p-4 text-center border border-red-800/50">
                <div className="text-2xl font-bold text-red-400 drop-shadow-sm">{currentUser.loginCount || 0}</div>
                <div className="text-sm text-red-500/80">지옥 접속</div>
              </div>
              <div className="bg-gradient-to-br from-gray-900/50 to-red-900/40 rounded-xl p-4 text-center border border-red-800/50">
                <div className="text-2xl font-bold text-red-400 drop-shadow-sm">
                  {currentUser.examHistory?.totalExams || 0}
                </div>
                <div className="text-sm text-red-500/80">심판 완료</div>
              </div>
              <div className="bg-gradient-to-br from-red-800/40 to-black/60 rounded-xl p-4 text-center border border-red-800/50">
                <div className="text-2xl font-bold text-red-400 drop-shadow-sm">
                  {currentUser.examHistory?.averageScore || 0}점
                </div>
                <div className="text-sm text-red-500/80">악마 평균</div>
              </div>
              <div className="bg-gradient-to-br from-black/70 to-red-900/50 rounded-xl p-4 text-center border border-red-800/50">
                <div className="text-2xl font-bold text-red-400 drop-shadow-sm">
                  {currentUser.examHistory?.recentScores?.length ? 
                    Math.max(...currentUser.examHistory.recentScores) : 0}점
                </div>
                <div className="text-sm text-red-500/80">최고 저주</div>
              </div>
            </div>

            {/* 과목별 어둠의 성과 */}
            {currentUser.examHistory?.subjectScores && (
              <div className="bg-gradient-to-br from-black/60 to-red-900/30 rounded-xl p-6 mb-6 border border-red-800/50 backdrop-blur-sm">
                <h4 className="font-semibold text-red-300 mb-4 drop-shadow-sm">📚 과목별 저주 성과</h4>
                <div className="space-y-4">
                  {Object.entries(currentUser.examHistory.subjectScores).map(([subject, data]) => {
                    const subjectName = subject === 'korean' ? '💀 어둠의 국어' : 
                                       subject === 'english' ? '👻 지옥의 영어' : '🔥 악마의 수학';
                    const percentage = data.average || 0;
                    
                    return (
                      <div key={subject}>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="font-medium text-red-400">{subjectName}</span>
                          <span className="text-red-500/80">{data.total}회 심판 • 평균 {data.average}점</span>
                        </div>
                        <div className="w-full bg-red-900/40 rounded-full h-2 border border-red-800/50">
                          <div 
                            className="bg-gradient-to-r from-red-600 to-red-800 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${percentage}%` }}
                          ></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 최근 저주 성적 추이 */}
            {currentUser.examHistory?.recentScores?.length > 0 && (
              <div className="bg-gradient-to-br from-black/60 to-red-900/30 border border-red-800/50 rounded-xl p-6 backdrop-blur-sm">
                <h4 className="font-semibold text-red-300 mb-4 drop-shadow-sm">📈 최근 저주 성적 추이</h4>
                <div className="flex items-end justify-between h-32 space-x-2">
                  {currentUser.examHistory.recentScores.map((score, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center">
                      <div 
                        className="w-full bg-gradient-to-t from-red-700 to-red-500 rounded-t transition-all duration-500 hover:from-red-800 hover:to-red-600"
                        style={{ height: `${(score / 100) * 100}%` }}
                      ></div>
                      <div className="text-xs font-medium text-red-400 mt-2">{score}점</div>
                      <div className="text-xs text-red-600/70">{index + 1}회</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 어둠의 회원등급 혜택 */}
          <div className="px-8 pb-6 relative z-10">
            <h3 className="text-lg font-semibold text-red-300 mb-4 drop-shadow-sm">🎁 {tierInfo.name} 등급 저주 혜택</h3>
            <div className="bg-gradient-to-br from-black/60 to-red-900/30 border border-red-800/50 rounded-xl p-6 backdrop-blur-sm">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium text-red-300 mb-3">현재 어둠의 혜택</h4>
                  <ul className="space-y-2">
                    {tierInfo.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <svg className="w-4 h-4 text-red-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span className="text-red-400">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                {nextTierInfo && (
                  <div>
                    <h4 className="font-medium text-red-300 mb-3">
                      {nextTierInfo.name} 등급 승급시 추가 저주
                    </h4>
                    <ul className="space-y-2">
                      {nextTierInfo.features.filter(f => !tierInfo.features.includes(f)).map((feature, index) => (
                        <li key={index} className="flex items-center text-sm text-red-500/80">
                          <svg className="w-4 h-4 text-red-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                          </svg>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <div className="mt-4 p-3 bg-red-900/50 rounded-lg border border-red-700/50">
                      <p className="text-sm text-red-400">
                        <span className="font-medium">{pointsToNext.toLocaleString()}저주 포인트</span> 더 모으면 어둠의 승급됩니다!
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 영혼 정보 */}
          <div className="px-8 pb-8 relative z-10">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-red-300 drop-shadow-sm">👤 영혼 정보</h3>
              {!isEditing ? (
                <button
                  onClick={handleEdit}
                  className="text-red-400 hover:text-red-300 font-medium text-sm flex items-center transition-colors duration-200"
                >
                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                  저주 편집
                </button>
              ) : (
                <div className="flex space-x-2">
                  <button
                    onClick={handleCancel}
                    className="text-red-500 hover:text-red-400 font-medium text-sm px-3 py-1 rounded border border-red-800/50 bg-black/40 transition-colors duration-200"
                  >
                    취소
                  </button>
                  <button
                    onClick={handleSave}
                    className="bg-red-700 text-red-300 font-medium text-sm px-3 py-1 rounded hover:bg-red-600 transition-colors duration-200"
                  >
                    저주 저장
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 영혼 이메일 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-red-300 mb-2">
                  영혼 이메일
                </label>
                <input
                  type="email"
                  value={currentUser.email}
                  disabled
                  className="w-full px-4 py-3 border border-red-800/50 rounded-xl bg-black/60 text-red-500/80 backdrop-blur-sm"
                />
              </div>

              {/* 영혼 이름 */}
              <div>
                <label className="block text-sm font-semibold text-red-300 mb-2">
                  영혼 이름
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-red-700/50 focus:ring-2 focus:ring-red-500 focus:border-transparent bg-black/60 text-red-300 placeholder-red-600/50' 
                      : 'border-red-800/50 bg-black/60 text-red-500/80'
                  }`}
                />
              </div>

              {/* 저주받은 전화번호 */}
              <div>
                <label className="block text-sm font-semibold text-red-300 mb-2">
                  저주받은 전화번호
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-red-700/50 focus:ring-2 focus:ring-red-500 focus:border-transparent bg-black/60 text-red-300 placeholder-red-600/50' 
                      : 'border-red-800/50 bg-black/60 text-red-500/80'
                  }`}
                />
              </div>

              {/* 지옥 학교 */}
              <div>
                <label className="block text-sm font-semibold text-red-300 mb-2">
                  지옥 학교
                </label>
                <input
                  type="text"
                  name="school"
                  value={formData.school}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-red-700/50 focus:ring-2 focus:ring-red-500 focus:border-transparent bg-black/60 text-red-300 placeholder-red-600/50' 
                      : 'border-red-800/50 bg-black/60 text-red-500/80'
                  }`}
                />
              </div>

              {/* 어둠의 주소 */}
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-red-300 mb-2">
                  어둠의 주소
                </label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-red-700/50 focus:ring-2 focus:ring-red-500 focus:border-transparent bg-black/60 text-red-300 placeholder-red-600/50' 
                      : 'border-red-800/50 bg-black/60 text-red-500/80'
                  }`}
                />
              </div>

              {/* 저주받은 생년월일 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-red-300 mb-2">
                  저주받은 생년월일
                </label>
                <input
                  type="date"
                  value={currentUser.birthDate}
                  disabled
                  className="w-full px-4 py-3 border border-red-800/50 rounded-xl bg-black/60 text-red-500/80 backdrop-blur-sm"
                />
              </div>

              {/* 어둠의 역할 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-red-300 mb-2">
                  어둠의 역할
                </label>
                <input
                  type="text"
                  value={roleInfo.name === '관리자' ? '👹 어둠의 지배자' :
                         roleInfo.name === '선생님' ? '🔮 어둠의 전달자' :
                         roleInfo.name === '학생' ? '👻 영혼 학습자' :
                         roleInfo.name === '학부모' ? '💀 보호령' : '🌑 어둠의 존재'}
                  disabled
                  className="w-full px-4 py-3 border border-red-800/50 rounded-xl bg-black/60 text-red-500/80 backdrop-blur-sm"
                />
              </div>
            </div>
          </div>

          {/* 어둠의 테두리 효과 */}
          <div className="absolute inset-0 rounded-2xl border border-red-700/30 pointer-events-none"></div>
        </div>
      </div>
    </div>
  );
}