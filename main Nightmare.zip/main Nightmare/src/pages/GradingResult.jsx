import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

export default function GradingResult() {
  const location = useLocation();
  const navigate = useNavigate();
  const resultData = location.state;
  
  // 선택된 과목 상태
  const [selectedSubject, setSelectedSubject] = useState('국어');
  // 애니메이션 상태 추가
  const [barsAnimated, setBarsAnimated] = useState(false);
  
  // 현재 시험지 페이지 상태 관리
  const [currentPage, setCurrentPage] = useState(0);
  
  // 이미지 확대/축소 모달 상태 관리
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [modalImageUrl, setModalImageUrl] = useState('');
  const [modalImageAlt, setModalImageAlt] = useState('');
  const [imageScale, setImageScale] = useState(1);
  const [imagePosition, setImagePosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  // 무서운 효과 상태
  const [glitchEffect, setGlitchEffect] = useState(false);
  const [bloodDrip, setBloodDrip] = useState(false);

  // useEffect 추가
  useEffect(() => {
    const timer = setTimeout(() => {
      setBarsAnimated(true);
    }, 500); // 0.5초 후에 애니메이션 시작
    
    return () => clearTimeout(timer);
  }, []);

  // 무서운 효과 트리거
  useEffect(() => {
    const glitchInterval = setInterval(() => {
      setGlitchEffect(true);
      setTimeout(() => setGlitchEffect(false), 200);
    }, 5000 + Math.random() * 10000);

    const bloodInterval = setInterval(() => {
      setBloodDrip(true);
      setTimeout(() => setBloodDrip(false), 3000);
    }, 8000 + Math.random() * 12000);

    return () => {
      clearInterval(glitchInterval);
      clearInterval(bloodInterval);
    };
  }, []);

  // 🔍 디버깅용 useEffect (한 번만 실행)
  useEffect(() => {
    console.log('GradingResult에서 받은 데이터:', resultData);
    console.log('examImage 데이터:', resultData?.examImage);
    console.log('uploadData 존재 여부:', !!resultData?.uploadData);
  }, []); // 빈 의존성 배열로 한 번만 실행

  // 📧 메모리 정리를 위한 useEffect
  useEffect(() => {
    return () => {
      console.log('GradingResult 컴포넌트 언마운트');
    };
  }, []);

  // 결과 데이터가 없으면 홈으로 리다이렉트
  if (!resultData) {
    navigate('/');
    return null;
  }

  // 📄 PDF 안전 뷰어 컴포넌트 (다크 테마 적용)
  const SafePdfViewer = ({ pdfUrl, alt, className }) => {
    const [showIframe, setShowIframe] = useState(false);
    const [debugInfo, setDebugInfo] = useState({});
    
    // PDF URL 분석 및 디버그 정보 생성
    useEffect(() => {
      if (pdfUrl) {
        console.log('PDF URL 분석:', {
          url: pdfUrl,
          length: pdfUrl.length,
          startsWithData: pdfUrl.startsWith('data:'),
          type: pdfUrl.split(',')[0],
          preview: pdfUrl.substring(0, 100) + '...',
          alt: alt
        });
        
        setDebugInfo({
          url: pdfUrl,
          length: pdfUrl.length,
          startsWithData: pdfUrl.startsWith('data:'),
          type: pdfUrl.split(',')[0],
          preview: pdfUrl.substring(0, 100) + '...'
        });
      }
    }, [pdfUrl, alt]);
    
    const handleOpenNewWindow = () => {
      console.log('새 창에서 PDF 열기 시도:', { url: pdfUrl?.substring(0, 100) + '...' });
      
      if (pdfUrl) {
        try {
          const newWindow = window.open('', '_blank');
          if (newWindow) {
            newWindow.document.write(`
              <!DOCTYPE html>
              <html>
                <head>
                  <title>${alt || 'PDF 파일'}</title>
                  <meta charset="UTF-8">
                  <style>
                    body { 
                      margin: 0; 
                      padding: 20px; 
                      font-family: 'Creepster', 'Arial Black', sans-serif; 
                      background: linear-gradient(135deg, #0d0d0d 0%, #1a0000 50%, #000000 100%);
                      color: #ff4444;
                    }
                    .container {
                      max-width: 100%;
                      margin: 0 auto;
                      background: #1a1a1a;
                      padding: 20px;
                      border-radius: 8px;
                      box-shadow: 0 0 30px rgba(255, 0, 0, 0.3);
                      border: 2px solid #ff0000;
                    }
                    .pdf-viewer {
                      width: 100%;
                      height: 80vh;
                      border: 2px solid #666;
                      border-radius: 4px;
                      filter: contrast(1.2) brightness(0.8);
                    }
                    .error-message {
                      color: #ff0000;
                      text-align: center;
                      padding: 20px;
                      text-shadow: 0 0 10px #ff0000;
                    }
                    .download-button {
                      background: linear-gradient(45deg, #660000, #cc0000);
                      color: white;
                      padding: 10px 20px;
                      border: 2px solid #ff0000;
                      border-radius: 4px;
                      cursor: pointer;
                      margin: 10px;
                      transition: all 0.3s ease;
                      text-shadow: 0 0 5px #000;
                    }
                    .download-button:hover {
                      background: linear-gradient(45deg, #cc0000, #ff0000);
                      box-shadow: 0 0 20px #ff0000;
                      transform: scale(1.05);
                    }
                  </style>
                </head>
                <body>
                  <div class="container">
                    <h1 style="text-shadow: 0 0 10px #ff0000; font-size: 2em;">${alt || 'CURSED PDF FILE'}</h1>
                    
                    <div style="margin-bottom: 20px;">
                      <button class="download-button" onclick="downloadPdf()">💀 파일 다운로드</button>
                    </div>
                    
                    <div id="pdf-container">
                      <iframe 
                        src="${pdfUrl}" 
                        class="pdf-viewer"
                        frameborder="0"
                        onload="console.log('PDF 로드 성공')"
                        onerror="showError()"
                      ></iframe>
                    </div>
                    
                    <div id="error-fallback" style="display: none;" class="error-message">
                      <p>⚠️ CURSED PDF CANNOT BE DISPLAYED ⚠️</p>
                      <p>The file is corrupted by dark forces...</p>
                      <button class="download-button" onclick="downloadPdf()">💀 Download if you dare</button>
                    </div>
                  </div>
                  
                  <script>
                    function showError() {
                      document.getElementById('pdf-container').style.display = 'none';
                      document.getElementById('error-fallback').style.display = 'block';
                    }
                    
                    function downloadPdf() {
                      const link = document.createElement('a');
                      link.href = '${pdfUrl}';
                      link.download = '${alt || 'cursed_document.pdf'}';
                      link.click();
                    }
                    
                    // 5초 후 PDF가 로드되지 않으면 에러 메시지 표시
                    setTimeout(() => {
                      const iframe = document.querySelector('iframe');
                      if (iframe && !iframe.contentDocument) {
                        showError();
                      }
                    }, 5000);
                  </script>
                </body>
              </html>
            `);
            newWindow.document.close();
          }
        } catch (error) {
          console.error('새 창 열기 실패:', error);
          alert('💀 The portal refuses to open. Dark forces block your way...');
        }
      }
    };
    
    const handleDownload = () => {
      if (pdfUrl) {
        const link = document.createElement('a');
        link.href = pdfUrl;
        link.download = alt || 'cursed_document.pdf';
        link.click();
      }
    };
    
    if (!pdfUrl) {
      return (
        <div className="text-center p-8">
          <div className="w-20 h-20 bg-red-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
            <svg className="w-10 h-10 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
          <h3 className="text-xl font-bold text-red-400 mb-2">💀 File Lost in the Void</h3>
          <p className="text-gray-400">The cursed PDF data has vanished into darkness...</p>
        </div>
      );
    }
    
    return (
      <div className="text-center p-8">
        <div className="w-20 h-20 bg-red-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
          <svg className="w-10 h-10 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        </div>
        <h3 className="text-xl font-bold text-red-400 mb-2">💀 Cursed PDF File</h3>
        <p className="text-gray-400 mb-4">{alt}</p>
        
        {/* 디버그 정보 표시 */}
        <div className="bg-gray-900 bg-opacity-80 p-4 rounded-lg mb-4 text-sm text-left border border-red-900">
          <h4 className="font-bold mb-2 text-red-400">🔍 File Information:</h4>
          <div className="text-gray-300">• 파일 크기: {debugInfo.length ? `${(debugInfo.length / 1024).toFixed(1)}KB` : 'Unknown'}</div>
          <div className="text-gray-300">• 데이터 형식: {debugInfo.startsWithData ? 'Base64 Data URL' : 'Regular URL'}</div>
          <div className="text-gray-300">• MIME 타입: {debugInfo.type || 'Unknown'}</div>
          <div className="text-gray-300">• 미리보기: {debugInfo.preview || 'None'}</div>
        </div>
        
        <div className="space-y-3">
          <button
            onClick={handleOpenNewWindow}
            className="bg-gradient-to-r from-red-800 to-red-600 text-white px-6 py-3 rounded-xl font-medium hover:from-red-700 hover:to-red-500 transition-all duration-300 mr-2 transform hover:scale-105 shadow-lg hover:shadow-red-500/50"
          >
            🌑 새 창에서 열기
          </button>
          
          <button
            onClick={() => setShowIframe(!showIframe)}
            className="bg-gradient-to-r from-purple-800 to-purple-600 text-white px-6 py-3 rounded-xl font-medium hover:from-purple-700 hover:to-purple-500 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-purple-500/50"
          >
            {showIframe ? '👁️ 미리보기 숨기기' : '👁️ 미리보기 보기'}
          </button>
          
          <div className="mt-2">
            <button
              onClick={handleDownload}
              className="bg-gradient-to-r from-gray-800 to-black text-white px-6 py-3 rounded-xl font-medium hover:from-gray-700 hover:to-gray-900 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-gray-500/50"
            >
              💀 다운로드
            </button>
          </div>
        </div>
        
        {showIframe && (
          <div className="mt-6 border border-red-900 rounded-lg overflow-hidden bg-black bg-opacity-50">
            <div className="bg-red-900 bg-opacity-50 p-3 text-sm text-red-200 border-b border-red-800">
              <strong>👁️ PDF 미리보기</strong> - 제대로 표시되지 않으면 '새 창에서 열기' 또는 '다운로드'를 사용하세요
            </div>
            
            <div className="relative bg-black" style={{ height: '600px' }}>
              <iframe
                src={pdfUrl}
                className="w-full h-full border-0 filter contrast-125 brightness-75"
                title={alt}
                onLoad={() => console.log('PDF iframe 로드 성공')}
                onError={() => console.log('PDF iframe 로드 실패')}
              />
            </div>
          </div>
        )}
        
        <div className="mt-6 p-4 bg-red-900 bg-opacity-30 rounded-lg border border-red-800">
          <h4 className="font-bold text-red-400 mb-2">💡 PDF 보기 방법</h4>
          <div className="text-sm text-gray-300 space-y-1">
            <div>• <strong>새 창에서 열기:</strong> 전체 화면으로 PDF 보기</div>
            <div>• <strong>다운로드:</strong> 컴퓨터에 저장하여 PDF 프로그램으로 열기</div>
            <div>• <strong>미리보기:</strong> 현재 페이지에서 바로 보기 (브라우저 지원 필요)</div>
          </div>
        </div>
      </div>
    );
  };

  // 🏠 홈으로 돌아가기
  const handleBackToHome = () => {
    navigate('/');
  };

  // 📝 새 모의고사 시작
  const handleNewExam = () => {
    navigate('/upload');
  };

  // 📚 오답노트 보기
  const handleWrongAnswers = () => {
    navigate('/wrong-answer-note');
  };

  // 📊 학습 분석
  const handleAnalysis = () => {
    navigate('/learning-analysis');
  };

  // 📷 시험지 이미지 결정 함수 (업로드된 이미지 우선, 없으면 더미 이미지)
  function getExamImages() {
    console.log('getExamImages 실행 - resultData:', resultData);
    
    // 첫 번째 우선순위: GradingProgress에서 spread된 examImage (base64 변환된 데이터)
    if (resultData && resultData.examImage && Array.isArray(resultData.examImage) && resultData.examImage.length > 0) {
      console.log('✅ examImage 배열 발견:', resultData.examImage.length, '개');
      return resultData.examImage.map((image, index) => ({
        id: index + 1,
        url: image.url, // 이미 base64 데이터 URL
        alt: `채점된 시험지 ${index + 1}페이지 - ${image.name}`,
        isUploaded: true,
        fileName: image.name,
        fileSize: image.size,
        fileType: image.name ? image.name.split('.').pop().toLowerCase() : 'unknown'
      }));
    }
    
    // 두 번째 우선순위: uploadData 내부의 examImage (이전 구조 호환)
    if (resultData && resultData.uploadData && resultData.uploadData.examImage && Array.isArray(resultData.uploadData.examImage) && resultData.uploadData.examImage.length > 0) {
      console.log('✅ uploadData.examImage 배열 발견:', resultData.uploadData.examImage.length, '개');
      return resultData.uploadData.examImage.map((image, index) => ({
        id: index + 1,
        url: image.url, // 이미 base64 데이터 URL
        alt: `채점된 시험지 ${index + 1}페이지 - ${image.name}`,
        isUploaded: true,
        fileName: image.name,
        fileSize: image.size,
        fileType: image.name ? image.name.split('.').pop().toLowerCase() : 'unknown'
      }));
    }
    
    // 마지막: 업로드된 이미지가 없으면 더미 이미지 사용
    console.log('⚠️ 업로드된 이미지가 없어 더미 이미지 사용');
    return [
      { id: 1, url: '/check.png', alt: '시험지 1페이지', isUploaded: false, fileType: 'png' },
      { id: 2, url: '/image.png', alt: '시험지 2페이지', isUploaded: false, fileType: 'png' },
      { id: 3, url: '/start.png', alt: '시험지 3페이지', isUploaded: false, fileType: 'png' }
    ];
  }

  // 과목별 데이터 (다크 테마 색상)
  const subjectData = {
    '국어': {
      color: 'red',
      bgColor: 'bg-red-800',
      lightBg: 'bg-red-900 bg-opacity-50',
      textColor: 'text-red-400',
      scores: [68, 72, 85, 82, 88, 92]
    },
    '영어': {
      color: 'purple',
      bgColor: 'bg-purple-800',
      lightBg: 'bg-purple-900 bg-opacity-50',
      textColor: 'text-purple-400',
      scores: [74, 78, 80, 75, 85, 87]
    },
    '수학': {
      color: 'gray',
      bgColor: 'bg-gray-800',
      lightBg: 'bg-gray-900 bg-opacity-50',
      textColor: 'text-gray-400',
      scores: [70, 77, 81, 77, 85, 88]
    }
  };

  // 현재 선택된 과목의 데이터
  const currentSubjectData = subjectData[selectedSubject];
  
  // 채점 결과 더미 데이터 (실제로는 resultData에서 가져올 데이터)
  const examResults = {
    correctAnswers: [1, 3, 2, 4, 5, 2, 1, 3, 4, 5, 2, 1, 3, 4, 5, 1, 2, 3, 4, 5, 1, 3, 2, 4, 5, 2, 1, 3, 4, 5, 2, 1, 3, 4, 5, 1, 2, 3, 4, 5, 1, 3, 2, 4, 5],
    userAnswers: [1, 2, 2, 4, 5, 3, 1, 3, 2, 5, 2, 1, 3, 4, 3, 1, 2, 3, 4, 4, 1, 3, 2, 4, 5, 2, 1, 1, 4, 5, 2, 1, 3, 4, 5, 1, 2, 3, 4, 5, 1, 3, 2, 4, 5]
  };

  const getScoreBySection = (start, end) => {
    let correct = 0;
    for (let i = start; i <= end; i++) {
      if (examResults.correctAnswers[i] === examResults.userAnswers[i]) {
        correct++;
      }
    }
    return Math.round((correct / (end - start + 1)) * 100);
  };

  // 더미 데이터 (실제로는 API에서 가져올 데이터) - 다크 테마 적용
  const userData = {
    name: '김학생',
    examCount: 5,
    currentScore: resultData.score || 87,
    improvement: '+12',
    streak: 7,
    // 📷 채점된 시험지 이미지들 - 업로드된 이미지를 우선 사용
    examImages: getExamImages(),
    subjectScores: [
      { subject: '국어', score: 92, color: 'from-red-800 to-red-600' },
      { subject: '영어', score: 85, color: 'from-purple-800 to-purple-600' },
      { subject: '수학', score: 78, color: 'from-gray-800 to-gray-600' }
    ],
    recentExams: [
      { subject: '국어', title: '2024 수능 모의고사 3회', date: '2024-03-25', score: 94, percent: 91 },
      { subject: '영어', title: '2024 3월 전국연합', date: '2024-03-22', score: 88, percent: 83 },
      { subject: '수학', title: '실전 모의고사 1회', date: '2024-03-20', score: 82, percent: 76 }
    ],
    recommendations: [
      { title: '취약점 집중 모의고사', desc: '작품과 문학 영역을 특별 집중', level: '수능' },
      { title: '실전 어법 모의고사', desc: '어법 문법 영역을 특별 집중', level: '70분' }
    ]
  };

  // 📄 페이지 내비게이션 함수
  const handlePreviousPage = () => {
    setCurrentPage(prev => Math.max(0, prev - 1));
  };

  const handleNextPage = () => {
    setCurrentPage(prev => Math.min(userData.examImages.length - 1, prev + 1));
  };

  // 🖼️ 이미지 모달 관련 함수들
  const openImageModal = (imageUrl, imageAlt) => {
    setModalImageUrl(imageUrl);
    setModalImageAlt(imageAlt);
    setIsImageModalOpen(true);
    setImageScale(1);
    setImagePosition({ x: 0, y: 0 });
  };

  const closeImageModal = () => {
    setIsImageModalOpen(false);
    setModalImageUrl('');
    setModalImageAlt('');
    setImageScale(1);
    setImagePosition({ x: 0, y: 0 });
  };

  const handleZoomIn = () => {
    setImageScale(prev => Math.min(prev + 0.2, 3));
  };

  const handleZoomOut = () => {
    setImageScale(prev => Math.max(prev - 0.2, 0.5));
  };

  const handleResetZoom = () => {
    setImageScale(1);
    setImagePosition({ x: 0, y: 0 });
  };

  const handleMouseDown = (e) => {
    if (imageScale > 1) {
      setIsDragging(true);
      setDragStart({
        x: e.clientX - imagePosition.x,
        y: e.clientY - imagePosition.y
      });
    }
  };

  const handleMouseMove = (e) => {
    if (isDragging && imageScale > 1) {
      setImagePosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && isImageModalOpen) {
        closeImageModal();
      }
    };

    if (isImageModalOpen) {
      document.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden'; // 배경 스크롤 방지
    }

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto'; // 스크롤 복원
    };
  }, [isImageModalOpen]);

  // 휠 줌 기능
  const handleWheel = (e) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.1 : 0.1;
    setImageScale(prev => Math.max(0.5, Math.min(3, prev + delta)));
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-black via-red-950 to-black relative overflow-hidden ${glitchEffect ? 'animate-pulse' : ''}`}>
      {/* 무서운 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 거미줄 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,0 Q50,30 100,0 L100,20 Q50,50 0,20 Z" fill="url(#webGradient)" />
            <defs>
              <linearGradient id="webGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ff0000" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#660000" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 피 효과 */}
        {bloodDrip && (
          <div className="absolute top-0 left-1/4 w-2 h-32 bg-gradient-to-b from-red-600 to-transparent animate-ping opacity-70"></div>
        )}
        
        {/* 안개 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-black/50 to-transparent"></div>
      </div>

      {/* 헤더 */}
      <div className="bg-black bg-opacity-80 shadow-2xl border-b border-red-900 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToHome}
                className="text-red-400 hover:text-red-300 mr-4 transition-all duration-300 transform hover:scale-110"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-bold bg-gradient-to-r from-red-500 to-red-300 bg-clip-text text-transparent ${glitchEffect ? 'animate-bounce' : ''}`}>
                💀 AI 채점 결과 - The Dark Assessment
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-6xl mx-auto space-y-8">
          
          {/* 인사말 섹션 - 무서운 버전 */}
          <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-red-900 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-red-900/20 to-black/20"></div>
            <div className="text-center relative z-10">
              <h2 className="text-3xl font-bold text-red-400 mb-2 filter drop-shadow-lg">
                안녕하세요, {userData.name}님... 👹
              </h2>
              <p className="text-gray-300 text-lg">
                어둠 속에서도 목표를 향해 나아가세요... 당신의 운명이 기다리고 있습니다.
              </p>
            </div>
            {/* 무서운 장식 */}
            <div className="absolute top-4 right-4 text-red-600 opacity-30 animate-pulse">💀</div>
            <div className="absolute bottom-4 left-4 text-red-600 opacity-30 animate-pulse">🕷️</div>
          </div>

          {/* 채점된 시험지 이미지 뷰어 - 다크 테마 */}
          <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-red-900 relative">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-red-400">📄 채점된 시험지 - Cursed Papers</h3>
              <div className="flex items-center space-x-4">
                {/* 업로드된 이미지 정보 표시 */}
                {userData.examImages[currentPage]?.isUploaded && (
                  <div className="text-sm text-gray-400">
                    <div className="flex items-center space-x-2">
                      <span className="bg-red-900 bg-opacity-50 text-red-300 px-2 py-1 rounded text-xs border border-red-800">업로드됨</span>
                      {userData.examImages[currentPage].fileName && (
                        <span className="truncate max-w-32 text-gray-300">{userData.examImages[currentPage].fileName}</span>
                      )}
                    </div>
                  </div>
                )}
                <div className="flex items-center space-x-2 text-sm text-gray-400">
                  <span>{currentPage + 1}</span>
                  <span>/</span>
                  <span>{userData.examImages.length}</span>
                </div>
              </div>
            </div>

            {/* 이미지 뷰어 */}
            <div className="relative">
              <div className="flex items-center justify-center bg-gray-900 bg-opacity-80 rounded-2xl overflow-hidden min-h-96 border border-red-900">
                {userData.examImages[currentPage] ? (
                  userData.examImages[currentPage].fileType === 'pdf' ? (
                    // PDF 파일 표시
                    <SafePdfViewer
                      pdfUrl={userData.examImages[currentPage].url}
                      alt={userData.examImages[currentPage].alt}
                      className="max-w-full h-auto max-h-96 object-contain filter contrast-125 brightness-75"
                    />
                  ) : (
                    // 이미지 파일 표시 (클릭 시 모달 열기)
                    <div 
                      className="cursor-pointer relative group"
                      onClick={() => openImageModal(userData.examImages[currentPage].url, userData.examImages[currentPage].alt)}
                    >
                      <img
                        src={userData.examImages[currentPage].url}
                        alt={userData.examImages[currentPage].alt}
                        className="max-w-full h-auto max-h-96 object-contain transition-all duration-300 group-hover:scale-105 filter contrast-125 brightness-75 sepia-[0.3] hue-rotate-[315deg]"
                        onError={(e) => {
                          // 이미지 로딩 실패 시 대체 이미지 표시
                          e.target.src = '/image.png';
                          console.warn('이미지 로딩 실패:', userData.examImages[currentPage].url);
                        }}
                      />
                      {/* 확대 아이콘 오버레이 */}
                      <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all duration-300">
                        <div className="bg-red-900 bg-opacity-80 rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 border border-red-600">
                          <svg className="w-6 h-6 text-red-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                          </svg>
                        </div>
                      </div>
                    </div>
                  )
                ) : (
                  <div className="text-gray-500 text-center">
                    <div className="text-6xl mb-4">💀</div>
                    <div>시험지를 불러오는 중... Loading cursed papers...</div>
                  </div>
                )}
              </div>

              {/* 업로드된 이미지 정보 */}
              {userData.examImages[currentPage]?.isUploaded && userData.examImages[currentPage].fileSize && (
                <div className="mt-4 text-sm text-gray-400 text-center">
                  파일 크기: {(userData.examImages[currentPage].fileSize / 1024 / 1024).toFixed(2)} MB
                </div>
              )}

              {/* 이전/다음 버튼 */}
              <div className="flex items-center justify-between mt-6">
                <button
                  onClick={handlePreviousPage}
                  disabled={currentPage === 0}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-medium transition-all duration-300 ${
                    currentPage === 0
                      ? 'bg-gray-800 text-gray-600 cursor-not-allowed'
                      : 'bg-red-900 bg-opacity-50 text-red-300 hover:bg-red-800 hover:bg-opacity-70 border border-red-800 transform hover:scale-105'
                  }`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
                  </svg>
                  <span>이전 페이지</span>
                </button>

                <div className="flex items-center space-x-2">
                  {userData.examImages.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentPage(index)}
                      className={`w-3 h-3 rounded-full transition-all duration-300 ${
                        index === currentPage
                          ? 'bg-red-500 shadow-lg shadow-red-500/50'
                          : 'bg-gray-600 hover:bg-gray-500'
                      }`}
                    />
                  ))}
                </div>

                <button
                  onClick={handleNextPage}
                  disabled={currentPage === userData.examImages.length - 1}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-medium transition-all duration-300 ${
                    currentPage === userData.examImages.length - 1
                      ? 'bg-gray-800 text-gray-600 cursor-not-allowed'
                      : 'bg-red-900 bg-opacity-50 text-red-300 hover:bg-red-800 hover:bg-opacity-70 border border-red-800 transform hover:scale-105'
                  }`}
                >
                  <span>다음 페이지</span>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          {/* 답안지 및 영어듣기 대본 섹션 - 다크 테마 */}
          {(resultData.answerSheet || resultData.listeningScript) && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* 답안지 섹션 */}
              {resultData.answerSheet && (
                <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-red-900">
                  <h3 className="text-2xl font-bold text-red-400 mb-6">📝 답안지 - Answer Sheet of Doom</h3>
                  
                  <div className="space-y-4">
                    {/* 파일 정보 */}
                    <div className="flex items-center justify-between p-4 bg-gray-900 bg-opacity-80 rounded-2xl border border-red-900">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-red-900 bg-opacity-50 rounded-full flex items-center justify-center">
                          <svg className="w-5 h-5 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                        </div>
                        <div>
                          <div className="font-medium text-red-300">{resultData.answerSheet.name}</div>
                          <div className="text-sm text-gray-400">
                            {(resultData.answerSheet.size / 1024 / 1024).toFixed(2)} MB
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => window.open(resultData.answerSheet.url, '_blank')}
                        className="bg-gradient-to-r from-red-800 to-red-600 text-white px-4 py-2 rounded-xl font-medium hover:from-red-700 hover:to-red-500 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-red-500/50"
                      >
                        💀 열기
                      </button>
                    </div>

                    {/* 답안지 미리보기 */}
                    <div className="bg-gray-900 bg-opacity-80 rounded-2xl overflow-hidden border border-red-900">
                      <div className="p-4 border-b border-red-800">
                        <h4 className="font-medium text-red-300">👁️ 미리보기</h4>
                      </div>
                      <div className="p-4">
                        {resultData.answerSheet.name.toLowerCase().endsWith('.pdf') ? (
                          <SafePdfViewer
                            pdfUrl={resultData.answerSheet.url}
                            alt="답안지 미리보기"
                            className="max-w-full h-auto max-h-64 object-contain mx-auto filter contrast-125 brightness-75"
                          />
                        ) : (
                          <img
                            src={resultData.answerSheet.url}
                            alt="답안지 미리보기"
                            className="max-w-full h-auto max-h-64 object-contain mx-auto filter contrast-125 brightness-75 sepia-[0.3] hue-rotate-[315deg]"
                            onError={(e) => {
                              e.target.style.display = 'none';
                              e.target.nextSibling.style.display = 'block';
                            }}
                          />
                        )}
                        <div className="text-center text-red-400 py-8" style={{ display: 'none' }}>
                          💀 미리보기를 불러올 수 없습니다
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 영어듣기 대본 섹션 */}
              {resultData.listeningScript && (
                <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-purple-900">
                  <h3 className="text-2xl font-bold text-purple-400 mb-6">🎧 영어듣기 대본 - Whispers from Beyond</h3>
                  
                  <div className="space-y-4">
                    {/* 파일 정보 */}
                    <div className="flex items-center justify-between p-4 bg-gray-900 bg-opacity-80 rounded-2xl border border-purple-900">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-purple-900 bg-opacity-50 rounded-full flex items-center justify-center">
                          <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                        </div>
                        <div>
                          <div className="font-medium text-purple-300">{resultData.listeningScript.name}</div>
                          <div className="text-sm text-gray-400">
                            {(resultData.listeningScript.size / 1024 / 1024).toFixed(2)} MB
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => window.open(resultData.listeningScript.url, '_blank')}
                        className="bg-gradient-to-r from-purple-800 to-purple-600 text-white px-4 py-2 rounded-xl font-medium hover:from-purple-700 hover:to-purple-500 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-purple-500/50"
                      >
                        👻 열기
                      </button>
                    </div>

                    {/* 대본 미리보기 */}
                    <div className="bg-gray-900 bg-opacity-80 rounded-2xl overflow-hidden border border-purple-900">
                      <div className="p-4 border-b border-purple-800">
                        <h4 className="font-medium text-purple-300">👁️ 미리보기</h4>
                      </div>
                      <div className="p-4">
                        {resultData.listeningScript.name.toLowerCase().endsWith('.pdf') ? (
                          <SafePdfViewer
                            pdfUrl={resultData.listeningScript.url}
                            alt="영어듣기 대본 미리보기"
                            className="max-w-full h-auto max-h-64 object-contain mx-auto filter contrast-125 brightness-75"
                          />
                        ) : (
                          <div className="text-center text-gray-400 py-8">
                            <div className="w-16 h-16 bg-purple-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4">
                              <svg className="w-8 h-8 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                              </svg>
                            </div>
                            <p>👻 텍스트 파일 미리보기</p>
                            <p className="text-sm text-gray-500 mt-1">파일을 열어서 내용을 확인하세요</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 채점 결과 시각화 - 다크 무서운 테마 */}
          <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-red-900">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-red-400">📊 문제별 채점 결과 - Results of Doom</h3>
            </div>

            {/* 선택 번호별 분포 - 무서운 스타일 */}
            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-red-900 mb-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-red-400">📊 선택 번호별 분포 - Distribution of Fate</h3>
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 bg-green-600 rounded border border-green-400"></div>
                    <span className="text-gray-300">정답</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 bg-red-600 rounded border border-red-400"></div>
                    <span className="text-gray-300">오답</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-1 bg-red-600 rounded"></div>
                    <span className="text-gray-300">내 선택</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-1 bg-purple-600 rounded" style={{background: 'repeating-linear-gradient(to right, #9333ea 0, #9333ea 8px, transparent 8px, transparent 16px)'}}></div>
                    <span className="text-gray-300">정답 패턴</span>
                  </div>
                </div>
              </div>
              
              {/* 45개 바 차트 + 그래프 - 무서운 스타일 */}
              <div className="relative h-80 overflow-x-auto bg-gray-900 bg-opacity-50 rounded-lg border border-red-900">
                <div className="flex items-end justify-start h-full min-w-max px-4">
                  <div className="flex items-end h-64 relative" style={{ gap: '4px', minWidth: 'calc(45 * 16px + 44 * 4px)' }}>
                    {examResults.userAnswers.map((answer, index) => {
                      // 선택 번호에 따라 바의 높이 결정
                      const heights = {
                        1: 15,
                        2: 30,
                        3: 45,
                        4: 60,
                        5: 75
                      };
                      
                      // 무서운 색상 팔레트
                      const horrorColors = [
                        '#660000', '#800000', '#990000', '#cc0000', '#ff0000',
                        '#660033', '#800033', '#990033', '#cc0033', '#ff0033',
                        '#330066', '#400080', '#500099', '#6600cc', '#8000ff'
                      ];
                      
                      return (
                        <div 
                          key={index}
                          className="rounded-t transition-all duration-1000 ease-out hover:opacity-80 cursor-pointer relative group flex-shrink-0 shadow-lg"
                          style={{
                            width: '16px',
                            height: barsAnimated ? `${heights[answer]}%` : '0%',
                            background: `linear-gradient(to top, ${horrorColors[index % horrorColors.length]}, ${horrorColors[(index + 5) % horrorColors.length]})`,
                            transitionDelay: `${index * 20}ms`,
                            boxShadow: `0 0 10px ${horrorColors[index % horrorColors.length]}50`
                          }}
                          title={`문제 ${index + 1}: ${answer}번 선택`}
                        >
                          <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-90 text-red-300 text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10 border border-red-900">
                            💀 {index + 1}번: {answer}번 선택
                          </div>
                        </div>
                      );
                    })}
                    
                    {/* 그래프 선과 점들 - 무서운 스타일 */}
                    {examResults.userAnswers.map((answer, index) => {
                      const heights = {
                        1: 15,
                        2: 30,
                        3: 45,
                        4: 60,
                        5: 75
                      };
                      
                      // 오답 문제들
                      const wrongAnswers = [1, 5, 8, 14, 19, 27];
                      const isWrongAnswer = wrongAnswers.includes(index);
                      
                      const barWidth = 16;
                      const gap = 4;
                      const x = index * (barWidth + gap) + barWidth / 2;
                      
                      // 오답인 경우 정답 위치로, 정답인 경우 내 선택 위치로
                      const pointHeight = isWrongAnswer ? heights[examResults.correctAnswers[index]] : heights[answer];
                      
                      return (
                        <div
                          key={`point-${index}`}
                          className="absolute pointer-events-none"
                          style={{
                            left: `${x - 4}px`,
                            bottom: barsAnimated ? `${pointHeight}%` : '0%',
                            width: '8px',
                            height: '8px',
                            borderRadius: '50%',
                            backgroundColor: isWrongAnswer ? '#ef4444' : '#ffffff',
                            border: isWrongAnswer ? '2px solid #dc2626' : '2px solid #9333ea',
                            transform: 'translateY(50%)',
                            transition: 'bottom 1000ms ease-out',
                            transitionDelay: `${index * 20 + 500}ms`,
                            zIndex: 10,
                            boxShadow: isWrongAnswer ? '0 0 10px #ef4444' : '0 0 10px #9333ea'
                          }}
                        />
                      );
                    })}
                    
                    {/* 선 그래프 - 무서운 스타일 */}
                    <svg 
                      className="absolute inset-0 pointer-events-none" 
                      style={{ 
                        width: '100%', 
                        height: '100%',
                        zIndex: 5
                      }}
                    >
                      <path
                        d={examResults.userAnswers.map((answer, index) => {
                          const heights = {
                            1: 15,
                            2: 30,
                            3: 45,
                            4: 60,
                            5: 75
                          };
                          
                          // 오답 문제들
                          const wrongAnswers = [1, 5, 8, 14, 19, 27];
                          const isWrongAnswer = wrongAnswers.includes(index);
                          
                          const barWidth = 16;
                          const gap = 4;
                          const x = index * (barWidth + gap) + barWidth / 2;
                          
                          // 오답인 경우 정답 위치로, 정답인 경우 내 선택 위치로
                          const pointHeight = isWrongAnswer ? heights[examResults.correctAnswers[index]] : heights[answer];
                          const y = 256 * (1 - pointHeight / 100); // 256px = h-64
                          
                          return `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
                        }).join(' ')}
                        stroke="#9333ea"
                        strokeWidth="3"
                        fill="none"
                        className={`transition-opacity duration-1000 ${barsAnimated ? 'opacity-80' : 'opacity-0'}`}
                        style={{ 
                          transitionDelay: '1000ms',
                          filter: 'drop-shadow(0 0 5px #9333ea)'
                        }}
                      />
                    </svg>
                  </div>
                </div>
              </div>
              
              {/* 총 문제 수 표시 */}
              <div className="mt-6 text-center text-sm text-gray-400">
                💀 총 45문제 - 선택 번호에 따른 바 높이 분포 (가로 스크롤 가능)
              </div>
            </div>

            {/* 문제별 정오답 그래프 - 무서운 스타일 */}
            <div className="mb-8">
              <h4 className="text-lg font-semibold text-red-300 mb-4">문제별 정답/오답 현황 (1~45번) - The Judgment</h4>
              <div className="flex flex-wrap gap-4 mb-4">
                {examResults.correctAnswers.map((correctAnswer, index) => {
                  const isCorrect = correctAnswer === examResults.userAnswers[index];
                  return (
                    <div key={index} className="flex flex-col items-center">
                      <div 
                        className={`w-8 h-8 rounded ${isCorrect ? 'bg-green-700 border-2 border-green-500 shadow-lg shadow-green-500/50' : 'bg-red-700 border-2 border-red-500 shadow-lg shadow-red-500/50'} 
                        hover:opacity-80 transition-all duration-300 cursor-pointer relative group flex items-center justify-center transform hover:scale-110`}
                        title={`문제 ${index + 1}: ${isCorrect ? '정답' : '오답'} (정답: ${correctAnswer}, 선택: ${examResults.userAnswers[index]})`}
                      >
                        <span className="text-white text-xs font-bold">{index + 1}</span>
                        <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-90 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10 border border-red-900">
                          💀 {index + 1}번: {isCorrect ? '정답' : '오답'} (정답: {correctAnswer}, 선택: {examResults.userAnswers[index]})
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 구간별 성취도 - 무서운 스타일 */}
            <div>
              <h4 className="text-lg font-semibold text-red-300 mb-4">구간별 성취도 - Sectional Doom Analysis</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-red-900 bg-opacity-50 rounded-2xl p-4 border border-red-800">
                  <div className="text-center">
                    <div className="text-lg font-semibold text-red-300 mb-2">💀 1~15번</div>
                    <div className="text-3xl font-bold text-red-400 mb-2">{getScoreBySection(0, 14)}%</div>
                    <div className="w-full bg-red-800 bg-opacity-50 rounded-full h-3 border border-red-700">
                      <div 
                        className="bg-gradient-to-r from-red-600 to-red-400 h-3 rounded-full transition-all duration-1000 shadow-lg shadow-red-500/50"
                        style={{ width: `${getScoreBySection(0, 14)}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
                
                <div className="bg-purple-900 bg-opacity-50 rounded-2xl p-4 border border-purple-800">
                  <div className="text-center">
                    <div className="text-lg font-semibold text-purple-300 mb-2">👻 16~30번</div>
                    <div className="text-3xl font-bold text-purple-400 mb-2">{getScoreBySection(15, 29)}%</div>
                    <div className="w-full bg-purple-800 bg-opacity-50 rounded-full h-3 border border-purple-700">
                      <div 
                        className="bg-gradient-to-r from-purple-600 to-purple-400 h-3 rounded-full transition-all duration-1000 shadow-lg shadow-purple-500/50"
                        style={{ width: `${getScoreBySection(15, 29)}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-900 bg-opacity-50 rounded-2xl p-4 border border-gray-700">
                  <div className="text-center">
                    <div className="text-lg font-semibold text-gray-300 mb-2">🕷️ 31~45번</div>
                    <div className="text-3xl font-bold text-gray-400 mb-2">{getScoreBySection(30, 44)}%</div>
                    <div className="w-full bg-gray-800 bg-opacity-50 rounded-full h-3 border border-gray-600">
                      <div 
                        className="bg-gradient-to-r from-gray-600 to-gray-400 h-3 rounded-full transition-all duration-1000 shadow-lg shadow-gray-500/50"
                        style={{ width: `${getScoreBySection(30, 44)}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 주요 통계 - 무서운 스타일 */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 border-2 border-red-900 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 to-transparent"></div>
              <div className="w-12 h-12 bg-red-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-red-400 mb-1 relative z-10">{userData.examCount}회</div>
              <div className="text-sm text-gray-400 relative z-10">모의고사 횟수</div>
              <div className="absolute top-2 right-2 text-red-600 opacity-30 animate-pulse">💀</div>
            </div>

            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 border-2 border-green-900 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-green-900/20 to-transparent"></div>
              <div className="w-12 h-12 bg-green-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-green-400 mb-1 relative z-10">{userData.currentScore}점</div>
              <div className="text-sm text-gray-400 relative z-10">AI 채점 점수</div>
              <div className="absolute top-2 right-2 text-green-600 opacity-30 animate-pulse">🎯</div>
            </div>

            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 border-2 border-purple-900 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 to-transparent"></div>
              <div className="w-12 h-12 bg-purple-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-purple-400 mb-1 relative z-10">
                <span className="text-green-400">{userData.improvement}</span>점
              </div>
              <div className="text-sm text-gray-400 relative z-10">향상도</div>
              <div className="absolute top-2 right-2 text-purple-600 opacity-30 animate-pulse">📈</div>
            </div>

            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-6 border-2 border-orange-900 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-orange-900/20 to-transparent"></div>
              <div className="w-12 h-12 bg-orange-900 bg-opacity-50 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                <svg className="w-6 h-6 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z" />
                </svg>
              </div>
              <div className="text-3xl font-bold text-orange-400 mb-1 relative z-10">{userData.streak}일</div>
              <div className="text-sm text-gray-400 relative z-10">학습 스트릭</div>
              <div className="absolute top-2 right-2 text-orange-600 opacity-30 animate-pulse">🔥</div>
            </div>
          </div>

          {/* 과목별 성취도와 최근 응시 모의고사 - 무서운 스타일 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* 과목별 성취도 */}
            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-red-900">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-red-400">과목별 성취도 - Subject Mastery</h3>
                <button className="text-red-400 text-sm font-medium hover:text-red-300 transition-colors duration-200">
                  👁️ 자세히 보기 →
                </button>
              </div>
              
              <div className="space-y-6">
                {userData.subjectScores.map((subject, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-gray-300">{subject.subject}</span>
                      <div className="flex items-center space-x-2">
                        <span className="text-2xl font-bold text-red-400">{subject.score}점</span>
                        <span className="text-sm text-gray-400">↗ 상승</span>
                      </div>
                    </div>
                    <div className="w-full bg-gray-800 bg-opacity-50 rounded-full h-3 border border-gray-700">
                      <div 
                        className={`bg-gradient-to-r ${subject.color} h-3 rounded-full transition-all duration-1000 relative overflow-hidden shadow-lg`}
                        style={{ 
                          width: `${subject.score}%`,
                          boxShadow: `0 0 15px ${subject.color.includes('red') ? '#ef4444' : subject.color.includes('purple') ? '#a855f7' : '#6b7280'}50`
                        }}
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 animate-pulse"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 최근 응시한 모의고사 */}
            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-purple-900">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-purple-400">최근 응시한 모의고사 - Recent Tests</h3>
                <button className="text-purple-400 text-sm font-medium hover:text-purple-300 transition-colors duration-200">
                  👻 전체 보기 →
                </button>
              </div>
              
              <div className="space-y-4">
                {userData.recentExams.map((exam, index) => (
                  <div key={index} className="flex items-center space-x-4 p-4 bg-gray-900 bg-opacity-80 rounded-2xl hover:bg-gray-800 hover:bg-opacity-80 transition-all duration-300 border border-gray-700 transform hover:scale-105">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-lg shadow-lg ${
                      exam.subject === '국어' ? 'bg-red-700 border-2 border-red-500' : 
                      exam.subject === '영어' ? 'bg-purple-700 border-2 border-purple-500' : 'bg-gray-700 border-2 border-gray-500'
                    }`}>
                      {exam.subject.charAt(0)}
                    </div>
                    
                    <div className="flex-1">
                      <div className="font-medium text-gray-300">{exam.title}</div>
                      <div className="text-sm text-gray-500">{exam.date}</div>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-xl font-bold text-red-400">{exam.score}점</div>
                      <div className="text-sm text-gray-500">{exam.percent}% 정답률</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 바로가기와 AI 추천 - 무서운 스타일 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* 바로가기 */}
            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-red-900">
              <h3 className="text-xl font-bold text-red-400 mb-6">바로가기 - Quick Actions</h3>
              
              <div className="space-y-4">
                <button 
                  onClick={handleNewExam}
                  className="w-full bg-gradient-to-r from-red-800 to-red-600 text-white p-4 rounded-2xl font-semibold text-left hover:from-red-700 hover:to-red-500 transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-red-500/50 border border-red-700"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-lg">💀 새 시험지 업로드</div>
                    </div>
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </button>

                <button 
                  onClick={handleWrongAnswers}
                  className="w-full bg-gray-900 bg-opacity-80 hover:bg-gray-800 hover:bg-opacity-80 text-gray-300 p-4 rounded-2xl font-semibold text-left transition-all duration-300 hover:scale-105 border border-gray-700"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-lg">📚 오답노트 보기</div>
                    </div>
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </button>

                <button 
                  onClick={handleAnalysis}
                  className="w-full bg-gray-900 bg-opacity-80 hover:bg-gray-800 hover:bg-opacity-80 text-gray-300 p-4 rounded-2xl font-semibold text-left transition-all duration-300 hover:scale-105 border border-gray-700"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-lg">📊 학습 분석</div>
                    </div>
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </button>
              </div>
            </div>

            {/* AI 추천 모의고사 */}
            <div className="bg-black bg-opacity-90 rounded-3xl shadow-2xl p-8 border-2 border-purple-900">
              <div className="flex items-center space-x-2 mb-6">
                <span className="text-xl font-bold text-purple-400">🤖 AI 추천 모의고사 - Dark Recommendations</span>
              </div>
              
              <div className="space-y-4">
                {userData.recommendations.map((rec, index) => (
                  <div key={index} className="p-4 bg-gradient-to-r from-purple-900/50 to-red-900/50 rounded-2xl border border-purple-800">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="font-semibold text-purple-300 mb-1">{rec.title}</div>
                        <div className="text-sm text-gray-400 mb-2">{rec.desc}</div>
                        <span className="inline-block bg-purple-900 bg-opacity-50 text-purple-300 px-3 py-1 rounded-full text-xs font-medium border border-purple-700">
                          {rec.level}
                        </span>
                      </div>
                    </div>
                    <button className="w-full bg-gradient-to-r from-purple-800 to-red-800 text-white py-2 rounded-xl font-medium hover:from-purple-700 hover:to-red-700 transition-all duration-300 mt-3 transform hover:scale-105 shadow-lg">
                      💀 시작하기
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 이번 주 우수 달성 - 무서운 버전 */}
          <div className="bg-gradient-to-r from-red-900 to-black rounded-3xl shadow-2xl p-8 text-white border-2 border-red-800 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-red-900/30 to-black/30"></div>
            <div className="flex items-center space-x-4 relative z-10">
              <div className="w-16 h-16 bg-black/40 rounded-2xl flex items-center justify-center border border-red-700">
                <span className="text-3xl animate-pulse">👑</span>
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-1 text-red-300">이번 주 우수 달성!</h3>
                <p className="text-red-200 mb-1">어둠의 클래스에 오셨습니다...</p>
                <div className="flex items-center space-x-4 text-sm">
                  <span>📊 학습 목표까지</span>
                  <span className="font-bold text-red-300">3회 남음</span>
                </div>
              </div>
            </div>
            {/* 무서운 장식 */}
            <div className="absolute top-4 right-4 text-red-600 opacity-50 animate-pulse">💀</div>
            <div className="absolute bottom-4 right-8 text-red-600 opacity-30 animate-pulse">🕷️</div>
          </div>

        </div>
      </div>

      {/* 🖼️ 이미지 확대/축소 모달 - 무서운 스타일 */}
      {isImageModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-95 flex items-center justify-center z-50">
          <div className="relative w-full h-full flex items-center justify-center">
            {/* 모달 헤더 */}
            <div className="absolute top-4 left-4 z-10">
              <div className="flex items-center space-x-4">
                <h3 className="text-red-400 text-lg font-bold">💀 {modalImageAlt}</h3>
                <div className="text-red-300 text-sm">
                  확대/축소: {Math.round(imageScale * 100)}%
                </div>
              </div>
            </div>

            {/* 모달 컨트롤 버튼 */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-10">
              <div className="flex items-center space-x-2 bg-black bg-opacity-80 rounded-full px-4 py-2 border border-red-900">
                <button
                  onClick={handleZoomOut}
                  className="text-red-400 hover:text-red-300 transition-colors duration-200 p-2"
                  title="축소"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM13 10H7" />
                  </svg>
                </button>
                <button
                  onClick={handleResetZoom}
                  className="text-red-400 hover:text-red-300 transition-colors duration-200 p-2"
                  title="원본 크기"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
                  </svg>
                </button>
                <button
                  onClick={handleZoomIn}
                  className="text-red-400 hover:text-red-300 transition-colors duration-200 p-2"
                  title="확대"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                  </svg>
                </button>
              </div>
            </div>

            {/* 이미지 컨테이너 */}
            <div 
              className="w-full h-full flex items-center justify-center overflow-hidden"
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              onWheel={handleWheel}
              style={{ cursor: imageScale > 1 ? (isDragging ? 'grabbing' : 'grab') : 'default' }}
            >
              <img
                src={modalImageUrl}
                alt={modalImageAlt}
                className="max-w-none select-none filter contrast-125 brightness-75 sepia-[0.3] hue-rotate-[315deg]"
                style={{
                  transform: `scale(${imageScale}) translate(${imagePosition.x / imageScale}px, ${imagePosition.y / imageScale}px)`,
                  transition: isDragging ? 'none' : 'transform 0.2s ease-out'
                }}
                onError={(e) => {
                  e.target.src = '/image.png';
                  console.warn('모달 이미지 로딩 실패:', modalImageUrl);
                }}
              />
            </div>

            {/* 배경 클릭 시 모달 닫기 */}
            <div 
              className="absolute inset-0 -z-10"
              onClick={closeImageModal}
            />

            {/* ESC 키 안내 버튼 */}
            <div className="absolute top-4 right-20">
              <div className="bg-gradient-to-r from-red-800 to-red-600 text-white px-4 py-2 rounded-full text-sm font-medium shadow-lg border border-red-700 backdrop-blur-sm hover:from-red-700 hover:to-red-500 transition-all duration-200 cursor-pointer transform hover:scale-105"
                   onClick={closeImageModal}
                   title="모달 닫기">
                <div className="flex items-center space-x-2">
                  <kbd className="bg-black/30 px-2 py-1 rounded text-xs font-mono border border-red-900">ESC</kbd>
                  <span>💀 닫기</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}