// ============================================
// 🌊 Deep Ocean MyPageModal.jsx - 심해 룸 모달
// ============================================
// 📱 주요 기능:
// - 바다 정보 표시
// - 심해 프로필 편집
// - 학습 통계 정보 표시
// - 반응형 심해 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { userRoles, memberTiers, pointsSystem, calculateUserTier, saveUserToStorage } from '../data/dummyUsers';

export default function MyPageModal({ isOpen, onClose, currentUser, onUserUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    school: ''
  });

  // 모달이 열릴 때 바다 정보로 초기화
  useEffect(() => {
    if (currentUser) {
      setFormData({
        name: currentUser.name || '',
        phone: currentUser.phone || '',
        address: currentUser.address || '',
        school: currentUser.school || ''
      });
    }
  }, [currentUser]);

  // 모달이 열릴 때 body 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.keyCode === 27) onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    // 원래 심해 데이터로 복원
    setFormData({
      name: currentUser.name || '',
      phone: currentUser.phone || '',
      address: currentUser.address || '',
      school: currentUser.school || ''
    });
  };

  const handleSave = () => {
    const updatedUser = {
      ...currentUser,
      ...formData
    };
    
    // 심해 스토리지 업데이트
    saveUserToStorage(updatedUser);
    
    // 부모 컴포넌트에 심해 업데이트 알림
    onUserUpdate(updatedUser);
    
    setIsEditing(false);
    alert('심해 정보가 성공적으로 업데이트되었습니다!');
  };

  if (!isOpen || !currentUser) return null;

  const roleInfo = userRoles[currentUser.role] || userRoles.student;
  const joinDate = new Date(currentUser.joinDate).toLocaleDateString('ko-KR');
  
  // 심해 회원등급 정보
  const currentTier = currentUser.role === 'admin' ? 'admin' : (currentUser.tier || calculateUserTier(currentUser.points || 0));
  const tierInfo = memberTiers[currentTier];
  const nextTier = currentTier === 'individual' ? 'pro' : 
                   currentTier === 'pro' ? 'proplus' : 
                   currentTier === 'proplus' ? 'ultra' : null;
  const nextTierInfo = nextTier ? memberTiers[nextTier] : null;
  
  // 심해 포인트 및 등급 진행도
  const currentPoints = currentUser.points || 0;
  const pointsToNext = nextTierInfo ? nextTierInfo.pointsRequired - currentPoints : 0;
  const progressPercentage = nextTierInfo ? 
    ((currentPoints - tierInfo.pointsRequired) / (nextTierInfo.pointsRequired - tierInfo.pointsRequired)) * 100 : 100;

  // 일일 채점 업로드 사용량 체크
  const today = new Date().toDateString();
  const hasResetToday = currentUser.dailyUploadsReset === today;
  const dailyUploadsUsed = hasResetToday ? (currentUser.dailyUploadsUsed || 0) : 0;
  const dailyUploadsRemaining = Math.max(0, tierInfo.dailyUploads - dailyUploadsUsed);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* 심해 배경 오버레이 */}
      <div 
        className="fixed inset-0 bg-indigo-500/20 backdrop-blur-sm transition-opacity duration-300"
        onClick={onClose}
      />
      
      {/* 심해 모달 컨테이너 */}
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="relative bg-slate-800/40 backdrop-blur-md rounded-2xl shadow-2xl shadow-indigo-500/50 w-full max-w-2xl transform transition-all duration-300 modal-enter border border-slate-700/50">
          {/* 심해 배경 효과 */}
          <div className="absolute inset-0 bg-gradient-to-br from-slate-800/60 via-indigo-900/40 to-blue-900/60 rounded-2xl"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(30,64,175,0.15)_0%,rgba(15,23,42,0.8)_50%,rgba(30,58,138,0.1)_100%)] rounded-2xl"></div>
          
          {/* 움직이는 바다 파티클 */}
          <div className="absolute inset-0 overflow-hidden rounded-2xl pointer-events-none">
            <div className="absolute top-8 left-12 w-1 h-1 bg-blue-400/40 rounded-full animate-pulse shadow-sm"></div>
            <div className="absolute top-16 right-16 w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse delay-700 shadow-sm"></div>
            <div className="absolute bottom-12 left-16 w-1 h-1 bg-indigo-400/30 rounded-full animate-pulse delay-1000 shadow-sm"></div>
            <div className="absolute top-1/2 right-12 w-1 h-1 bg-teal-500/40 rounded-full animate-pulse delay-500 shadow-sm"></div>
          </div>

          {/* 심해 닫기 버튼 */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-cyan-300 hover:text-cyan-100 transition-colors duration-200 z-10 bg-slate-800/50 rounded-full p-2 backdrop-blur-sm border border-slate-700/50"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          {/* 심해 헤더 */}
          <div className="px-8 pt-8 pb-6 relative z-10">
            <div className="text-center mb-6">
              <div className="w-20 h-20 rounded-full overflow-hidden mx-auto mb-4 shadow-lg shadow-indigo-500/50 ring-4 ring-slate-700/50">
                <img 
                  src={currentUser.avatar} 
                  alt={currentUser.name}
                  className="w-full h-full object-cover brightness-110 saturate-150"
                />
              </div>
              <h2 className="text-2xl font-bold text-cyan-300 mb-2 drop-shadow-lg">{currentUser.name}</h2>
              <div className="flex items-center justify-center space-x-2 mb-4">
                <span className="bg-slate-800/80 text-cyan-300 px-3 py-1 rounded-full text-sm font-medium border border-slate-600/50">
                  {roleInfo.name === '관리자' ? '🌊 심해 마스터' :
                   roleInfo.name === '선생님' ? '🐙 교육 전문가' :
                   roleInfo.name === '학생' ? '🐠 바다 탐험가' :
                   roleInfo.name === '학부모' ? '🦈 보호자' : '🌊 심해 멤버'}
                </span>
                <span className="text-cyan-200/80 text-sm">가입일: {joinDate}</span>
              </div>
            </div>

            {/* 심해 회원등급 및 포인트 정보 */}
            <div className="bg-slate-800/50 backdrop-blur-md border border-slate-700/50 rounded-2xl p-6 mb-6 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <span className="text-3xl drop-shadow-lg">{tierInfo.icon}</span>
                  <div>
                    <h3 className="text-xl font-bold text-cyan-300 drop-shadow-sm">{tierInfo.name}</h3>
                    <p className="text-sm text-cyan-200/80">심해 등급</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-cyan-200 drop-shadow-sm">{currentPoints.toLocaleString()}</div>
                  <div className="text-sm text-cyan-200/80">바다 포인트</div>
                </div>
              </div>

              {/* 심해 등급 진행도 */}
              {nextTierInfo && (
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-cyan-200/80">다음 등급까지</span>
                    <span className="font-medium text-cyan-300">{pointsToNext.toLocaleString()}P 남음</span>
                  </div>
                  <div className="w-full bg-slate-700/60 rounded-full h-2 border border-slate-600/50">
                    <div 
                      className="bg-gradient-to-r from-indigo-600 to-cyan-600 h-2 rounded-full transition-all duration-300 shadow-sm"
                      style={{ width: `${Math.min(100, Math.max(0, progressPercentage))}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-xs mt-1 text-cyan-200/70">
                    <span>{tierInfo.name}</span>
                    <span>{nextTierInfo.name} {nextTierInfo.icon}</span>
                  </div>
                </div>
              )}

              {/* 일일 채점 업로드 제한 */}
              <div className="flex items-center justify-between text-sm">
                <span className="text-cyan-200/80">일일 채점 업로드</span>
                <span className={`font-medium ${dailyUploadsRemaining > 0 ? 'text-cyan-300' : 'text-red-400'}`}>
                  {dailyUploadsRemaining > 999 ? '무제한' : `${dailyUploadsRemaining}회 남음`}
                </span>
              </div>
            </div>
          </div>

          {/* 심해 학습 통계 대시보드 */}
          <div className="px-8 pb-6 relative z-10">
            <h3 className="text-lg font-semibold text-cyan-300 mb-4 drop-shadow-sm">📊 심해 통계</h3>
            
            {/* 주요 학습 지표 */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-4 text-center border border-slate-700/50">
                <div className="text-2xl font-bold text-cyan-200 drop-shadow-sm">{currentUser.loginCount || 0}</div>
                <div className="text-sm text-cyan-200/80">로그인 횟수</div>
              </div>
              <div className="bg-indigo-900/60 backdrop-blur-sm rounded-xl p-4 text-center border border-indigo-600/50">
                <div className="text-2xl font-bold text-indigo-300 drop-shadow-sm">
                  {currentUser.examHistory?.totalExams || 0}
                </div>
                <div className="text-sm text-cyan-200/80">채점 완료</div>
              </div>
              <div className="bg-blue-900/60 backdrop-blur-sm rounded-xl p-4 text-center border border-blue-600/50">
                <div className="text-2xl font-bold text-blue-300 drop-shadow-sm">
                  {currentUser.examHistory?.averageScore || 0}점
                </div>
                <div className="text-sm text-cyan-200/80">평균 점수</div>
              </div>
              <div className="bg-cyan-900/60 backdrop-blur-sm rounded-xl p-4 text-center border border-cyan-600/50">
                <div className="text-2xl font-bold text-cyan-300 drop-shadow-sm">
                  {currentUser.examHistory?.recentScores?.length ? 
                    Math.max(...currentUser.examHistory.recentScores) : 0}점
                </div>
                <div className="text-sm text-cyan-200/80">최고 점수</div>
              </div>
            </div>

            {/* 과목별 심해 성과 */}
            {currentUser.examHistory?.subjectScores && (
              <div className="bg-slate-800/50 backdrop-blur-md rounded-xl p-6 mb-6 border border-slate-700/50 shadow-lg">
                <h4 className="font-semibold text-cyan-300 mb-4 drop-shadow-sm">📚 과목별 학습 성과</h4>
                <div className="space-y-4">
                  {Object.entries(currentUser.examHistory.subjectScores).map(([subject, data]) => {
                    const subjectName = subject === 'korean' ? '🌊 심해 국어' : 
                                       subject === 'english' ? '🐠 바다 영어' : '🐙 심해 수학';
                    const percentage = data.average || 0;
                    
                    return (
                      <div key={subject}>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="font-medium text-cyan-300">{subjectName}</span>
                          <span className="text-cyan-200/80">{data.total}회 채점 • 평균 {data.average}점</span>
                        </div>
                        <div className="w-full bg-slate-700/60 rounded-full h-2 border border-slate-600/50">
                          <div 
                            className="bg-gradient-to-r from-indigo-600 to-cyan-600 h-2 rounded-full transition-all duration-500 shadow-sm"
                            style={{ width: `${percentage}%` }}
                          ></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 최근 학습 성적 추이 */}
            {currentUser.examHistory?.recentScores?.length > 0 && (
              <div className="bg-slate-800/50 backdrop-blur-md border border-slate-700/50 rounded-xl p-6 shadow-lg">
                <h4 className="font-semibold text-cyan-300 mb-4 drop-shadow-sm">📈 최근 성적 추이</h4>
                <div className="flex items-end justify-between h-32 space-x-2">
                  {currentUser.examHistory.recentScores.map((score, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center">
                      <div 
                        className="w-full bg-gradient-to-t from-indigo-600 to-cyan-600 rounded-t transition-all duration-500 hover:from-indigo-500 hover:to-cyan-500 shadow-sm"
                        style={{ height: `${(score / 100) * 100}%` }}
                      ></div>
                      <div className="text-xs font-medium text-cyan-300 mt-2">{score}점</div>
                      <div className="text-xs text-cyan-200/70">{index + 1}회</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 심해 회원등급 혜택 */}
          <div className="px-8 pb-6 relative z-10">
            <h3 className="text-lg font-semibold text-cyan-300 mb-4 drop-shadow-sm">🎁 {tierInfo.name} 등급 혜택</h3>
            <div className="bg-slate-800/50 backdrop-blur-md border border-slate-700/50 rounded-xl p-6 shadow-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium text-cyan-300 mb-3">현재 심해 혜택</h4>
                  <ul className="space-y-2">
                    {tierInfo.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <svg className="w-4 h-4 text-cyan-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span className="text-cyan-300">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                {nextTierInfo && (
                  <div>
                    <h4 className="font-medium text-cyan-300 mb-3">
                      {nextTierInfo.name} 등급 업그레이드시 추가 혜택
                    </h4>
                    <ul className="space-y-2">
                      {nextTierInfo.features.filter(f => !tierInfo.features.includes(f)).map((feature, index) => (
                        <li key={index} className="flex items-center text-sm text-cyan-200/80">
                          <svg className="w-4 h-4 text-blue-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                          </svg>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <div className="mt-4 p-3 bg-indigo-900/60 rounded-lg border border-indigo-600/50">
                      <p className="text-sm text-cyan-300">
                        <span className="font-medium">{pointsToNext.toLocaleString()}바다 포인트</span> 더 모으면 업그레이드됩니다!
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 바다 정보 */}
          <div className="px-8 pb-8 relative z-10">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-cyan-300 drop-shadow-sm">👤 개인 정보</h3>
              {!isEditing ? (
                <button
                  onClick={handleEdit}
                  className="text-cyan-300 hover:text-cyan-100 font-medium text-sm flex items-center transition-colors duration-200"
                >
                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                  편집
                </button>
              ) : (
                <div className="flex space-x-2">
                  <button
                    onClick={handleCancel}
                    className="text-cyan-300 hover:text-cyan-100 font-medium text-sm px-3 py-1 rounded border border-slate-600/50 bg-slate-800/50 transition-colors duration-200"
                  >
                    취소
                  </button>
                  <button
                    onClick={handleSave}
                    className="bg-indigo-600 text-cyan-100 font-medium text-sm px-3 py-1 rounded hover:bg-indigo-500 transition-colors duration-200 shadow-sm"
                  >
                    저장
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 이메일 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-cyan-300 mb-2">
                  이메일
                </label>
                <input
                  type="email"
                  value={currentUser.email}
                  disabled
                  className="w-full px-4 py-3 border border-slate-600/50 rounded-xl bg-slate-800/60 text-cyan-200/80 backdrop-blur-sm"
                />
              </div>

              {/* 이름 */}
              <div>
                <label className="block text-sm font-semibold text-cyan-300 mb-2">
                  이름
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-cyan-400/50 focus:ring-2 focus:ring-cyan-500 focus:border-transparent bg-slate-800/80 text-cyan-100 placeholder-cyan-300/50' 
                      : 'border-slate-600/50 bg-slate-800/60 text-cyan-200/80'
                  }`}
                />
              </div>

              {/* 전화번호 */}
              <div>
                <label className="block text-sm font-semibold text-cyan-300 mb-2">
                  전화번호
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-cyan-400/50 focus:ring-2 focus:ring-cyan-500 focus:border-transparent bg-slate-800/80 text-cyan-100 placeholder-cyan-300/50' 
                      : 'border-slate-600/50 bg-slate-800/60 text-cyan-200/80'
                  }`}
                />
              </div>

              {/* 학교 */}
              <div>
                <label className="block text-sm font-semibold text-cyan-300 mb-2">
                  학교
                </label>
                <input
                  type="text"
                  name="school"
                  value={formData.school}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-cyan-400/50 focus:ring-2 focus:ring-cyan-500 focus:border-transparent bg-slate-800/80 text-cyan-100 placeholder-cyan-300/50' 
                      : 'border-slate-600/50 bg-slate-800/60 text-cyan-200/80'
                  }`}
                />
              </div>

              {/* 주소 */}
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-cyan-300 mb-2">
                  주소
                </label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-3 border rounded-xl transition-all duration-200 backdrop-blur-sm ${
                    isEditing 
                      ? 'border-cyan-400/50 focus:ring-2 focus:ring-cyan-500 focus:border-transparent bg-slate-800/80 text-cyan-100 placeholder-cyan-300/50' 
                      : 'border-slate-600/50 bg-slate-800/60 text-cyan-200/80'
                  }`}
                />
              </div>

              {/* 생년월일 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-cyan-300 mb-2">
                  생년월일
                </label>
                <input
                  type="date"
                  value={currentUser.birthDate}
                  disabled
                  className="w-full px-4 py-3 border border-slate-600/50 rounded-xl bg-slate-800/60 text-cyan-200/80 backdrop-blur-sm"
                />
              </div>

              {/* 역할 (읽기 전용) */}
              <div>
                <label className="block text-sm font-semibold text-cyan-300 mb-2">
                  역할
                </label>
                <input
                  type="text"
                  value={roleInfo.name === '관리자' ? '🌊 심해 마스터' :
                         roleInfo.name === '선생님' ? '🐙 교육 전문가' :
                         roleInfo.name === '학생' ? '🐠 바다 탐험가' :
                         roleInfo.name === '학부모' ? '🦈 보호자' : '🌊 심해 멤버'}
                  disabled
                  className="w-full px-4 py-3 border border-slate-600/50 rounded-xl bg-slate-800/60 text-cyan-200/80 backdrop-blur-sm"
                />
              </div>
            </div>
          </div>

          {/* 심해 테두리 효과 */}
          <div className="absolute inset-0 rounded-2xl border border-cyan-400/30 pointer-events-none"></div>
        </div>
      </div>
    </div>
  );
}