// ============================================
// 💀 Dark Horror Hero.jsx - 어둠 속의 영웅 섹션
// ============================================
import React, { useLayoutEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function Hero({ onNext }) {
  const heroRef = useRef(null);
  const titleRef = useRef(null);
  const subtitleRef = useRef(null);
  const buttonsRef = useRef(null);
  const bgRef = useRef(null);
  const particlesRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 지옥의 패럴랙스 효과
      gsap.to(bgRef.current, {
        yPercent: 50,
        ease: "none",
        scrollTrigger: {
          trigger: heroRef.current,
          start: "top bottom",
          end: "bottom top",
          scrub: true
        }
      });

      // 어둠의 텍스트 애니메이션
      const tl = gsap.timeline();
      
      tl.fromTo(titleRef.current, 
        { 
          y: 150, 
          opacity: 0, 
          scale: 0.6,
          rotationX: -120,
          filter: "blur(20px)"
        },
        { 
          y: 0, 
          opacity: 1, 
          scale: 1,
          rotationX: 0,
          filter: "blur(0px)",
          duration: 1.8, 
          ease: "power4.out" 
        }
      )
      .fromTo(subtitleRef.current,
        { y: 80, opacity: 0, filter: "blur(10px)" },
        { y: 0, opacity: 1, filter: "blur(0px)", duration: 1.2, ease: "power3.out" },
        "-=0.8"
      )
      .fromTo(buttonsRef.current,
        { y: 60, opacity: 0, scale: 0.8, rotationY: 90 },
        { y: 0, opacity: 1, scale: 1, rotationY: 0, duration: 1.0, ease: "back.out(2)" },
        "-=0.6"
      );

      // 악령 파티클 애니메이션
      particlesRef.current.forEach((particle, index) => {
        if (particle) {
          gsap.to(particle, {
            y: "random(-40, 40)",
            x: "random(-40, 40)",
            rotation: "random(-360, 360)",
            scale: "random(0.5, 1.5)",
            duration: "random(3, 6)",
            repeat: -1,
            yoyo: true,
            ease: "sine.inOut",
            delay: index * 0.2
          });
        }
      });

    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={heroRef}
      className="relative min-h-screen bg-gradient-to-br from-black via-gray-900 to-red-900 overflow-hidden flex items-center"
    >
      {/* 지옥의 배경 요소들 */}
      <div ref={bgRef} className="absolute inset-0 overflow-hidden">
        {/* 어둠의 그라데이션 블러 */}
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-br from-red-800/30 to-black/50 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-br from-purple-900/30 to-red-800/40 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-br from-gray-800/20 to-black/40 rounded-full blur-3xl animate-pulse delay-500"></div>
        
        {/* 어둠의 추가 레이어 */}
        <div className="absolute inset-0 bg-black/60"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_20%,black_80%)]"></div>
        
        {/* 떠다니는 악령 파티클들 */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            ref={el => particlesRef.current[i] = el}
            className={`absolute w-6 h-6 bg-gradient-to-br from-red-600 to-black rounded-full opacity-30 blur-sm shadow-lg shadow-red-500/50`}
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
          ></div>
        ))}

        {/* 추가 어둠 효과들 */}
        {[...Array(6)].map((_, i) => (
          <div
            key={`shadow-${i}`}
            className={`absolute w-8 h-8 bg-gray-900/40 rounded-full blur-lg animate-pulse`}
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.5}s`
            }}
          ></div>
        ))}
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center min-h-screen py-20">
          {/* 어둠의 텍스트 콘텐츠 */}
          <div className="flex-1 lg:pr-12 text-center lg:text-left">
            {/* 지옥의 배지 */}
            <div 
              data-aos="fade-down" 
              data-aos-delay="100"
              className="inline-flex items-center space-x-3 bg-gradient-to-r from-red-900/50 to-black/70 border border-red-800/50 text-red-400 px-6 py-3 rounded-full text-sm font-semibold mb-8 shadow-lg shadow-red-500/30 hover:shadow-xl hover:shadow-red-500/50 transition-all duration-300 hover:scale-105 backdrop-blur-sm"
            >
              <div className="relative">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <div className="absolute inset-0 w-2 h-2 bg-red-500 rounded-full animate-ping opacity-75"></div>
              </div>
              <span>👹 AI 악마 심판 시스템</span>
              <span className="bg-gradient-to-r from-red-600 to-black text-red-300 px-2 py-1 rounded-full text-xs font-bold animate-pulse border border-red-700">
                CURSED
              </span>
            </div>
            
            {/* 어둠의 메인 타이틀 */}
            <h1 
              ref={titleRef}
              className="text-5xl md:text-6xl lg:text-7xl font-black leading-tight mb-6 drop-shadow-2xl"
            >
              <span className="bg-gradient-to-r from-red-600 via-red-500 to-red-700 bg-clip-text text-transparent drop-shadow-2xl">
                AI 악마의
              </span>
              <br />
              <span className="text-red-300 drop-shadow-lg">
                무자비한 심판,
              </span>
              <br />
              <span className="bg-gradient-to-r from-gray-400 to-red-600 bg-clip-text text-transparent">
                지옥 같은 정확성
              </span>
            </h1>
            
            {/* 어둠의 서브타이틀 */}
            <p 
              ref={subtitleRef}
              className="text-xl md:text-2xl text-gray-300 mb-10 leading-relaxed max-w-3xl mx-auto lg:mx-0 drop-shadow-lg"
            >
              <span className="font-semibold text-red-400">YOLO8 악마의 눈</span>, 
              <span className="font-semibold text-purple-400"> OCR 영혼 추출</span>, 
              <span className="font-semibold text-gray-400"> GPT 지옥 해설</span>이 
              결합된 차세대 악마 심판 솔루션
            </p>

            {/* 지옥의 버튼들 */}
            <div 
              ref={buttonsRef}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12"
            >
              <button 
                onClick={onNext}
                className="group bg-gradient-to-r from-red-800 to-black text-red-300 px-8 py-4 rounded-2xl font-bold text-lg shadow-xl shadow-red-500/50 hover:shadow-2xl hover:shadow-red-500/70 transition-all duration-300 hover:scale-105 hover:from-red-700 hover:to-red-900 relative overflow-hidden border-2 border-red-700 hover:border-red-500"
              >
                <span className="relative z-10 flex items-center justify-center">
                  🔥 지옥문 열기
                  <svg className="ml-2 w-6 h-6 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-red-400/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
              </button>
            </div>

            {/* 어둠의 통계 */}
            <div 
              data-aos="fade-up" 
              data-aos-delay="400"
              className="grid grid-cols-3 gap-8 pt-8 border-t border-red-900/50"
            >
              <div className="text-center group bg-black/40 p-4 rounded-lg border border-red-900/30">
                <div className="text-3xl font-black bg-gradient-to-r from-red-500 to-red-700 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                  99.9%
                </div>
                <div className="text-sm text-red-400 font-medium">악마의 정확도</div>
              </div>
              <div className="text-center group bg-black/40 p-4 rounded-lg border border-red-900/30">
                <div className="text-3xl font-black bg-gradient-to-r from-red-600 to-gray-500 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                  6.66초
                </div>
                <div className="text-sm text-red-400 font-medium">지옥 처리시간</div>
              </div>
              <div className="text-center group bg-black/40 p-4 rounded-lg border border-red-900/30">
                <div className="text-3xl font-black bg-gradient-to-r from-gray-500 to-red-600 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                  666+
                </div>
                <div className="text-sm text-red-400 font-medium">저주받은 시험지</div>
              </div>
            </div>
          </div>

          {/* 어둠의 오른쪽 일러스트레이션 */}
          <div className="flex-1 lg:pl-12 mt-12 lg:mt-0">
            <div 
              data-aos="fade-left" 
              data-aos-delay="200"
              className="relative"
            >
              {/* 지옥의 메인 카드 */}
              <div className="bg-gradient-to-br from-gray-900 to-black p-8 rounded-3xl shadow-2xl shadow-red-500/30 transform rotate-3 hover:rotate-0 transition-all duration-700 hover:scale-105 border border-red-800/50 relative overflow-hidden">
                {/* 카드 내부 어둠 글로우 */}
                <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 to-black/80 rounded-3xl"></div>
                
                <div className="relative z-10">
                  {/* 지옥의 브라우저 헤더 */}
                  <div className="flex items-center space-x-2 mb-6">
                    <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                    <div className="w-3 h-3 bg-gray-600 rounded-full animate-pulse delay-100"></div>
                    <div className="w-3 h-3 bg-red-700 rounded-full animate-pulse delay-200"></div>
                    <div className="flex-1 bg-gray-800 h-6 rounded-full ml-4 border border-red-900/50"></div>
                  </div>
                  
                  {/* 어둠의 콘텐츠 */}
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="h-4 bg-gradient-to-r from-red-800 to-red-900 rounded-lg w-3/4 animate-pulse shadow-lg"></div>
                      <div className="h-4 bg-gradient-to-r from-gray-800 to-gray-900 rounded-lg w-1/2 animate-pulse shadow-lg delay-100"></div>
                      <div className="h-4 bg-gradient-to-r from-red-700 to-black rounded-lg w-2/3 animate-pulse shadow-lg delay-200"></div>
                    </div>
                    
                    {/* 지옥의 결과 카드 */}
                    <div className="bg-gradient-to-br from-red-900/50 to-black/80 p-6 rounded-2xl shadow-lg shadow-red-500/30 border border-red-800/50 backdrop-blur-sm">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-sm font-bold text-red-400 flex items-center">
                          <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 18.5c-.77.833.192 2.5 1.732 2.5z" />
                          </svg>
                          심판 완료
                        </span>
                        <span className="text-xs text-red-500">6.66초</span>
                      </div>
                      <div className="text-4xl font-black bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent drop-shadow-lg">
                        13점
                      </div>
                      <div className="text-sm text-red-400 mt-2">
                        20문제 중 3문제 정답 💀
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        "더 노력이 필요합니다..."
                      </div>
                    </div>
                  </div>
                </div>

                {/* 어둠의 추가 효과 */}
                <div className="absolute inset-0 bg-gradient-to-t from-red-900/20 to-transparent rounded-3xl"></div>
              </div>

              {/* 떠다니는 악마 요소들 */}
              <div className="absolute -top-6 -right-6 w-16 h-16 bg-gradient-to-br from-red-600 to-black rounded-2xl flex items-center justify-center shadow-xl shadow-red-500/50 animate-bounce border-2 border-red-700">
                <span className="text-red-300 text-2xl">💀</span>
              </div>
              
              <div className="absolute -bottom-6 -left-6 w-16 h-16 bg-gradient-to-br from-gray-700 to-red-800 rounded-2xl flex items-center justify-center shadow-xl shadow-red-500/50 animate-pulse border-2 border-red-800">
                <span className="text-red-400 text-2xl">🔥</span>
              </div>

              {/* 추가 어둠 장식 */}
              <div className="absolute top-1/2 -left-8 w-12 h-12 bg-gradient-to-br from-red-800 to-black rounded-full flex items-center justify-center shadow-lg shadow-red-500/40 animate-pulse delay-300">
                <span className="text-red-400 text-lg">👁️</span>
              </div>

              <div className="absolute top-1/4 -right-8 w-12 h-12 bg-gradient-to-br from-black to-red-900 rounded-full flex items-center justify-center shadow-lg shadow-red-500/40 animate-pulse delay-700">
                <span className="text-red-400 text-lg">⚡</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 어둠의 안개 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent"></div>
    </section>
  );
}