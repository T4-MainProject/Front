// ============================================
// ✨ 간소화된 Angelic Light Footer.jsx - 희망의 발끝
// ============================================
import React from 'react';

export default function SimpleFooter() {
  return (
    <footer className="bg-gradient-to-b from-white via-sky-50 to-blue-100 text-blue-700 py-12 relative overflow-hidden">
      {/* 천국의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-t from-white/80 via-sky-50/60 to-blue-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,rgba(255,255,255,0.8)_100%)]"></div>
      
      {/* 움직이는 빛의 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-4 left-1/4 w-2 h-2 bg-blue-400/30 rounded-full animate-pulse"></div>
        <div className="absolute top-8 right-1/3 w-1 h-1 bg-sky-400/40 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-6 left-1/2 w-1 h-1 bg-indigo-400/30 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-blue-500/40 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-sky-300/30 rounded-full animate-pulse delay-1500"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between">
          {/* 천사의 로고 */}
          <div className="flex items-center space-x-3 mb-6 md:mb-0">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-sky-500 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/50 border border-blue-300/50">
              <span className="text-white font-bold text-lg drop-shadow-lg">👼</span>
            </div>
            <div>
              <h3 className="text-xl font-bold text-blue-700 drop-shadow-lg">AngelCheck</h3>
              <p className="text-blue-600/80 text-sm drop-shadow-sm">👼 AI 천사 축복 시스템</p>
            </div>
          </div>
          
          {/* 천사의 간단한 정보 */}
          <div className="text-center md:text-right">
            <p className="text-blue-600/80 text-sm mb-2 drop-shadow-sm">
              © 2025 AngelCheck. All hopes reserved.
            </p>
            <div className="flex items-center justify-center md:justify-end space-x-4 text-xs text-blue-500/70">
              <span>천국 문의</span>
              <span>•</span>
              <span>heavensupport@angelcheck.co.kr</span>
            </div>
          </div>
        </div>
                
        {/* 천사의 기술 스택 */}
        <div className="mt-8 pt-8 border-t border-blue-300/50 text-center">
          <p className="text-blue-600/80 text-sm drop-shadow-sm">
            Powered by <span className="text-blue-600 font-semibold">👁️ YOLO8 천사의 눈</span> •
            <span className="text-sky-600 font-semibold"> 🔮 OCR 지혜 추출</span> •
            <span className="text-blue-600 font-semibold"> 👼 GPT 축복</span>
          </p>
        </div>

        {/* 추가 빛의 장식 */}
        <div className="mt-6 text-center">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-100/40 to-white/60 px-4 py-2 rounded-full border border-blue-300/50 shadow-lg shadow-blue-500/30">
            <span className="text-blue-600/80 text-xs">⚡ 천국 서버 상태:</span>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
              <span className="text-blue-600 text-xs font-semibold">운영중</span>
            </div>
          </div>
        </div>

        {/* 천사의 축복 메시지 */}
        <div className="mt-6 text-center">
          <p className="text-blue-500/60 text-xs italic drop-shadow-sm">
            "빛 속에서 태어나 희망을 품는 자들을 위한 축복 시스템"
          </p>
        </div>
      </div>

      {/* 하단 빛 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-white to-transparent pointer-events-none"></div>
      
      {/* 빛의 테두리 */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-blue-400/50 to-transparent"></div>
    </footer>
  );
}