// ============================================
// 🌊 Deep Ocean AppHeader.jsx - 깊은 바다 헤더
// ============================================
import React, { useState, useEffect } from 'react';

export default function AppHeader({ currentUser, onOpenLogin, onOpenSignup, onLogout, onOpenMyPage }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // 🌊 활성 버튼 상태 관리 (어떤 바다 문이 열려있는지)
  const [activeButton, setActiveButton] = useState(null); // 'login' | 'signup' | null
  
  // 🏖️ 버튼 클릭 상태 관리 (바다 클릭 애니메이션용)
  const [clickedButtons, setClickedButtons] = useState({
    login: false,
    signup: false,
    mypage: false
  });

  const handleLogin = () => {
    // 바다 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, login: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, login: false }));
    }, 200);
    
    // 바다 활성 버튼 설정
    setActiveButton('login');
    
    // 바다 로그인 문 열기
    if (onOpenLogin) {
      onOpenLogin();
    }
  };

  const handleSignup = () => {
    // 바다 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, signup: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, signup: false }));
    }, 200);
    
    // 바다 활성 버튼 설정
    setActiveButton('signup');
    
    // 심해 멤버십 가입 문서 열기
    if (onOpenSignup) {
      onOpenSignup();
    }
  };

  const handleLogout = () => {
    // 바다 로그아웃 확인
    if (window.confirm('🌊 정말 깊은 바다에서 로그아웃하시겠습니까?')) {
      setActiveButton(null); // 바다 활성 상태 초기화
      if (onLogout) {
        onLogout();
      }
    }
  };

  const handleMyPage = () => {
    // 바다 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, mypage: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, mypage: false }));
    }, 200);
    
    // 심해 룸 열기
    if (onOpenMyPage) {
      onOpenMyPage();
    }
  };

  // 바다 문이 닫힐 때 활성 상태 해제
  useEffect(() => {
    // 사용자 상태가 변경되면 바다 활성 버튼 초기화
    if (currentUser) {
      setActiveButton(null);
    }
  }, [currentUser]);

  // 심해 아바타 이미지 처리
  const getAvatarSrc = (avatar) => {
    if (!avatar) {
      return "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiMxRTQwQUYiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iI0ZGRkZGRiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iI0ZGRkZGRiIvPgo8L3N2Zz4K";
    }
    return avatar;
  };

  // 바다 역할 텍스트 변환
  const getRoleText = (role) => {
    switch(role) {
      case 'admin': return '🌊 심해 마스터';
      case 'teacher': return '🐙 교육 전문가';
      case 'student': return '🐠 바다 탐험가';
      case 'parent': return '🦈 보호자';
      default: return '🌊 심해 멤버';
    }
  };

  return (
    <header className="bg-slate-900/95 backdrop-blur-md shadow-2xl shadow-indigo-900/30 border-b border-slate-700/50 sticky top-0 z-50 relative overflow-hidden">
      {/* 심해 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 via-indigo-900/80 to-blue-900/90"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(30,64,175,0.15)_0%,rgba(15,23,42,0.8)_50%,rgba(30,58,138,0.1)_100%)]"></div>
      
      {/* 움직이는 심해 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-2 h-2 bg-blue-400/40 rounded-full animate-pulse shadow-lg shadow-blue-500/50"></div>
        <div className="absolute top-2 right-1/3 w-1 h-1 bg-indigo-400/30 rounded-full animate-pulse delay-500 shadow-lg shadow-indigo-500/50"></div>
        <div className="absolute bottom-1 left-1/2 w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse delay-1000 shadow-lg shadow-cyan-500/50"></div>
      </div>

      <div className="container mx-auto flex items-center justify-between py-4 px-4 lg:px-6 relative z-10">
        {/* 심해 로고 영역 */}
        <div className="flex items-center space-x-4">
          <div className="relative group">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 via-blue-600 to-cyan-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/50 group-hover:shadow-xl group-hover:shadow-indigo-500/70 transition-all duration-300 group-hover:scale-105 border-2 border-slate-700/50">
              <span className="text-cyan-100 font-bold text-xl drop-shadow-lg">🌊</span>
            </div>
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/40 via-blue-500/20 to-cyan-600/40 rounded-xl blur opacity-60 group-hover:opacity-80 transition-opacity duration-300"></div>
          </div>
          
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-300 via-blue-300 to-indigo-300 bg-clip-text text-transparent drop-shadow-lg">
              OceanCheck
            </h1>
            <p className="text-xs text-cyan-300/80 font-medium tracking-wide drop-shadow-sm">
              🌊 AI 심해 채점 시스템
            </p>
          </div>
        </div>

        {/* 심해 우측 상태 표시기 - 데스크탑 */}
        <div className="hidden lg:flex items-center space-x-6 flex-1 justify-end mr-8">
          <div className="flex items-center space-x-2 bg-slate-800/60 backdrop-blur-sm border border-slate-700/50 px-4 py-2 rounded-full">
            <div className="relative">
              <div className="w-3 h-3 bg-cyan-400 rounded-full animate-pulse"></div>
              <div className="absolute inset-0 w-3 h-3 bg-cyan-400 rounded-full animate-ping opacity-40"></div>
            </div>
            <span className="text-sm font-medium text-cyan-300">⭐ 심해 운영중</span>
          </div>
          
          <div className="text-sm text-cyan-300 bg-slate-800/60 backdrop-blur-sm px-3 py-1 rounded-full border border-slate-700/50">
            <span className="font-medium">바다 정확도</span>
            <span className="ml-2 text-cyan-200 font-bold">99.5%</span>
          </div>
        </div>

        {/* 심해 우측 버튼들 */}
        <div className="flex items-center space-x-4">
          {/* 심해 데스크탑 버튼들 */}
          <div className="hidden md:flex items-center space-x-3">
            {currentUser ? (
              // 사용자가 로그인된 상태
              <>
                {/* 사용자 정보 */}
                <div className="flex items-center space-x-3 text-sm">
                  <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-cyan-400/70 shadow-lg shadow-cyan-500/50">
                    <img 
                      src={getAvatarSrc(currentUser.avatar)} 
                      alt={currentUser.name || '심해 멤버'}
                      className="w-full h-full object-cover brightness-110 saturate-150"
                      onError={(e) => {
                        e.target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiMxRTQwQUYiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iI0ZGRkZGRiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iI0ZGRkZGRiIvPgo8L3N2Zz4K";
                      }}
                    />
                  </div>
                  <div className="text-cyan-300">
                    <span className="font-medium drop-shadow-sm">{currentUser.name || '심해 멤버'}</span>
                    <span className="ml-2 text-xs bg-slate-800/70 text-cyan-300 px-2 py-1 rounded-full border border-slate-700/50">
                      {getRoleText(currentUser.role)}
                    </span>
                  </div>
                </div>

                {/* 심해 룸 버튼 */}
                <button
                  onClick={handleMyPage}
                  className={`font-medium px-4 py-2 rounded-lg transition-all duration-200 relative group border border-slate-700/50 ${
                    clickedButtons.mypage 
                      ? 'text-cyan-100 bg-slate-800/80 transform scale-95 shadow-lg shadow-cyan-500/50' 
                      : 'text-cyan-300 hover:text-cyan-100 hover:bg-slate-800/60 hover:shadow-lg hover:shadow-cyan-500/40'
                  }`}
                >
                  🐙 마이 오션
                  <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-cyan-400 group-hover:w-full transition-all duration-300"></span>
                </button>
                
                {/* 로그아웃 버튼 */}
                <button
                  onClick={handleLogout}
                  className="bg-gradient-to-r from-indigo-600 to-blue-600 text-cyan-100 font-medium px-6 py-2 rounded-lg shadow-md shadow-indigo-500/50 hover:shadow-lg hover:shadow-indigo-500/70 transition-all duration-300 hover:scale-105 relative overflow-hidden group border-2 border-slate-700/50"
                >
                  <span className="relative z-10">🌊 로그아웃</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-white/10 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-500"></div>
                </button>
              </>
            ) : (
              // 사용자가 로그인되지 않은 상태
              <>
                <button
                  onClick={handleLogin}
                  className={`font-medium px-6 py-3 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                    activeButton === 'login'
                      ? 'bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 border-slate-700/50 text-cyan-100 shadow-lg shadow-indigo-500/50'
                      : clickedButtons.login 
                      ? 'bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 border-slate-700/50 text-cyan-100 transform scale-95 shadow-lg shadow-indigo-500/50'
                      : 'bg-slate-800/60 backdrop-blur-sm border-slate-700/50 text-cyan-300 hover:bg-gradient-to-r hover:from-indigo-600 hover:via-blue-600 hover:to-cyan-600 hover:border-slate-700/50 hover:text-cyan-100 hover:scale-105 hover:shadow-lg hover:shadow-indigo-500/50'
                  }`}
                >
                  {(activeButton === 'login' || clickedButtons.login) && (
                    <div className="absolute inset-0 bg-gradient-to-r from-white/10 via-white/5 to-white/10 animate-pulse"></div>
                  )}
                  <span className="relative z-10">🌊 심해 입장</span>
                </button>
                
                <button
                  onClick={handleSignup}
                  className={`font-medium px-6 py-3 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                    activeButton === 'signup'
                      ? 'bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 border-slate-700/50 text-cyan-100 shadow-lg shadow-indigo-500/50'
                      : clickedButtons.signup 
                      ? 'bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 border-slate-700/50 text-cyan-100 transform scale-95 shadow-lg shadow-indigo-500/50'
                      : 'bg-slate-800/60 backdrop-blur-sm border-slate-700/50 text-cyan-300 hover:bg-gradient-to-r hover:from-indigo-600 hover:via-blue-600 hover:to-cyan-600 hover:border-slate-700/50 hover:text-cyan-100 hover:scale-105 hover:shadow-lg hover:shadow-indigo-500/50'
                  }`}
                >
                  {(activeButton === 'signup' || clickedButtons.signup) && (
                    <div className="absolute inset-0 bg-gradient-to-r from-white/10 via-white/5 to-white/10 animate-pulse"></div>
                  )}
                  <span className="relative z-10">🐠 심해 멤버십</span>
                </button>
              </>
            )}
          </div>

          {/* 심해 모바일 메뉴 버튼 */}
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-slate-800/50 transition-colors duration-200 text-cyan-300 border border-slate-700/50 bg-slate-800/30 backdrop-blur-sm"
            aria-label="심해 메뉴 토글"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* 심해 모바일 메뉴 */}
      {isMenuOpen && (
        <div className="md:hidden bg-slate-800/40 backdrop-blur-md border-t border-slate-700/50 py-4 px-4 shadow-lg shadow-indigo-500/30">
          {/* 심해 모바일 상태 표시 */}
          <div className="flex items-center space-x-2 bg-slate-800/60 px-3 py-2 rounded-lg mb-4 border border-slate-700/50">
            <div className="relative">
              <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
              <div className="absolute inset-0 w-2 h-2 bg-cyan-400 rounded-full animate-ping opacity-30"></div>
            </div>
            <span className="text-sm text-cyan-300 font-medium">⭐ 심해 운영중</span>
            <span className="text-xs text-cyan-200 ml-auto">바다 정확도 99.5%</span>
          </div>
          
          {currentUser ? (
            // 사용자가 로그인된 상태 - 모바일
            <div className="space-y-4">
              {/* 사용자 정보 */}
              <div className="flex items-center space-x-3 bg-slate-800/60 backdrop-blur-sm px-4 py-3 rounded-lg border border-slate-700/50">
                <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-cyan-400/70 shadow-lg shadow-cyan-500/50">
                  <img 
                    src={getAvatarSrc(currentUser.avatar)} 
                    alt={currentUser.name || '심해 멤버'}
                    className="w-full h-full object-cover brightness-110 saturate-150"
                    onError={(e) => {
                      e.target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiMxRTQwQUYiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iI0ZGRkZGRiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iI0ZGRkZGRiIvPgo8L3N2Zz4K";
                    }}
                  />
                </div>
                <div>
                  <div className="font-medium text-cyan-300">{currentUser.name || '심해 멤버'}</div>
                  <div className="text-sm text-cyan-200">
                    {getRoleText(currentUser.role)}
                  </div>
                </div>
              </div>

              {/* 심해 모바일 버튼들 */}
              <div className="space-y-3">
                <button
                  onClick={handleMyPage}
                  className={`w-full text-left font-medium py-3 px-4 rounded-lg transition-all duration-200 border border-slate-700/50 ${
                    clickedButtons.mypage 
                      ? 'text-cyan-100 bg-slate-800/80 transform scale-95 shadow-lg shadow-cyan-500/50' 
                      : 'text-cyan-300 hover:text-cyan-100 hover:bg-slate-800/60 hover:shadow-lg hover:shadow-cyan-500/40'
                  }`}
                >
                  🐙 마이 오션
                </button>
                
                <button
                  onClick={handleLogout}
                  className="w-full bg-gradient-to-r from-indigo-600 to-blue-600 text-cyan-100 font-medium py-3 px-4 rounded-lg shadow-md shadow-indigo-500/50 hover:shadow-lg hover:shadow-indigo-500/70 transition-all duration-300 border-2 border-slate-700/50"
                >
                  🌊 로그아웃
                </button>
              </div>
            </div>
          ) : (
            // 사용자가 로그인되지 않은 상태 - 모바일
            <div className="space-y-3">
              <button
                onClick={handleLogin}
                className={`w-full font-medium py-3 px-4 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                  activeButton === 'login'
                    ? 'bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 border-slate-700/50 text-cyan-100 shadow-lg shadow-indigo-500/50'
                    : clickedButtons.login 
                    ? 'bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 border-slate-700/50 text-cyan-100 transform scale-95 shadow-lg shadow-indigo-500/50'
                    : 'bg-slate-800/60 backdrop-blur-sm border-slate-700/50 text-cyan-300 hover:bg-gradient-to-r hover:from-indigo-600 hover:via-blue-600 hover:to-cyan-600 hover:border-slate-700/50 hover:text-cyan-100 hover:shadow-lg hover:shadow-indigo-500/50'
                }`}
              >
                {(activeButton === 'login' || clickedButtons.login) && (
                  <div className="absolute inset-0 bg-gradient-to-r from-white/10 via-white/5 to-white/10 animate-pulse"></div>
                )}
                <span className="relative z-10">🌊 심해 입장</span>
              </button>
              
              <button
                onClick={handleSignup}
                className={`w-full font-medium py-3 px-4 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                  activeButton === 'signup'
                    ? 'bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 border-slate-700/50 text-cyan-100 shadow-lg shadow-indigo-500/50'
                    : clickedButtons.signup 
                    ? 'bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 border-slate-700/50 text-cyan-100 transform scale-95 shadow-lg shadow-indigo-500/50'
                    : 'bg-slate-800/60 backdrop-blur-sm border-slate-700/50 text-cyan-300 hover:bg-gradient-to-r hover:from-indigo-600 hover:via-blue-600 hover:to-cyan-600 hover:border-slate-700/50 hover:text-cyan-100 hover:shadow-lg hover:shadow-indigo-500/50'
                }`}
              >
                {(activeButton === 'signup' || clickedButtons.signup) && (
                  <div className="absolute inset-0 bg-gradient-to-r from-white/10 via-white/5 to-white/10 animate-pulse"></div>
                )}
                <span className="relative z-10">🐠 심해 멤버십</span>
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
}