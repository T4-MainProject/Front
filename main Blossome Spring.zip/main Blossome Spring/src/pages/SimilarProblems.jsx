import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function BlossomSimilarProblems() {
  const navigate = useNavigate();
  const location = useLocation();
  const [userAnswers, setUserAnswers] = useState({});
  const [showResults, setShowResults] = useState({});
  const [selectedProblem, setSelectedProblem] = useState(null);

  // 🌸 벚꽃 효과 상태
  const [petalFall, setPetalFall] = useState(false);
  const [blossomWave, setBlossomWave] = useState(false);
  const [sparkleEffect, setSparkleEffect] = useState(false);
  const [gentleBreeze, setGentleBreeze] = useState(false);

  // URL 파라미터에서 문제 ID 가져오기
  const problemId = location.state?.problemId || 1;
  const originalProblem = location.state?.originalProblem || {};

  // 🌸 뒤로가기
  const handleBackToNote = () => {
    navigate('/wrong-answer-note');
  };

  // 🌸 벚꽃 효과 트리거
  useEffect(() => {
    const petalInterval = setInterval(() => {
      setPetalFall(true);
      setTimeout(() => setPetalFall(false), 800);
    }, 9000 + Math.random() * 15000);

    const blossomInterval = setInterval(() => {
      setBlossomWave(true);
      setTimeout(() => setBlossomWave(false), 3000);
    }, 12000 + Math.random() * 20000);

    const sparkleInterval = setInterval(() => {
      setSparkleEffect(true);
      setTimeout(() => setSparkleEffect(false), 2000);
    }, 7000 + Math.random() * 13000);

    const breezeInterval = setInterval(() => {
      setGentleBreeze(true);
      setTimeout(() => setGentleBreeze(false), 4000);
    }, 20000 + Math.random() * 30000);

    return () => {
      clearInterval(petalInterval);
      clearInterval(blossomInterval);
      clearInterval(sparkleInterval);
      clearInterval(breezeInterval);
    };
  }, []);

  // 유사 기출문제 더미 데이터 (지문 포함) - 🌸 벚꽃 버전
  const similarProblems = {
    1: [
      {
        id: 101,
        year: '2023',
        exam: '수능',
        passage: `문화는 인간이 자연 환경에 적응하며 만들어낸 아름다운 창조물의 총체이다. 각 지역과 민족은 그들만의 독특한 환경과 역사적 경험을 바탕으로 고유한 문화를 형성해 왔다. 이러한 문화의 다양성은 인류의 소중한 자산이다.

오늘날 세계화의 물결 속에서 서로 다른 문화들이 만나고 있다. 이때 중요한 것은 한 문화가 다른 문화를 일방적으로 흡수하거나 동화시키는 것이 아니라, 서로의 가치를 인정하고 존중하며 조화롭게 공존하는 것이다. 문화의 획일화는 인류의 창조적 잠재력을 약화시킬 수 있기 때문이다.

따라서 우리는 문화의 다양성을 보호하고 증진시키기 위해 노력해야 한다. 이는 곧 인류 문명의 발전을 위한 필수 조건이기도 하다.`,
        question: '다음 글에서 필자가 강조하고자 하는 바는?',
        options: [
          '① 문화의 획일성이 세계화에 미치는 긍정적 영향',
          '② 전통 문화의 보존이 현대 사회에서 갖는 의미',
          '③ 문화의 다양성이 인류 발전에 갖는 중요성',
          '④ 현대 문명의 발전이 문화 변화에 미치는 영향'
        ],
        answer: 3,
        explanation: '글 전체에서 문화의 다양성이 인류의 소중한 자산이며, 인류 문명의 발전을 위한 필수 조건임을 강조하고 있습니다. 특히 마지막 문단에서 이를 명확히 드러내고 있습니다.'
      },
      {
        id: 102,
        year: '2022',
        exam: '6월 모의평가',
        passage: `현대 사회에서 문화 간 교류가 활발해지면서 새로운 형태의 문화 융합 현상이 나타나고 있다. 이는 단순히 서로 다른 문화 요소들이 섞이는 것을 넘어서, 완전히 새로운 문화적 가치와 형태를 창출하는 과정이다.

예를 들어, 한국의 K-pop은 서양의 대중음악과 동양의 전통적 감성이 만나 탄생한 독특한 문화 장르이다. 이처럼 문화 융합은 기존의 문화적 경계를 허물고 새로운 창조적 에너지를 발생시킨다.

중요한 것은 이러한 융합 과정에서 각 문화의 고유성을 잃지 않으면서도 새로운 문화적 가치를 만들어내는 것이다.`,
        question: '글의 화제로 가장 적절한 것은?',
        options: [
          '① 문화 간 충돌과 그 해결 방안',
          '② 현대 사회의 문화 융합 현상',
          '③ 전통 문화의 보존 필요성',
          '④ 세계화가 문화에 미치는 부정적 영향'
        ],
        answer: 2,
        explanation: '글 전체에서 현대 사회에서 나타나는 문화 융합 현상에 대해 설명하고 있으며, K-pop을 구체적인 사례로 제시하면서 이 현상의 특징과 의미를 다루고 있습니다.'
      },
      {
        id: 103,
        year: '2021',
        exam: '9월 모의평가',
        passage: `문화적 정체성은 개인이나 집단이 특정한 문화에 소속감을 느끼며 형성하는 인식이다. 이는 태어나면서부터 자연스럽게 습득되는 것이 아니라, 사회적 상호작용을 통해 점진적으로 구성되는 것이다.

현대의 다문화 사회에서 개인은 여러 문화에 동시에 노출되며, 이로 인해 복합적인 문화적 정체성을 형성하게 된다. 이는 과거의 단일한 문화적 정체성과는 다른 새로운 형태의 정체성이라고 할 수 있다.

이러한 변화는 개인에게 더 풍부하고 유연한 사고를 가능하게 하지만, 동시에 정체성 혼란이라는 과제도 안겨준다. 따라서 현대인은 다양한 문화적 요소들을 조화롭게 통합하여 자신만의 고유한 정체성을 형성해 나가야 한다.`,
        question: '다음 글의 주제문은?',
        options: [
          '① 첫 번째 문단의 첫 번째 문장',
          '② 두 번째 문단의 두 번째 문장',
          '③ 세 번째 문단의 첫 번째 문장',
          '④ 마지막 문단의 마지막 문장'
        ],
        answer: 4,
        explanation: '마지막 문장에서 글 전체의 핵심 메시지인 "현대인이 다양한 문화적 요소들을 조화롭게 통합하여 자신만의 고유한 정체성을 형성해야 한다"는 주제를 요약하여 제시하고 있습니다.'
      }
    ],
    2: [
      {
        id: 201,
        year: '2023',
        exam: '수능',
        passage: `Technology has dramatically changed the way we communicate with others. Social media platforms have made it easier than ever to stay connected with friends and family around the world. However, this convenience comes with certain challenges.

Many people now prefer digital communication over face-to-face interaction. While this may seem efficient, it can lead to a lack of genuine human connection. The nuances of body language and vocal tone are often lost in digital communication.

Furthermore, the constant availability of digital communication can create pressure to respond immediately to messages. This can lead to stress and anxiety, particularly among young people who feel obligated to maintain their online presence constantly.`,
        question: 'The word "however" in the passage can be replaced by:',
        options: [
          '① therefore',
          '② moreover',
          '③ nevertheless',
          '④ consequently'
        ],
        answer: 3,
        explanation: '"However"는 앞의 내용과 대조되는 내용을 이어갈 때 사용하는 역접 접속부사로, "nevertheless"와 같은 의미입니다.'
      },
      {
        id: 202,
        year: '2022',
        exam: '6월 모의평가',
        passage: `Climate change is one of the most pressing issues of our time. The Earth's temperature has been rising steadily due to increased greenhouse gas emissions. This warming trend is causing significant changes to weather patterns around the globe.

Scientists have been studying this phenomenon for decades. They have collected extensive data showing that human activities are the primary cause of recent climate change. The burning of fossil fuels releases carbon dioxide into the atmosphere, which traps heat and causes global warming.

The effects of climate change are already visible. We can see melting ice caps, rising sea levels, and more frequent extreme weather events. If we don't take action soon, these problems will only get worse.`,
        question: 'Which conjunction best fits the blank in "Scientists have been studying this phenomenon for decades, _____ they have strong evidence."?',
        options: [
          '① although',
          '② because',
          '③ and',
          '④ since'
        ],
        answer: 3,
        explanation: '문맥상 과학자들이 수십 년간 연구해왔다는 내용과 강력한 증거를 가지고 있다는 내용을 자연스럽게 연결하는 접속사 "and"가 적절합니다.'
      }
    ],
    3: [
      {
        id: 301,
        year: '2023',
        exam: '수능',
        passage: `이차함수는 y = ax² + bx + c (a ≠ 0) 형태로 나타낼 수 있으며, 그래프는 포물선 모양을 이룬다. 이차함수의 최댓값이나 최솟값은 포물선의 꼭짓점에서 나타난다.

이차함수 f(x) = ax² + bx + c에서 a > 0이면 아래로 볼록한 포물선이 되어 최솟값을 가지고, a < 0이면 위로 볼록한 포물선이 되어 최댓값을 가진다.

꼭짓점의 x좌표는 x = -b/2a로 구할 수 있으며, 이 값을 함수에 대입하면 최댓값 또는 최솟값을 구할 수 있다.`,
        question: 'f(x) = -3x² + 12x - 5의 최댓값은?',
        options: [
          '① 5',
          '② 7',
          '③ 9',
          '④ 11'
        ],
        answer: 2,
        explanation: 'a = -3 < 0이므로 최댓값을 가집니다. 꼭짓점의 x좌표는 x = -12/(2×(-3)) = 2입니다. f(2) = -3(4) + 12(2) - 5 = -12 + 24 - 5 = 7입니다.'
      },
      {
        id: 302,
        year: '2022',
        exam: '6월 모의평가',
        passage: `이차함수의 그래프를 이용하면 이차부등식을 쉽게 해결할 수 있다. 이차함수 y = ax² + bx + c의 그래프와 x축의 교점을 구하면, 이것이 이차방정식 ax² + bx + c = 0의 해가 된다.

판별식 D = b² - 4ac의 값에 따라 교점의 개수가 결정된다. D > 0이면 두 개의 서로 다른 실근을 가지고, D = 0이면 중근을 가지며, D < 0이면 실근이 없다.

이차부등식을 풀 때는 이차함수의 그래프를 그려서 x축보다 위에 있는 부분과 아래에 있는 부분을 구분하여 해를 구한다.`,
        question: '이차함수 y = -x² + 6x - 2의 꼭짓점의 y좌표는?',
        options: [
          '① 5',
          '② 6',
          '③ 7',
          '④ 8'
        ],
        answer: 3,
        explanation: '꼭짓점의 x좌표는 x = -6/(2×(-1)) = 3입니다. y = -(3)² + 6(3) - 2 = -9 + 18 - 2 = 7입니다.'
      }
    ]
  };

  const currentProblems = similarProblems[problemId] || [];

  const handleAnswerSelect = (problemId, optionIndex) => {
    setUserAnswers(prev => ({
      ...prev,
      [problemId]: optionIndex
    }));
  };

  const handleSubmitAnswer = (problemId) => {
    setShowResults(prev => ({
      ...prev,
      [problemId]: true
    }));
  };

  const handleShowProblem = (problemId) => {
    setSelectedProblem(selectedProblem === problemId ? null : problemId);
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-pink-100 relative overflow-hidden ${petalFall ? 'animate-pulse' : ''}`}>
      {/* 🌸 벚꽃 배경 효과 */}
      <div className="fixed inset-0 pointer-events-none">
        {/* 벚꽃 그라데이션 효과 */}
        <div className="absolute top-0 left-0 w-full h-full opacity-20">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,0 Q50,20 100,0 L100,15 Q50,35 0,15 Z" fill="url(#blossomGradient)" />
            <path d="M0,40 Q25,60 50,40 Q75,20 100,40" stroke="#ec4899" strokeWidth="0.5" fill="none" opacity="0.6"/>
            <path d="M15,0 L15,100 M35,0 L35,100 M55,0 L55,100 M75,0 L75,100" stroke="#be185d" strokeWidth="0.3" opacity="0.4"/>
            <circle cx="30" cy="30" r="2" fill="#ec4899" opacity="0.7"/>
            <circle cx="70" cy="70" r="1.5" fill="#be185d" opacity="0.6"/>
            <defs>
              <linearGradient id="blossomGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ec4899" stopOpacity="0.5" />
                <stop offset="50%" stopColor="#be185d" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#9d174d" stopOpacity="0.2" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* 🌸 벚꽃 꽃잎 효과 */}
        {blossomWave && (
          <>
            <div className="absolute top-0 left-1/5 w-3 h-40 bg-gradient-to-b from-pink-400 to-transparent animate-pulse opacity-60"></div>
            <div className="absolute top-0 right-1/4 w-2 h-32 bg-gradient-to-b from-rose-400 to-transparent animate-pulse opacity-50"></div>
            <div className="absolute top-0 left-3/4 w-2.5 h-36 bg-gradient-to-b from-fuchsia-400 to-transparent animate-bounce opacity-70"></div>
          </>
        )}
        
        {/* 🌺 반짝임 효과 */}
        {sparkleEffect && (
          <div className="absolute inset-0 bg-gradient-to-r from-pink-200/30 via-white/40 to-rose-200/30 animate-pulse"></div>
        )}
        
        {/* 🌸 벚꽃 바람 효과 */}
        {gentleBreeze && (
          <div className="absolute top-1/3 right-10 w-20 h-32 bg-pink-200/40 opacity-50 rounded-full blur-2xl animate-pulse"></div>
        )}
        
        {/* 벚꽃 안개 효과 */}
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-white/40 to-transparent"></div>
        
        {/* 움직이는 벚꽃들 */}
        <div className="absolute top-1/4 left-10 w-32 h-32 bg-pink-300/30 rounded-full blur-3xl opacity-50 animate-pulse"></div>
        <div className="absolute bottom-1/3 right-20 w-40 h-40 bg-rose-300/30 rounded-full blur-3xl opacity-40 animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-2/3 left-1/3 w-24 h-24 bg-fuchsia-300/30 rounded-full blur-3xl opacity-60 animate-pulse" style={{ animationDelay: '4s' }}></div>
        
        {/* 흩날리는 벚꽃 꽃잎들 */}
        <div className="absolute top-10 left-1/6 w-3 h-3 bg-pink-400/60 rounded-full animate-pulse shadow-md transform rotate-45"></div>
        <div className="absolute top-20 right-1/4 w-2 h-2 bg-rose-400/50 rounded-full animate-pulse delay-500 shadow-sm transform rotate-12"></div>
        <div className="absolute bottom-32 left-1/2 w-2 h-2 bg-pink-300/50 rounded-full animate-pulse delay-1000 shadow-sm transform -rotate-12"></div>
        <div className="absolute top-1/2 left-1/5 w-1 h-1 bg-rose-300/40 rounded-full animate-pulse delay-700 shadow-sm"></div>
        <div className="absolute bottom-40 right-1/3 w-2 h-2 bg-pink-400/40 rounded-full animate-pulse delay-300 shadow-sm transform rotate-45"></div>
      </div>

      {/* 🌸 헤더 - 벚꽃 스타일 */}
      <div className="bg-white/20 backdrop-blur-md shadow-2xl shadow-pink-500/20 border-b border-white/30">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToNote}
                className="text-pink-600 hover:text-pink-700 mr-4 transition-all duration-300 transform hover:scale-110 bg-white/50 backdrop-blur-sm p-2 rounded-full border border-white/30 shadow-lg"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className={`text-2xl font-black bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent ${petalFall ? 'animate-bounce' : ''} drop-shadow-lg`}>
                🔍 유사한 역대 기출문제 - 벚꽃 정원의 보물찾기
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          
          {/* 원본 문제 정보 - 🌸 벚꽃 스타일 */}
          {originalProblem.question && (
            <div className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-pink-500/20 p-6 mb-8 border border-white/30 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-pink-100/30 to-rose-100/30"></div>
              <h2 className="text-lg font-black text-pink-700 mb-4 relative z-10 drop-shadow-sm">📝 원본 학습 문제 - 벚꽃 정원의 출발점</h2>
              <div className="bg-pink-50/60 backdrop-blur-sm border border-pink-200 rounded-2xl p-4 relative z-10 shadow-inner">
                <p className="text-pink-800 font-medium">{originalProblem.question}</p>
                <div className="flex items-center justify-between mt-3">
                  <span className="text-pink-600">🌺 내 답: <strong className="bg-pink-100/60 backdrop-blur-sm px-2 py-1 rounded-full border border-pink-200">{originalProblem.userAnswer}</strong></span>
                  <span className="text-rose-600">🌸 정답: <strong className="bg-rose-100/60 backdrop-blur-sm px-2 py-1 rounded-full border border-rose-200">{originalProblem.correctAnswer}</strong></span>
                </div>
              </div>
              {/* 🌺 벚꽃 장식 */}
              <div className="absolute top-2 right-2 text-pink-400 opacity-60 animate-pulse">🌺</div>
              <div className="absolute bottom-2 left-2 text-rose-400 opacity-50 animate-pulse">🌸</div>
            </div>
          )}

          {/* 유사 기출문제 목록 - 🌸 벚꽃 스타일 */}
          <div className="space-y-8">
            {currentProblems.map((problem) => (
              <div key={problem.id} className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-pink-500/20 p-8 border border-white/30 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-pink-100/20 to-rose-100/20"></div>
                
                {/* 문제 헤더 */}
                <div className="flex items-center justify-between mb-6 relative z-10">
                  <div className="flex items-center space-x-4">
                    <span className="bg-gradient-to-r from-pink-500 to-rose-500 text-white px-4 py-2 rounded-full font-black shadow-lg shadow-pink-500/50">
                      🌺 {problem.year}년 {problem.exam}
                    </span>
                    <span className="bg-fuchsia-100/60 text-fuchsia-700 px-3 py-1 rounded-full text-sm font-medium border border-fuchsia-300 backdrop-blur-sm">
                      🌸 기출문제
                    </span>
                  </div>
                  <button
                    onClick={() => handleShowProblem(problem.id)}
                    className={`px-6 py-3 rounded-2xl font-bold transition-all duration-300 transform hover:scale-105 ${
                      selectedProblem === problem.id
                        ? 'bg-gradient-to-r from-pink-500 to-rose-500 text-white shadow-lg shadow-pink-500/50'
                        : 'bg-white/50 backdrop-blur-sm text-pink-700 hover:bg-white/70 border border-white/40 hover:border-pink-300'
                    }`}
                  >
                    {selectedProblem === problem.id ? '🌸 문제 접기' : '🌺 문제 풀어보기'}
                  </button>
                </div>

                {/* 지문 (있는 경우) - 🌸 벚꽃 스타일 */}
                {problem.passage && (
                  <div className="mb-6 relative z-10">
                    <h4 className="font-black text-pink-700 mb-3 drop-shadow-sm">📄 지문 - 벚꽃 정원의 이야기</h4>
                    <div className="bg-white/50 backdrop-blur-sm border border-white/40 rounded-2xl p-6 shadow-inner">
                      <p className="text-pink-800 leading-relaxed whitespace-pre-line">
                        {problem.passage}
                      </p>
                    </div>
                  </div>
                )}

                {/* 문제 */}
                <div className="mb-6 relative z-10">
                  <h4 className="font-black text-rose-700 mb-3 drop-shadow-sm">❓ 문제 - 벚꽃의 질문</h4>
                  <p className="text-lg font-bold text-rose-800 mb-4 drop-shadow-sm">{problem.question}</p>
                </div>

                {/* 선택지 및 풀이 - 🌸 벚꽃 스타일 */}
                {selectedProblem === problem.id && (
                  <div className="space-y-4 relative z-10">
                    <div className="bg-pink-50/60 backdrop-blur-sm border border-pink-200 rounded-2xl p-6 shadow-inner">
                      <h5 className="font-black text-pink-700 mb-4 drop-shadow-sm">🌺 선택지 - 벚꽃 정원의 선택</h5>
                      <div className="space-y-3">
                        {problem.options.map((option, optionIndex) => (
                          <label key={optionIndex} className="flex items-center space-x-3 cursor-pointer hover:bg-pink-100/50 hover:backdrop-blur-sm p-3 rounded-xl transition-all duration-300 transform hover:scale-105 border border-transparent hover:border-pink-200">
                            <input
                              type="radio"
                              name={`problem-${problem.id}`}
                              value={optionIndex}
                              onChange={() => handleAnswerSelect(problem.id, optionIndex)}
                              className="w-4 h-4 text-pink-600 bg-white border-pink-300 focus:ring-pink-500"
                            />
                            <span className={`text-lg ${
                              showResults[problem.id] && optionIndex === problem.answer - 1
                                ? 'text-rose-700 font-black'
                                : showResults[problem.id] && userAnswers[problem.id] === optionIndex && optionIndex !== problem.answer - 1
                                ? 'text-pink-600 font-bold'
                                : 'text-pink-800'
                            }`}>
                              {option}
                            </span>
                          </label>
                        ))}
                      </div>

                      <div className="flex space-x-3 mt-6">
                        <button
                          onClick={() => handleSubmitAnswer(problem.id)}
                          disabled={userAnswers[problem.id] === undefined}
                          className="bg-gradient-to-r from-pink-500 to-rose-500 text-white px-6 py-3 rounded-2xl font-bold hover:from-pink-400 hover:to-rose-400 transition-all duration-300 disabled:bg-white/50 disabled:text-gray-500 disabled:cursor-not-allowed transform hover:scale-105 shadow-lg hover:shadow-pink-500/50 border-2 border-white/30 backdrop-blur-sm"
                        >
                          🌺 정답 확인
                        </button>
                        {showResults[problem.id] && (
                          <div className="flex items-center space-x-2 bg-rose-100/60 backdrop-blur-sm px-4 py-2 rounded-full border border-rose-200">
                            <span className="text-rose-700 font-medium">🌸 정답:</span>
                            <span className="font-black text-rose-600">{problem.answer}번</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* 해설 - 🌸 벚꽃 스타일 */}
                    {showResults[problem.id] && (
                      <div className="bg-rose-50/60 backdrop-blur-sm border border-rose-200 rounded-2xl p-6 shadow-inner">
                        <h6 className="font-black text-rose-700 mb-3 drop-shadow-sm">💡 해설 - 벚꽃 정원의 지혜</h6>
                        <p className="text-rose-800 leading-relaxed">{problem.explanation}</p>
                      </div>
                    )}
                  </div>
                )}
                
                {/* 🌺 벚꽃 장식 */}
                <div className="absolute top-4 right-4 text-pink-400 opacity-50 animate-pulse">
                  {problem.id % 3 === 0 ? '🌺' : problem.id % 3 === 1 ? '🌸' : '💮'}
                </div>
                <div className="absolute bottom-4 left-4 text-rose-400 opacity-40 animate-pulse">💮</div>
              </div>
            ))}
          </div>

          {/* 문제가 없는 경우 */}
          {currentProblems.length === 0 && (
            <div className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-pink-500/20 p-12 border border-white/30 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-pink-100/30 to-rose-100/30"></div>
              <div className="relative z-10">
                <div className="text-6xl mb-4 animate-pulse">🌸</div>
                <h3 className="text-2xl font-black text-pink-700 mb-4 drop-shadow-sm">유사한 문제를 찾을 수 없습니다</h3>
                <p className="text-pink-600 mb-8">이 문제 유형에 대한 기출문제가 아직 준비되지 않았습니다.</p>
                <button
                  onClick={() => navigate('/wrong-answer-note')}
                  className="bg-gradient-to-r from-pink-500 to-rose-500 text-white px-8 py-4 rounded-2xl font-black transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-pink-500/50 border-2 border-white/30 backdrop-blur-sm"
                >
                  🌺 학습노트로 돌아가기
                </button>
              </div>
            </div>
          )}

          {/* 하단 액션 버튼 - 🌸 벚꽃 스타일 */}
          {currentProblems.length > 0 && (
            <div className="mt-12 flex justify-center space-x-4">
              <button
                onClick={() => navigate('/wrong-answer-note')}
                className="bg-gradient-to-r from-pink-500 to-rose-500 text-white px-8 py-4 rounded-2xl font-black text-lg shadow-2xl shadow-pink-500/50 hover:shadow-pink-500/70 transition-all duration-300 transform hover:scale-105 border-2 border-white/30 backdrop-blur-sm"
              >
                📚 학습노트로 돌아가기
              </button>
              <button
                onClick={() => navigate('/upload')}
                className="bg-gradient-to-r from-fuchsia-500 to-pink-500 text-white px-8 py-4 rounded-2xl font-black text-lg shadow-2xl shadow-fuchsia-500/50 hover:shadow-fuchsia-500/70 transition-all duration-300 transform hover:scale-105 border-2 border-white/30 backdrop-blur-sm"
              >
                📝 새로운 시험지 풀기
              </button>
            </div>
          )}

          {/* 통계 정보 (문제를 푼 경우) */}
          {Object.keys(showResults).length > 0 && (
            <div className="mt-12 bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-pink-500/20 p-8 border border-white/30 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-pink-100/30 to-rose-100/30"></div>
              <div className="text-center relative z-10">
                <h3 className="text-2xl font-black bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent mb-6 drop-shadow-lg">📊 학습 현황 - 벚꽃 정원의 성장</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-pink-50/60 backdrop-blur-sm rounded-2xl p-6 border border-pink-200 shadow-lg">
                    <div className="text-3xl mb-2">🎯</div>
                    <div className="text-2xl font-black text-pink-700 mb-1 drop-shadow-sm">
                      {Object.keys(showResults).filter(key => 
                        userAnswers[key] === currentProblems.find(p => p.id == key)?.answer - 1
                      ).length}
                    </div>
                    <div className="text-sm text-pink-600 font-medium">정답 문제</div>
                  </div>
                  
                  <div className="bg-rose-50/60 backdrop-blur-sm rounded-2xl p-6 border border-rose-200 shadow-lg">
                    <div className="text-3xl mb-2">📊</div>
                    <div className="text-2xl font-black text-rose-700 mb-1 drop-shadow-sm">
                      {Object.keys(showResults).length > 0 ? 
                        Math.round((Object.keys(showResults).filter(key => 
                          userAnswers[key] === currentProblems.find(p => p.id == key)?.answer - 1
                        ).length / Object.keys(showResults).length) * 100) : 0}%
                    </div>
                    <div className="text-sm text-rose-600 font-medium">정답률</div>
                  </div>
                  
                  <div className="bg-fuchsia-50/60 backdrop-blur-sm rounded-2xl p-6 border border-fuchsia-200 shadow-lg">
                    <div className="text-3xl mb-2">📚</div>
                    <div className="text-2xl font-black text-fuchsia-700 mb-1 drop-shadow-sm">
                      {Object.keys(showResults).length}/{currentProblems.length}
                    </div>
                    <div className="text-sm text-fuchsia-600 font-medium">완료 문제</div>
                  </div>
                </div>
                
                {/* 개별 문제 결과 */}
                <div className="mt-8 bg-white/50 backdrop-blur-sm rounded-2xl p-6 border border-white/40 shadow-lg">
                  <h4 className="font-black text-pink-700 mb-4 drop-shadow-sm">🔍 문제별 결과</h4>
                  <div className="space-y-3">
                    {currentProblems.map(problem => {
                      const isAnswered = showResults[problem.id];
                      const isCorrect = userAnswers[problem.id] === problem.answer - 1;
                      
                      if (!isAnswered) return null;
                      
                      return (
                        <div key={problem.id} className="flex items-center justify-between p-3 bg-white/60 backdrop-blur-sm rounded-xl border border-white/50 shadow-sm">
                          <span className="text-pink-700 font-medium">
                            🌺 {problem.year}년 {problem.exam}
                          </span>
                          <span className={`font-bold ${isCorrect ? 'text-rose-600' : 'text-pink-600'}`}>
                            {isCorrect ? '✅ 정답' : '❌ 오답'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
              
              {/* 🌺 벚꽃 장식 */}
              <div className="absolute top-4 right-4 text-pink-400 opacity-60 animate-pulse">📈</div>
              <div className="absolute bottom-4 left-4 text-rose-400 opacity-50 animate-pulse">🏆</div>
            </div>
          )}

          {/* 추천 학습법 (일부 문제를 푼 경우) */}
          {Object.keys(showResults).length > 0 && Object.keys(showResults).length < currentProblems.length && (
            <div className="mt-8 bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl shadow-pink-500/20 p-8 border border-white/30 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-fuchsia-100/30 to-pink-100/30"></div>
              <div className="relative z-10">
                <h3 className="text-xl font-black bg-gradient-to-r from-fuchsia-600 to-pink-600 bg-clip-text text-transparent mb-4 drop-shadow-lg">💡 추천 학습법 - 벚꽃 정원의 조언</h3>
                <div className="bg-fuchsia-50/60 backdrop-blur-sm rounded-2xl p-6 border border-fuchsia-200 shadow-lg">
                  <div className="space-y-3 text-fuchsia-800">
                    <div>🌸 남은 문제들도 풀어보세요! 더 많은 연습이 실력 향상에 도움됩니다.</div>
                    <div>🌺 틀린 문제는 해설을 꼼꼼히 읽어보세요.</div>
                    <div>💮 비슷한 유형의 문제를 더 찾아서 연습해보세요.</div>
                  </div>
                </div>
              </div>
              
              {/* 🌺 벚꽃 장식 */}
              <div className="absolute top-4 right-4 text-fuchsia-400 opacity-60 animate-pulse">💡</div>
              <div className="absolute bottom-4 left-4 text-pink-400 opacity-50 animate-pulse">📖</div>
            </div>
          )}
        </div>
      </div>

      {/* 🌸 벚꽃 CSS 애니메이션 */}
      <style jsx>{`
        @keyframes petal-pulse {
          0%, 100% { 
            opacity: 0.6;
            transform: scale(1) rotate(0deg);
          }
          50% { 
            opacity: 1;
            transform: scale(1.05) rotate(180deg);
          }
        }
        
        @keyframes blossom-appear {
          0% { 
            opacity: 0;
            transform: translateY(10px) scale(0.9) rotate(0deg);
          }
          50% { 
            opacity: 0.8;
            transform: translateY(0px) scale(1) rotate(180deg);
          }
          100% { 
            opacity: 0;
            transform: translateY(-10px) scale(1.1) rotate(360deg);
          }
        }
        
        @keyframes petal-flow {
          0% { 
            transform: translateY(-50%) scaleY(0) rotate(0deg);
            opacity: 0;
          }
          30% { 
            transform: translateY(0%) scaleY(1) rotate(180deg);
            opacity: 0.8;
          }
          70% { 
            transform: translateY(200%) scaleY(1) rotate(360deg);
            opacity: 0.6;
          }
          100% { 
            transform: translateY(300%) scaleY(0) rotate(720deg);
            opacity: 0;
          }
        }
        
        @keyframes blossom-shimmer {
          0%, 100% { 
            opacity: 0.2;
            filter: hue-rotate(0deg);
          }
          50% { 
            opacity: 0.6;
            filter: hue-rotate(30deg);
          }
        }
        
        @keyframes gentle-sway {
          0%, 100% { 
            transform: translateX(0) rotate(0deg); 
          }
          25% { 
            transform: translateX(2px) translateY(-1px) rotate(1deg); 
          }
          50% { 
            transform: translateX(0) translateY(-2px) rotate(0deg); 
          }
          75% { 
            transform: translateX(-2px) translateY(-1px) rotate(-1deg); 
          }
        }
        
        .animate-petal-pulse {
          animation: petal-pulse 2s ease-in-out infinite;
        }
        
        .animate-blossom-appear {
          animation: blossom-appear 4s ease-in-out;
        }
        
        .animate-petal-flow {
          animation: petal-flow 3s ease-in-out;
        }
        
        .animate-blossom-shimmer {
          animation: blossom-shimmer 4s ease-in-out infinite;
        }
        
        .animate-gentle-sway {
          animation: gentle-sway 6s ease-in-out infinite;
        }
        
        /* 🌸 스크롤바 스타일링 - 벚꽃 버전 */
        ::-webkit-scrollbar {
          width: 12px;
        }
        
        ::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.3);
          border-radius: 6px;
        }
        
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #ec4899, #be185d);
          border-radius: 6px;
          border: 2px solid rgba(255, 255, 255, 0.3);
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #db2777, #9d174d);
        }
        
        /* 🌺 반짝임 효과 - 벚꽃 버전 */
        .sparkle-text {
          position: relative;
        }
        
        .sparkle-text::before,
        .sparkle-text::after {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: linear-gradient(45deg, transparent, rgba(236, 72, 153, 0.3), transparent);
          animation: sparkle 2s ease-in-out infinite;
        }
        
        .sparkle-text::after {
          animation-delay: 1s;
        }
        
        @keyframes sparkle {
          0%, 100% {
            transform: translateX(-100%);
          }
          50% {
            transform: translateX(100%);
          }
        }
        
        /* 🌸 호버 글로우 효과 - 벚꽃 버전 */
        .blossom-hover {
          transition: all 0.3s ease;
        }
        
        .blossom-hover:hover {
          filter: drop-shadow(0 0 20px rgba(236, 72, 153, 0.6));
          transform: scale(1.02) rotate(1deg);
        }
        
        /* 🌺 벚꽃 글로우 효과 */
        .blossom-glow {
          box-shadow: 0 0 20px rgba(236, 72, 153, 0.3);
        }
        
        .blossom-glow:hover {
          box-shadow: 0 0 30px rgba(236, 72, 153, 0.5);
        }
        
        /* 🌸 벚꽃 텍스트 효과 */
        .blossom-text {
          background: linear-gradient(45deg, #ec4899, #be185d, #ec4899);
          background-size: 200% 200%;
          animation: blossom-gradient 3s ease infinite;
        }
        
        @keyframes blossom-gradient {
          0%, 100% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
        }
      `}</style>
    </div>
  );
}