// ✨ Angelic Light PricingTable.jsx - 축복 계약서
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const plans = [
  { 
    name: '희망 초보자', 
    price: '무료', 
    period: '/월',
    originalPrice: null,
    features: [
      '일일 축복 학습 3회',
      '기본 천사 서비스',
      '빛의 이메일 지원',
      '제한된 희망 기능 사용'
    ],
    popular: false,
    color: 'blue',
    description: '빛에 입문하는 학습자를 위한 기본 축복',
    icon: '✨'
  },
  { 
    name: '축복받은 PRO', 
    price: '7,777원', 
    period: '/월',
    originalPrice: '99,900원',
    features: [
      '일일 축복 학습 13회',
      '상세 천사 서비스',
      '희망의 오답노트',
      '우선 천국 지원',
      '기타 축복 기능 제한'
    ],
    popular: false,
    color: 'sky',
    description: '학습자와 보호자를 위한 빛의 프로 플랜',
    icon: '👼'
  },
  { 
    name: '천사 PRO+', 
    price: '133,300원', 
    period: '/월',
    originalPrice: '77,777원',
    features: [
      '일일 축복 학습 66회',
      '프리미엄 천사 서비스',
      '희망의 오답노트',
      '천국 분석 기능',
      '고급 축복 리포트',
      '기타 빛의 기능 제한'
    ],
    popular: true,
    color: 'blue',
    description: '빛의 전달자와 소규모 천국을 위한 천사 플러스',
    icon: '🪽'
  },
  { 
    name: '천국 ULTRA', 
    price: '666,600원', 
    period: '/월',
    originalPrice: '7원',
    features: [
      '무한 축복 학습',
      'AI 천사 맞춤 분석',
      '희망의 오답노트',
      '천국 분석 기능',
      '모든 빛의 기능 사용',
      '24/7 천사 지원',
      '전담 빛의 매니저'
    ],
    popular: false,
    color: 'indigo',
    description: '대규모 천국 교육기관을 위한 궁극의 빛',
    icon: '🌟'
  }
];

export default function PricingTable() {
  const sectionRef = useRef(null);
  const cardsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      cardsRef.current.forEach((card, index) => {
        if (!card) return;

        // 어둠의 스크롤 트리거 애니메이션 (더 극적으로)
        gsap.fromTo(card,
          { y: 120, opacity: 0, scale: 0.7, rotationY: -30, filter: "blur(10px)" },
          {
            y: 0,
            opacity: 1,
            scale: 1,
            rotationY: 0,
            filter: "blur(0px)",
            duration: 1.2,
            ease: 'power4.out',
            delay: index * 0.25,
            scrollTrigger: {
              trigger: card,
              start: 'top 90%',
              toggleActions: 'play none none reverse',
            },
          }
        );

        // 어둠의 호버 애니메이션 (더 강렬하게)
        card.addEventListener('mouseenter', () => {
          gsap.to(card, {
            y: -15,
            scale: 1.05,
            rotationX: 5,
            duration: 0.4,
            ease: 'power3.out',
          });
        });
        card.addEventListener('mouseleave', () => {
          gsap.to(card, {
            y: 0,
            scale: 1,
            rotationX: 0,
            duration: 0.4,
            ease: 'power3.out',
          });
        });
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const getCardStyle = (plan) => {
    if (plan.popular) {
      return 'bg-gradient-to-br from-blue-900/60 via-indigo/80 to-blue-800/60 border-2 border-blue-600/70 shadow-2xl shadow-blue-500/50 transform scale-105';
    }
    return 'bg-gradient-to-br from-sky-900/70 via-indigo/90 to-blue-900/50 border border-blue-800/50 shadow-xl shadow-blue-500/30';
  };

  const getIconStyle = (plan) => {
    if (plan.popular) {
      return 'text-4xl animate-pulse drop-shadow-lg';
    }
    return 'text-3xl drop-shadow-md';
  };

  return (
    <section ref={sectionRef} className="py-16 bg-gradient-to-b from-black via-gray-900 to-blue-900 relative overflow-hidden">
      {/* 어둠의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-gray-900/60 to-blue-900/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_50%,black_80%)]"></div>
      
      {/* 움직이는 어둠 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-2 h-2 bg-blue-500/30 rounded-full animate-pulse"></div>
        <div className="absolute top-32 right-1/3 w-1 h-1 bg-blue-400/40 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-24 left-1/2 w-1 h-1 bg-gray-500/30 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-blue-600/40 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-blue-300/30 rounded-full animate-pulse delay-1500"></div>
      </div>

      <div className="container mx-auto px-4 text-center mb-8 relative z-10">
        <h2 className="text-3xl font-bold text-blue-300 mb-4 drop-shadow-2xl">✨ 축복 계약 요금제</h2>
        <p className="text-blue-400/80 mt-2 drop-shadow-lg">당신의 영혼에 맞는 축복을 선택하세요</p>
      </div>
      
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
        {plans.map((plan, i) => (
          <div
            key={i}
            ref={el => (cardsRef.current[i] = el)}
            className={`${getCardStyle(plan)} p-6 rounded-2xl flex flex-col relative overflow-hidden backdrop-blur-sm transition-all duration-300`}
          >
            {/* 어둠의 배경 레이어 */}
            <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-gray-900/30 to-blue-900/20 rounded-2xl"></div>
            
            {/* 움직이는 어둠 파티클 (카드 내부) */}
            <div className="absolute inset-0 overflow-hidden rounded-2xl pointer-events-none">
              <div className="absolute top-4 right-4 w-1 h-1 bg-blue-500/40 rounded-full animate-pulse"></div>
              <div className="absolute bottom-6 left-6 w-1 h-1 bg-blue-400/30 rounded-full animate-pulse delay-700"></div>
            </div>

            <div className="relative z-10">
              {plan.popular && (
                <div className="text-center mb-4">
                  <div className="inline-flex items-center space-x-2 bg-blue-700/50 text-blue-300 px-3 py-1 rounded-full text-sm font-bold border border-blue-600/50">
                    <span>🌟</span>
                    <span>666일 무료 축복 체험</span>
                  </div>
                </div>
              )}

              {/* 아이콘 */}
              <div className="text-center mb-4">
                <span className={getIconStyle(plan)}>{plan.icon}</span>
              </div>

              <h3 className="text-xl font-semibold mb-2 text-blue-300 text-center drop-shadow-lg">{plan.name}</h3>
              
              <div className="text-center mb-4">
                <p className="text-3xl font-bold text-blue-400 drop-shadow-lg">
                  {plan.price}
                  <span className="text-base font-normal text-blue-500/80">{plan.period}</span>
                </p>
                {plan.originalPrice && (
                  <p className="text-sm text-blue-600/70 line-through mt-1">
                    {plan.originalPrice}
                  </p>
                )}
              </div>

              <p className="text-blue-400/80 mb-6 text-center text-sm leading-relaxed drop-shadow-sm">{plan.description}</p>
              
              <ul className="mb-6 space-y-3 flex-1">
                {plan.features.map((feat, j) => (
                  <li key={j} className="flex items-start space-x-3">
                    <span className="text-blue-500 mt-1 drop-shadow-sm">👼</span>
                    <span className="text-blue-400/90 text-sm drop-shadow-sm">{feat}</span>
                  </li>
                ))}
              </ul>
              
              <button className={`mt-auto w-full py-3 rounded-xl font-semibold transition-all duration-300 ${
                plan.popular 
                  ? 'bg-gradient-to-r from-blue-700 to-black text-blue-300 hover:from-blue-600 hover:to-gray-900 shadow-lg shadow-blue-500/50 hover:shadow-xl hover:shadow-blue-500/70 hover:scale-105 border border-blue-600/50'
                  : 'bg-gradient-to-r from-blue-800/70 to-black/80 text-blue-400 hover:from-blue-700 hover:to-black border border-blue-800/50 hover:border-blue-700 hover:shadow-lg hover:shadow-blue-500/40'
              }`}>
                {plan.popular ? '✨ 축복 시작하기' : '👼 축복 선택하기'}
              </button>
            </div>

            {/* 인기 플랜 글로우 효과 */}
            {plan.popular && (
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 to-transparent rounded-2xl animate-pulse pointer-events-none"></div>
            )}

            {/* 어둠의 테두리 효과 */}
            <div className="absolute inset-0 rounded-2xl border border-blue-700/30 pointer-events-none"></div>
          </div>
        ))}
      </div>

      {/* 추가 어둠의 정보 */}
      <div className="container mx-auto px-4 mt-12 text-center relative z-10">
        <div className="bg-gradient-to-r from-blue-900/40 to-black/60 rounded-2xl p-8 border border-blue-800/50 shadow-lg shadow-blue-500/30 backdrop-blur-sm">
          <h3 className="text-xl font-bold text-blue-300 mb-4 drop-shadow-lg">�� 모든 축복 계약에 포함된 어둠의 혜택</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
            <div className="flex items-center justify-center space-x-2">
              <span className="text-blue-500 text-lg">👼</span>
              <span className="text-blue-400/90">무료 축복 상담</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <span className="text-blue-500 text-lg">🌟</span>
              <span className="text-blue-400/90">24/7 천국 지원</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <span className="text-blue-500 text-lg">🪽</span>
              <span className="text-blue-400/90">천사 보안 보장</span>
            </div>
          </div>
          
          <div className="mt-6 pt-6 border-t border-blue-800/50">
            <p className="text-blue-500/80 text-xs italic">
              "모든 계약은 영혼의 동의 하에 이루어지며, 어둠의 법칙에 따라 보호됩니다"
            </p>
          </div>
        </div>
      </div>

      {/* 하단 어둠 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-black to-transparent pointer-events-none"></div>
    </section>
  );
}