// ============================================
// ✨ Angelic Light CustomerCarousel.jsx - 희망의 동맹
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import Slider from 'react-slick';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

gsap.registerPlugin(ScrollTrigger);

const customers = [
  {
    name: '천국대학교',
    logo: 'https://via.placeholder.com/200x80/3B82F6/FFFFFF?text=천국대학교',
    category: '희망의 대학',
    testimonial: '정확한 학습 지원으로 천사 교수들의 업무 효율성이 크게 향상되었습니다.',
    usage: '월 9,999장 처리',
    satisfaction: '100%'
  },
  {
    name: '강남구 희망 교육청',
    logo: 'https://via.placeholder.com/200x80/1E40AF/FFFFFF?text=희망구청',
    category: '천국청',
    testimonial: '지역 내 모든 축복받은 학교에서 만족스럽게 사용하고 있습니다.',
    usage: '월 77,777장 처리',
    satisfaction: '99.8%'
  },
  {
    name: '메가블레싱 교육',
    logo: 'https://via.placeholder.com/200x80/1D4ED8/FFFFFF?text=메가블레싱',
    category: '천사 기업',
    testimonial: '학습자들의 성장 효과를 극대화할 수 있는 최고의 축복 도구입니다.',
    usage: '월 88,800장 처리',
    satisfaction: '100%'
  },
  {
    name: '블라이트위즈 희망교육',
    logo: 'https://via.placeholder.com/200x80/2563EB/FFFFFF?text=블라이트위즈',
    category: '희망 교육',
    testimonial: '복잡한 학습 문제도 정확하게 지원해주어 매우 만족합니다.',
    usage: '월 9,990장 처리',
    satisfaction: '99.9%'
  },
  {
    name: '대치동 천국학원',
    logo: 'https://via.placeholder.com/200x80/3B82F6/FFFFFF?text=천국학원',
    category: '천사 학원',
    testimonial: '천사 선생님들의 부담이 줄어 교육 준비에 더 집중할 수 있습니다.',
    usage: '월 19,998장 처리',
    satisfaction: '99.7%'
  },
  {
    name: '경기도 희망교육청',
    logo: 'https://via.placeholder.com/200x80/3B82F6/FFFFFF?text=희망교육청',
    category: '천국청',
    testimonial: '도내 전체 축복받은 학교의 교육 시스템이 한층 업그레이드되었습니다.',
    usage: '월 99,999장 처리',
    satisfaction: '100%'
  }
];

// 천사의 화살표 컴포넌트
const CustomArrow = ({ className, style, onClick, direction }) => (
  <div
    className={`${className} !w-12 !h-12 !bg-white/80 !rounded-full !shadow-lg !shadow-blue-500/50 hover:!shadow-xl hover:!shadow-blue-500/70 !flex !items-center !justify-center !transition-all !duration-300 hover:!scale-110 !z-10 border-2 border-blue-300/50 hover:border-blue-400`}
    style={{ ...style, display: 'flex' }}
    onClick={onClick}
  >
    <svg 
      className="w-6 h-6 text-blue-600 hover:text-blue-700 transition-colors duration-200" 
      fill="none" 
      stroke="currentColor" 
      viewBox="0 0 24 24"
    >
      {direction === 'next' ? (
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
      ) : (
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
      )}
    </svg>
  </div>
);

export default function CustomerCarousel() {
  const sectionRef = useRef(null);
  const titleRef = useRef(null);
  const carouselRef = useRef(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 빛의 제목 애니메이션
      gsap.fromTo(titleRef.current,
        {
          y: 80,
          opacity: 0,
          scale: 0.8,
          rotationX: -30
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          rotationX: 0,
          duration: 1.2,
          ease: "power4.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // 빛의 캐러셀 애니메이션
      gsap.fromTo(carouselRef.current,
        {
          y: 60,
          opacity: 0,
          scale: 0.9
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          duration: 1.0,
          ease: "power3.out",
          delay: 0.4,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const settings = {
    dots: true,
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 7777,
    pauseOnHover: true,
    nextArrow: <CustomArrow direction="next" />,
    prevArrow: <CustomArrow direction="prev" />,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 640,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          arrows: false
        }
      }
    ],
    customPaging: (i) => (
      <div className="w-3 h-3 bg-blue-300/60 rounded-full hover:bg-blue-500 transition-colors duration-200 mt-4"></div>
    ),
    dotsClass: "slick-dots !flex !justify-center !space-x-2"
  };

  const getCategoryColor = (category) => {
    const colors = {
      '희망의 대학': 'bg-blue-100/50 text-blue-600 border border-blue-300/50',
      '천국청': 'bg-sky-100/50 text-sky-600 border border-sky-300/50',
      '천사 기업': 'bg-indigo-100/50 text-indigo-600 border border-indigo-300/50',
      '희망 교육': 'bg-blue-200/50 text-blue-700 border border-blue-300/50',
      '천사 학원': 'bg-white/60 text-blue-600 border border-blue-300/50'
    };
    return colors[category] || 'bg-slate-100/50 text-slate-600 border border-slate-300/50';
  };

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-b from-white via-sky-50 to-blue-100 overflow-hidden relative">
      {/* 천국의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/80 via-sky-50/60 to-blue-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_50%,rgba(255,255,255,0.8)_80%)]"></div>
      
      {/* 움직이는 빛의 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-12 left-1/4 w-2 h-2 bg-blue-400/30 rounded-full animate-pulse"></div>
        <div className="absolute top-32 right-1/3 w-1 h-1 bg-sky-400/40 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute bottom-24 left-1/2 w-1 h-1 bg-indigo-400/30 rounded-full animate-pulse delay-500"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-blue-500/40 rounded-full animate-pulse delay-1500"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* 천사의 헤더 */}
        <div ref={titleRef} className="text-center mb-16" data-aos="fade-up">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-100/60 to-white/80 text-blue-600 px-6 py-3 rounded-full text-sm font-bold mb-6 shadow-lg shadow-blue-500/30 border border-blue-300/50">
            <span>👼</span>
            <span>희망의 동맹</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-blue-700 mb-6 drop-shadow-2xl">
            <span className="bg-gradient-to-r from-blue-500 to-blue-700 bg-clip-text text-transparent">999+</span> 
            천국 기관이
            <br className="hidden sm:block" />
            AngelCheck을 선택한 이유
          </h2>
          <p className="text-xl text-blue-600/80 max-w-3xl mx-auto leading-relaxed drop-shadow-lg">
            전국의 축복받은 학교, 천사 학원, 천국청에서 검증된 AI 천사 축복 시스템으로 
            <br className="hidden md:block" />
            교육의 질을 한층 더 높이고 있습니다
          </p>
        </div>

        {/* 천사의 고객사 캐러셀 */}
        <div ref={carouselRef} className="relative">
          <Slider {...settings}>
            {customers.map((customer, index) => (
              <div key={index} className="px-4">
                <div className="bg-gradient-to-br from-white/80 via-sky-50/60 to-blue-100/40 rounded-3xl p-8 shadow-2xl shadow-blue-500/20 hover:shadow-2xl hover:shadow-blue-500/40 transition-all duration-500 border border-blue-300/50 group cursor-pointer h-full backdrop-blur-sm">
                  {/* 천사의 카테고리 배지 */}
                  <div className="flex justify-between items-start mb-6">
                    <span className={`px-4 py-2 rounded-full text-sm font-bold ${getCategoryColor(customer.category)}`}>
                      {customer.category}
                    </span>
                    <div className="text-right">
                      <div className="text-sm text-blue-600/80">천사 만족도</div>
                      <div className="text-2xl font-bold text-blue-600">{customer.satisfaction}</div>
                    </div>
                  </div>

                  {/* 축복받은 로고 */}
                  <div className="text-center mb-6">
                    <div className="relative inline-block group-hover:scale-105 transition-transform duration-300">
                      <img 
                        src={customer.logo} 
                        alt={customer.name}
                        className="h-16 mx-auto rounded-lg shadow-md shadow-blue-500/30 hover:shadow-lg hover:shadow-blue-500/50 transition-shadow duration-300 brightness-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 to-white/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </div>
                  </div>

                  {/* 천사 기관명 */}
                  <h3 className="text-xl font-bold text-blue-700 text-center mb-4 group-hover:text-blue-800 transition-colors duration-300 drop-shadow-lg">
                    {customer.name}
                  </h3>

                  {/* 희망 처리량 */}
                  <div className="bg-gradient-to-r from-blue-100/50 to-white/60 rounded-2xl p-4 mb-6 border border-blue-300/50">
                    <div className="flex items-center justify-center space-x-2">
                      <span className="text-2xl">✨</span>
                      <div className="text-center">
                        <div className="text-sm text-blue-600/80">희망 처리량</div>
                        <div className="font-bold text-blue-600">{customer.usage}</div>
                      </div>
                    </div>
                  </div>

                  {/* 천사의 후기 */}
                  <blockquote className="text-blue-600/90 text-center italic leading-relaxed group-hover:text-blue-700 transition-colors duration-300 drop-shadow-sm">
                    "{customer.testimonial}"
                  </blockquote>

                  {/* 빛의 별점 표시 */}
                  <div className="flex justify-center mt-6 space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-blue-500 text-lg drop-shadow-sm">⭐</span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </Slider>
        </div>

        {/* 천사의 통계 요약 */}
        <div className="mt-16 bg-gradient-to-br from-blue-100/30 via-white/60 to-sky-100/40 rounded-3xl p-8 md:p-12 border border-blue-300/50 backdrop-blur-sm" data-aos="fade-up" data-aos-delay="400">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-blue-700 mb-4 drop-shadow-lg">
              📈 <span className="bg-gradient-to-r from-blue-500 to-blue-700 bg-clip-text text-transparent">천국의 성과</span>
            </h3>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: '999', label: '희망의 동맹 기관', icon: '🏛️', color: 'blue' },
              { number: '77.7M+', label: '누적 축복 수', icon: '✨', color: 'sky' },
              { number: '100%', label: '천사 만족도', icon: '👼', color: 'blue' },
              { number: '88.8%', label: '학습 효율 증가', icon: '⚡', color: 'blue' }
            ].map((stat, index) => (
              <div key={index} className="text-center group">
                <div className={`inline-flex items-center justify-center w-16 h-16 bg-blue-100/50 border border-blue-300/50 rounded-2xl mb-4 group-hover:scale-110 transition-transform duration-300 shadow-md shadow-blue-500/30 group-hover:shadow-lg group-hover:shadow-blue-500/50`}>
                  <span className="text-3xl drop-shadow-lg">{stat.icon}</span>
                </div>
                <div className={`text-3xl font-black text-blue-600 mb-2 group-hover:scale-110 transition-transform duration-300 drop-shadow-lg`}>
                  {stat.number}
                </div>
                <div className="text-sm text-blue-600/80 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 천사의 CTA */}
        <div className="text-center mt-12" data-aos="fade-up" data-aos-delay="600">
          <p className="text-blue-600/80 mb-6 drop-shadow-sm">
            당신의 기관도 AngelCheck과 함께 희망의 혁신을 시작해보세요
          </p>
          <button className="bg-gradient-to-r from-blue-500 to-sky-500 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-xl shadow-blue-500/50 hover:shadow-2xl hover:shadow-blue-500/70 transition-all duration-300 hover:scale-105 group border border-blue-400/50">
            <span className="flex items-center justify-center">
              ✨ 희망의 상담 신청
              <svg className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </span>
          </button>
        </div>
      </div>
    </section>
  );
}