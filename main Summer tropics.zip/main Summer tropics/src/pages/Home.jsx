// ============================================
// 🌺 Tropical Paradise Home.jsx - 황홀찬 밝고 파라다이스스러운 분위기
// ============================================
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AOS from 'aos';
import 'aos/dist/aos.css';

// 기존 컴포넌트들 활용
import TopBar from '../components/TopBar';
import AppHeader from '../components/AppHeader';
import NavBar from '../components/NavBar';
import Hero from '../components/Hero';
import FeatureExplanation from '../components/FeatureExplanation';
import FeatureList from '../components/FeatureList';
import CustomerCarousel from '../components/CustomerCarousel';
import PricingTable from '../components/PricingTable';
import ContentLeft from '../components/ContentLeft';
import Sidebar from '../components/Sidebar';
import Footer from '../components/Footer';

// 모달 컴포넌트들
import LoginModal from '../components/LoginModal';
import SignupModal from '../components/SignupModal';
import MyPageModal from '../components/MyPageModal';

// 더미 데이터 및 유틸리티
import { getUserFromStorage, removeUserFromStorage } from '../data/dummyUsers';

export default function Home() {
  // 🔮 React Router 네비게이션 훅 (열대 속 안내자)
  const navigate = useNavigate();
  
  // 🌺 모달 상태 관리 (황홀 속 모달들)
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isSignupModalOpen, setIsSignupModalOpen] = useState(false);
  const [isMyPageModalOpen, setIsMyPageModalOpen] = useState(false);
  
  // 🏝️ 로그인 상태 관리 (파라다이스 사용자)
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // 🌺 버튼 클릭 상태 관리 (열대의 클릭들)
  const [clickedButtons, setClickedButtons] = useState({
    login: false,
    signup: false,
    mypage: false,
    upload: false,
    demo: false
  });

  // 🌴 업로드 페이지로 이동 함수 (열대 속으로)
  const handleNavigateToUpload = () => {
    // 열대의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, upload: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, upload: false }));
    }, 200);
    
    // 파라다이스 존재 확인
    if (!currentUser) {
      alert('🌺 파라다이스의 황홀이 필요합니다. 로그인하여 열대에 참여하세요.');
      return;
    }
    
    navigate('/upload');
  };

  // 업로드 페이지로 이동하는 함수 (낙원문 열기)
  const handleStartUpload = () => {
    // 열대의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, upload: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, upload: false }));
    }, 200);
    
    // 파라다이스 존재 확인
    if (!currentUser) {
      alert('🏝️ 낙원문에 들어가려면 먼저 파라다이스의 황홀을 받아야 합니다.');
      return;
    }
    
    navigate('/upload');
  };

  // 🌅 로그인 모달 관리 함수들 (노을의 문)
  const handleOpenLogin = () => {
    // 노을의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, login: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, login: false }));
    }, 200);
    
    setIsLoginModalOpen(true);
  };

  const handleCloseLogin = () => {
    setIsLoginModalOpen(false);
  };

  const handleOpenSignup = () => {
    // 노을의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, signup: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, signup: false }));
    }, 200);
    
    setIsSignupModalOpen(true);
  };

  const handleCloseSignup = () => {
    setIsSignupModalOpen(false);
  };

  // 모달 간 전환 함수들 (차원 이동)
  const handleSwitchToSignup = () => {
    setIsLoginModalOpen(false);
    setIsSignupModalOpen(true);
  };

  const handleSwitchToLogin = () => {
    setIsSignupModalOpen(false);
    setIsLoginModalOpen(true);
  };

  // 🌺 로그인 성공 핸들러 (영혼 결속)
  const handleLoginSuccess = (user) => {
    setCurrentUser(user);
    setIsLoginModalOpen(false);
  };

  // 🏖️ 회원가입 성공 핸들러 (영혼 계약)
  const handleSignupSuccess = (user) => {
    setCurrentUser(user);
    setIsSignupModalOpen(false);
  };

  // 🌴 로그아웃 핸들러 (영혼 해방)
  const handleLogout = () => {
    setCurrentUser(null);
    removeUserFromStorage();
  };

  // 🏝️ 마이페이지 핸들러 (영혼의 방)
  const handleOpenMyPage = () => {
    // 노을의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, mypage: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, mypage: false }));
    }, 200);
    
    setIsMyPageModalOpen(true);
  };

  const handleCloseMyPage = () => {
    setIsMyPageModalOpen(false);
  };

  // 🌅 사용자 정보 업데이트 핸들러 (영혼 변화)
  const handleUserUpdate = (updatedUser) => {
    setCurrentUser(updatedUser);
  };

  // 🎭 데모 영상 핸들러 (파라다이스 시연)
  const handleDemoClick = () => {
    // 노을의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, demo: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, demo: false }));
    }, 200);
    
    // 여기에 파라다이스 데모 영상 로직 추가 가능
    console.log('🎬 열대 속 데모 영상이 재생됩니다...');
  };

  useEffect(() => {
    // AOS 초기화 (열대의 애니메이션)
    AOS.init({
      duration: 1200,
      easing: 'ease-out-cubic',
      once: true,
      offset: 50,
      delay: 200
    });

    // 스크롤 시 열대의 새로고침
    const handleScroll = () => {
      AOS.refresh();
    };

    window.addEventListener('scroll', handleScroll);

    // 영혼 저장소에서 사용자 정보 확인
    const storedUser = getUserFromStorage();
    if (storedUser) {
      setCurrentUser(storedUser);
    }
    setIsLoading(false);

    // 페이지 로드 완료 후 열대 속으로 스크롤
    window.scrollTo(0, 0);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-orange-50 to-yellow-100 overflow-x-hidden relative">
      {/* 열대의 배경 효과 */}
      <div className="fixed inset-0 bg-gradient-to-br from-pink-50 via-orange-50 to-yellow-100 opacity-90 z-0"></div>
      <div className="fixed inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(244,114,182,0.1)_100%)] z-0"></div>
      
      {/* 움직이는 파라다이스들 */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute -top-40 -left-40 w-80 h-80 bg-pink-200/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -right-40 w-80 h-80 bg-orange-200/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/4 w-60 h-60 bg-yellow-300/30 rounded-full blur-2xl animate-pulse delay-500"></div>
      </div>

      {/* 메인 콘텐츠 (열대 속 내용) */}
      <div className="relative z-10">
        {/* 최상단 바 (황홀의 경계) */}
        <TopBar />
        
        {/* 헤더 (황홀의 관문) */}
        <AppHeader 
          currentUser={currentUser}
          onOpenLogin={handleOpenLogin}
          onOpenSignup={handleOpenSignup}
          onLogout={handleLogout}
          onOpenMyPage={handleOpenMyPage}
        />

        {/* 네비게이션 (열대의 길잡이) */}
        <NavBar />

        {/* 메인 콘텐츠 */}
        <main className="bg-white/50 backdrop-blur-sm">
          {/* 히어로 섹션 (황홀의 영웅) */}
          <Hero onNext={handleNavigateToUpload} />

          {/* 기능 설명 섹션 (열대의 기능들) */}
          <FeatureExplanation />

          {/* 주요 특징 섹션 (파라다이스의 특징들) */}
          <FeatureList />

          {/* 고객사 캐러셀 (황홀의 동맹) */}
          <CustomerCarousel />

          {/* 요금제 섹션 (파라다이스의 대가) */}
          <PricingTable />

          {/* 콘텐츠 + 사이드바 섹션 (열대의 소굴) */}
          <section className="py-16 bg-gradient-to-b from-white via-orange-50 to-pink-100 relative">
            <div className="container mx-auto px-4">
              <div className="flex flex-col lg:flex-row gap-8 max-w-7xl mx-auto">
                {/* 왼쪽 콘텐츠 (열대의 왼편) */}
                <ContentLeft />
                
                {/* 오른쪽 사이드바 (열대의 오른편) */}
                <Sidebar onNext={handleStartUpload} />
              </div>
            </div>
          </section>

          {/* 체험 CTA (열대의 유혹) */}
          <section className="py-20 bg-gradient-to-br from-pink-100 via-orange-50 to-yellow-50 relative overflow-hidden">
            {/* 낙원의 배경 장식 */}
            <div className="absolute inset-0 overflow-hidden">
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-pink-400/10 rounded-full blur-3xl animate-pulse"></div>
              <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-orange-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-yellow-300/20 rounded-full blur-3xl animate-pulse delay-500"></div>
              
              {/* 추가 열대 효과 */}
              <div className="absolute inset-0 bg-white/60"></div>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_30%,rgba(244,114,182,0.1)_70%)]"></div>
            </div>

            <div className="container mx-auto px-4 text-center relative z-10">
              <div className="max-w-4xl mx-auto">
                <h2 className="text-3xl md:text-4xl font-bold text-pink-600 mb-6 drop-shadow-lg">
                  🌺 파라다이스의 학습을 지금 체험해보세요
                </h2>
                <p className="text-lg text-pink-500 mb-8 leading-relaxed drop-shadow-sm">
                  빠르고 정확한 AI 황홀으로 당신의 학습이 낙원 같은 경험이 됩니다.
                  지금 바로 무료로 시작하여 파라다이스의 도움을 받아보세요!
                </p>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                  <button
                    onClick={handleNavigateToUpload}
                    className={`px-8 py-4 bg-gradient-to-r from-pink-600 to-orange-500 text-white font-bold rounded-2xl 
                    hover:from-pink-500 hover:to-orange-400 transition-all duration-300 transform hover:scale-105 
                    shadow-lg hover:shadow-xl hover:shadow-pink-500/50 border border-pink-400/50 group
                    ${clickedButtons.upload ? 'scale-95' : ''}`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className="text-xl group-hover:scale-110 transition-transform duration-200">🌺</span>
                      <span>무료로 파라다이스 체험하기</span>
                      <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </div>
                  </button>
                  
                  <button
                    onClick={handleDemoClick}
                    className={`px-8 py-4 bg-white/90 text-pink-600 font-semibold rounded-2xl border-2 border-pink-300
                    hover:bg-pink-50 hover:border-pink-400 transition-all duration-300 transform hover:scale-105 
                    shadow-lg hover:shadow-xl hover:shadow-pink-500/30 group backdrop-blur-sm
                    ${clickedButtons.demo ? 'scale-95' : ''}`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className="text-lg group-hover:scale-110 transition-transform duration-200">🎥</span>
                      <span>데모 영상 보기</span>
                    </div>
                  </button>
                </div>
                
                <div className="mt-8 flex justify-center items-center space-x-8 text-sm text-pink-400">
                  <div className="flex items-center space-x-2">
                    <span className="text-pink-500">✅</span>
                    <span>신용카드 필요없음</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-pink-500">✅</span>
                    <span>즉시 사용 가능</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-pink-500">✅</span>
                    <span>파라다이스 지원</span>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </main>

        {/* 황홀의 푸터 */}
        <Footer />

        {/* 열대로 올라가는 버튼 */}
        <ScrollToTopButton />
      </div>

      {/* 모달 컴포넌트들 (황홀의 창문들) */}
      <LoginModal 
        isOpen={isLoginModalOpen}
        onClose={handleCloseLogin}
        onSwitchToSignup={handleSwitchToSignup}
        onLoginSuccess={handleLoginSuccess}
      />
      
      <SignupModal 
        isOpen={isSignupModalOpen}
        onClose={handleCloseSignup}
        onSwitchToLogin={handleSwitchToLogin}
        onSignupSuccess={handleSignupSuccess}
      />

      <MyPageModal 
        isOpen={isMyPageModalOpen}
        onClose={handleCloseMyPage}
        currentUser={currentUser}
        onUserUpdate={handleUserUpdate}
      />
    </div>
  );
}

// 열대의 정상으로 올라가는 버튼 컴포넌트
function ScrollToTopButton() {
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  if (!isVisible) return null;

  return (
    <button
      onClick={scrollToTop}
      className="fixed bottom-8 right-8 w-12 h-12 bg-gradient-to-r from-pink-600 to-orange-500 text-white rounded-full shadow-lg hover:shadow-xl hover:shadow-pink-500/50 transition-all duration-300 hover:scale-110 z-50 flex items-center justify-center group border border-pink-400/50"
      title="파라다이스 맨 위로"
    >
      <svg className="w-6 h-6 group-hover:scale-110 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
      </svg>
    </button>
  );
}