// ============================================
// 💀 Dark Horror GradingProgress.jsx - 심판 대기 페이지
// ============================================
// 📊 주요 기능:
// - 심판 상태 추적 (영혼 대기 → 심판 완료)
// - 실시간 저주 카운트다운 타이머
// - 어둠의 진행률 표시 (0% → 100%)
// - 지옥 서비스 소개 슬라이드
// - 반응형 어둠 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

export default function GradingProgress() {
  // 🧭 어둠의 라우터 훅
  const location = useLocation();
  const navigate = useNavigate();
  
  // 📝 업로드된 영혼 데이터
  const uploadData = location.state?.uploadData;

  // 📊 상태 관리
  const [status, setStatus] = useState('영혼 대기'); // '영혼 대기' | '심판 진행' | '심판 완료'
  const [progress, setProgress] = useState(0); // 어둠의 진행률 (0-100)
  const [timeLeft, setTimeLeft] = useState(6); // 남은 시간 (초) - 666초의 축약
  const [currentSlide, setCurrentSlide] = useState(0); // 현재 슬라이드 인덱스

  // 🎯 어둠의 학습법 및 활용팁 슬라이드 데이터
  const serviceSlides = [
    {
      title: "📚 어둠의 효과적인 학습 전략",
      description: "지옥의 체계적인 학습 계획으로 영혼의 성적을 향상시키는 방법을 알아보세요",
      features: [
        "주기적인 악마 모의고사 활용",
        "영혼의 취약점 집중 저주",
        "어둠의 학습 진도 체크리스트 작성"
      ],
      color: "from-red-600 to-black"
    },
    {
      title: "📝 저주받은 오답노트 활용법",
      description: "틀린 문제를 지옥의 체계로 정리하여 영혼의 실력을 키우는 방법입니다",
      features: [
        "오답 원인 악마 분석하기",
        "유사 문제 저주 반복 학습",
        "정기적인 지옥 복습 스케줄"
      ],
      color: "from-red-700 to-red-900"
    },
    {
      title: "🔄 어둠의 반복학습 전략",
      description: "악마의 과학적인 반복 학습으로 영혼의 장기 기억을 강화하는 방법입니다",
      features: [
        "망각 곡선 악마 활용한 복습",
        "단계별 지옥 난이도 조절",
        "성취도 기반 저주 학습량 조정"
      ],
      color: "from-black to-red-800"
    },
    {
      title: "📊 영혼의 성취도 추적 관리",
      description: "학습 성과를 어둠으로 시각화하여 저주 동기부여와 목표 달성을 도와드립니다",
      features: [
        "성적 변화 지옥 그래프 분석",
        "과목별 악마 강약점 파악",
        "학습 목표 저주 설정과 달성"
      ],
      color: "from-red-900 to-black"
    }
  ];

  // ⏰ 어둠의 타이머 및 진행률 관리
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          setStatus('심판 완료');
          setProgress(100);
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });

      // 어둠의 진행률 업데이트 (6초 기준)
      setProgress(prev => {
        const newProgress = ((6 - timeLeft + 1) / 6) * 100;
        return Math.min(newProgress, 100);
      });

      // 어둠의 상태 업데이트
      if (timeLeft <= 3 && timeLeft > 1) {
        setStatus('심판 진행');
      } else if (timeLeft <= 1) {
        setStatus('심판 완료');
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  // 🎠 어둠의 슬라이드 자동 전환
  useEffect(() => {
    const slideTimer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % serviceSlides.length);
    }, 4000); // 4초마다 슬라이드 변경

    return () => clearInterval(slideTimer);
  }, [serviceSlides.length]);

  // 🏠 지옥으로 돌아가기
  const handleBackToHome = () => {
    navigate('/');
  };

  // 📊 심판 결과 보기 (심판 완료 시)
  const handleViewResults = () => {
    navigate('/grading-result', { 
      state: { 
        ...uploadData,
        score: 66,
        totalQuestions: 13,
        correctAnswers: 6,
        timeSpent: '66분 6초'
      }
    });
  };

  // 업로드 데이터가 없으면 지옥으로 리다이렉트
  if (!uploadData) {
    navigate('/');
    return null;
  }

  // ⏰ 어둠의 시간 포맷팅
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 📊 상태별 어둠의 아이콘
  const getStatusIcon = () => {
    switch (status) {
      case '영혼 대기':
        return (
          <div className="w-16 h-16 bg-red-900/60 rounded-full flex items-center justify-center border border-red-700/50 shadow-lg shadow-red-500/50">
            <svg className="w-8 h-8 text-red-400 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
        );
      case '심판 진행':
        return (
          <div className="w-16 h-16 bg-red-800/60 rounded-full flex items-center justify-center border border-red-600/50 shadow-lg shadow-red-500/50">
            <svg className="w-8 h-8 text-red-300 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </div>
        );
      case '심판 완료':
        return (
          <div className="w-16 h-16 bg-red-700/60 rounded-full flex items-center justify-center border border-red-600/50 shadow-lg shadow-red-500/50">
            <svg className="w-8 h-8 text-red-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-red-900 relative overflow-hidden">
      {/* 어둠의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-gray-900/60 to-red-900/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_50%,black_80%)]"></div>
      
      {/* 움직이는 어둠 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-1/4 w-2 h-2 bg-red-500/30 rounded-full animate-pulse"></div>
        <div className="absolute top-40 right-1/3 w-1 h-1 bg-red-400/40 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-32 left-1/2 w-1 h-1 bg-gray-500/30 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-red-600/40 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-red-300/30 rounded-full animate-pulse delay-1500"></div>
      </div>

      {/* 어둠의 헤더 */}
      <div className="bg-gradient-to-r from-black/80 to-red-900/60 shadow-lg shadow-red-500/20 border-b border-red-800/50 relative z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToHome}
                className="text-red-400 hover:text-red-300 mr-4 transition-colors duration-200"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent drop-shadow-lg">
                💀 AI 심판 진행 중
              </h1>
            </div>
            
            {/* 어둠의 진행률 표시 */}
            <div className="hidden md:flex items-center space-x-4">
              <div className="text-sm text-red-400/80">
                심판률: <span className="font-bold text-red-400">{Math.round(progress)}%</span>
              </div>
              <div className="text-sm text-red-400/80">
                남은 어둠: <span className="font-bold text-red-400">{formatTime(timeLeft)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* 왼쪽: 심판 진행 상황 */}
            <div className="space-y-6">
              {/* 과목/학년 정보 카드 */}
              <div className="bg-gradient-to-br from-red-900/30 to-black/60 rounded-3xl shadow-2xl shadow-red-500/20 p-6 border border-red-800/50 backdrop-blur-sm">
                <h3 className="text-lg font-semibold text-red-300 mb-4 text-center drop-shadow-lg">💀 심판 정보</h3>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-red-600 rounded-full mr-3"></div>
                    <span className="text-red-400/80 text-sm">저주받은 과목:</span>
                    <span className="font-medium text-red-300 ml-2">{uploadData.subject}</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-red-700 rounded-full mr-3"></div>
                    <span className="text-red-400/80 text-sm">영혼 학년:</span>
                    <span className="font-medium text-red-300 ml-2">{uploadData.grade}</span>
                  </div>
                  {uploadData.examType && (
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-red-800 rounded-full mr-3"></div>
                      <span className="text-red-400/80 text-sm">심판 유형:</span>
                      <span className="font-medium text-red-300 ml-2">{uploadData.examType}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* 심판 진행 상황 통합 카드 */}
              <div className="bg-gradient-to-br from-red-900/30 to-black/60 rounded-3xl shadow-2xl shadow-red-500/20 p-8 border border-red-800/50 backdrop-blur-sm">
                <h3 className="text-xl font-bold text-red-300 mb-6 text-center drop-shadow-lg">💀 심판 진행 상황</h3>
                
                {/* 상태, 시간, 진행률 테이블 */}
                <div className="space-y-6">
                  {/* 상태 섹션 */}
                  <div className="text-center border-b border-red-800/50 pb-6">
                    <div className="flex justify-center mb-4">
                      {getStatusIcon()}
                    </div>
                    <h2 className="text-2xl font-bold text-red-300 mb-2 drop-shadow-lg">
                      {status}
                    </h2>
                    <p className="text-red-400/80 drop-shadow-sm">
                      {status === '영혼 대기' && 'AI 악마 시스템이 영혼 시험지를 분석하고 있습니다'}
                      {status === '심판 진행' && 'YOLO8과 악마 OCR이 영혼 답안을 인식하고 있습니다'}
                      {status === '심판 완료' && '모든 어둠의 심판이 완료되었습니다!'}
                    </p>
                  </div>

                  {/* 시간 & 진행률 테이블 */}
                  <div className="grid grid-cols-2 gap-6">
                    {/* 남은 시간 */}
                    <div className="text-center">
                      <h4 className="text-sm font-semibold text-red-400/80 mb-2">남은 어둠</h4>
                      <div className="text-3xl font-bold bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent drop-shadow-lg">
                        {formatTime(timeLeft)}
                      </div>
                      <p className="text-red-500/70 text-xs mt-1">예상 완료시간</p>
                    </div>

                    {/* 진행률 */}
                    <div className="text-center">
                      <h4 className="text-sm font-semibold text-red-400/80 mb-2">심판률</h4>
                      <div className="text-3xl font-bold text-red-400 drop-shadow-lg">
                        {Math.round(progress)}%
                      </div>
                      <p className="text-red-500/70 text-xs mt-1">처리 완료도</p>
                    </div>
                  </div>

                  {/* 어둠의 진행률 바 */}
                  <div className="pt-4">
                    <div className="w-full bg-red-900/40 rounded-full h-4 mb-4 border border-red-800/50">
                      <div 
                        className="bg-gradient-to-r from-red-600 to-red-800 h-4 rounded-full transition-all duration-1000 relative overflow-hidden"
                        style={{ width: `${progress}%` }}
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-red-300/30 to-transparent transform -skew-x-12 animate-pulse"></div>
                      </div>
                    </div>

                    {/* 어둠의 진행 상태 */}
                    <div className="text-center">
                      {status === '영혼 대기' && (
                        <div className="bg-red-900/50 text-red-400 px-4 py-2 rounded-full text-sm font-medium border border-red-700/50 backdrop-blur-sm">
                          영혼 파일 업로드 중입니다.
                        </div>
                      )}
                      {status === '심판 진행' && (
                        <div className="bg-red-900/50 text-red-400 px-4 py-2 rounded-full text-sm font-medium border border-red-700/50 backdrop-blur-sm">
                          영혼 파일 업로드 완료되었습니다.
                        </div>
                      )}
                      {status === '심판 완료' && (
                        <div className="bg-red-900/50 text-red-400 px-4 py-2 rounded-full text-sm font-medium border border-red-700/50 backdrop-blur-sm">
                          💀 심판 결과 보기를 확인하세요
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* 어둠의 완료 버튼 */}
              {status === '심판 완료' && (
                <div className="text-center">
                  <button
                    onClick={handleViewResults}
                    className="bg-gradient-to-r from-red-700 to-black text-red-300 px-8 py-4 rounded-2xl font-bold text-lg shadow-2xl shadow-red-500/50 hover:shadow-2xl hover:shadow-red-500/70 transition-all duration-300 hover:scale-105 border border-red-700/50"
                  >
                    💀 심판 결과 보기
                  </button>
                </div>
              )}
            </div>

            {/* 오른쪽: 어둠의 서비스 소개 슬라이드 */}
            <div className="bg-gradient-to-br from-red-900/30 to-black/60 rounded-3xl shadow-2xl shadow-red-500/20 overflow-hidden border border-red-800/50 backdrop-blur-sm">
              <div className="p-6 border-b border-red-800/50">
                <h3 className="text-xl font-bold text-red-300 drop-shadow-lg">
                  어둠의 학습법 및 활용팁
                </h3>
                <p className="text-red-400/80 text-sm mt-1 drop-shadow-sm">
                  효과적인 지옥 학습 전략과 영혼 성적 향상 방법을 알아보세요
                </p>
              </div>

              {/* 어둠의 슬라이드 컨테이너 */}
              <div className="relative h-96 overflow-hidden">
                {serviceSlides.map((slide, index) => (
                  <div
                    key={index}
                    className={`absolute inset-0 transition-transform duration-500 ease-in-out ${
                      index === currentSlide ? 'translate-x-0' : 
                      index < currentSlide ? '-translate-x-full' : 'translate-x-full'
                    }`}
                  >
                    <div className={`h-full bg-gradient-to-br ${slide.color} p-8 text-red-300 relative overflow-hidden`}>
                      {/* 어둠의 배경 효과 */}
                      <div className="absolute inset-0 bg-gradient-to-br from-black/40 via-red-900/20 to-transparent"></div>
                      
                      <div className="flex flex-col justify-center h-full relative z-10">
                        <h4 className="text-2xl font-bold mb-4 drop-shadow-lg">{slide.title}</h4>
                        <p className="text-lg mb-6 text-red-300/90 drop-shadow-sm">{slide.description}</p>
                        
                        <div className="space-y-3">
                          {slide.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center">
                              <div className="w-2 h-2 bg-red-400/80 rounded-full mr-3"></div>
                              <span className="text-red-300/90 drop-shadow-sm">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* 어둠의 슬라이드 인디케이터 */}
              <div className="flex justify-center space-x-2 p-4 bg-black/60 backdrop-blur-sm">
                {serviceSlides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-200 ${
                      index === currentSlide ? 'bg-red-600' : 'bg-red-800/50 hover:bg-red-700'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* 하단 업로드 정보 */}
          <div className="mt-8 bg-gradient-to-br from-red-900/30 to-black/60 rounded-2xl shadow-lg shadow-red-500/20 p-6 border border-red-800/50 backdrop-blur-sm">
            <h4 className="text-lg font-semibold text-red-300 mb-4 drop-shadow-lg">업로드된 영혼 파일 정보</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <span className="text-red-500/70">영혼 파일명:</span>
                <p className="font-medium truncate text-red-400">{uploadData.fileName}</p>
              </div>
              <div>
                <span className="text-red-500/70">크기:</span>
                <p className="font-medium text-red-400">{(uploadData.fileSize / 1024 / 1024).toFixed(2)} MB</p>
              </div>
              <div>
                <span className="text-red-500/70">저주받은 과목:</span>
                <p className="font-medium text-red-400">{uploadData.subject}</p>
              </div>
              <div>
                <span className="text-red-500/70">영혼 학년:</span>
                <p className="font-medium text-red-400">{uploadData.grade}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}