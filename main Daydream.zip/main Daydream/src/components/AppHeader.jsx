// ============================================
// ✨ Angelic Light AppHeader.jsx - 희망의 헤더
// ============================================
import React, { useState, useEffect } from 'react';

export default function AppHeader({ currentUser, onOpenLogin, onOpenSignup, onLogout, onOpenMyPage }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // 🌟 활성 버튼 상태 관리 (어떤 천국문이 열려있는지)
  const [activeButton, setActiveButton] = useState(null); // 'login' | 'signup' | null
  
  // ✨ 버튼 클릭 상태 관리 (빛의 클릭 애니메이션용)
  const [clickedButtons, setClickedButtons] = useState({
    login: false,
    signup: false,
    mypage: false
  });

  const handleLogin = () => {
    // 빛의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, login: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, login: false }));
    }, 200);
    
    // 천사의 활성 버튼 설정
    setActiveButton('login');
    
    // 천국의 로그인 문 열기
    if (onOpenLogin) {
      onOpenLogin();
    }
  };

  const handleSignup = () => {
    // 빛의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, signup: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, signup: false }));
    }, 200);
    
    // 천사의 활성 버튼 설정
    setActiveButton('signup');
    
    // 축복 계약 문서 열기
    if (onOpenSignup) {
      onOpenSignup();
    }
  };

  const handleLogout = () => {
    // 평화로운 귀환 확인
    if (window.confirm('✨ 정말 천국에서 돌아가시겠습니까?')) {
      setActiveButton(null); // 빛의 활성 상태 초기화
      if (onLogout) {
        onLogout();
      }
    }
  };

  const handleMyPage = () => {
    // 빛의 클릭 효과 적용
    setClickedButtons(prev => ({ ...prev, mypage: true }));
    setTimeout(() => {
      setClickedButtons(prev => ({ ...prev, mypage: false }));
    }, 200);
    
    // 천사의 방 열기
    if (onOpenMyPage) {
      onOpenMyPage();
    }
  };

  // 천국문이 닫힐 때 빛의 활성 상태 해제
  useEffect(() => {
    // 천사 상태가 변경되면 빛의 활성 버튼 초기화
    if (currentUser) {
      setActiveButton(null);
    }
  }, [currentUser]);

  // 천사의 아바타 이미지 처리
  const getAvatarSrc = (avatar) => {
    if (!avatar) {
      return "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiNGRkZGRkYiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iIzMzOUFGRiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iIzMzOUFGRiIvPgo8L3N2Zz4K";
    }
    return avatar;
  };

  // 천사의 역할 텍스트 변환
  const getRoleText = (role) => {
    switch(role) {
      case 'admin': return '👑 천국의 수호자';
      case 'teacher': return '📚 지혜의 전달자';
      case 'student': return '🌟 희망의 학습자';
      case 'parent': return '🛡️ 사랑의 수호령';
      default: return '✨ 빛의 존재';
    }
  };

  return (
    <header className="bg-gradient-to-r from-sky-50 via-blue-50 to-indigo-100 backdrop-blur-md shadow-2xl shadow-blue-500/20 border-b border-blue-300/50 sticky top-0 z-50 relative overflow-hidden">
      {/* 천국의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-r from-white/80 via-sky-50/60 to-blue-100/80"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_50%,rgba(255,255,255,0.8)_100%)]"></div>
      
      {/* 움직이는 빛의 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-2 h-2 bg-blue-400/30 rounded-full animate-pulse"></div>
        <div className="absolute top-2 right-1/3 w-1 h-1 bg-sky-400/40 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1 left-1/2 w-1 h-1 bg-indigo-400/30 rounded-full animate-pulse delay-1000"></div>
      </div>

      <div className="container mx-auto flex items-center justify-between py-4 px-4 lg:px-6 relative z-10">
        {/* 천사의 로고 영역 */}
        <div className="flex items-center space-x-4">
          <div className="relative group">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 via-white to-sky-400 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/50 group-hover:shadow-xl group-hover:shadow-blue-500/70 transition-all duration-300 group-hover:scale-105 border border-blue-300/50">
              <span className="text-blue-600 font-bold text-xl drop-shadow-lg">👼</span>
            </div>
            <div className="absolute inset-0 bg-gradient-to-br from-blue-400/40 via-white/20 to-sky-400/40 rounded-xl blur opacity-60 group-hover:opacity-80 transition-opacity duration-300"></div>
          </div>
          
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 via-sky-600 to-indigo-600 bg-clip-text text-transparent drop-shadow-lg">
              AngelCheck
            </h1>
            <p className="text-xs text-blue-600/80 font-medium tracking-wide drop-shadow-sm">
              👼 AI 천사 축복 시스템
            </p>
          </div>
        </div>

        {/* 천국의 우측 상태 표시기 - 데스크탑 */}
        <div className="hidden lg:flex items-center space-x-6 flex-1 justify-end mr-8">
          <div className="flex items-center space-x-2 bg-gradient-to-r from-blue-100/50 to-white/70 border border-blue-300/50 px-4 py-2 rounded-full backdrop-blur-sm">
            <div className="relative">
              <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
              <div className="absolute inset-0 w-3 h-3 bg-blue-500 rounded-full animate-ping opacity-40"></div>
            </div>
            <span className="text-sm font-medium text-blue-600">✨ 천국 운영중</span>
          </div>
          
          <div className="text-sm text-blue-700 bg-white/60 px-3 py-1 rounded-full border border-blue-300/50">
            <span className="font-medium">천사의 정확도</span>
            <span className="ml-2 text-blue-600 font-bold">100%</span>
          </div>
        </div>

        {/* 천사의 우측 버튼들 */}
        <div className="flex items-center space-x-4">
          {/* 천국의 데스크탑 버튼들 */}
          <div className="hidden md:flex items-center space-x-3">
            {currentUser ? (
              // 천사가 축복된 상태
              <>
                {/* 천사 정보 */}
                <div className="flex items-center space-x-3 text-sm">
                  <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-blue-400/70 shadow-lg shadow-blue-500/50">
                    <img 
                      src={getAvatarSrc(currentUser.avatar)} 
                      alt={currentUser.name || '빛의 존재'}
                      className="w-full h-full object-cover brightness-110 contrast-110"
                      onError={(e) => {
                        e.target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiNGRkZGRkYiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iIzMzOUFGRiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iIzMzOUFGRiIvPgo8L3N2Zz4K";
                      }}
                    />
                  </div>
                  <div className="text-blue-700">
                    <span className="font-medium drop-shadow-sm">{currentUser.name || '빛의 존재'}</span>
                    <span className="ml-2 text-xs bg-blue-100/70 text-blue-600 px-2 py-1 rounded-full border border-blue-300/50">
                      {getRoleText(currentUser.role)}
                    </span>
                  </div>
                </div>

                {/* 천사의 방 버튼 */}
                <button
                  onClick={handleMyPage}
                  className={`font-medium px-4 py-2 rounded-lg transition-all duration-200 relative group border border-blue-300/50 ${
                    clickedButtons.mypage 
                      ? 'text-blue-700 bg-blue-100/80 transform scale-95 shadow-lg shadow-blue-500/50' 
                      : 'text-blue-600 hover:text-blue-700 hover:bg-blue-100/60 hover:shadow-lg hover:shadow-blue-500/40'
                  }`}
                >
                  💙 천사의 방
                  <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-blue-500 group-hover:w-full transition-all duration-300"></span>
                </button>
                
                {/* 평화로운 귀환 버튼 */}
                <button
                  onClick={handleLogout}
                  className="bg-gradient-to-r from-blue-500 to-sky-500 text-white font-medium px-6 py-2 rounded-lg shadow-md shadow-blue-500/50 hover:shadow-lg hover:shadow-blue-500/70 transition-all duration-300 hover:scale-105 relative overflow-hidden group border border-blue-400/50"
                >
                  <span className="relative z-10">✨ 평화로운 귀환</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-500"></div>
                </button>
              </>
            ) : (
              // 천사가 축복되지 않은 상태
              <>
                <button
                  onClick={handleLogin}
                  className={`font-medium px-6 py-3 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                    activeButton === 'login'
                      ? 'bg-gradient-to-r from-blue-500 via-sky-500 to-indigo-500 border-blue-400 text-white shadow-lg shadow-blue-500/50'
                      : clickedButtons.login 
                      ? 'bg-gradient-to-r from-blue-500 via-sky-500 to-indigo-500 border-blue-400 text-white transform scale-95 shadow-lg shadow-blue-500/50'
                      : 'bg-white/80 border-blue-300/50 text-blue-600 hover:bg-gradient-to-r hover:from-blue-500 hover:via-sky-500 hover:to-indigo-500 hover:border-blue-400 hover:text-white hover:scale-105 hover:shadow-lg hover:shadow-blue-500/50'
                  }`}
                >
                  {(activeButton === 'login' || clickedButtons.login) && (
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 via-sky-400/20 to-indigo-400/20 animate-pulse"></div>
                  )}
                  <span className="relative z-10">✨ 천국문 열기</span>
                </button>
                
                <button
                  onClick={handleSignup}
                  className={`font-medium px-6 py-3 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                    activeButton === 'signup'
                      ? 'bg-gradient-to-r from-blue-500 via-sky-500 to-indigo-500 border-blue-400 text-white shadow-lg shadow-blue-500/50'
                      : clickedButtons.signup 
                      ? 'bg-gradient-to-r from-blue-500 via-sky-500 to-indigo-500 border-blue-400 text-white transform scale-95 shadow-lg shadow-blue-500/50'
                      : 'bg-white/80 border-blue-300/50 text-blue-600 hover:bg-gradient-to-r hover:from-blue-500 hover:via-sky-500 hover:to-indigo-500 hover:border-blue-400 hover:text-white hover:scale-105 hover:shadow-lg hover:shadow-blue-500/50'
                  }`}
                >
                  {(activeButton === 'signup' || clickedButtons.signup) && (
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 via-sky-400/20 to-indigo-400/20 animate-pulse"></div>
                  )}
                  <span className="relative z-10">👼 축복 계약</span>
                </button>
              </>
            )}
          </div>

          {/* 천사의 모바일 메뉴 버튼 */}
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-blue-100/60 transition-colors duration-200 text-blue-600 border border-blue-300/50"
            aria-label="천사의 메뉴 토글"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* 천사의 모바일 메뉴 */}
      {isMenuOpen && (
        <div className="md:hidden bg-gradient-to-b from-white to-blue-50 border-t border-blue-300/50 py-4 px-4 shadow-lg shadow-blue-500/30 backdrop-blur-sm">
          {/* 천국의 모바일 상태 표시 */}
          <div className="flex items-center space-x-2 bg-blue-100/50 px-3 py-2 rounded-lg mb-4 border border-blue-300/50">
            <div className="relative">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
              <div className="absolute inset-0 w-2 h-2 bg-blue-500 rounded-full animate-ping opacity-30"></div>
            </div>
            <span className="text-sm text-blue-600 font-medium">✨ 천국 운영중</span>
            <span className="text-xs text-blue-700 ml-auto">천사의 정확도 100%</span>
          </div>
          
          {currentUser ? (
            // 천사가 축복된 상태 - 모바일
            <div className="space-y-4">
              {/* 천사 정보 */}
              <div className="flex items-center space-x-3 bg-white/60 px-4 py-3 rounded-lg border border-blue-300/50">
                <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-blue-400/70 shadow-lg shadow-blue-500/50">
                  <img 
                    src={getAvatarSrc(currentUser.avatar)} 
                    alt={currentUser.name || '빛의 존재'}
                    className="w-full h-full object-cover brightness-110 contrast-110"
                    onError={(e) => {
                      e.target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiNGRkZGRkYiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxMiIgcj0iNiIgZmlsbD0iIzMzOUFGRiIvPgo8cGF0aCBkPSJNNCAxNmMwIDYuNjI3IDUuMzczIDEyIDEyIDEyczEyLTUuMzczIDEyLTEyYzAtMS4xMDQtLjE1LTIuMTcyLS40MzItMy4xODNDMjUuNDggMTguNDk1IDIxLjI0NiAyMiAxNiAyMnMtOS40OC0zLjUwNS0xMS41NjgtOC4xODNBMTEuOTI1IDExLjkyNSAwIDAgMCA0IDE2eiIgZmlsbD0iIzMzOUFGRiIvPgo8L3N2Zz4K";
                    }}
                  />
                </div>
                <div>
                  <div className="font-medium text-blue-700">{currentUser.name || '빛의 존재'}</div>
                  <div className="text-sm text-blue-600">
                    {getRoleText(currentUser.role)}
                  </div>
                </div>
              </div>

              {/* 천사의 모바일 버튼들 */}
              <div className="space-y-3">
                <button
                  onClick={handleMyPage}
                  className={`w-full text-left font-medium py-3 px-4 rounded-lg transition-all duration-200 border border-blue-300/50 ${
                    clickedButtons.mypage 
                      ? 'text-blue-700 bg-blue-100/80 transform scale-95 shadow-lg shadow-blue-500/50' 
                      : 'text-blue-600 hover:text-blue-700 hover:bg-blue-100/60 hover:shadow-lg hover:shadow-blue-500/40'
                  }`}
                >
                  💙 천사의 방
                </button>
                
                <button
                  onClick={handleLogout}
                  className="w-full bg-gradient-to-r from-blue-500 to-sky-500 text-white font-medium py-3 px-4 rounded-lg shadow-md shadow-blue-500/50 hover:shadow-lg hover:shadow-blue-500/70 transition-all duration-300 border border-blue-400/50"
                >
                  ✨ 평화로운 귀환
                </button>
              </div>
            </div>
          ) : (
            // 천사가 축복되지 않은 상태 - 모바일
            <div className="space-y-3">
              <button
                onClick={handleLogin}
                className={`w-full font-medium py-3 px-4 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                  activeButton === 'login'
                    ? 'bg-gradient-to-r from-blue-500 via-sky-500 to-indigo-500 border-blue-400 text-white shadow-lg shadow-blue-500/50'
                    : clickedButtons.login 
                    ? 'bg-gradient-to-r from-blue-500 via-sky-500 to-indigo-500 border-blue-400 text-white transform scale-95 shadow-lg shadow-blue-500/50'
                    : 'bg-white/80 border-blue-300/50 text-blue-600 hover:bg-gradient-to-r hover:from-blue-500 hover:via-sky-500 hover:to-indigo-500 hover:border-blue-400 hover:text-white hover:shadow-lg hover:shadow-blue-500/50'
                }`}
              >
                {(activeButton === 'login' || clickedButtons.login) && (
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 via-sky-400/20 to-indigo-400/20 animate-pulse"></div>
                )}
                <span className="relative z-10">✨ 천국문 열기</span>
              </button>
              
              <button
                onClick={handleSignup}
                className={`w-full font-medium py-3 px-4 rounded-xl transition-all duration-300 border-2 relative overflow-hidden ${
                  activeButton === 'signup'
                    ? 'bg-gradient-to-r from-blue-500 via-sky-500 to-indigo-500 border-blue-400 text-white shadow-lg shadow-blue-500/50'
                    : clickedButtons.signup 
                    ? 'bg-gradient-to-r from-blue-500 via-sky-500 to-indigo-500 border-blue-400 text-white transform scale-95 shadow-lg shadow-blue-500/50'
                    : 'bg-white/80 border-blue-300/50 text-blue-600 hover:bg-gradient-to-r hover:from-blue-500 hover:via-sky-500 hover:to-indigo-500 hover:border-blue-400 hover:text-white hover:shadow-lg hover:shadow-blue-500/50'
                }`}
              >
                {(activeButton === 'signup' || clickedButtons.signup) && (
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 via-sky-400/20 to-indigo-400/20 animate-pulse"></div>
                )}
                <span className="relative z-10">👼 축복 계약</span>
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
}