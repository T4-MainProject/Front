// ============================================
// 💀 Dark Horror FeatureCard.jsx - 어둠의 특징 카드
// ============================================
import React, { useRef, useEffect } from 'react';
import { gsap } from 'gsap';

export default function FeatureCard({ 
  icon, 
  title, 
  description, 
  gradient = 'from-red-600 to-black',
  bgGradient = 'from-red-900/30 to-black/60',
  className = '',
  delay = 0,
  ...props 
}) {
  const cardRef = useRef(null);
  const iconRef = useRef(null);

  useEffect(() => {
    const card = cardRef.current;
    const iconEl = iconRef.current;

    if (!card || !iconEl) return;

    // 어둠의 초기 진입 애니메이션 (더 극적으로)
    gsap.fromTo(card, 
      { 
        y: 80, 
        opacity: 0, 
        scale: 0.7,
        rotationY: -30,
        filter: "blur(10px)"
      },
      { 
        y: 0, 
        opacity: 1, 
        scale: 1,
        rotationY: 0,
        filter: "blur(0px)",
        duration: 1.2, 
        ease: "power4.out",
        delay: delay 
      }
    );

    // 어둠의 호버 애니메이션 설정 (더 강렬하게)
    const handleMouseEnter = () => {
      gsap.to(card, {
        y: -12,
        scale: 1.05,
        rotationX: 5,
        duration: 0.4,
        ease: "power3.out"
      });

      gsap.to(iconEl, {
        scale: 1.25,
        rotation: -12,
        y: -5,
        duration: 0.4,
        ease: "back.out(2)"
      });
    };

    const handleMouseLeave = () => {
      gsap.to(card, {
        y: 0,
        scale: 1,
        rotationX: 0,
        duration: 0.4,
        ease: "power3.out"
      });

      gsap.to(iconEl, {
        scale: 1,
        rotation: 0,
        y: 0,
        duration: 0.4,
        ease: "power3.out"
      });
    };

    card.addEventListener('mouseenter', handleMouseEnter);
    card.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      card.removeEventListener('mouseenter', handleMouseEnter);
      card.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [delay]);

  return (
    <div 
      ref={cardRef}
      className={`
        bg-gradient-to-br ${bgGradient} p-8 rounded-3xl shadow-2xl shadow-red-500/20 hover:shadow-2xl hover:shadow-red-500/40
        border border-red-800/50 transition-all duration-500 cursor-pointer group 
        relative overflow-hidden backdrop-blur-sm ${className}
      `}
      {...props}
    >
      {/* 어둠의 배경 호버 효과 */}
      <div className={`
        absolute inset-0 bg-gradient-to-br ${gradient} opacity-0 
        group-hover:opacity-20 transition-opacity duration-500 rounded-3xl
      `}></div>
      
      {/* 어둠의 배경 레이어 */}
      <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-gray-900/40 to-red-900/30 rounded-3xl"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,black_40%)] rounded-3xl"></div>
      
      {/* 떠다니는 악령 파티클들 */}
      <div className="absolute top-4 right-4 w-2 h-2 bg-red-500/40 rounded-full animate-pulse"></div>
      <div className="absolute bottom-6 left-6 w-1 h-1 bg-red-400/60 rounded-full animate-ping"></div>
      <div className="absolute top-1/2 right-8 w-1.5 h-1.5 bg-gray-500/50 rounded-full animate-bounce"></div>
      <div className="absolute top-1/3 left-4 w-1 h-1 bg-red-600/40 rounded-full animate-pulse delay-700"></div>
      <div className="absolute bottom-1/3 right-6 w-1 h-1 bg-red-300/30 rounded-full animate-ping delay-1000"></div>
      
      {/* 어둠의 아이콘 */}
      <div className="relative z-10 text-center mb-6">
        <div className="relative inline-block">
          <div 
            ref={iconRef}
            className={`
              inline-flex items-center justify-center w-20 h-20 
              bg-gradient-to-br from-black/80 to-red-900/60 rounded-2xl shadow-lg shadow-red-500/50 group-hover:shadow-xl group-hover:shadow-red-500/70
              transition-all duration-300 relative z-10 border border-red-700/50
            `}
          >
            <span className="text-4xl drop-shadow-lg filter">{icon}</span>
          </div>
          
          {/* 아이콘 어둠의 글로우 효과 */}
          <div className={`
            absolute inset-0 bg-gradient-to-br ${gradient} rounded-2xl 
            blur-lg opacity-0 group-hover:opacity-50 transition-opacity duration-300
          `}></div>
          
          {/* 추가 어둠 효과 */}
          <div className="absolute inset-0 bg-red-600/20 rounded-2xl blur-md opacity-0 group-hover:opacity-30 transition-opacity duration-500"></div>
        </div>
      </div>
      
      {/* 어둠의 콘텐츠 */}
      <div className="relative z-10 text-center">
        <h3 className="text-xl font-bold text-red-300 mb-4 group-hover:text-red-200 transition-colors duration-300 drop-shadow-lg">
          {title}
        </h3>
        <p className="text-red-400/90 leading-relaxed group-hover:text-red-300 transition-colors duration-300 drop-shadow-sm">
          {description}
        </p>
      </div>

      {/* 하단 어둠의 액센트 라인 */}
      <div className={`
        absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${gradient} 
        transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 
        origin-left rounded-b-3xl shadow-lg shadow-red-500/50
      `}></div>

      {/* 어둠의 코너 장식 */}
      <div className="absolute top-0 right-0 w-20 h-20 overflow-hidden rounded-tr-3xl">
        <div className={`
          absolute -top-8 -right-8 w-16 h-16 bg-gradient-to-br ${gradient} 
          rounded-full opacity-30 group-hover:opacity-60 transition-opacity duration-300 animate-pulse
        `}></div>
      </div>

      {/* 추가 어둠의 장식 요소들 */}
      <div className="absolute top-0 left-0 w-16 h-16 overflow-hidden rounded-tl-3xl">
        <div className="absolute -top-6 -left-6 w-12 h-12 bg-red-800/20 rounded-full opacity-40 group-hover:opacity-60 transition-opacity duration-300 animate-pulse delay-500"></div>
      </div>

      {/* 어둠의 경계선 효과 */}
      <div className="absolute inset-0 rounded-3xl border border-red-700/30 group-hover:border-red-600/50 transition-colors duration-300"></div>
      
      {/* 중앙 어둠 효과 */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-black/10 rounded-full blur-3xl opacity-0 group-hover:opacity-40 transition-opacity duration-700"></div>

      {/* 하단 어둠 그라데이션 */}
      <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-black/30 to-transparent rounded-b-3xl pointer-events-none"></div>
    </div>
  );
}