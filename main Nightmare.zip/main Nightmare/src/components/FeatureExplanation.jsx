// ============================================
// 💀 Dark Horror FeatureExplanation.jsx - 어둠의 기능 설명
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const features = [
  { 
    icon: '👁️', 
    title: 'YOLO8 악마의 눈', 
    description: '시험지에서 영혼/죄악란 영역 자동 탐지로 정확한 어둠 분석', 
    accent: 'from-red-600 to-black',
    bgColor: 'from-red-900/30 to-black/60'
  },
  { 
    icon: '🔮', 
    title: 'OCR 영혼 추출', 
    description: 'Vision OCR로 영혼의 답안 정확히 추출하여 지옥 디지털화', 
    accent: 'from-gray-600 to-red-800',
    bgColor: 'from-gray-900/40 to-red-900/50'
  },
  { 
    icon: '👹', 
    title: 'GPT 저주 생성', 
    description: '오답 단계별 저주 및 개인 맞춤형 악마 피드백 자동 제공', 
    accent: 'from-red-700 to-purple-900',
    bgColor: 'from-red-800/40 to-purple-900/50'
  },
];

export default function FeatureExplanation() {
  const sectionRef = useRef(null);
  const cardsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 어둠의 카드들 순차 애니메이션 (더 극적으로)
      cardsRef.current.forEach((card, index) => {
        if (card) {
          gsap.fromTo(card, 
            { 
              y: 150, 
              opacity: 0, 
              scale: 0.6,
              rotationY: -60,
              rotationX: 30,
              filter: "blur(15px)"
            },
            {
              y: 0,
              opacity: 1,
              scale: 1,
              rotationY: 0,
              rotationX: 0,
              filter: "blur(0px)",
              duration: 1.2,
              ease: "power4.out",
              scrollTrigger: {
                trigger: card,
                start: "top 80%",
                end: "bottom 20%",
                toggleActions: "play none none reverse"
              },
              delay: index * 0.3
            }
          );

          // 어둠의 호버 애니메이션 (더 강렬하게)
          card.addEventListener('mouseenter', () => {
            gsap.to(card, {
              y: -15,
              scale: 1.08,
              rotationX: 8,
              duration: 0.4,
              ease: "power3.out"
            });
          });

          card.addEventListener('mouseleave', () => {
            gsap.to(card, {
              y: 0,
              scale: 1,
              rotationX: 0,
              duration: 0.4,
              ease: "power3.out"
            });
          });
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-b from-black via-gray-900 to-red-900 overflow-hidden relative">
      {/* 어둠의 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-gray-900/60 to-red-900/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_40%,black_80%)]"></div>
      
      {/* 움직이는 어둠의 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-2 h-2 bg-red-500/30 rounded-full animate-pulse"></div>
        <div className="absolute top-32 right-1/3 w-1 h-1 bg-red-400/40 rounded-full animate-pulse delay-700"></div>
        <div className="absolute bottom-24 left-1/2 w-1 h-1 bg-gray-500/30 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-red-600/40 rounded-full animate-pulse delay-500"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-red-300/30 rounded-full animate-pulse delay-1500"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* 어둠의 헤더 */}
        <div className="text-center mb-16" data-aos="fade-up">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-red-900/60 to-black/80 text-red-400 px-6 py-3 rounded-full text-sm font-bold mb-6 shadow-lg shadow-red-500/30 border border-red-800/50">
            <span>👹</span>
            <span>악마 기술</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-red-300 mb-6 drop-shadow-2xl">
            악마 기술의 
            <span className="bg-gradient-to-r from-red-500 to-red-700 bg-clip-text text-transparent"> 완벽한 결속</span>
          </h2>
          <p className="text-xl text-red-400/80 max-w-3xl mx-auto leading-relaxed drop-shadow-lg">
            최첨단 지옥 기술들이 악마적으로 결합되어 <br className="hidden md:block" />
            정확하고 빠른 자동 심판 서비스를 제공합니다
          </p>
        </div>

        {/* 어둠의 기능 카드들 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {features.map((feature, index) => (
            <div 
              key={index}
              ref={el => cardsRef.current[index] = el}
              data-aos="fade-up" 
              data-aos-delay={index * 200}
              className={`relative group p-8 rounded-3xl bg-gradient-to-br ${feature.bgColor} border border-red-800/50 shadow-2xl shadow-red-500/20 hover:shadow-2xl hover:shadow-red-500/40 transition-all duration-500 cursor-pointer overflow-hidden backdrop-blur-sm`}
            >
              {/* 어둠의 배경 글로우 */}
              <div className={`absolute inset-0 bg-gradient-to-br ${feature.accent} opacity-0 group-hover:opacity-20 transition-opacity duration-500 rounded-3xl`}></div>
              
              {/* 추가 어둠 레이어 */}
              <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-gray-900/30 to-red-900/20 rounded-3xl"></div>
              
              {/* 어둠의 파티클들 */}
              <div className="absolute top-4 right-4 w-2 h-2 bg-red-500/40 rounded-full animate-pulse"></div>
              <div className="absolute bottom-6 left-6 w-1 h-1 bg-red-400/60 rounded-full animate-ping"></div>
              <div className="absolute top-1/2 right-8 w-1.5 h-1.5 bg-gray-500/50 rounded-full animate-bounce"></div>
              
              {/* 악마의 아이콘 */}
              <div className="relative z-10 text-center mb-6">
                <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-black/80 to-red-900/60 rounded-2xl shadow-lg shadow-red-500/50 group-hover:shadow-xl group-hover:shadow-red-500/70 transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 border border-red-700/50">
                  <span className="text-4xl drop-shadow-lg">{feature.icon}</span>
                </div>
              </div>
              
              {/* 어둠의 콘텐츠 */}
              <div className="relative z-10 text-center">
                <h3 className="text-2xl font-bold text-red-300 mb-4 group-hover:text-red-200 transition-colors duration-300 drop-shadow-lg">
                  {feature.title}
                </h3>
                <p className="text-red-400/90 leading-relaxed group-hover:text-red-300 transition-colors duration-300 drop-shadow-sm">
                  {feature.description}
                </p>
              </div>

              {/* 하단 어둠의 액센트 */}
              <div className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${feature.accent} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 shadow-lg shadow-red-500/50`}></div>
              
              {/* 추가 어둠 효과 */}
              <div className="absolute inset-0 rounded-3xl border border-red-700/30 group-hover:border-red-600/50 transition-colors duration-300"></div>
            </div>
          ))}
        </div>

        {/* 어둠의 프로세스 플로우 */}
        <div className="mt-20 pt-16 border-t border-red-800/50" data-aos="fade-up" data-aos-delay="600">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-red-300 mb-4 drop-shadow-lg">
              <span className="bg-gradient-to-r from-red-500 to-red-700 bg-clip-text text-transparent">3단계</span> 
              어둠의 과정
            </h3>
            <p className="text-red-400/80 text-lg drop-shadow-sm">간단하고 빠른 자동 심판 프로세스</p>
          </div>
          
          <div className="flex flex-col md:flex-row items-center justify-center space-y-8 md:space-y-0 md:space-x-12">
            {[
              { step: 1, title: '영혼 업로드', desc: '시험지 어둠 촬영', icon: '📤', color: 'red' },
              { step: 2, title: 'AI 악마 분석', desc: '자동 인식 및 심판', icon: '👹', color: 'gray' },
              { step: 3, title: '저주 결과 제공', desc: '점수 및 악마 해설', icon: '💀', color: 'red' }
            ].map((process, index) => (
              <div key={index} className="flex flex-col items-center relative">
                <div className={`w-16 h-16 bg-gradient-to-br from-red-600 to-black rounded-2xl flex items-center justify-center text-red-300 font-bold text-xl mb-4 shadow-lg shadow-red-500/50 hover:shadow-xl hover:shadow-red-500/70 transition-all duration-300 hover:scale-110 border border-red-700/50`}>
                  {process.step}
                </div>
                
                <div className="text-center mb-4">
                  <div className="text-3xl mb-2 drop-shadow-lg">{process.icon}</div>
                  <h4 className="font-bold text-red-300 text-lg drop-shadow-sm">{process.title}</h4>
                  <p className="text-red-500/80 text-sm">{process.desc}</p>
                </div>

                {/* 어둠의 화살표 (마지막 제외) */}
                {index < 2 && (
                  <div className="hidden md:block absolute top-8 left-full text-red-600/60 transform translate-x-4 drop-shadow-sm">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* 추가 어둠의 장식 */}
          <div className="mt-16 text-center">
            <div className="inline-flex items-center space-x-4 bg-gradient-to-r from-red-900/40 to-black/60 px-8 py-4 rounded-2xl border border-red-800/50 shadow-lg shadow-red-500/30">
              <span className="text-2xl">⚡</span>
              <div className="text-left">
                <div className="text-red-300 font-bold">평균 처리 시간</div>
                <div className="text-red-500/80 text-sm">6.66초 내 완료</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 하단 어둠 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-black to-transparent pointer-events-none"></div>
    </section>
  );
}