// ============================================
// 💀 Dark Horror ContentLeft.jsx - 어둠의 소식
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const updates = [
  {
    type: 'update',
    title: 'AI 악마 성능 대폭 강화',
    date: '2025.01.20',
    content: 'YOLO8 지옥 버전 적용으로 영혼 인식 정확도가 13.3% 향상되었습니다. 특히 저주받은 글씨 해독 능력이 크게 개선되었습니다.',
    icon: '👹',
    color: 'red',
    badge: '저주'
  },
  {
    type: 'feature',
    title: '대량 심판 기능 지옥 출시',
    date: '2025.01.15',
    content: '여러 영혼을 한 번에 업로드하여 일괄 심판할 수 있는 대량 처리 기능이 추가되었습니다. 최대 666장까지 동시 처리 가능합니다.',
    icon: '🔥',
    color: 'dark',
    badge: '악마'
  },
  {
    type: 'notice',
    title: '새로운 저주 템플릿 추가',
    date: '2025.01.10',
    content: '수학, 과학, 언어 과목별 맞춤형 저주 템플릿이 추가되어 더욱 잔혹하고 정확한 심판을 제공합니다.',
    icon: '📜',
    color: 'purple',
    badge: null
  },
  {
    type: 'maintenance',
    title: '지옥 서버 최적화 완료',
    date: '2025.01.05',
    content: '어둠의 안정성 향상을 위한 지옥 서버 최적화 작업이 완료되어 처리 속도가 평균 66.6% 향상되었습니다.',
    icon: '⚡',
    color: 'gray',
    badge: null
  }
];

const quickLinks = [
  { title: '악마 사용 가이드', icon: '📚', desc: '지옥의 사용법 익히기' },
  { title: '공포 튜토리얼', icon: '🎥', desc: '악몽으로 배우기' },
  { title: '저주받은 질문들', icon: '❓', desc: '지옥 FAQ 확인하기' },
  { title: '어둠의 지원', icon: '🛠️', desc: '악마의 도움받기' }
];

export default function ContentLeft() {
  const sectionRef = useRef(null);
  const cardsRef = useRef([]);
  const linksRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 어둠의 업데이트 카드들 순차 애니메이션
      gsap.fromTo(cardsRef.current,
        {
          x: -80,
          opacity: 0,
          scale: 0.8,
          rotationY: -30
        },
        {
          x: 0,
          opacity: 1,
          scale: 1,
          rotationY: 0,
          duration: 0.8,
          stagger: 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // 어둠의 퀵링크 애니메이션
      gsap.fromTo(linksRef.current,
        {
          y: 50,
          opacity: 0,
          scale: 0.9
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          duration: 0.6,
          stagger: 0.12,
          ease: "back.out(1.7)",
          delay: 0.4,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const getColorClasses = (color) => {
    const colors = {
      red: {
        bg: 'bg-gradient-to-r from-red-900/30 to-black/50',
        border: 'border-l-red-600',
        text: 'text-red-400',
        badge: 'bg-red-600'
      },
      dark: {
        bg: 'bg-gradient-to-r from-gray-900/50 to-red-900/30',
        border: 'border-l-gray-600',
        text: 'text-gray-300',
        badge: 'bg-gray-700'
      },
      purple: {
        bg: 'bg-gradient-to-r from-purple-900/30 to-black/50',
        border: 'border-l-purple-600',
        text: 'text-purple-400',
        badge: 'bg-purple-600'
      },
      gray: {
        bg: 'bg-gradient-to-r from-gray-800/50 to-gray-900/50',
        border: 'border-l-gray-500',
        text: 'text-gray-400',
        badge: 'bg-gray-600'
      }
    };
    return colors[color];
  };

  return (
    <section ref={sectionRef} className="flex-1">
      <div className="bg-gradient-to-br from-black via-gray-900 to-red-900 rounded-3xl shadow-2xl shadow-red-500/20 border border-red-800/50 overflow-hidden h-full relative">
        {/* 어둠의 배경 효과 */}
        <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-gray-900/60 to-red-900/40"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,black_100%)]"></div>
        
        {/* 움직이는 어둠의 파티클들 */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-4 left-8 w-1 h-1 bg-red-500/40 rounded-full animate-pulse"></div>
          <div className="absolute top-12 right-12 w-1 h-1 bg-red-400/30 rounded-full animate-pulse delay-700"></div>
          <div className="absolute bottom-16 left-16 w-1 h-1 bg-gray-500/40 rounded-full animate-pulse delay-1000"></div>
        </div>

        {/* 어둠의 헤더 */}
        <div className="bg-gradient-to-r from-red-900/50 to-black/70 p-6 border-b border-red-800/50 relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-black rounded-2xl flex items-center justify-center shadow-lg shadow-red-500/50 border border-red-700/50">
                <span className="text-red-300 text-2xl drop-shadow-lg">💀</span>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-red-300 drop-shadow-lg">
                  어둠의 소식 & 저주 업데이트
                </h2>
                <p className="text-red-500/80 text-sm drop-shadow-sm">
                  지옥의 개선사항과 새로운 저주를 확인하세요
                </p>
              </div>
            </div>
            <button className="bg-black/60 hover:bg-red-900/60 border border-red-700/50 hover:border-red-600 text-red-400 hover:text-red-300 px-4 py-2 rounded-xl font-medium transition-all duration-200 hover:scale-105 shadow-sm shadow-red-500/30 hover:shadow-md hover:shadow-red-500/50">
              🔥 모든 저주 보기
            </button>
          </div>
        </div>

        {/* 어둠의 업데이트 목록 */}
        <div className="p-6 space-y-4 max-h-96 overflow-y-auto relative z-10">
          {updates.map((update, index) => {
            const colors = getColorClasses(update.color);
            return (
              <div 
                key={index}
                ref={el => cardsRef.current[index] = el}
                className={`
                  ${colors.bg} ${colors.border}
                  p-5 rounded-2xl border-l-4 hover:shadow-lg hover:shadow-red-500/30 transition-all duration-300 
                  cursor-pointer group relative overflow-hidden backdrop-blur-sm
                `}
              >
                {/* 어둠의 배경 호버 효과 */}
                <div className="absolute inset-0 bg-gradient-to-r from-red-900/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                <div className="flex items-start space-x-4 relative z-10">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-black/60 rounded-xl shadow-md shadow-red-500/30 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 border border-red-800/50">
                      <span className="text-2xl drop-shadow-lg">{update.icon}</span>
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <h3 className="font-bold text-red-300 group-hover:text-red-200 transition-colors duration-200 drop-shadow-sm">
                          {update.title}
                        </h3>
                        {update.badge && (
                          <span className={`${colors.badge} text-red-200 px-2 py-1 rounded-full text-xs font-bold animate-pulse border border-red-700/50`}>
                            {update.badge}
                          </span>
                        )}
                      </div>
                      <span className="text-sm text-red-500/80 flex-shrink-0">
                        {update.date}
                      </span>
                    </div>
                    <p className="text-red-400/90 text-sm leading-relaxed group-hover:text-red-300 transition-colors duration-200 drop-shadow-sm">
                      {update.content}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* 어둠의 퀵 액세스 링크 */}
        <div className="p-6 bg-gradient-to-b from-black/60 to-red-900/40 border-t border-red-800/50 relative z-10">
          <h3 className="font-bold text-red-300 mb-4 flex items-center drop-shadow-sm">
            <span className="text-lg mr-2">🔗</span>
            어둠의 바로가기
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {quickLinks.map((link, index) => (
              <button
                key={index}
                ref={el => linksRef.current[index] = el}
                className="flex items-center space-x-3 p-4 bg-black/40 hover:bg-gradient-to-r hover:from-red-900/40 hover:to-black/60 rounded-xl transition-all duration-300 group border border-red-800/50 hover:border-red-600 hover:shadow-md hover:shadow-red-500/30"
              >
                <span className="text-2xl group-hover:scale-110 transition-transform duration-200 drop-shadow-sm">
                  {link.icon}
                </span>
                <div className="text-left">
                  <div className="font-medium text-red-300 group-hover:text-red-200 transition-colors duration-200 text-sm drop-shadow-sm">
                    {link.title}
                  </div>
                  <div className="text-xs text-red-500/80 group-hover:text-red-400 transition-colors duration-200">
                    {link.desc}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* 추가 어둠 효과 */}
        <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-black to-transparent pointer-events-none"></div>
      </div>
    </section>
  );
}