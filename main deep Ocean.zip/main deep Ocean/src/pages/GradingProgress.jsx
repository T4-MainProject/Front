// ============================================
// 🌊 Deep Ocean GradingProgress.jsx - 바다 분석 대기 페이지
// ============================================
// 📊 주요 기능:
// - 바다 분석 상태 추적 (파일 대기 → 분석 완료)
// - 실시간 심해 카운트다운 타이머
// - 아름다운 진행률 표시 (0% → 100%)
// - 심해 학습법 소개 슬라이드
// - 반응형 심해 디자인
// ============================================

import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

export default function GradingProgress() {
  // 🧭 심해 라우터 훅
  const location = useLocation();
  const navigate = useNavigate();
  
  // 📝 업로드된 파일 데이터
  const uploadData = location.state?.uploadData;

  // 📊 상태 관리
  const [status, setStatus] = useState('파일 대기'); // '파일 대기' | '분석 진행' | '분석 완료'
  const [progress, setProgress] = useState(0); // 바다 진행률 (0-100)
  const [timeLeft, setTimeLeft] = useState(6); // 남은 시간 (초)
  const [currentSlide, setCurrentSlide] = useState(0); // 현재 슬라이드 인덱스

  // 🎯 심해 학습법 및 활용팁 슬라이드 데이터
  const serviceSlides = [
    {
      title: "📚 바다 효과적인 학습 전략",
      description: "심해의 체계적인 학습 계획으로 성적을 향상시키는 방법을 알아보세요",
      features: [
        "주기적인 바다 모의고사 활용",
        "개인 취약점 집중 학습",
        "심해 학습 진도 체크리스트 작성"
      ],
      color: "from-indigo-600 to-cyan-500"
    },
    {
      title: "📝 바다 학습노트 활용법",
      description: "틀린 문제를 체계적으로 정리하여 실력을 키우는 방법입니다",
      features: [
        "오답 원인 분석하기",
        "유사 문제 반복 학습",
        "정기적인 복습 스케줄"
      ],
      color: "from-blue-600 to-teal-500"
    },
    {
      title: "🔄 심해 반복학습 전략",
      description: "과학적인 반복 학습으로 장기 기억을 강화하는 방법입니다",
      features: [
        "망각 곡선 활용한 복습",
        "단계별 난이도 조절",
        "성취도 기반 학습량 조정"
      ],
      color: "from-cyan-600 to-indigo-500"
    },
    {
      title: "📊 성취도 추적 관리",
      description: "학습 성과를 시각화하여 동기부여와 목표 달성을 도와드립니다",
      features: [
        "성적 변화 그래프 분석",
        "과목별 강약점 파악",
        "학습 목표 설정과 달성"
      ],
      color: "from-teal-600 to-blue-500"
    }
  ];

  // ⏰ 심해 타이머 및 진행률 관리
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          setStatus('분석 완료');
          setProgress(100);
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });

      // 바다 진행률 업데이트 (6초 기준)
      setProgress(prev => {
        const newProgress = ((6 - timeLeft + 1) / 6) * 100;
        return Math.min(newProgress, 100);
      });

      // 심해 상태 업데이트
      if (timeLeft <= 3 && timeLeft > 1) {
        setStatus('분석 진행');
      } else if (timeLeft <= 1) {
        setStatus('분석 완료');
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  // 🎠 심해 슬라이드 자동 전환
  useEffect(() => {
    const slideTimer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % serviceSlides.length);
    }, 4000); // 4초마다 슬라이드 변경

    return () => clearInterval(slideTimer);
  }, [serviceSlides.length]);

  // 🏠 심해로 돌아가기
  const handleBackToHome = () => {
    navigate('/');
  };

  // 📊 분석 결과 보기 (분석 완료 시)
  const handleViewResults = () => {
    navigate('/grading-result', { 
      state: { 
        ...uploadData,
        score: 85,
        totalQuestions: 20,
        correctAnswers: 17,
        timeSpent: '35분 20초'
      }
    });
  };

  // 업로드 데이터가 없으면 심해로 리다이렉트
  if (!uploadData) {
    navigate('/');
    return null;
  }

  // ⏰ 바다 시간 포맷팅
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 📊 상태별 심해 아이콘
  const getStatusIcon = () => {
    switch (status) {
      case '파일 대기':
        return (
          <div className="w-16 h-16 bg-slate-800/60 backdrop-blur-sm rounded-full flex items-center justify-center border border-slate-700/50 shadow-lg shadow-indigo-500/30">
            <svg className="w-8 h-8 text-cyan-400 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
        );
      case '분석 진행':
        return (
          <div className="w-16 h-16 bg-slate-800/60 backdrop-blur-sm rounded-full flex items-center justify-center border border-slate-700/50 shadow-lg shadow-blue-500/30">
            <svg className="w-8 h-8 text-blue-400 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </div>
        );
      case '분석 완료':
        return (
          <div className="w-16 h-16 bg-slate-800/60 backdrop-blur-sm rounded-full flex items-center justify-center border border-slate-700/50 shadow-lg shadow-cyan-500/30">
            <svg className="w-8 h-8 text-cyan-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-blue-950 relative overflow-hidden">
      {/* 심해 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900/80 via-indigo-900/60 to-blue-900/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_50%,rgba(15,23,42,0.8)_80%)]"></div>
      
      {/* 움직이는 심해 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-1/4 w-2 h-2 bg-blue-400/50 rounded-full animate-pulse shadow-lg shadow-blue-500/50"></div>
        <div className="absolute top-40 right-1/3 w-1 h-1 bg-indigo-400/60 rounded-full animate-pulse delay-700 shadow-lg shadow-indigo-500/50"></div>
        <div className="absolute bottom-32 left-1/2 w-1 h-1 bg-cyan-400/50 rounded-full animate-pulse delay-1000 shadow-lg shadow-cyan-500/50"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-teal-400/60 rounded-full animate-pulse delay-500 shadow-lg shadow-teal-500/50"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-blue-500/50 rounded-full animate-pulse delay-1500 shadow-lg shadow-blue-500/50"></div>
      </div>

      {/* 심해 헤더 */}
      <div className="bg-slate-800/60 backdrop-blur-md shadow-lg shadow-indigo-900/20 border-b border-slate-700/50 relative z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToHome}
                className="text-cyan-300 hover:text-cyan-200 mr-4 transition-colors duration-200 bg-slate-800/50 backdrop-blur-sm p-2 rounded-full border border-slate-700/50 shadow-lg hover:bg-slate-700/60"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className="text-2xl font-black bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent drop-shadow-lg">
                🌊 AI 바다 분석 진행 중
              </h1>
            </div>
            
            {/* 심해 진행률 표시 */}
            <div className="hidden md:flex items-center space-x-4">
              <div className="text-sm text-cyan-400 bg-slate-800/50 backdrop-blur-sm px-3 py-1 rounded-full border border-slate-700/50">
                분석률: <span className="font-bold text-cyan-300">{Math.round(progress)}%</span>
              </div>
              <div className="text-sm text-blue-400 bg-slate-800/50 backdrop-blur-sm px-3 py-1 rounded-full border border-slate-700/50">
                남은 시간: <span className="font-bold text-blue-300">{formatTime(timeLeft)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* 왼쪽: 분석 진행 상황 */}
            <div className="space-y-6">
              {/* 과목/학년 정보 카드 */}
              <div className="bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-indigo-900/20 p-6 border border-slate-700/50">
                <h3 className="text-lg font-black text-cyan-300 mb-4 text-center drop-shadow-lg">🌊 분석 정보</h3>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-cyan-500 rounded-full mr-3"></div>
                    <span className="text-cyan-400 text-sm">과목:</span>
                    <span className="font-bold text-cyan-300 ml-2">{uploadData.subject}</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                    <span className="text-blue-400 text-sm">학년:</span>
                    <span className="font-bold text-blue-300 ml-2">{uploadData.grade}</span>
                  </div>
                  {uploadData.examType && (
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-indigo-500 rounded-full mr-3"></div>
                      <span className="text-indigo-400 text-sm">분석 유형:</span>
                      <span className="font-bold text-indigo-300 ml-2">{uploadData.examType}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* 분석 진행 상황 통합 카드 */}
              <div className="bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-indigo-900/20 p-8 border border-slate-700/50">
                <h3 className="text-xl font-black text-cyan-300 mb-6 text-center drop-shadow-lg">🌊 분석 진행 상황</h3>
                
                {/* 상태, 시간, 진행률 테이블 */}
                <div className="space-y-6">
                  {/* 상태 섹션 */}
                  <div className="text-center border-b border-slate-700/50 pb-6">
                    <div className="flex justify-center mb-4">
                      {getStatusIcon()}
                    </div>
                    <h2 className="text-2xl font-black text-cyan-300 mb-2 drop-shadow-lg">
                      {status}
                    </h2>
                    <p className="text-cyan-400 drop-shadow-sm">
                      {status === '파일 대기' && 'AI 바다 시스템이 시험지를 분석하고 있습니다'}
                      {status === '분석 진행' && '심해 OCR이 답안을 인식하고 있습니다'}
                      {status === '분석 완료' && '모든 바다 분석이 완료되었습니다!'}
                    </p>
                  </div>

                  {/* 시간 & 진행률 테이블 */}
                  <div className="grid grid-cols-2 gap-6">
                    {/* 남은 시간 */}
                    <div className="text-center">
                      <h4 className="text-sm font-bold text-cyan-400 mb-2">남은 시간</h4>
                      <div className="text-3xl font-black bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent drop-shadow-lg">
                        {formatTime(timeLeft)}
                      </div>
                      <p className="text-cyan-500 text-xs mt-1">예상 완료시간</p>
                    </div>

                    {/* 진행률 */}
                    <div className="text-center">
                      <h4 className="text-sm font-bold text-blue-400 mb-2">분석률</h4>
                      <div className="text-3xl font-black text-blue-400 drop-shadow-lg">
                        {Math.round(progress)}%
                      </div>
                      <p className="text-blue-500 text-xs mt-1">처리 완료도</p>
                    </div>
                  </div>

                  {/* 바다 진행률 바 */}
                  <div className="pt-4">
                    <div className="w-full bg-slate-700/50 backdrop-blur-sm rounded-full h-4 mb-4 border border-slate-600/50">
                      <div 
                        className="bg-gradient-to-r from-indigo-500 to-cyan-500 h-4 rounded-full transition-all duration-1000 relative overflow-hidden"
                        style={{ width: `${progress}%` }}
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent transform -skew-x-12 animate-pulse"></div>
                      </div>
                    </div>

                    {/* 바다 진행 상태 */}
                    <div className="text-center">
                      {status === '파일 대기' && (
                        <div className="bg-slate-800/70 backdrop-blur-sm text-cyan-300 px-4 py-2 rounded-full text-sm font-bold border border-slate-700/50">
                          파일 업로드 중입니다.
                        </div>
                      )}
                      {status === '분석 진행' && (
                        <div className="bg-slate-800/70 backdrop-blur-sm text-blue-300 px-4 py-2 rounded-full text-sm font-bold border border-slate-700/50">
                          파일 업로드 완료되었습니다.
                        </div>
                      )}
                      {status === '분석 완료' && (
                        <div className="bg-slate-800/70 backdrop-blur-sm text-cyan-300 px-4 py-2 rounded-full text-sm font-bold border border-slate-700/50">
                          🌊 분석 결과 보기를 확인하세요
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* 심해 완료 버튼 */}
              {status === '분석 완료' && (
                <div className="text-center">
                  <button
                    onClick={handleViewResults}
                    className="bg-gradient-to-r from-indigo-600 to-cyan-600 text-white px-8 py-4 rounded-2xl font-black text-lg shadow-2xl shadow-indigo-500/50 hover:shadow-2xl hover:shadow-indigo-500/70 transition-all duration-300 hover:scale-105 border-2 border-slate-700/50 backdrop-blur-sm"
                  >
                    🌊 분석 결과 보기
                  </button>
                </div>
              )}
            </div>

            {/* 오른쪽: 심해 서비스 소개 슬라이드 */}
            <div className="bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-indigo-900/20 overflow-hidden border border-slate-700/50">
              <div className="p-6 border-b border-slate-700/50">
                <h3 className="text-xl font-black text-cyan-300 drop-shadow-lg">
                  심해 학습법 및 활용팁
                </h3>
                <p className="text-cyan-400 text-sm mt-1 drop-shadow-sm">
                  효과적인 바다 학습 전략과 성적 향상 방법을 알아보세요
                </p>
              </div>

              {/* 심해 슬라이드 컨테이너 */}
              <div className="relative h-96 overflow-hidden">
                {serviceSlides.map((slide, index) => (
                  <div
                    key={index}
                    className={`absolute inset-0 transition-transform duration-500 ease-in-out ${
                      index === currentSlide ? 'translate-x-0' : 
                      index < currentSlide ? '-translate-x-full' : 'translate-x-full'
                    }`}
                  >
                    <div className={`h-full bg-gradient-to-br ${slide.color} p-8 text-white relative overflow-hidden`}>
                      {/* 심해 배경 효과 */}
                      <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-white/10"></div>
                      
                      <div className="flex flex-col justify-center h-full relative z-10">
                        <h4 className="text-2xl font-black mb-4 drop-shadow-lg">{slide.title}</h4>
                        <p className="text-lg mb-6 text-white/90 drop-shadow-sm">{slide.description}</p>
                        
                        <div className="space-y-3">
                          {slide.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center">
                              <div className="w-2 h-2 bg-white/80 rounded-full mr-3"></div>
                              <span className="text-white/90 drop-shadow-sm">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* 심해 슬라이드 인디케이터 */}
              <div className="flex justify-center space-x-2 p-4 bg-slate-800/80 backdrop-blur-sm">
                {serviceSlides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-200 ${
                      index === currentSlide ? 'bg-cyan-500' : 'bg-slate-600 hover:bg-cyan-400'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* 하단 업로드 정보 */}
          <div className="mt-8 bg-slate-800/60 backdrop-blur-md rounded-2xl shadow-lg shadow-indigo-900/20 p-6 border border-slate-700/50">
            <h4 className="text-lg font-black text-cyan-300 mb-4 drop-shadow-lg">업로드된 파일 정보</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <span className="text-cyan-400">파일명:</span>
                <p className="font-bold truncate text-cyan-300">{uploadData.fileName}</p>
              </div>
              <div>
                <span className="text-cyan-400">크기:</span>
                <p className="font-bold text-cyan-300">{(uploadData.fileSize / 1024 / 1024).toFixed(2)} MB</p>
              </div>
              <div>
                <span className="text-cyan-400">과목:</span>
                <p className="font-bold text-cyan-300">{uploadData.subject}</p>
              </div>
              <div>
                <span className="text-cyan-400">학년:</span>
                <p className="font-bold text-cyan-300">{uploadData.grade}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}