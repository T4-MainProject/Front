// ============================================
// ✨ Angelic Light SignupModal.jsx - 희망의 계약 모달
// ============================================
// 📝 주요 기능:
// - 모달 형태의 천사 회원가입 폼
// - 천사 정보 입력 및 유효성 검사
// - 희망의 계약 처리
// - 반응형 디자인 및 빛의 애니메이션
// ============================================

import React, { useState, useEffect } from 'react';
import { registerUser, checkEmailExists, saveUserToStorage } from '../data/dummyUsers';

export default function SignupModal({ isOpen, onClose, onSwitchToLogin, onSignupSuccess }) {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    passwordConfirm: '',
    name: '',
    phone: '',
    birthDate: '',
    address: '',
    school: ''
  });

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  // 모달이 열릴 때 body 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.keyCode === 27) onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // 에러 메시지 클리어
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    // 이메일 유효성 검사
    if (!formData.email) {
      newErrors.email = '천사의 이메일을 입력해주세요.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = '올바른 이메일 형식을 입력해주세요.';
    } else if (checkEmailExists(formData.email)) {
      newErrors.email = '이미 등록된 천사의 이메일입니다.';
    }

    // 비밀번호 유효성 검사
    if (!formData.password) {
      newErrors.password = '빛의 비밀번호를 입력해주세요.';
    } else if (formData.password.length < 6) {
      newErrors.password = '비밀번호는 최소 6자 이상이어야 합니다.';
    }

    // 비밀번호 확인
    if (!formData.passwordConfirm) {
      newErrors.passwordConfirm = '축복 비밀번호 확인을 입력해주세요.';
    } else if (formData.password !== formData.passwordConfirm) {
      newErrors.passwordConfirm = '비밀번호가 일치하지 않습니다.';
    }

    // 이름 유효성 검사
    if (!formData.name.trim()) {
      newErrors.name = '천사의 이름을 입력해주세요.';
    }

    // 전화번호 유효성 검사
    if (!formData.phone) {
      newErrors.phone = '연락처를 입력해주세요.';
    } else if (!/^[0-9-]+$/.test(formData.phone)) {
      newErrors.phone = '올바른 전화번호 형식을 입력해주세요.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);
    
    try {
      // 시뮬레이션된 로딩 (실제 천국 API 호출 시뮬레이션)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // 더미 데이터로 천사 계약 처리
      const result = registerUser(formData);
      
      if (result.success) {
        // 축복 저장소에 천사 정보 저장
        saveUserToStorage(result.user);
        
        // 부모 컴포넌트에 천사 계약 성공 알림
        onSignupSuccess(result.user);
        
        // 성공 메시지 표시
        alert(`${result.message}\n✨ 빛의 세계에 오신 것을 환영합니다, ${result.user.name}님! 🌟`);
      } else {
        // 천사 계약 실패 에러 표시
        setErrors({ general: result.message });
      }
    } catch (error) {
      console.error('천사 계약 오류:', error);
      setErrors({ general: '천사 계약 처리 중 예상치 못한 오류가 발생했습니다.' });
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* 빛의 배경 오버레이 */}
      <div 
        className="fixed inset-0 bg-white bg-opacity-95 transition-opacity duration-300"
        onClick={onClose}
      />
      
      {/* 천사의 모달 컨테이너 */}
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="relative bg-white rounded-3xl shadow-2xl shadow-blue-500/20 w-full max-w-2xl transform transition-all duration-300 modal-enter border-2 border-blue-200">
          {/* 천사의 배경 효과 */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50/80 via-white/90 to-sky-100/60 rounded-3xl"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,rgba(255,255,255,0.9)_100%)] rounded-3xl"></div>
          
          {/* 움직이는 빛의 파티클 */}
          <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
            <div className="absolute top-8 left-12 w-1 h-1 bg-blue-400/60 rounded-full animate-pulse"></div>
            <div className="absolute top-16 right-16 w-1 h-1 bg-sky-400/50 rounded-full animate-pulse delay-700"></div>
            <div className="absolute bottom-12 left-16 w-1 h-1 bg-indigo-400/40 rounded-full animate-pulse delay-1000"></div>
            <div className="absolute top-1/2 right-12 w-1 h-1 bg-blue-500/60 rounded-full animate-pulse delay-500"></div>
            <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-sky-300/50 rounded-full animate-pulse delay-1500"></div>
          </div>

          {/* 천사의 닫기 버튼 */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-blue-400 hover:text-blue-500 transition-colors duration-200 z-10 p-2 hover:bg-blue-100/50 rounded-xl"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          {/* 천사의 헤더 */}
          <div className="px-8 pt-8 pb-6 text-center relative z-10">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-sky-400 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/50 border border-blue-300">
              <span className="text-3xl text-white">👼</span>
            </div>
            <h2 className="text-2xl font-bold text-blue-600 mb-2 drop-shadow-lg">✨ 희망의 계약 - Angel Registration</h2>
            <p className="text-blue-500 drop-shadow-sm">AngelCheck과 함께 빛의 여정을 시작하세요</p>
          </div>

          {/* 천사의 폼 */}
          <form onSubmit={handleSubmit} className="px-8 pb-8 max-h-96 overflow-y-auto relative z-10">
            {/* 전체 에러 메시지 */}
            {errors.general && (
              <div className="mb-4 p-3 bg-red-100 border border-red-300 text-red-600 rounded-xl text-sm backdrop-blur-sm">
                {errors.general}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 천사 이메일 */}
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-blue-600 mb-2 drop-shadow-sm">
                  천사의 이메일 <span className="text-blue-500">*</span>
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  disabled={isLoading}
                  className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 transition-all duration-200 backdrop-blur-sm ${
                    errors.email 
                      ? 'border-red-300 focus:ring-red-500 bg-red-50' 
                      : 'border-blue-300 focus:ring-blue-500 focus:border-transparent bg-blue-50/30'
                  }`}
                  placeholder="angel@example.com"
                />
                {errors.email && <p className="mt-1 text-sm text-red-500">{errors.email}</p>}
              </div>

              {/* 빛의 비밀번호 */}
              <div>
                <label className="block text-sm font-semibold text-blue-600 mb-2 drop-shadow-sm">
                  빛의 비밀번호 <span className="text-blue-500">*</span>
                </label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  disabled={isLoading}
                  className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 transition-all duration-200 backdrop-blur-sm ${
                    errors.password 
                      ? 'border-red-300 focus:ring-red-500 bg-red-50' 
                      : 'border-blue-300 focus:ring-blue-500 focus:border-transparent bg-blue-50/30'
                  }`}
                  placeholder="안전한 빛의 비밀번호"
                />
                {errors.password && <p className="mt-1 text-sm text-red-500">{errors.password}</p>}
              </div>

              {/* 축복 비밀번호 확인 */}
              <div>
                <label className="block text-sm font-semibold text-blue-600 mb-2 drop-shadow-sm">
                  축복 비밀번호 확인 <span className="text-blue-500">*</span>
                </label>
                <input
                  type="password"
                  name="passwordConfirm"
                  value={formData.passwordConfirm}
                  onChange={handleInputChange}
                  disabled={isLoading}
                  className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 transition-all duration-200 backdrop-blur-sm ${
                    errors.passwordConfirm 
                      ? 'border-red-300 focus:ring-red-500 bg-red-50' 
                      : 'border-blue-300 focus:ring-blue-500 focus:border-transparent bg-blue-50/30'
                  }`}
                  placeholder="비밀번호 재입력"
                />
                {errors.passwordConfirm && <p className="mt-1 text-sm text-red-500">{errors.passwordConfirm}</p>}
              </div>

              {/* 천사의 이름 */}
              <div>
                <label className="block text-sm font-semibold text-blue-600 mb-2 drop-shadow-sm">
                  천사의 이름 <span className="text-blue-500">*</span>
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  disabled={isLoading}
                  className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 transition-all duration-200 backdrop-blur-sm ${
                    errors.name 
                      ? 'border-red-300 focus:ring-red-500 bg-red-50' 
                      : 'border-blue-300 focus:ring-blue-500 focus:border-transparent bg-blue-50/30'
                  }`}
                  placeholder="홍길동"
                />
                {errors.name && <p className="mt-1 text-sm text-red-500">{errors.name}</p>}
              </div>

              {/* 연락처 */}
              <div>
                <label className="block text-sm font-semibold text-blue-600 mb-2 drop-shadow-sm">
                  연락처 <span className="text-blue-500">*</span>
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  disabled={isLoading}
                  className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 transition-all duration-200 backdrop-blur-sm ${
                    errors.phone 
                      ? 'border-red-300 focus:ring-red-500 bg-red-50' 
                      : 'border-blue-300 focus:ring-blue-500 focus:border-transparent bg-blue-50/30'
                  }`}
                  placeholder="010-1234-5678"
                />
                {errors.phone && <p className="mt-1 text-sm text-red-500">{errors.phone}</p>}
              </div>

              {/* 생년월일 */}
              <div>
                <label className="block text-sm font-semibold text-blue-600 mb-2 drop-shadow-sm">
                  생년월일
                </label>
                <input
                  type="date"
                  name="birthDate"
                  value={formData.birthDate}
                  onChange={handleInputChange}
                  disabled={isLoading}
                  className="w-full px-4 py-3 border border-blue-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-blue-50/30 transition-all duration-200 backdrop-blur-sm"
                />
              </div>

              {/* 학교 */}
              <div>
                <label className="block text-sm font-semibold text-blue-600 mb-2 drop-shadow-sm">
                  학교
                </label>
                <input
                  type="text"
                  name="school"
                  value={formData.school}
                  onChange={handleInputChange}
                  disabled={isLoading}
                  className="w-full px-4 py-3 border border-blue-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-blue-50/30 transition-all duration-200 backdrop-blur-sm"
                  placeholder="희망고등학교"
                />
              </div>

              {/* 주소 */}
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-blue-600 mb-2 drop-shadow-sm">
                  주소
                </label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  disabled={isLoading}
                  className="w-full px-4 py-3 border border-blue-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-blue-50/30 transition-all duration-200 backdrop-blur-sm"
                  placeholder="서울특별시 강남구..."
                />
              </div>
            </div>

            {/* 계약 버튼들 */}
            <div className="mt-8 space-y-4">
              <button
                type="submit"
                disabled={isLoading}
                className={`w-full py-4 px-6 rounded-xl font-semibold text-white transition-all duration-300 transform hover:scale-105 ${
                  isLoading 
                    ? 'bg-blue-300 cursor-not-allowed' 
                    : 'bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 hover:to-sky-400 shadow-lg hover:shadow-blue-500/50'
                }`}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center">
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    ✨ 천사 계약 처리 중...
                  </div>
                ) : '👼 희망의 계약 완료'}
              </button>

              <div className="text-center">
                <span className="text-blue-500 text-sm">이미 천사이신가요? </span>
                <button
                  type="button"
                  onClick={onSwitchToLogin}
                  disabled={isLoading}
                  className="text-blue-600 hover:text-blue-500 font-medium text-sm transition-colors duration-200 hover:underline"
                >
                  ✨ 천국문 열기
                </button>
              </div>
            </div>
          </form>

          {/* 천사 장식 */}
          <div className="absolute top-4 right-16 text-blue-400 opacity-30 animate-pulse">✨</div>
          <div className="absolute bottom-4 left-8 text-blue-400 opacity-20 animate-pulse">🌟</div>
        </div>
      </div>
    </div>
  );
}