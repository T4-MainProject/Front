import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function DeepOceanWrongAnswerNote() {
  const [selectedSubject, setSelectedSubject] = useState('전체');
  const [waveEffect, setWaveEffect] = useState(false);
  const navigate = useNavigate();

  // 🌊 파도 효과
  useEffect(() => {
    const interval = setInterval(() => {
      setWaveEffect(true);
      setTimeout(() => setWaveEffect(false), 800);
    }, 4000 + Math.random() * 6000);
    
    return () => clearInterval(interval);
  }, []);

  // 🌊 심해 오답 데이터
  const deepOceanWrongAnswers = [
    // 국어 (4개)
    {
      id: 1,
      subject: '국어',
      question: '다음 글의 중심 내용으로 가장 적절한 것은?',
      userAnswer: '②',
      correctAnswer: '④',
      explanation: '이 문제는 글의 전체적인 맥락을 파악하는 문제입니다. 지문에서 강조하는 핵심은 "문화의 다양성"이며, 이는 4번 선택지에서 명확히 드러납니다.',
      difficulty: '중',
      category: '독해',
      points: 3,
      pearlCount: 1247
    },
    {
      id: 2,
      subject: '국어',
      question: '다음 시에서 화자의 정서로 가장 적절한 것은?',
      userAnswer: '①',
      correctAnswer: '③',
      explanation: '시상 전개 과정에서 화자의 감정 변화를 주의 깊게 살펴봐야 합니다. 초반의 그리움에서 후반부의 체념적 수용으로 이어지는 정서적 흐름이 핵심입니다.',
      difficulty: '상',
      category: '문학',
      points: 4,
      pearlCount: 2156
    },
    {
      id: 3,
      subject: '국어',
      question: '다음 문장에서 높임법이 잘못 사용된 것은?',
      userAnswer: '④',
      correctAnswer: '②',
      explanation: '높임법은 주체높임, 객체높임, 상대높임으로 구분됩니다. 이 문제에서는 주체와 객체의 관계를 정확히 파악하여 적절한 높임 표현을 사용해야 합니다.',
      difficulty: '하',
      category: '문법',
      points: 2,
      pearlCount: 892
    },
    {
      id: 4,
      subject: '국어',
      question: '다음 발표에서 청중과의 소통 방법으로 가장 적절한 것은?',
      userAnswer: '③',
      correctAnswer: '⑤',
      explanation: '화법에서는 청중의 반응을 살피고 상호작용을 유도하는 것이 중요합니다. 단순한 정보 전달이 아닌 청중 참여형 발표 기법을 활용해야 합니다.',
      difficulty: '중',
      category: '화법과 작문',
      points: 3,
      pearlCount: 1456
    },

    // 영어 (4개)
    {
      id: 5,
      subject: '영어',
      question: 'Choose the most appropriate word to fill in the blank.',
      userAnswer: 'though',
      correctAnswer: 'because',
      explanation: '문맥상 인과관계를 나타내는 접속사가 필요합니다. "though"는 양보의 의미이지만, 여기서는 "because"가 적절합니다.',
      difficulty: '하',
      category: '어법',
      points: 2,
      pearlCount: 743
    },
    {
      id: 6,
      subject: '영어',
      question: 'What is the main idea of the passage?',
      userAnswer: '①',
      correctAnswer: '④',
      explanation: '지문의 주제를 파악할 때는 각 단락의 핵심 내용과 전체적인 흐름을 종합적으로 고려해야 합니다. 세부 사항이 아닌 전체를 아우르는 내용을 찾는 것이 중요합니다.',
      difficulty: '중',
      category: '독해',
      points: 3,
      pearlCount: 1889
    },
    {
      id: 7,
      subject: '영어',
      question: 'Choose the best word to fill in the blank considering the context.',
      userAnswer: 'However',
      correctAnswer: 'Therefore',
      explanation: '빈칸 앞뒤 문맥을 보면 결과나 결론을 나타내는 표현이 필요합니다. "However"는 대조의 의미이지만, 여기서는 "Therefore"가 논리적 흐름에 맞습니다.',
      difficulty: '상',
      category: '빈칸추론',
      points: 4,
      pearlCount: 2987
    },
    {
      id: 8,
      subject: '영어',
      question: 'Choose the most logical order of the given sentences.',
      userAnswer: '②',
      correctAnswer: '⑤',
      explanation: '문장의 순서를 배열할 때는 시간적 순서, 논리적 연결, 대명사나 지시어의 지시 대상 등을 종합적으로 고려해야 합니다.',
      difficulty: '상',
      category: '순서배열',
      points: 4,
      pearlCount: 3124
    },

    // 수학 (4개)
    {
      id: 9,
      subject: '수학',
      question: '다음 이차함수의 최댓값을 구하시오. f(x) = -2x² + 8x - 3',
      userAnswer: '7',
      correctAnswer: '5',
      explanation: '이차함수 f(x) = -2x² + 8x - 3에서 x = -b/2a = -8/(-4) = 2일 때 최댓값을 가집니다. f(2) = -2(4) + 8(2) - 3 = -8 + 16 - 3 = 5',
      difficulty: '상',
      category: '함수',
      points: 4,
      pearlCount: 4567
    },
    {
      id: 10,
      subject: '수학',
      question: '원의 중심이 (2, 3)이고 반지름이 5인 원의 방정식을 구하시오.',
      userAnswer: '(x-2)² + (y-3)² = 10',
      correctAnswer: '(x-2)² + (y-3)² = 25',
      explanation: '원의 표준형은 (x-a)² + (y-b)² = r²입니다. 여기서 중심이 (2,3), 반지름이 5이므로 (x-2)² + (y-3)² = 5² = 25가 됩니다.',
      difficulty: '하',
      category: '기하',
      points: 2,
      pearlCount: 1234
    },
    {
      id: 11,
      subject: '수학',
      question: '주사위를 두 번 던져서 나온 눈의 합이 7이 될 확률을 구하시오.',
      userAnswer: '1/5',
      correctAnswer: '1/6',
      explanation: '두 주사위의 합이 7이 되는 경우는 (1,6), (2,5), (3,4), (4,3), (5,2), (6,1)로 총 6가지입니다. 전체 경우의 수는 6×6=36이므로 확률은 6/36 = 1/6입니다.',
      difficulty: '중',
      category: '확률과 통계',
      points: 3,
      pearlCount: 2345
    },
    {
      id: 12,
      subject: '수학',
      question: 'f(x) = 2x³ - 6x² + 6x - 1일 때, f\'(x)를 구하시오.',
      userAnswer: '6x² - 6x + 6',
      correctAnswer: '6x² - 12x + 6',
      explanation: '미분 공식을 사용하면 f\'(x) = 6x² - 12x + 6입니다. 각 항을 차수를 1씩 낮추고 원래 차수를 계수에 곱하면 됩니다. -6x² 항의 미분에서 실수가 있었습니다.',
      difficulty: '중',
      category: '미적분',
      points: 3,
      pearlCount: 1876
    }
  ];

  const subjects = ['전체', '국어', '영어', '수학'];
  const filteredProblems = selectedSubject === '전체' 
    ? deepOceanWrongAnswers 
    : deepOceanWrongAnswers.filter(problem => problem.subject === selectedSubject);

  const getDifficultyColor = (difficulty) => {
    switch(difficulty) {
      case '하': return 'bg-slate-700/60 text-cyan-300 border-slate-600';
      case '중': return 'bg-indigo-700/60 text-blue-300 border-indigo-600';
      case '상': return 'bg-blue-700/60 text-cyan-200 border-blue-600';
      default: return 'bg-slate-800/60 text-cyan-300 border-slate-700';
    }
  };

  const getSubjectEmoji = (subject) => {
    switch(subject) {
      case '국어': return '🐙';
      case '영어': return '🐠';
      case '수학': return '💎';
      default: return '🌊';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-blue-900 relative overflow-hidden">
      {/* 🌊 심해 배경 효과 */}
      <div className="absolute inset-0 opacity-30">
        <div className="w-full h-full bg-gradient-to-b from-transparent via-indigo-800/50 to-transparent animate-pulse"></div>
      </div>
      
      {/* 🌊 파도 효과 */}
      {waveEffect && (
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-600/30 via-cyan-400/40 to-blue-600/30 animate-pulse pointer-events-none z-10"></div>
      )}

      {/* 🌊 떠다니는 심해 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-1/4 w-3 h-3 bg-cyan-400/40 rounded-full animate-pulse shadow-lg shadow-cyan-500/50"></div>
        <div className="absolute top-40 right-1/3 w-2 h-2 bg-blue-400/30 rounded-full animate-pulse delay-700 shadow-lg shadow-blue-500/50"></div>
        <div className="absolute bottom-60 left-1/2 w-2 h-2 bg-indigo-400/30 rounded-full animate-pulse delay-1000 shadow-lg shadow-indigo-500/50"></div>
        <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-teal-500/40 rounded-full animate-pulse delay-500 shadow-lg shadow-teal-500/50"></div>
      </div>

      {/* 🌊 심해 헤더 */}
      <div className="bg-slate-900/80 backdrop-blur-md shadow-2xl shadow-indigo-900/30 border-b border-slate-700/50 relative z-20">
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/60 via-indigo-900/80 to-blue-900/60"></div>
        <div className="container mx-auto px-4 py-4 relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                className="text-cyan-300 hover:text-cyan-200 mr-4 transition-all duration-300 hover:scale-110 bg-slate-800/60 backdrop-blur-sm p-2 rounded-full border border-slate-700/50 shadow-lg shadow-indigo-500/30"
                onClick={() => navigate(-1)}
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 
                className={`text-2xl font-black bg-gradient-to-r from-cyan-300 to-blue-300 bg-clip-text text-transparent ${waveEffect ? 'animate-pulse' : ''} cursor-pointer hover:from-cyan-200 hover:to-blue-200 transition-all duration-300 drop-shadow-lg`}
                onClick={() => navigate('/')}
              >
                🌊 심해 학습노트
              </h1>
            </div>
            <div className="text-cyan-300 text-sm opacity-80 bg-slate-800/60 backdrop-blur-sm px-3 py-1 rounded-full border border-slate-700/50">
              "깊은 바다 속 완벽한 학습 가이드"
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-20">
        <div className="max-w-6xl mx-auto">
          
          {/* 🌊 과목 필터 */}
          <div className="bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-indigo-900/30 p-6 mb-8 border border-slate-700/50">
            <div className="flex flex-wrap gap-4">
              {subjects.map((subject) => (
                <button
                  key={subject}
                  onClick={() => setSelectedSubject(subject)}
                  className={`px-6 py-3 rounded-2xl font-bold transition-all duration-300 border-2 shadow-lg ${
                    selectedSubject === subject
                      ? 'bg-gradient-to-r from-indigo-600 to-cyan-600 text-white shadow-indigo-500/50 border-indigo-400 scale-105'
                      : 'bg-slate-800/60 backdrop-blur-sm text-cyan-300 hover:bg-slate-700/60 border-slate-700/50 hover:border-indigo-400 hover:scale-105 hover:shadow-indigo-500/40'
                  }`}
                >
                  {getSubjectEmoji(subject)} {subject}
                </button>
              ))}
            </div>
          </div>

          {/* 🌊 심해 오답 목록 */}
          <div className="space-y-8">
            {filteredProblems.map((problem) => (
              <div key={problem.id} className="bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-indigo-900/30 p-8 border border-slate-700/50 hover:border-indigo-400 hover:shadow-indigo-500/30 transition-all duration-300 group hover:scale-[1.02]">
                
                {/* 🌊 문제 헤더 */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-4">
                    <span className="bg-gradient-to-r from-indigo-600 to-cyan-600 text-white px-4 py-2 rounded-full font-bold shadow-lg shadow-indigo-500/50">
                      {getSubjectEmoji(problem.subject)} {problem.subject}
                    </span>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium border backdrop-blur-sm ${getDifficultyColor(problem.difficulty)}`}>
                      깊이: {problem.difficulty}
                    </span>
                    <span className="bg-blue-700/60 text-blue-300 px-3 py-1 rounded-full text-sm font-medium border border-blue-600 backdrop-blur-sm">
                      {problem.category}
                    </span>
                    <span className="text-cyan-300 text-sm font-medium bg-slate-800/60 backdrop-blur-sm px-2 py-1 rounded-full border border-slate-700/50">
                      {problem.points}점
                    </span>
                  </div>
                  <div className="text-cyan-300 text-sm opacity-80 bg-slate-800/60 backdrop-blur-sm px-3 py-1 rounded-full border border-slate-700/50">
                    🐚 {problem.pearlCount.toLocaleString()}명의 바다 탐험가가 학습했습니다
                  </div>
                </div>

                {/* 🌊 문제 내용 */}
                <div className="mb-6">
                  <h3 className="text-lg font-bold text-cyan-200 mb-4 group-hover:text-cyan-100 transition-colors drop-shadow-sm">
                    {problem.question}
                  </h3>
                  
                  <div className="bg-slate-700/60 backdrop-blur-sm border border-slate-600 rounded-2xl p-4 mb-4 shadow-inner">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-cyan-300 font-medium">선택한 답: </span>
                        <span className="font-bold text-cyan-200 bg-slate-800/60 backdrop-blur-sm px-3 py-1 rounded-full border border-slate-600">
                          {problem.userAnswer}
                        </span>
                      </div>
                      <div>
                        <span className="text-blue-300 font-medium">정답: </span>
                        <span className="font-bold text-blue-200 bg-blue-800/60 backdrop-blur-sm px-3 py-1 rounded-full border border-blue-600">
                          {problem.correctAnswer}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-indigo-900/40 backdrop-blur-sm border border-indigo-700/50 rounded-2xl p-4 shadow-lg">
                    <h4 className="font-bold text-indigo-300 mb-2 flex items-center space-x-2">
                      <span>🧠</span>
                      <span>심해 해설</span>
                    </h4>
                    <p className="text-cyan-200 leading-relaxed">{problem.explanation}</p>
                  </div>
                </div>

                {/* 🌊 유사 문제 버튼 */}
                <div className="border-t border-slate-700/50 pt-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-lg font-bold text-cyan-200 flex items-center space-x-2">
                      <span>🔍</span>
                      <span>유사한 심해 문제들</span>
                    </h4>
                    <button
                      onClick={() => navigate('/similar-problems', { 
                        state: { 
                          problemId: problem.id, 
                          originalProblem: problem 
                        } 
                      })}
                      className="bg-gradient-to-r from-indigo-600 to-cyan-600 text-white px-6 py-3 rounded-2xl font-bold hover:from-indigo-500 hover:to-cyan-500 transition-all duration-300 shadow-lg shadow-indigo-500/50 hover:shadow-indigo-500/70 hover:scale-105 border-2 border-slate-700/50 backdrop-blur-sm"
                    >
                      심해 탐험하기 →
                    </button>
                  </div>
                  <div className="bg-blue-900/40 backdrop-blur-sm border border-blue-700/50 rounded-2xl p-4 shadow-inner">
                    <p className="text-blue-200 text-sm">
                      이 문제와 유사한 심해 문제들이 당신의 학습을 도와드립니다. 
                      더 깊은 바다 지식의 심연에서 완벽한 학습을 경험해보세요! 🌊
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* 🌊 하단 액션 버튼 */}
          <div className="mt-12 text-center">
            <button
              onClick={() => alert('새로운 심해 시험지를 불러옵니다...')}
              className="bg-gradient-to-r from-indigo-600 to-cyan-600 text-white px-8 py-4 rounded-2xl font-black text-lg shadow-2xl shadow-indigo-500/50 hover:shadow-indigo-500/70 transition-all duration-300 hover:scale-105 border-2 border-slate-700/50 backdrop-blur-sm relative overflow-hidden group"
            >
              <span className="relative z-10 flex items-center space-x-2">
                <span>🌊</span>
                <span>새로운 심해 시험지로 도전하기</span>
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-white/10 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
            </button>
            <p className="text-cyan-300 text-sm mt-3 opacity-80 bg-slate-800/60 backdrop-blur-sm px-4 py-2 rounded-full border border-slate-700/50 inline-block">
              "더 완벽한 학습을 위한 바다 여행"
            </p>
          </div>

          {/* 🌊 통계 요약 카드 */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-indigo-900/30 p-6 text-center border border-slate-700/50 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-800/30 to-transparent"></div>
              <div className="w-12 h-12 bg-indigo-700/70 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10 border border-indigo-600 shadow-lg shadow-indigo-500/50">
                <svg className="w-6 h-6 text-indigo-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <div className="text-3xl font-black text-indigo-300 mb-1 relative z-10 drop-shadow-lg">
                {filteredProblems.length}
              </div>
              <div className="text-sm text-indigo-400 relative z-10 font-medium">총 오답 문제</div>
              <div className="absolute top-2 right-2 text-indigo-400 opacity-60 animate-pulse">📝</div>
            </div>

            <div className="bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-indigo-900/30 p-6 text-center border border-slate-700/50 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-800/30 to-transparent"></div>
              <div className="w-12 h-12 bg-blue-700/70 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10 border border-blue-600 shadow-lg shadow-blue-500/50">
                <svg className="w-6 h-6 text-blue-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
              <div className="text-3xl font-black text-blue-300 mb-1 relative z-10 drop-shadow-lg">
                {Math.round(filteredProblems.reduce((sum, p) => sum + p.points, 0))}
              </div>
              <div className="text-sm text-blue-400 relative z-10 font-medium">총 실수 점수</div>
              <div className="absolute top-2 right-2 text-blue-400 opacity-60 animate-pulse">📊</div>
            </div>

            <div className="bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-indigo-900/30 p-6 text-center border border-slate-700/50 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-800/30 to-transparent"></div>
              <div className="w-12 h-12 bg-cyan-700/70 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10 border border-cyan-600 shadow-lg shadow-cyan-500/50">
                <svg className="w-6 h-6 text-cyan-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div className="text-3xl font-black text-cyan-300 mb-1 relative z-10 drop-shadow-lg">
                {Math.round(filteredProblems.reduce((sum, p) => sum + p.pearlCount, 0) / filteredProblems.length).toLocaleString()}
              </div>
              <div className="text-sm text-cyan-400 relative z-10 font-medium">평균 학습자 수</div>
              <div className="absolute top-2 right-2 text-cyan-400 opacity-60 animate-pulse">👥</div>
            </div>
          </div>

          {/* 🌊 학습 동기 부여 섹션 */}
          <div className="mt-12 bg-slate-800/60 backdrop-blur-md rounded-3xl shadow-2xl shadow-indigo-900/30 p-8 border border-slate-700/50 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-800/30 to-blue-800/30"></div>
            <div className="text-center relative z-10">
              <h3 className="text-2xl font-black bg-gradient-to-r from-cyan-300 to-blue-300 bg-clip-text text-transparent mb-6 drop-shadow-lg">🌊 심해 학습 동기</h3>
              
              <div className="bg-slate-700/60 backdrop-blur-sm rounded-2xl p-6 border border-slate-600 shadow-lg">
                <div className="text-4xl mb-4 animate-pulse">🌊</div>
                <h4 className="text-xl font-black text-cyan-300 mb-2 drop-shadow-sm">오답을 통해 얻는 바다의 지혜</h4>
                <p className="text-cyan-200 mb-4">
                  실수는 학습의 시작입니다. 각 오답은 당신이 더 깊은 바다로 잠수할 수 있는 진주와 같습니다.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="bg-indigo-800/60 backdrop-blur-sm p-3 rounded-xl border border-indigo-600">
                    <div className="text-indigo-300 font-bold">🎯 학습 목표</div>
                    <div className="text-indigo-200">각 오답을 완벽히 이해하기</div>
                  </div>
                  <div className="bg-blue-800/60 backdrop-blur-sm p-3 rounded-xl border border-blue-600">
                    <div className="text-blue-300 font-bold">⚡ 성장 포인트</div>
                    <div className="text-blue-200">
                      {filteredProblems.length}개 문제 × 완벽 이해 = 성공
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* 🌊 바다 장식 */}
            <div className="absolute top-4 right-4 text-cyan-400 opacity-60 animate-pulse">🌊</div>
            <div className="absolute bottom-4 left-4 text-indigo-400 opacity-50 animate-pulse">🐚</div>
          </div>
        </div>
      </div>

      {/* 🌊 심해 CSS 애니메이션 */}
      <style jsx>{`
        @keyframes wave-flow {
          0% {
            transform: translateX(-100px) translateY(0px) rotate(0deg);
            opacity: 0;
          }
          10% {
            opacity: 1;
          }
          90% {
            opacity: 0.8;
          }
          100% {
            transform: translateX(100vw) translateY(50px) rotate(180deg);
            opacity: 0;
          }
        }
        
        @keyframes deep-float {
          0%, 100% { 
            transform: translateY(0px) rotate(0deg);
          }
          33% { 
            transform: translateY(-12px) rotate(120deg);
          }
          66% { 
            transform: translateY(6px) rotate(240deg);
          }
        }
        
        @keyframes ocean-glow {
          0%, 100% { 
            filter: drop-shadow(0 0 10px rgba(6, 182, 212, 0.8)) brightness(1.0); 
          }
          50% { 
            filter: drop-shadow(0 0 25px rgba(6, 182, 212, 1.2)) brightness(1.3); 
          }
        }
        
        @keyframes gentle-tide {
          0%, 100% { 
            transform: translateX(0) rotate(0deg); 
          }
          25% { 
            transform: translateX(3px) translateY(-2px) rotate(2deg); 
          }
          50% { 
            transform: translateX(0) translateY(-4px) rotate(0deg); 
          }
          75% { 
            transform: translateX(-3px) translateY(-2px) rotate(-2deg); 
          }
        }
        
        @keyframes bubble-rise {
          0%, 100% {
            transform: translateY(100%);
            opacity: 0;
          }
          10% {
            opacity: 1;
          }
          90% {
            opacity: 0.8;
          }
        }
        
        .animate-wave-flow {
          animation: wave-flow 12s linear infinite;
        }
        
        .animate-deep-float {
          animation: deep-float 5s ease-in-out infinite;
        }
        
        .animate-ocean-glow {
          animation: ocean-glow 4s ease-in-out infinite;
        }
        
        .animate-gentle-tide {
          animation: gentle-tide 8s ease-in-out infinite;
        }
        
        /* 🌊 스크롤바 스타일링 - 심해 버전 */
        ::-webkit-scrollbar {
          width: 14px;
        }
        
        ::-webkit-scrollbar-track {
          background: rgba(30, 41, 59, 0.4);
          border-radius: 7px;
        }
        
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #3730a3, #1e40af);
          border-radius: 7px;
          border: 2px solid rgba(30, 41, 59, 0.4);
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #4338ca, #2563eb);
        }
        
        /* 🌊 심해 호버 효과 */
        .ocean-hover:hover {
          transform: scale(1.02) rotate(0.5deg);
          box-shadow: 0 25px 50px -12px rgba(6, 182, 212, 0.4);
        }
        
        /* 🌊 바다 글로우 효과 */
        .ocean-glow {
          box-shadow: 0 0 20px rgba(6, 182, 212, 0.3);
        }
        
        .ocean-glow:hover {
          box-shadow: 0 0 30px rgba(6, 182, 212, 0.5);
        }
        
        /* 🌊 심해 텍스트 효과 */
        .ocean-text {
          background: linear-gradient(45deg, #06b6d4, #3b82f6, #06b6d4);
          background-size: 200% 200%;
          animation: ocean-gradient 4s ease infinite;
        }
        
        @keyframes ocean-gradient {
          0%, 100% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
        }
        
        /* 🌊 바다 버튼 효과 */
        .ocean-button {
          position: relative;
          overflow: hidden;
        }
        
        .ocean-button::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
          transition: left 0.6s;
        }
        
        .ocean-button:hover::before {
          left: 100%;
        }
        
        /* 🌊 물결 효과 */
        .ripple-text {
          position: relative;
        }
        
        .ripple-text::before,
        .ripple-text::after {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: linear-gradient(45deg, transparent, rgba(6, 182, 212, 0.3), transparent);
          animation: ripple 3s ease-in-out infinite;
        }
        
        .ripple-text::after {
          animation-delay: 1.5s;
        }
        
        @keyframes ripple {
          0%, 100% {
            transform: translateX(-100%);
          }
          50% {
            transform: translateX(100%);
          }
        }
        
        /* 🌊 심해 카드 효과 */
        .ocean-card {
          background: linear-gradient(135deg, rgba(30, 41, 59, 0.6), rgba(15, 23, 42, 0.4));
          backdrop-filter: blur(12px);
          border: 1px solid rgba(71, 85, 105, 0.5);
          transition: all 0.3s ease;
        }
        
        .ocean-card:hover {
          background: linear-gradient(135deg, rgba(30, 41, 59, 0.8), rgba(15, 23, 42, 0.6));
          border-color: rgba(6, 182, 212, 0.5);
          transform: translateY(-8px);
          box-shadow: 0 25px 50px rgba(6, 182, 212, 0.3);
        }
        
        /* 🌊 심해 그라데이션 테두리 */
        .ocean-border {
          border: 2px solid transparent;
          background: linear-gradient(rgba(30, 41, 59, 0.8), rgba(30, 41, 59, 0.8)) padding-box,
                      linear-gradient(45deg, #06b6d4, #3b82f6, #1e40af) border-box;
        }
        
        /* 🌊 심해 그림자 효과 */
        .ocean-shadow {
          box-shadow: 
            0 4px 6px rgba(6, 182, 212, 0.1),
            0 1px 3px rgba(6, 182, 212, 0.08),
            inset 0 1px 0 rgba(255, 255, 255, 0.1);
        }
        
        .ocean-shadow:hover {
          box-shadow: 
            0 20px 25px rgba(6, 182, 212, 0.2),
            0 10px 10px rgba(6, 182, 212, 0.1),
            inset 0 1px 0 rgba(255, 255, 255, 0.15);
        }
        
        /* 🌊 기포 효과 */
        .bubble-animation {
          animation: bubble-rise 6s ease-in-out infinite;
        }
        
        /* 🌊 심해 입자 효과 */
        .deep-particles::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background-image: 
            radial-gradient(2px 2px at 20px 30px, rgba(6, 182, 212, 0.3), transparent),
            radial-gradient(2px 2px at 40px 70px, rgba(59, 130, 246, 0.3), transparent),
            radial-gradient(1px 1px at 90px 40px, rgba(30, 64, 175, 0.3), transparent),
            radial-gradient(1px 1px at 130px 80px, rgba(6, 182, 212, 0.3), transparent);
          background-repeat: repeat;
          background-size: 200px 100px;
          animation: deep-particles-float 20s linear infinite;
        }
        
        @keyframes deep-particles-float {
          0% {
            transform: translateY(0);
          }
          100% {
            transform: translateY(-200px);
          }
        }
      `}</style>
    </div>
  );
}