// ============================================
// ✨ Angelic Light LoginModal.jsx - 천국문 로그인 모달
// ============================================
// 📝 주요 기능:
// - 모달 형태의 천국문 로그인 폼
// - 천사/비밀번호 입력
// - 천국문 열기, 천사 등록, 빛의 비밀번호 복원 버튼
// - 반응형 디자인 및 빛의 애니메이션
// ============================================

import React, { useState, useEffect } from 'react';
import { validateLogin, saveUserToStorage } from '../data/dummyUsers';
import ForgotPasswordModal from './ForgotPasswordModal';

export default function LoginModal({ isOpen, onClose, onSwitchToSignup, onLoginSuccess }) {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);

  // 모달이 열릴 때 body 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.keyCode === 27) onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  // 천국문 로그인 모달이 닫힐 때 비밀번호 찾기 모달도 닫기
  useEffect(() => {
    if (!isOpen) {
      setShowForgotPassword(false);
    }
  }, [isOpen]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // 에러 메시지 클리어
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    // 천사 이메일 검증
    if (!formData.email) {
      newErrors.email = '천사의 이메일을 입력해주세요.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = '올바른 천사 이메일 형식이 아닙니다.';
    }

    // 빛의 비밀번호 검증
    if (!formData.password) {
      newErrors.password = '빛의 비밀번호를 입력해주세요.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);
    
    try {
      // 시뮬레이션된 로딩 (실제 천국 API 호출 시뮬레이션)
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // 더미 데이터로 천사 인증 검증
      const result = validateLogin(formData.email, formData.password);
      
      if (result.success) {
        // 천국 스토리지에 천사 정보 저장
        saveUserToStorage(result.user);
        
        // 부모 컴포넌트에 천국문 입장 성공 알림
        onLoginSuccess(result.user);
        
        // 성공 메시지 표시
        alert(`${result.message}\n빛의 세계에 오신 것을 환영합니다, ${result.user.name}님!`);
      } else {
        // 천국문 입장 실패 에러 표시
        setErrors({ general: result.message });
      }
    } catch (error) {
      console.error('천국문 입장 오류:', error);
      setErrors({ general: '천국문 입장 처리 중 예상치 못한 오류가 발생했습니다.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = () => {
    setShowForgotPassword(true);
  };

  const handleForgotPasswordClose = () => {
    setShowForgotPassword(false);
  };

  const handleForgotPasswordSuccess = () => {
    setShowForgotPassword(false);
    // 빛의 비밀번호 재설정 성공 후 천국문 로그인 모달로 돌아가기
    alert('빛의 비밀번호가 성공적으로 변경되었습니다. 새로운 축복으로 천국문에 입장해주세요.');
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 overflow-y-auto">
        {/* 빛의 배경 오버레이 */}
        <div 
          className="fixed inset-0 bg-white bg-opacity-95 transition-opacity duration-300"
          onClick={onClose}
        />
        
        {/* 빛의 모달 컨테이너 */}
        <div className="flex min-h-full items-center justify-center p-4">
          <div className="relative bg-white rounded-3xl shadow-2xl shadow-blue-500/20 w-full max-w-md transform transition-all duration-300 modal-enter border-2 border-blue-200">
            
            {/* 빛의 배경 효과 */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-50/80 via-white/90 to-sky-100/60 rounded-3xl"></div>
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_60%,rgba(255,255,255,0.9)_100%)] rounded-3xl"></div>
            
            {/* 움직이는 빛의 파티클 */}
            <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
              <div className="absolute top-8 left-12 w-1 h-1 bg-blue-400/60 rounded-full animate-pulse"></div>
              <div className="absolute top-16 right-16 w-1 h-1 bg-sky-400/50 rounded-full animate-pulse delay-700"></div>
              <div className="absolute bottom-12 left-16 w-1 h-1 bg-indigo-400/40 rounded-full animate-pulse delay-1000"></div>
              <div className="absolute top-1/2 right-12 w-1 h-1 bg-blue-500/60 rounded-full animate-pulse delay-500"></div>
            </div>

            {/* 빛의 닫기 버튼 */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-blue-400 hover:text-blue-500 transition-colors duration-200 z-10 p-2 hover:bg-blue-100/50 rounded-xl"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            {/* 빛의 헤더 */}
            <div className="px-8 pt-8 pb-6 text-center relative z-10">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-sky-400 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/50 border border-blue-300">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-blue-600 mb-2 drop-shadow-lg">✨ 천국문 입장</h2>
              <p className="text-blue-500 drop-shadow-sm">AngelCheck 빛의 세계에 오신 것을 환영합니다</p>
            </div>

            {/* 빛의 폼 */}
            <form onSubmit={handleSubmit} className="px-8 pb-8 relative z-10">
              {/* 전체 에러 메시지 */}
              {errors.general && (
                <div className="mb-4 p-3 bg-red-100 border border-red-300 text-red-600 rounded-xl text-sm backdrop-blur-sm">
                  {errors.general}
                </div>
              )}

              {/* 천사 이메일 입력 */}
              <div className="mb-4">
                <label className="block text-sm font-semibold text-blue-600 mb-2 drop-shadow-sm">
                  천사의 이메일
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="angel@heavenly.co.kr"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:border-transparent transition-all duration-200 bg-blue-50/30 text-blue-700 placeholder-blue-400 backdrop-blur-sm ${
                    errors.email 
                      ? 'border-red-300 focus:ring-red-500' 
                      : 'border-blue-300 focus:ring-blue-500'
                  }`}
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-500">{errors.email}</p>
                )}
              </div>

              {/* 빛의 비밀번호 입력 */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-blue-600 mb-2 drop-shadow-sm">
                  빛의 비밀번호
                </label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  placeholder="빛의 비밀번호를 입력하세요"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:border-transparent transition-all duration-200 bg-blue-50/30 text-blue-700 placeholder-blue-400 backdrop-blur-sm ${
                    errors.password 
                      ? 'border-red-300 focus:ring-red-500' 
                      : 'border-blue-300 focus:ring-blue-500'
                  }`}
                />
                {errors.password && (
                  <p className="mt-1 text-sm text-red-500">{errors.password}</p>
                )}
              </div>

              {/* 천국문 입장 버튼 */}
              <button
                type="submit"
                disabled={isLoading}
                className={`w-full py-3 px-4 rounded-xl font-semibold text-white transition-all duration-300 mb-4 transform hover:scale-105 ${
                  isLoading
                    ? 'bg-blue-300 cursor-not-allowed'
                    : 'bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 hover:to-sky-400 shadow-lg hover:shadow-blue-500/50'
                }`}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center">
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    천국문 입장 중...
                  </div>
                ) : (
                  '✨ 천국문 입장'
                )}
              </button>

              {/* 빛의 비밀번호 복원 */}
              <button
                type="button"
                onClick={handleForgotPassword}
                className="w-full text-center text-sm text-blue-500 hover:text-blue-400 transition-colors duration-200 mb-4 hover:underline"
              >
                🔑 빛의 비밀번호를 잊으셨나요?
              </button>

              {/* 빛의 구분선 */}
              <div className="relative mb-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-blue-200" />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-4 bg-gradient-to-r from-white to-blue-50 text-blue-400">또는</span>
                </div>
              </div>

              {/* 천사 등록 버튼 */}
              <button
                type="button"
                onClick={onSwitchToSignup}
                className="w-full py-3 px-4 border border-blue-300 rounded-xl font-semibold text-blue-500 hover:bg-blue-100/50 hover:border-blue-400 transition-all duration-200 bg-blue-50/30 backdrop-blur-sm"
              >
                천사가 되고 싶으신가요? 👼 천사 등록하기
              </button>
            </form>

            {/* 추가 빛 장식 */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
              <div className="flex items-center space-x-1 text-xs text-blue-400">
                <span>✨</span>
                <span>천국 서버 연결됨</span>
                <div className="w-1 h-1 bg-blue-400 rounded-full animate-pulse"></div>
              </div>
            </div>

            {/* 빛의 테두리 효과 */}
            <div className="absolute inset-0 rounded-3xl border border-blue-300/30 pointer-events-none"></div>
          </div>
        </div>
      </div>

      {/* 빛의 비밀번호 복원 모달 */}
      <ForgotPasswordModal
        isOpen={showForgotPassword}
        onClose={handleForgotPasswordClose}
        onSuccess={handleForgotPasswordSuccess}
      />
    </>
  );
}