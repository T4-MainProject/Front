// ============================================
// 🌸 Spring Blossom SimpleFooter.jsx - 벚꽃 간소 푸터
// ============================================
import React from 'react';

export default function SimpleFooter() {
  return (
    <footer className="bg-gradient-to-br from-pink-100 via-rose-50 to-pink-100 text-pink-700 py-12 relative overflow-hidden border-t border-white/50">
      {/* 🌺 벚꽃 정원 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-t from-white/80 via-pink-50/60 to-rose-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_60%_40%,rgba(253,125,191,0.18)_0%,rgba(251,207,232,0.12)_50%,rgba(244,114,182,0.18)_80%)]"></div>
      
      {/* 🌸 흩날리는 벚꽃 꽃잎들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-4 left-1/4 w-4 h-4 bg-pink-400/50 rounded-full animate-pulse shadow-lg transform rotate-45"></div>
        <div className="absolute top-8 right-1/3 w-3 h-3 bg-rose-400/60 rounded-full animate-pulse delay-700 shadow-lg transform rotate-12"></div>
        <div className="absolute bottom-6 left-1/2 w-3 h-3 bg-pink-300/50 rounded-full animate-pulse delay-1000 shadow-lg transform -rotate-12"></div>
        <div className="absolute top-1/2 right-1/4 w-3 h-3 bg-rose-500/60 rounded-full animate-pulse delay-500 shadow-lg"></div>
        <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-pink-300/50 rounded-full animate-pulse delay-1500 shadow-lg transform rotate-45"></div>
      </div>

      {/* 🌸 미니 벚꽃 나무 장식 */}
      <div className="absolute top-6 right-12 opacity-18">
        <svg width="40" height="50" viewBox="0 0 40 50">
          <path d="M20 50 L20 25 M10 25 Q20 18 30 25" stroke="#ec4899" strokeWidth="2" fill="none"/>
          <circle cx="20" cy="22" r="4" fill="#ec4899"/>
          <circle cx="15" cy="22" r="1.5" fill="#fce7f3"/>
          <circle cx="25" cy="24" r="1.5" fill="#fce7f3"/>
          <circle cx="18" cy="19" r="1" fill="#f9a8d4"/>
          <circle cx="22" cy="20" r="1" fill="#f9a8d4"/>
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between">
          {/* 🌸 벚꽃 정원 로고 */}
          <div className="flex items-center space-x-3 mb-6 md:mb-0">
            <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-rose-500 rounded-2xl flex items-center justify-center shadow-xl shadow-pink-500/60 border-2 border-white/40 backdrop-blur-sm">
              <span className="text-white font-bold text-xl drop-shadow-lg">🌸</span>
            </div>
            <div>
              <h3 className="text-xl font-bold text-pink-700 drop-shadow-lg">BlossomCheck</h3>
              <p className="text-pink-600 text-sm drop-shadow-sm">🌺 AI 벚꽃 로즈 시스템</p>
            </div>
          </div>
          
          {/* 🌸 간단한 정보 */}
          <div className="text-center md:text-right">
            <p className="text-pink-600 text-sm mb-2 drop-shadow-sm backdrop-blur-sm bg-white/25 rounded-xl px-4 py-2 border border-white/40">
              © 2025 BlossomCheck. All roses reserved.
            </p>
            <div className="flex items-center justify-center md:justify-end space-x-4 text-xs text-pink-500/80">
              <span className="bg-white/25 backdrop-blur-sm rounded-lg px-3 py-1 border border-white/40">벚꽃 정원 문의</span>
              <span>•</span>
              <span className="bg-white/25 backdrop-blur-sm rounded-lg px-3 py-1 border border-white/40">blossom@skycheck.co.kr</span>
            </div>
          </div>
        </div>
                
        {/* 🌺 로즈 기술 스택 */}
        <div className="mt-8 pt-8 border-t border-white/40 text-center">
          <div className="bg-white/30 backdrop-blur-md rounded-2xl p-6 border border-white/40 shadow-lg shadow-pink-500/30">
            <p className="text-pink-600 text-sm drop-shadow-sm mb-4">
              Powered by <span className="text-pink-700 font-semibold">👁️ YOLO8 벚꽃의 눈</span> •
              <span className="text-rose-700 font-semibold"> 🔮 OCR 벚꽃 추출</span> •
              <span className="text-pink-700 font-semibold"> 🌺 GPT 로즈</span>
            </p>
          </div>
        </div>

        {/* 🌸 추가 로즈한 장식 */}
        <div className="mt-6 text-center">
          <div className="inline-flex items-center space-x-3 bg-white/30 backdrop-blur-md px-6 py-3 rounded-full border border-white/40 shadow-lg shadow-pink-500/40">
            <span className="text-pink-600 text-xs">⚡ 벚꽃 정원 서버 상태:</span>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-pink-500 rounded-full animate-pulse shadow-sm"></div>
              <span className="text-pink-700 text-xs font-semibold">운영중</span>
            </div>
          </div>
        </div>

        {/* 🌸 벚꽃 정원 축복 메시지 */}
        <div className="mt-6 text-center">
          <div className="bg-white/25 backdrop-blur-sm rounded-2xl p-4 border border-white/40 shadow-lg max-w-2xl mx-auto">
            <p className="text-pink-600/80 text-xs italic drop-shadow-sm">
              "로즈 속에서 태어나 벚꽃 정원을 품는 자들을 위한 벚꽃 시스템"
            </p>
          </div>
        </div>
      </div>

      {/* 🌸 하단 로즈 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-10 bg-gradient-to-t from-white/50 to-transparent pointer-events-none backdrop-blur-sm"></div>
      
      {/* 🌹 로즈 테두리 */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-pink-400/70 to-transparent shadow-sm"></div>
    </footer>
  );
}