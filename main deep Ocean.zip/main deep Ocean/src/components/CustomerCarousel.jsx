// ============================================
// 🌊 Deep Ocean CustomerCarousel.jsx - 심해 파트너십
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import Slider from 'react-slick';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

gsap.registerPlugin(ScrollTrigger);

const customers = [
  {
    name: '아쿠아대학교',
    logo: 'https://via.placeholder.com/200x80/1E40AF/FFFFFF?text=아쿠아대학교',
    category: '심해 대학',
    testimonial: '정확한 학습 지원으로 바다 교수들의 업무 효율성이 크게 향상되었습니다.',
    usage: '월 9,999장 처리',
    satisfaction: '100%'
  },
  {
    name: '강남구 심해 교육청',
    logo: 'https://via.placeholder.com/200x80/2563EB/FFFFFF?text=심해구청',
    category: '바다청',
    testimonial: '지역 내 모든 심해 학교에서 만족스럽게 사용하고 있습니다.',
    usage: '월 77,777장 처리',
    satisfaction: '99.8%'
  },
  {
    name: '메가오션 교육',
    logo: 'https://via.placeholder.com/200x80/0EA5E9/FFFFFF?text=메가오션',
    category: '바다 기업',
    testimonial: '학습자들의 성장 효과를 극대화할 수 있는 최고의 바다 도구입니다.',
    usage: '월 88,800장 처리',
    satisfaction: '100%'
  },
  {
    name: '딥블루 심해교육',
    logo: 'https://via.placeholder.com/200x80/0D9488/FFFFFF?text=딥블루',
    category: '심해 교육',
    testimonial: '복잡한 학습 문제도 정확하게 지원해주어 매우 만족합니다.',
    usage: '월 9,990장 처리',
    satisfaction: '99.9%'
  },
  {
    name: '대치동 바다학원',
    logo: 'https://via.placeholder.com/200x80/1E40AF/FFFFFF?text=바다학원',
    category: '심해 학원',
    testimonial: '바다 선생님들의 부담이 줄어 교육 준비에 더 집중할 수 있습니다.',
    usage: '월 19,998장 처리',
    satisfaction: '99.7%'
  },
  {
    name: '경기도 심해교육청',
    logo: 'https://via.placeholder.com/200x80/2563EB/FFFFFF?text=심해교육청',
    category: '바다청',
    testimonial: '도내 전체 심해 학교의 교육 시스템이 한층 업그레이드되었습니다.',
    usage: '월 99,999장 처리',
    satisfaction: '100%'
  }
];

// 🌊 심해 화살표 컴포넌트
const CustomArrow = ({ className, style, onClick, direction }) => (
  <div
    className={`${className} !w-14 !h-14 !bg-slate-800/30 !backdrop-blur-md !rounded-full !shadow-2xl !shadow-indigo-500/50 hover:!shadow-2xl hover:!shadow-cyan-500/70 !flex !items-center !justify-center !transition-all !duration-300 hover:!scale-110 !z-10 border-2 border-slate-700/50 hover:border-cyan-400/50`}
    style={{ ...style, display: 'flex' }}
    onClick={onClick}
  >
    <svg 
      className="w-7 h-7 text-cyan-300 hover:text-cyan-100 transition-colors duration-200 drop-shadow-lg" 
      fill="none" 
      stroke="currentColor" 
      viewBox="0 0 24 24"
    >
      {direction === 'next' ? (
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" />
      ) : (
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15 19l-7-7 7-7" />
      )}
    </svg>
  </div>
);

export default function CustomerCarousel() {
  const sectionRef = useRef(null);
  const titleRef = useRef(null);
  const carouselRef = useRef(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 🌊 제목 애니메이션
      gsap.fromTo(titleRef.current,
        {
          y: 80,
          opacity: 0,
          scale: 0.8,
          rotationX: -30
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          rotationX: 0,
          duration: 1.2,
          ease: "power4.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // 🌊 캐러셀 애니메이션
      gsap.fromTo(carouselRef.current,
        {
          y: 60,
          opacity: 0,
          scale: 0.9
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          duration: 1.0,
          ease: "power3.out",
          delay: 0.4,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const settings = {
    dots: true,
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 7777,
    pauseOnHover: true,
    nextArrow: <CustomArrow direction="next" />,
    prevArrow: <CustomArrow direction="prev" />,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 640,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          arrows: false
        }
      }
    ],
    customPaging: (i) => (
      <div className="w-3 h-3 bg-cyan-400/60 rounded-full hover:bg-cyan-300 transition-colors duration-200 mt-4 shadow-sm"></div>
    ),
    dotsClass: "slick-dots !flex !justify-center !space-x-2"
  };

  const getCategoryColor = (category) => {
    const colors = {
      '심해 대학': 'bg-indigo-900/60 text-indigo-300 border border-indigo-600/50 backdrop-blur-sm',
      '바다청': 'bg-blue-900/60 text-blue-300 border border-blue-600/50 backdrop-blur-sm',
      '바다 기업': 'bg-cyan-900/60 text-cyan-300 border border-cyan-600/50 backdrop-blur-sm',
      '심해 교육': 'bg-teal-900/60 text-teal-300 border border-teal-600/50 backdrop-blur-sm',
      '심해 학원': 'bg-slate-800/60 text-cyan-300 border border-cyan-600/50 backdrop-blur-sm'
    };
    return colors[category] || 'bg-slate-800/60 text-cyan-300 border border-cyan-600/50 backdrop-blur-sm';
  };

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-br from-slate-900 via-indigo-900 to-blue-950 overflow-hidden relative">
      {/* 🌊 심해 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900/90 via-indigo-900/70 to-blue-900/80"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_25%,rgba(30,64,175,0.2)_0%,rgba(15,23,42,0.8)_40%,rgba(30,58,138,0.15)_80%)]"></div>
      
      {/* 🐠 떠다니는 심해 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-12 left-1/4 w-3 h-3 bg-blue-400/40 rounded-full animate-pulse shadow-lg shadow-blue-500/50"></div>
        <div className="absolute top-32 right-1/3 w-2 h-2 bg-cyan-400/50 rounded-full animate-pulse delay-1000 shadow-lg shadow-cyan-500/50"></div>
        <div className="absolute bottom-24 left-1/2 w-2 h-2 bg-indigo-400/40 rounded-full animate-pulse delay-500 shadow-lg shadow-indigo-500/50"></div>
        <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-teal-500/50 rounded-full animate-pulse delay-1500 shadow-lg shadow-teal-500/50"></div>
        
        {/* 🐙 장식 요소들 */}
        <div className="absolute top-20 right-10 opacity-20">
          <svg width="60" height="80" viewBox="0 0 60 80">
            <path d="M30 80 L30 40 M15 40 Q30 25 45 40" stroke="#3B82F6" strokeWidth="2" fill="none"/>
            <circle cx="30" cy="35" r="6" fill="#1E40AF"/>
          </svg>
        </div>
        <div className="absolute bottom-32 left-16 opacity-25">
          <svg width="40" height="60" viewBox="0 0 40 60">
            <path d="M20 60 L20 30 M10 30 Q20 20 30 30" stroke="#0891b2" strokeWidth="2" fill="none"/>
            <circle cx="20" cy="25" r="4" fill="#0891b2"/>
          </svg>
        </div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* 🌊 헤더 */}
        <div ref={titleRef} className="text-center mb-16" data-aos="fade-up">
          <div className="inline-flex items-center space-x-3 bg-slate-800/30 backdrop-blur-md border border-slate-700/50 text-cyan-300 px-6 py-3 rounded-full text-sm font-bold mb-6 shadow-lg shadow-indigo-500/30 hover:shadow-xl hover:shadow-cyan-500/50 transition-all duration-300 hover:scale-105">
            <span>🌊</span>
            <span>심해 파트너십</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-cyan-300 mb-6 drop-shadow-2xl">
            <span className="bg-gradient-to-r from-cyan-300 to-blue-300 bg-clip-text text-transparent">999+</span> 
            심해 기관이
            <br className="hidden sm:block" />
            OceanCheck을 선택한 이유
          </h2>
          <p className="text-xl text-cyan-200 max-w-3xl mx-auto leading-relaxed drop-shadow-lg backdrop-blur-sm bg-slate-800/20 rounded-2xl p-6 border border-slate-700/30">
            전국의 심해 학교, 바다 학원, 심해청에서 검증된 AI 바다 시스템으로 
            <br className="hidden md:block" />
            교육의 질을 한층 더 높이고 있습니다
          </p>
        </div>

        {/* 🌊 고객사 캐러셀 */}
        <div ref={carouselRef} className="relative">
          <Slider {...settings}>
            {customers.map((customer, index) => (
              <div key={index} className="px-4">
                <div className="bg-slate-800/40 backdrop-blur-md rounded-3xl p-8 shadow-2xl shadow-indigo-500/20 hover:shadow-2xl hover:shadow-cyan-500/40 transition-all duration-500 border border-slate-700/50 group cursor-pointer h-full relative overflow-hidden">
                  {/* 🐠 카테고리 배지 */}
                  <div className="flex justify-between items-start mb-6">
                    <span className={`px-4 py-2 rounded-full text-sm font-bold ${getCategoryColor(customer.category)}`}>
                      {customer.category}
                    </span>
                    <div className="text-right">
                      <div className="text-sm text-cyan-300/80">바다 만족도</div>
                      <div className="text-2xl font-bold text-cyan-300 drop-shadow-sm">{customer.satisfaction}</div>
                    </div>
                  </div>

                  {/* 🌊 로고 */}
                  <div className="text-center mb-6">
                    <div className="relative inline-block group-hover:scale-105 transition-transform duration-300">
                      <img 
                        src={customer.logo} 
                        alt={customer.name}
                        className="h-16 mx-auto rounded-lg shadow-md shadow-indigo-500/30 hover:shadow-lg hover:shadow-cyan-500/50 transition-shadow duration-300 brightness-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-indigo-600/20 to-cyan-600/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </div>
                  </div>

                  {/* 🐙 기관명 */}
                  <h3 className="text-xl font-bold text-cyan-300 text-center mb-4 group-hover:text-cyan-100 transition-colors duration-300 drop-shadow-lg">
                    {customer.name}
                  </h3>

                  {/* 🌊 처리량 */}
                  <div className="bg-slate-800/60 backdrop-blur-sm rounded-2xl p-4 mb-6 border border-slate-700/50 shadow-lg">
                    <div className="flex items-center justify-center space-x-2">
                      <span className="text-2xl">🌊</span>
                      <div className="text-center">
                        <div className="text-sm text-cyan-300/80">바다 처리량</div>
                        <div className="font-bold text-cyan-300 drop-shadow-sm">{customer.usage}</div>
                      </div>
                    </div>
                  </div>

                  {/* 🐠 후기 */}
                  <blockquote className="text-cyan-200 text-center italic leading-relaxed group-hover:text-cyan-100 transition-colors duration-300 drop-shadow-sm">
                    "{customer.testimonial}"
                  </blockquote>

                  {/* 🌊 별점 표시 */}
                  <div className="flex justify-center mt-6 space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-cyan-400 text-lg drop-shadow-sm animate-pulse" style={{animationDelay: `${i * 0.2}s`}}>⭐</span>
                    ))}
                  </div>
                  
                  {/* 🌊 심해 글로우 효과 */}
                  <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/10 to-cyan-600/10 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                </div>
              </div>
            ))}
          </Slider>
        </div>

        {/* 🌊 통계 요약 */}
        <div className="mt-16 bg-slate-800/30 backdrop-blur-md rounded-3xl p-8 md:p-12 border border-slate-700/50 shadow-2xl shadow-indigo-500/20" data-aos="fade-up" data-aos-delay="400">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-cyan-300 mb-4 drop-shadow-lg">
              📈 <span className="bg-gradient-to-r from-cyan-300 to-blue-300 bg-clip-text text-transparent">바다의 성과</span>
            </h3>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: '999', label: '심해 파트너 기관', icon: '🏛️', color: 'cyan' },
              { number: '77.7M+', label: '누적 바다 수', icon: '🌊', color: 'blue' },
              { number: '100%', label: '심해 만족도', icon: '🐙', color: 'indigo' },
              { number: '88.8%', label: '학습 효율 증가', icon: '⚡', color: 'teal' }
            ].map((stat, index) => (
              <div key={index} className="text-center group">
                <div className={`inline-flex items-center justify-center w-16 h-16 bg-slate-800/60 backdrop-blur-sm border border-slate-700/50 rounded-2xl mb-4 group-hover:scale-110 transition-transform duration-300 shadow-md shadow-indigo-500/30 group-hover:shadow-lg group-hover:shadow-cyan-500/50`}>
                  <span className="text-3xl drop-shadow-lg">{stat.icon}</span>
                </div>
                <div className={`text-3xl font-black text-cyan-300 mb-2 group-hover:scale-110 transition-transform duration-300 drop-shadow-lg`}>
                  {stat.number}
                </div>
                <div className="text-sm text-cyan-200 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 🌊 CTA */}
        <div className="text-center mt-12" data-aos="fade-up" data-aos-delay="600">
          <p className="text-cyan-200 mb-6 drop-shadow-sm backdrop-blur-sm bg-slate-800/20 rounded-xl p-4 border border-slate-700/30 inline-block">
            당신의 기관도 OceanCheck과 함께 심해의 혁신을 시작해보세요
          </p>
          <button className="bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 text-cyan-100 px-10 py-5 rounded-3xl font-bold text-xl shadow-2xl shadow-indigo-500/50 hover:shadow-3xl hover:shadow-cyan-500/70 transition-all duration-500 hover:scale-105 group border-2 border-slate-700/50 backdrop-blur-sm">
            <span className="flex items-center justify-center">
              🌊 심해 상담 신청
              <svg className="ml-3 w-6 h-6 group-hover:translate-x-2 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </span>
          </button>
        </div>
      </div>
      
      <style jsx>{`
        .shadow-3xl {
          box-shadow: 0 35px 60px -12px rgba(0, 0, 0, 0.25);
        }
      `}</style>
    </section>
  );
}