// ============================================
// 🌸 Spring Blossom ContentLeft.jsx - 벚꽃 좌측 콘텐츠
// ============================================
import React, { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function ContentLeft({ 
  title = "벚꽃 정원 기능",
  subtitle = "로즈 학습 경험", 
  description = "봄바람의 AI 기술로 완벽한 학습을 지원합니다.",
  features = [],
  image = null,
  ctaText = "벚꽃 정원 체험하기",
  onCtaClick = () => {},
  className = "",
  ...props 
}) {
  const containerRef = useRef(null);
  const contentRef = useRef(null);
  const imageRef = useRef(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 🌸 좌측 콘텐츠 애니메이션 (벚꽃 느낌으로)
      gsap.fromTo(contentRef.current,
        { 
          x: -100, 
          opacity: 0, 
          rotationY: -15,
          filter: "blur(10px)"
        },
        { 
          x: 0, 
          opacity: 1, 
          rotationY: 0,
          filter: "blur(0px)",
          duration: 1.2, 
          ease: "power4.out",
          scrollTrigger: {
            trigger: containerRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // 🌺 우측 이미지 애니메이션 (벚꽃 정원 효과)
      if (imageRef.current) {
        gsap.fromTo(imageRef.current,
          { 
            x: 100, 
            opacity: 0, 
            scale: 0.8,
            rotationY: 15
          },
          { 
            x: 0, 
            opacity: 1, 
            scale: 1,
            rotationY: 0,
            duration: 1.2, 
            ease: "power4.out",
            delay: 0.3,
            scrollTrigger: {
              trigger: containerRef.current,
              start: "top 80%",
              end: "bottom 20%",
              toggleActions: "play none none reverse"
            }
          }
        );
      }
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={containerRef}
      className={`py-20 bg-gradient-to-br from-pink-50 via-rose-50 to-pink-100 relative overflow-hidden ${className}`}
      {...props}
    >
      {/* 🌸 벚꽃 정원 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/80 via-pink-50/60 to-rose-100/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_80%,rgba(253,125,191,0.18)_0%,rgba(251,207,232,0.12)_50%,rgba(244,114,182,0.18)_80%)]"></div>
      
      {/* 🌺 흩날리는 벚꽃 꽃잎들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-4 h-4 bg-pink-400/50 rounded-full animate-pulse shadow-lg transform rotate-45"></div>
        <div className="absolute top-32 right-1/3 w-3 h-3 bg-rose-400/60 rounded-full animate-pulse delay-700 shadow-lg transform rotate-12"></div>
        <div className="absolute bottom-24 left-1/2 w-3 h-3 bg-pink-300/50 rounded-full animate-pulse delay-1000 shadow-lg transform -rotate-12"></div>
        <div className="absolute top-1/2 right-1/4 w-3 h-3 bg-rose-500/60 rounded-full animate-pulse delay-500 shadow-lg"></div>
        <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-pink-300/50 rounded-full animate-pulse delay-1500 shadow-lg transform rotate-45"></div>
        <div className="absolute top-20 right-1/5 w-2 h-2 bg-rose-300/40 rounded-full animate-pulse delay-300 shadow-lg transform -rotate-30"></div>
      </div>

      {/* 🌸 장식 벚꽃 나무 */}
      <div className="absolute top-20 right-16 opacity-15">
        <svg width="100" height="140" viewBox="0 0 100 140">
          <path d="M50 140 L50 70 M30 70 Q50 50 70 70 M25 65 Q50 45 75 65" stroke="#ec4899" strokeWidth="4" fill="none"/>
          <circle cx="50" cy="60" r="10" fill="#ec4899"/>
          <path d="M40 60 Q25 40 10 45 M60 60 Q75 40 90 45" stroke="#f472b6" strokeWidth="3" fill="none"/>
          {/* 벚꽃 */}
          <circle cx="35" cy="55" r="3" fill="#fce7f3"/>
          <circle cx="65" cy="58" r="3" fill="#fce7f3"/>
          <circle cx="45" cy="50" r="2" fill="#f9a8d4"/>
          <circle cx="55" cy="52" r="2" fill="#f9a8d4"/>
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* 🌸 좌측 콘텐츠 */}
          <div ref={contentRef} className="order-2 lg:order-1">
            {/* 🌺 배지 */}
            <div className="inline-flex items-center space-x-3 bg-white/30 backdrop-blur-md border border-white/40 text-pink-700 px-6 py-3 rounded-full text-sm font-bold mb-6 shadow-lg shadow-pink-500/40 hover:shadow-xl hover:shadow-rose-500/60 transition-all duration-300 hover:scale-105">
              <span>🌸</span>
              <span>벚꽃 정원 혁신</span>
            </div>

            {/* 🌺 타이틀 */}
            <h2 className="text-4xl md:text-5xl font-black text-pink-700 mb-4 drop-shadow-2xl">
              <span className="bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">
                {title}
              </span>
            </h2>

            {/* 🌹 서브타이틀 */}
            <h3 className="text-2xl font-bold text-rose-600 mb-6 drop-shadow-lg">
              {subtitle}
            </h3>

            {/* 🌺 설명 */}
            <div className="bg-white/30 backdrop-blur-md rounded-2xl p-6 border border-white/40 shadow-lg mb-8">
              <p className="text-lg text-pink-600 leading-relaxed drop-shadow-sm">
                {description}
              </p>
            </div>

            {/* 🌸 특징 목록 */}
            {features.length > 0 && (
              <div className="mb-8">
                <h4 className="text-xl font-bold text-pink-700 mb-4 drop-shadow-sm">🌺 주요 특징</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {features.map((feature, index) => (
                    <div 
                      key={index}
                      className="flex items-start space-x-3 bg-white/25 backdrop-blur-sm rounded-xl p-4 border border-white/40 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
                    >
                      <span className="text-pink-500 mt-1 drop-shadow-sm flex-shrink-0">
                        {feature.icon || '🌸'}
                      </span>
                      <div>
                        <h5 className="font-semibold text-pink-700 drop-shadow-sm">
                          {feature.title}
                        </h5>
                        <p className="text-pink-600 text-sm drop-shadow-sm">
                          {feature.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 🌸 CTA 버튼 */}
            <button
              onClick={onCtaClick}
              className="bg-gradient-to-r from-pink-500 via-rose-500 to-pink-600 text-white px-10 py-5 rounded-3xl font-bold text-xl shadow-2xl shadow-pink-500/60 hover:shadow-3xl hover:shadow-rose-500/80 transition-all duration-500 hover:scale-105 group border-2 border-white/40 backdrop-blur-sm relative overflow-hidden"
            >
              <span className="relative z-10 flex items-center justify-center">
                {ctaText}
                <svg className="ml-3 w-6 h-6 group-hover:translate-x-2 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-white/15 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
            </button>
          </div>

          {/* 🌸 우측 이미지/콘텐츠 */}
          <div ref={imageRef} className="order-1 lg:order-2">
            {image ? (
              <div className="relative">
                <div className="bg-white/35 backdrop-blur-md rounded-3xl p-8 shadow-3xl shadow-pink-500/40 hover:shadow-3xl hover:shadow-rose-500/50 border border-white/50 transition-all duration-500 hover:scale-105 relative overflow-hidden">
                  {/* 🌺 로즈 배경 효과 */}
                  <div className="absolute inset-0 bg-gradient-to-br from-pink-100/25 to-rose-100/25 rounded-3xl"></div>
                  
                  <img 
                    src={image} 
                    alt={title}
                    className="w-full h-auto rounded-2xl shadow-xl relative z-10"
                  />
                  
                  {/* 🌹 로즈 꽃잎들 */}
                  <div className="absolute top-4 right-4 w-4 h-4 bg-pink-400/60 rounded-full animate-pulse shadow-lg transform rotate-45"></div>
                  <div className="absolute bottom-6 left-6 w-3 h-3 bg-rose-400/70 rounded-full animate-ping shadow-lg transform rotate-12"></div>
                  <div className="absolute top-1/2 right-8 w-3 h-3 bg-pink-300/60 rounded-full animate-bounce shadow-lg transform -rotate-12"></div>
                </div>

                {/* 🌺 떠다니는 장식 요소들 */}
                <div className="absolute -top-6 -right-6 w-16 h-16 bg-gradient-to-br from-pink-500 to-rose-500 rounded-3xl flex items-center justify-center shadow-2xl shadow-pink-500/60 animate-bounce border-2 border-white/40 backdrop-blur-sm">
                  <span className="text-white text-2xl drop-shadow-lg">🌺</span>
                </div>
                
                <div className="absolute -bottom-6 -left-6 w-16 h-16 bg-gradient-to-br from-rose-500 to-pink-600 rounded-3xl flex items-center justify-center shadow-2xl shadow-rose-500/60 animate-pulse border-2 border-white/40 backdrop-blur-sm">
                  <span className="text-white text-2xl drop-shadow-lg">🌹</span>
                </div>
              </div>
            ) : (
              /* 🌸 기본 일러스트레이션 */
              <div className="bg-white/35 backdrop-blur-md rounded-3xl p-12 shadow-3xl shadow-pink-500/40 border border-white/50 relative overflow-hidden">
                {/* 🌸 로즈 배경 효과 */}
                <div className="absolute inset-0 bg-gradient-to-br from-pink-100/25 to-rose-100/25 rounded-3xl"></div>
                
                <div className="text-center relative z-10">
                  <div className="w-32 h-32 bg-gradient-to-br from-pink-500 to-rose-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-pink-500/60 border-4 border-white/40">
                    <span className="text-6xl text-white drop-shadow-2xl">🌸</span>
                  </div>
                  
                  <h3 className="text-2xl font-bold text-pink-700 mb-4 drop-shadow-lg">
                    벚꽃 정원 경험
                  </h3>
                  
                  <p className="text-pink-600 leading-relaxed drop-shadow-sm">
                    봄바람의 벚꽃처럼 아름답고 순수한 
                    <br />
                    AI 학습 경험을 만나보세요
                  </p>
                </div>

                {/* 🌹 로즈 꽃잎들 */}
                <div className="absolute top-4 right-4 w-4 h-4 bg-pink-400/60 rounded-full animate-pulse shadow-lg transform rotate-45"></div>
                <div className="absolute bottom-6 left-6 w-3 h-3 bg-rose-400/70 rounded-full animate-ping shadow-lg transform rotate-12"></div>
                <div className="absolute top-1/2 right-8 w-3 h-3 bg-pink-300/60 rounded-full animate-bounce shadow-lg transform -rotate-12"></div>
                <div className="absolute top-1/3 left-8 w-2 h-2 bg-rose-500/70 rounded-full animate-pulse delay-700 transform rotate-45"></div>
                <div className="absolute bottom-1/3 right-1/3 w-2 h-2 bg-pink-400/50 rounded-full animate-pulse delay-400 transform -rotate-30"></div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 🌸 하단 로즈 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white/50 to-transparent pointer-events-none backdrop-blur-sm"></div>
      
      <style jsx>{`
        .shadow-3xl {
          box-shadow: 0 35px 60px -12px rgba(0, 0, 0, 0.25);
        }
      `}</style>
    </section>
  );
}