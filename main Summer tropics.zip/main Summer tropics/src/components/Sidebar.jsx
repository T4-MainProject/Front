// ============================================
// 🏝️ Tropical Paradise Footer.jsx - 파라다이스 푸터
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const footerSections = [
  {
    title: '파라다이스 서비스',
    links: [
      { name: 'AI 자동 채점', href: '#' },
      { name: '대량 채점 처리', href: '#' },
      { name: '파라다이스 API 서비스', href: '#' },
      { name: '교육기관 솔루션', href: '#' }
    ]
  },
  {
    title: '크리스탈 지원',
    links: [
      { name: '사용자 가이드', href: '#' },
      { name: '자주 묻는 질문', href: '#' },
      { name: '기술 지원', href: '#' },
      { name: '문의하기', href: '#' }
    ]
  },
  {
    title: '파라다이스 회사',
    links: [
      { name: '회사 소개', href: '#' },
      { name: '채용 정보', href: '#' },
      { name: '보도자료', href: '#' },
      { name: '파트너십', href: '#' }
    ]
  }
];

const socialLinks = [
  { name: 'Paradise Twitter', icon: '🐦', href: '#', color: 'hover:bg-emerald-500' },
  { name: 'Crystal Book', icon: '📖', href: '#', color: 'hover:bg-cyan-500' },
  { name: 'Paradise Gram', icon: '📸', href: '#', color: 'hover:bg-emerald-400' },
  { name: 'Crystal In', icon: '💼', href: '#', color: 'hover:bg-sky-500' },
  { name: 'Paradise Tube', icon: '📺', href: '#', color: 'hover:bg-teal-500' }
];

export default function Footer() {
  const footerRef = useRef(null);
  const sectionsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 파라다이스 푸터 섹션들 애니메이션 (부드럽고 우아하게)
      gsap.fromTo(sectionsRef.current,
        {
          y: 80,
          opacity: 0,
          scale: 0.9,
          filter: "blur(5px)"
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          filter: "blur(0px)",
          duration: 1.0,
          stagger: 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: footerRef.current,
            start: "top 90%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, footerRef);

    return () => ctx.revert();
  }, []);

  return (
    <footer ref={footerRef} className="bg-gradient-to-br from-emerald-100 via-cyan-50 to-sky-100 text-emerald-700 relative overflow-hidden">
      {/* 파라다이스 배경 장식 */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-gradient-to-br from-emerald-400/20 to-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-gradient-to-br from-sky-400/15 to-emerald-300/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-br from-cyan-400/10 to-emerald-300/15 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* 추가 파라다이스 레이어 */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/30 via-emerald-50/40 to-cyan-100/30"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.1)_0%,rgba(6,182,212,0.05)_50%,rgba(14,165,233,0.1)_100%)]"></div>

      {/* 움직이는 크리스탈 파티클 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-16 left-1/4 w-2 h-2 bg-emerald-400/40 rounded-full animate-pulse shadow-sm"></div>
        <div className="absolute top-32 right-1/3 w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse delay-700 shadow-sm"></div>
        <div className="absolute bottom-24 left-1/2 w-1 h-1 bg-sky-400/30 rounded-full animate-pulse delay-1000 shadow-sm"></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-teal-500/40 rounded-full animate-pulse delay-500 shadow-sm"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-emerald-300/30 rounded-full animate-pulse delay-1500 shadow-sm"></div>
        <div className="absolute top-1/3 left-1/5 w-1 h-1 bg-emerald-500/40 rounded-full animate-pulse delay-300 shadow-sm"></div>
      </div>

      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
          {/* 파라다이스 회사 정보 */}
          <div 
            ref={el => sectionsRef.current[0] = el}
            className="lg:col-span-2"
          >
            <div className="flex items-center space-x-4 mb-6">
              <div className="relative group">
                <div className="w-14 h-14 bg-gradient-to-br from-emerald-500 via-cyan-400 to-sky-500 rounded-2xl flex items-center justify-center shadow-2xl shadow-emerald-500/50 group-hover:scale-110 transition-transform duration-300 border-2 border-white/30">
                  <span className="text-white font-bold text-2xl drop-shadow-lg">🏝️</span>
                </div>
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/40 via-cyan-300/20 to-sky-400/40 rounded-2xl blur opacity-50 group-hover:opacity-70 transition-opacity duration-300"></div>
              </div>
              <div>
                <h3 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-cyan-600 bg-clip-text text-transparent drop-shadow-lg">
                  ParadiseCheck
                </h3>
                <p className="text-emerald-600/80 text-sm font-medium tracking-wide">
                  🏖️ AI POWERED PARADISE SYSTEM
                </p>
              </div>
            </div>
            
            <p className="text-emerald-600/80 mb-6 leading-relaxed max-w-md drop-shadow-sm">
              첨단 크리스탈 기술로 파라다이스의 미래를 만들어가는 ParadiseCheck. 
              정확하고 빠른 자동 채점으로 더 나은 학습 경험을 제공합니다.
            </p>
            
            {/* 파라다이스 소셜 미디어 */}
            <div className="flex space-x-3 mb-8">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className={`w-12 h-12 bg-white/40 backdrop-blur-sm ${social.color} rounded-xl flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-lg hover:shadow-emerald-500/30 group border border-white/50 hover:border-emerald-400`}
                  title={social.name}
                >
                  <span className="text-xl group-hover:scale-110 transition-transform duration-200 drop-shadow-sm">
                    {social.icon}
                  </span>
                </a>
              ))}
            </div>

            {/* 파라다이스 연락처 정보 */}
            <div className="space-y-3 text-sm text-emerald-600/80">
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-emerald-100/60 rounded-lg flex items-center justify-center group-hover:bg-emerald-200 transition-colors duration-200 border border-emerald-300/50">
                  <span>📧</span>
                </div>
                <div>
                  <p className="text-emerald-700 font-medium">support@paradise.co.kr</p>
                  <p className="text-xs text-emerald-600/70">고객 지원 이메일</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-emerald-100/60 rounded-lg flex items-center justify-center group-hover:bg-emerald-200 transition-colors duration-200 border border-emerald-300/50">
                  <span>📞</span>
                </div>
                <div>
                  <p className="text-emerald-700 font-medium">02-1234-5678</p>
                  <p className="text-xs text-emerald-600/70">평일 09:00 - 18:00</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 group">
                <div className="w-8 h-8 bg-emerald-100/60 rounded-lg flex items-center justify-center group-hover:bg-emerald-200 transition-colors duration-200 border border-emerald-300/50">
                  <span>📍</span>
                </div>
                <div>
                  <p className="text-emerald-700 font-medium">서울특별시 강남구 테헤란로 123</p>
                  <p className="text-xs text-emerald-600/70">ParadiseCheck 본사</p>
                </div>
              </div>
            </div>
          </div>

          {/* 파라다이스 링크 섹션들 */}
          {footerSections.map((section, index) => (
            <div 
              key={index}
              ref={el => sectionsRef.current[index + 1] = el}
              className="lg:col-span-1"
            >
              <h4 className="text-lg font-bold mb-6 text-emerald-700 relative drop-shadow-sm">
                {section.title}
                <div className="absolute bottom-0 left-0 w-8 h-0.5 bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-full"></div>
              </h4>
              <ul className="space-y-4">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a 
                      href={link.href}
                      className="text-emerald-600/80 hover:text-emerald-700 transition-all duration-200 hover:translate-x-2 transform inline-block relative group py-1"
                    >
                      <span className="relative z-10 drop-shadow-sm">{link.name}</span>
                      <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-emerald-500 to-cyan-500 group-hover:w-full transition-all duration-300"></span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* 파라다이스 구분선 */}
        <div className="my-12">
          <div className="h-px bg-gradient-to-r from-transparent via-emerald-300/50 to-transparent"></div>
        </div>
        
        {/* 파라다이스 하단 정보 */}
        <div 
          ref={el => sectionsRef.current[4] = el}
          className="flex flex-col lg:flex-row justify-between items-center text-sm text-emerald-600/80"
        >
          <div className="space-y-2 lg:space-y-0 text-center lg:text-left mb-6 lg:mb-0">
            <p className="font-medium drop-shadow-sm">© 2025 ParadiseCheck Co., Ltd. All rights reserved.</p>
            <p className="text-xs">
              사업자등록번호: 123-45-67890 | 대표: 🏝️ 김파라다이스 | 통신판매업신고: 2024-서울강남구-1234
            </p>
          </div>
          
          <div className="flex flex-wrap justify-center lg:justify-end gap-6">
            <a href="#" className="hover:text-emerald-700 transition-colors duration-200 relative group">
              <span>이용약관</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-emerald-500 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-emerald-700 transition-colors duration-200 relative group font-semibold">
              <span>개인정보처리방침</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-cyan-500 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-emerald-700 transition-colors duration-200 relative group">
              <span>쿠키정책</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-sky-500 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#" className="hover:text-emerald-700 transition-colors duration-200 relative group">
              <span>사이트맵</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-teal-500 group-hover:w-full transition-all duration-300"></span>
            </a>
          </div>
        </div>

        {/* 파라다이스 인증 마크들 */}
        <div 
          ref={el => sectionsRef.current[5] = el}
          className="mt-12 pt-8 border-t border-emerald-300/50 flex flex-wrap justify-center lg:justify-start items-center gap-4 text-xs text-emerald-600/80"
        >
          <div className="flex items-center space-x-2 bg-white/40 backdrop-blur-sm px-4 py-2 rounded-xl border border-emerald-300/50 hover:border-emerald-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🔒</span>
            <span className="text-emerald-700">보안 인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-white/40 backdrop-blur-sm px-4 py-2 rounded-xl border border-emerald-300/50 hover:border-emerald-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">✅</span>
            <span className="text-emerald-700">개인정보보호 인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-white/40 backdrop-blur-sm px-4 py-2 rounded-xl border border-emerald-300/50 hover:border-emerald-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🏆</span>
            <span className="text-emerald-700">ISO 27001 인증</span>
          </div>
          <div className="flex items-center space-x-2 bg-white/40 backdrop-blur-sm px-4 py-2 rounded-xl border border-emerald-300/50 hover:border-emerald-400 transition-colors duration-200 group">
            <span className="group-hover:scale-110 transition-transform duration-200">🛡️</span>
            <span className="text-emerald-700">GDPR 준수</span>
          </div>
        </div>

        {/* 파라다이스 추가 정보 */}
        <div 
          ref={el => sectionsRef.current[6] = el}
          className="mt-8 text-center"
        >
          <p className="text-xs text-emerald-600/70 leading-relaxed max-w-2xl mx-auto drop-shadow-sm">
            ParadiseCheck는 크리스탈 기술 혁신을 통해 더 나은 교육 환경을 만들어가고 있습니다. 
            우리의 AI 기술이 전 세계 교육자와 학습자들에게 도움이 되기를 바랍니다.
          </p>
          
          <div className="mt-6 flex justify-center items-center space-x-2 text-xs text-emerald-600/80">
            <span>Made with</span>
            <span className="text-emerald-500 animate-pulse">💚</span>
            <span>in Seoul, Korea</span>
          </div>
        </div>

        {/* 추가 파라다이스 안내 */}
        <div 
          ref={el => sectionsRef.current[7] = el}
          className="mt-8 text-center"
        >
          <div className="inline-flex items-center space-x-2 bg-emerald-100/60 text-emerald-700 px-4 py-2 rounded-full text-xs border border-emerald-300/50">
            <span>🌟</span>
            <span>이 사이트는 파라다이스 보안 시스템으로 보호됩니다</span>
          </div>
        </div>
      </div>

      {/* 하단 파라다이스 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-white/20 to-transparent pointer-events-none"></div>
    </footer>
  );
}