// ============================================
// 🌊 Deep Ocean FeatureList.jsx - 심해 특징 목록
// ============================================
import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const features = [
  { 
    icon: '⚡', 
    title: '번개같은 학습 속도', 
    description: '평균 7.77초 내 분석 완료로 즉시 바다 결과 확인',
    gradient: 'from-indigo-600 to-cyan-600',
    bgGradient: 'from-slate-900/60 to-slate-800/80'
  },
  { 
    icon: '👁️', 
    title: '심해의 정확도', 
    description: '100% 정확도로 신뢰할 수 있는 바다 학습 결과',
    gradient: 'from-blue-600 to-cyan-600',
    bgGradient: 'from-indigo-900/70 to-blue-900/80'
  },
  { 
    icon: '🌊', 
    title: '상세한 바다 분석', 
    description: '문제별 심해 분석과 학습 성장 패턴 리포트 제공',
    gradient: 'from-cyan-600 to-teal-600',
    bgGradient: 'from-blue-900/60 to-slate-800/70'
  },
  { 
    icon: '🔒', 
    title: '심해의 보안', 
    description: '학습정보 보호와 데이터 바다 암호화로 안전한 심해 서비스',
    gradient: 'from-indigo-600 to-blue-600',
    bgGradient: 'from-slate-800/70 to-indigo-900/60'
  }
];

export default function FeatureList() {
  const sectionRef = useRef(null);
  const cardsRef = useRef([]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // 🌊 카드들 스태거 애니메이션 (심해 느낌으로)
      gsap.fromTo(cardsRef.current, 
        {
          y: 100,
          opacity: 0,
          scale: 0.6,
          rotationY: -45,
          filter: "blur(10px)"
        },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          rotationY: 0,
          filter: "blur(0px)",
          duration: 1.0,
          stagger: 0.2,
          ease: 'power4.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            end: 'bottom 20%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // 🌊 개별 카드 호버 애니메이션 (심해 효과)
      cardsRef.current.forEach((card) => {
        if (card) {
          card.addEventListener('mouseenter', () => {
            gsap.to(card, {
              y: -16,
              scale: 1.06,
              rotationX: 8,
              duration: 0.5,
              ease: "power3.out"
            });
          });

          card.addEventListener('mouseleave', () => {
            gsap.to(card, {
              y: 0,
              scale: 1,
              rotationX: 0,
              duration: 0.5,
              ease: "power3.out"
            });
          });
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-br from-slate-900 via-indigo-900 to-blue-950 relative overflow-hidden">
      {/* 🌊 심해 배경 효과 */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900/90 via-indigo-900/70 to-blue-900/80"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_75%,rgba(30,64,175,0.2)_0%,rgba(15,23,42,0.8)_50%,rgba(30,58,138,0.15)_80%)]"></div>
      
      {/* 🐠 떠다니는 심해 파티클들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-1/4 w-3 h-3 bg-blue-400/40 rounded-full animate-pulse shadow-lg shadow-blue-500/50"></div>
        <div className="absolute top-40 right-1/3 w-2 h-2 bg-cyan-400/50 rounded-full animate-pulse delay-700 shadow-lg shadow-cyan-500/50"></div>
        <div className="absolute bottom-32 left-1/2 w-2 h-2 bg-indigo-400/40 rounded-full animate-pulse delay-1000 shadow-lg shadow-indigo-500/50"></div>
        <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-teal-500/50 rounded-full animate-pulse delay-500 shadow-lg shadow-teal-500/50"></div>
        <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-blue-300/40 rounded-full animate-pulse delay-1500 shadow-lg shadow-blue-400/50"></div>
        <div className="absolute top-1/3 left-1/5 w-2 h-2 bg-cyan-400/50 rounded-full animate-pulse delay-300 shadow-lg shadow-cyan-500/50"></div>
      </div>

      {/* 🐙 장식 산고들 */}
      <div className="absolute top-16 right-20 opacity-20">
        <svg width="70" height="100" viewBox="0 0 70 100">
          <path d="M35 100 L35 50 M18 50 Q35 35 52 50 M13 45 Q35 30 57 45" stroke="#3B82F6" strokeWidth="2" fill="none"/>
          <circle cx="35" cy="40" r="7" fill="#1E40AF"/>
          <path d="M28 40 Q20 30 10 35 M42 40 Q50 30 60 35" stroke="#2563EB" strokeWidth="2" fill="none"/>
        </svg>
      </div>
      <div className="absolute bottom-24 left-16 opacity-25">
        <svg width="50" height="70" viewBox="0 0 50 70">
          <path d="M25 70 L25 35 M13 35 Q25 25 37 35" stroke="#0891b2" strokeWidth="2" fill="none"/>
          <circle cx="25" cy="30" r="5" fill="#0891b2"/>
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* 🌊 헤더 */}
        <div className="text-center mb-16" data-aos="fade-up">
          <div className="inline-flex items-center space-x-3 bg-slate-800/30 backdrop-blur-md border border-slate-700/50 text-cyan-300 px-6 py-3 rounded-full text-sm font-bold mb-6 shadow-lg shadow-indigo-500/30 hover:shadow-xl hover:shadow-cyan-500/50 transition-all duration-300 hover:scale-105">
            <span>🌊</span>
            <span>심해 특징</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-cyan-300 mb-6 drop-shadow-2xl">
            왜 
            <span className="bg-gradient-to-r from-cyan-300 to-blue-300 bg-clip-text text-transparent"> OceanCheck</span>을 
            <br className="hidden sm:block" />
            선택해야 할까요?
          </h2>
          <p className="text-xl text-cyan-200 max-w-3xl mx-auto leading-relaxed drop-shadow-lg backdrop-blur-sm bg-slate-800/30 rounded-2xl p-6 border border-slate-700/50">
            최고의 바다 기술력과 심해 사용자 경험을 바탕으로 한 <br className="hidden md:block" />
            차별화된 자동 학습 지원 서비스를 제공합니다
          </p>
        </div>

        {/* 🌊 기능 카드 그리드 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              ref={el => cardsRef.current[index] = el}
              className={`relative group p-8 rounded-3xl bg-gradient-to-br ${feature.bgGradient} backdrop-blur-md border border-slate-700/50 shadow-2xl shadow-indigo-500/20 hover:shadow-3xl hover:shadow-cyan-500/40 transition-all duration-500 cursor-pointer overflow-hidden`}
            >
              {/* 🐠 배경 글로우 효과 */}
              <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-20 transition-opacity duration-500 rounded-3xl`}></div>
              
              {/* 🌊 추가 심해 레이어 */}
              <div className="absolute inset-0 bg-gradient-to-br from-slate-800/80 via-indigo-900/40 to-blue-900/50 rounded-3xl"></div>
              
              {/* 🐠 바다 파티클들 */}
              <div className="absolute top-4 right-4 w-3 h-3 bg-blue-400/50 rounded-full animate-pulse shadow-lg shadow-blue-500/50"></div>
              <div className="absolute bottom-6 left-6 w-2 h-2 bg-cyan-400/60 rounded-full animate-ping shadow-lg shadow-cyan-500/50"></div>
              <div className="absolute top-1/2 right-8 w-2 h-2 bg-indigo-400/50 rounded-full animate-bounce shadow-lg shadow-indigo-500/50"></div>
              
              {/* 🌊 아이콘 */}
              <div className="relative z-10 mb-6">
                <div className={`inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br ${feature.gradient} rounded-3xl text-cyan-100 text-3xl shadow-2xl shadow-indigo-500/50 group-hover:shadow-3xl group-hover:shadow-cyan-500/70 transition-all duration-300 group-hover:scale-110 group-hover:rotate-12 border-2 border-slate-700/50`}>
                  {feature.icon}
                </div>
              </div>
              
              {/* 🌊 콘텐츠 */}
              <div className="relative z-10">
                <h3 className="text-xl font-bold text-cyan-300 mb-3 group-hover:text-cyan-100 transition-colors duration-300 drop-shadow-lg">
                  {feature.title}
                </h3>
                
                <p className="text-cyan-200 text-sm leading-relaxed group-hover:text-cyan-100 transition-colors duration-300 drop-shadow-sm">
                  {feature.description}
                </p>
              </div>

              {/* 🌊 호버 시 나타나는 바다 액센트 */}
              <div className={`absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r ${feature.gradient} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left shadow-lg shadow-indigo-500/50`}></div>
              
              {/* 🐙 추가 심해 효과 */}
              <div className="absolute inset-0 rounded-3xl border border-slate-700/50 group-hover:border-cyan-400/60 transition-colors duration-300"></div>
              
              {/* 🐠 중앙 바다 효과 */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-28 h-28 bg-gradient-radial from-cyan-300/15 via-blue-300/10 to-transparent rounded-full blur-3xl opacity-0 group-hover:opacity-50 transition-opacity duration-500"></div>
            </div>
          ))}
        </div>

        {/* 🌊 추가 통계 섹션 */}
        <div className="mt-20 pt-16 border-t border-slate-700/50" data-aos="fade-up" data-aos-delay="400">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-cyan-300 mb-4 drop-shadow-lg">
              <span className="bg-gradient-to-r from-cyan-300 to-blue-300 bg-clip-text text-transparent">실시간</span> 
              심해 현황
            </h3>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: '88.8K+', label: '누적 바다수', icon: '🌊', color: 'indigo' },
              { number: '100%', label: '심해 정확도', icon: '👁️', color: 'cyan' },
              { number: '7.77초', label: '평균 분석시간', icon: '⚡', color: 'blue' },
              { number: '999+', label: '활성 바다자', icon: '🐠', color: 'teal' }
            ].map((stat, index) => (
              <div key={index} className="text-center group">
                <div className={`inline-flex items-center justify-center w-16 h-16 bg-slate-800/60 backdrop-blur-md border border-slate-700/50 rounded-2xl mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-indigo-500/30 group-hover:shadow-xl group-hover:shadow-cyan-500/50`}>
                  <span className="text-3xl drop-shadow-lg">{stat.icon}</span>
                </div>
                <div className={`text-3xl font-black text-cyan-300 mb-2 group-hover:scale-110 transition-transform duration-300 drop-shadow-lg`}>
                  {stat.number}
                </div>
                <div className="text-sm text-cyan-200 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>

          {/* 🌊 추가 바다한 장식 */}
          <div className="mt-16 flex justify-center">
            <div className="bg-slate-800/30 backdrop-blur-md px-8 py-6 rounded-3xl border border-slate-700/50 shadow-2xl shadow-indigo-500/30 max-w-md">
              <div className="text-center">
                <div className="text-cyan-300 font-bold text-lg mb-2 drop-shadow-sm">🌊 심해의 성장</div>
                <div className="text-cyan-200 text-sm">매일 새로운 바다자들이 합류하고 있습니다</div>
                <div className="mt-3 flex justify-center space-x-4">
                  <div className="text-center bg-slate-800/50 backdrop-blur-sm rounded-xl p-3 border border-slate-700/50">
                    <div className="text-cyan-300 font-bold">+77</div>
                    <div className="text-xs text-cyan-400/70">오늘</div>
                  </div>
                  <div className="text-center bg-slate-800/50 backdrop-blur-sm rounded-xl p-3 border border-slate-700/50">
                    <div className="text-cyan-300 font-bold">+999</div>
                    <div className="text-xs text-cyan-400/70">이번 달</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 🌊 하단 심해 효과 */}
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-slate-900/60 to-transparent pointer-events-none backdrop-blur-sm"></div>
      
      <style jsx>{`
        .bg-gradient-radial {
          background: radial-gradient(circle, var(--tw-gradient-stops));
        }
        
        .shadow-3xl {
          box-shadow: 0 35px 60px -12px rgba(0, 0, 0, 0.25);
        }
      `}</style>
    </section>
  );
}